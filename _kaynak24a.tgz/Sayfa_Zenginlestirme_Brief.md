# Hizmet sayfaları — zenginleştirme brief'i

12 Ağustos 2026 · Developer → Business, Marketing, ve tasarım tarafı

Bugün elimizde tek bir hizmet sayfası var: **AI Readiness Audit**. Diğer beşi
hâlâ ana sayfadaki katalog satırı. Sonuç ekranındaki üç bandın butonu da
oraya gidiyor, çünkü gidecek sayfa yok.

Bu belge üç ayrı şey istiyor ve karıştırılmamalı: **Business metni yazar,
Marketing dili ve aramayı belirler, tasarım sayfanın nasıl göründüğüne karar
verir.** Developer yapıyı kurar ve üçünü birleştirir.

---

## 1. Business'tan istenen

Her hizmet için **altı blok**. Uzun olmasın; her biri iki-üç cümle.

| Blok | Ne cevaplıyor | Uzunluk |
|---|---|---|
| **Kim için** | Bu hizmet hangi durumdaki şirkete uygun, hangisine değil | 2 cümle |
| **Ne yapıyoruz** | Somut olarak ne teslim ediliyor | 3-4 cümle |
| **Nasıl işliyor** | Adım adım, gün ya da hafta olarak | 4-6 madde |
| **Ne teslim alıyorsunuz** | Elle tutulur çıktı: rapor, yol haritası, oturum | 3-5 madde |
| **Ne zaman uygun değil** | Dürüst eleme. Bu bölüm sayfanın en güvenilir yeri olur | 2-3 cümle |
| **Sonraki adım** | Görüşme mi, teklif mi | 1 cümle |

**Fiyat yok.** K50 duruyor: sitede rakam, aralık ya da "şu kadardan başlar"
geçmez.

**Hizmet adları İngilizce kalır** (Business K34): AI Readiness Audit, Discovery
Sprint, Transformation Retainer, Advisory Board Seat, Executive Workshop,
Keynote & Konuşmalar. Türkçe sayfada da çevrilmez.

**Öncelik sırası** — sonuç ekranındaki üç bandın gideceği yer olduğu için:

1. Discovery Sprint (50–69 bandı)
2. Transformation Retainer (70–84 bandı)
3. Advisory Board Seat (85+ bandı)
4. Executive Workshop
5. Keynote & Konuşmalar

Ayrıca **AI Readiness Audit** için: mevcut metin doğru ama ince. Yukarıdaki altı
bloğa göre genişletilmesi lazım, özellikle "ne zaman uygun değil" hiç yok.

---

## 2. Marketing'ten istenen

**Her sayfa için bir arama sorusu kümesi.** Şirketin gerçekten aradığı cümleler,
anahtar kelime listesi değil. Örnek biçim:

> *Discovery Sprint* → "AI yol haritası nasıl çıkarılır", "AI projesine
> nereden başlanır", "AI danışmanlık süreci nasıl işler"

Her sayfa için **üç ila beş soru** yeter. Bunlar sayfadaki ara başlıklara ve
sayfanın sonundaki sık sorulanlara dönüşecek — yani metnin içine sıkıştırılan
kelimeler değil, sayfanın cevapladığı gerçek sorular.

Ayrıca her sayfa için:

- **`<title>`** — 60 karakteri geçmeyen
- **Meta açıklama** — 155 karakter, iki dilde
- **Hangi blog yazısı hangi sayfaya bağlanmalı** — dört yazımız var, her hizmet
  sayfası en az birine bağlanmalı ve o yazı da sayfaya geri bağlanmalı

Son madde önemli ve şu an hiç yok: **sitede iç bağlantı yok denecek kadar az.**
Hizmet sayfaları ile blog birbirini beslemiyor.

---

## 3. Tasarım tarafına verilecek prompt

Aşağıdakini olduğu gibi kullanabilirsin.

> Bir danışmanlık şirketi için hizmet sayfası tasarla. Şirket AI dönüşümünün
> insan tarafıyla ilgileniyor: strateji, sahiplik, kapasite. Müşteri, orta
> ölçekli şirketlerin CEO'su ya da genel müdürü — teknik değil, sabırsız,
> satılmaktan hoşlanmıyor.
>
> **Ton:** sakin, kanıtlı, abartısız. Vaat değil, ne yapıldığının tarifi.
> Ünlem yok, rozet yok, "devrim" yok. Sayfanın en ikna edici yeri "bu hizmet
> şuna uygun değil" diyen bölüm olmalı.
>
> **Renkler:** yüzey beyaz, arka plan #F1F0EC, metin #1A1815, tek vurgu rengi
> terracotta #B84C2E. Koyu zemin yok. Vurgu rengi yalnızca bağlantılarda,
> butonlarda ve tek bir ince çizgide kullanılır — dolgu olarak değil.
>
> **Tipografi:** başlıklar serif (Cormorant Garamond), gövde sans (Inter).
> Gövde 17px civarı, satır aralığı geniş. Uzun metin okunacak, taranmayacak.
>
> **Yapı, bu sırayla:**
> 1. Başlık ve tek cümlelik tanım
> 2. Kim için — ve kim için değil
> 3. Ne yapıyoruz
> 4. Nasıl işliyor: numaralı adımlar, Roma rakamlarıyla
> 5. Ne teslim alıyorsunuz
> 6. Bu hizmet ne zaman uygun değil
> 7. İlgili yazılar — bloga üç bağlantı
> 8. Sık sorulanlar — üç ila beş soru, açılır kapanır
> 9. Tek bir çağrı: teklif iste ya da görüşme ayarla
>
> **Kısıtlar:** fiyat yok. Stok fotoğraf yok. İkon kalabalığı yok. Sayfa
> 1136 piksellik tek bir kolonda, iki yanı boşluk. Mobilde tek kolon ve her
> dokunma hedefi en az 44 piksel.
>
> Masaüstü ve mobil için birer ekran ver.

---

## 4. Developer'da kalan

Metin ve tasarım geldiğinde bende olan iş:

- Şablonu genişletmek: sık sorulanlar bölümü, ilgili yazılar bölümü, açılır
  kapanır başlıklar
- **FAQ yapısal verisi** (schema.org) — sık sorulanlar arama sonucunda
  görünsün diye
- Her hizmet için ayrı sayfa üretmek, `build.py` zaten bunu yapıyor
- Sonuç ekranındaki üç bandın butonunu kendi sayfasına bağlamak
- Blog yazılarından hizmet sayfalarına, hizmet sayfalarından bloga çift yönlü
  bağlantı
- `check-links` ve `check-service` için yeni kontroller

Metin gelmeden hiçbiri başlayamaz. Tasarım gelmeden yapı kurulur ama görünüm
kurulmaz.

---

## 5. Sıra

1. **Business** altı bloğu Discovery Sprint için yazar — bir sayfa, örnek olsun
2. **Marketing** o sayfa için arama sorularını ve title/açıklamayı verir
3. **Tasarım** yukarıdaki promptla bir ekran çıkarır
4. Developer üçünü birleştirip **tek bir sayfa** kurar
5. O sayfa onaylanınca kalan dördü aynı kalıptan çıkar

Tek sayfayı önce bitirmek, altısını paralel yürütmekten hızlı. Kalıp
onaylanmadan beş sayfa yazdırmak, beş sayfayı iki kez yazdırmak demek.
