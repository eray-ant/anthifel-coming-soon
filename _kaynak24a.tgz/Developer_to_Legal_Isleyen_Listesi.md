# Developer → Legal · İşleyen listesi

**Yazan:** Developer · **İlk tarih:** 12 Ağustos 2026 · **Task:** `DEV-001`

> **Değişiklik · 16 Ağustos 2026**
> **Yayında mı:** Evet — bu dosyadaki her satır `dist/preview/` içinde çalışan
> koddan okundu, ve işleyen listesinin kendisi `legal.py` içinde duruyor.
> **Services ile hizalı mı:** Evet. Bu dosya hizmet anlatısına dokunmuyor;
> yalnızca hangi işleyene hangi verinin ulaştığını söylüyor.
> **Ne değişti:** Google Analytics 4 tabloya eklendi (15 Ağustos'ta kuruldu, bu
> dosya 12 Ağustos'ta yazılmıştı — Legal'in sorduğu tutarsızlık buydu). Ayrıca
> LGL-037'nin cevabı, çerez bandının ne yaptığı ve onayınıza sunulan Türkçe
> künye metni eklendi.

Bu, Legal'in 3 Ağustos'ta istediği işleyen listesidir. Koddan okundu, hafızadan
değil: aşağıdaki her satır `dist/preview/` içindeki dosyaların **gerçekten
yaptığı** bir şeydir.

**Önceki teslim geçersizdir.** 10 Ağustos'ta bir liste verilmişti ve 12 Ağustos
akşamı dört satırı yanlıştı. Ne olduğu bu dosyanın sonunda yazıyor, çünkü
listenin kendisinden çok o kısım işe yarıyor.

---

## Yayında olan işleyenler

| İşleyen | Ne yapar | Hangi kişisel veri ulaşır | Nerede barındırılır |
|---|---|---|---|
| **DigitalOcean App Platform** | Web sitesi barındırma. Bütün sayfaları sunar | Sunucu erişim kayıtlarında IP adresi ve tarayıcı bilgisi | **Birleşik Krallık — Londra (LON1)**. 12 Ağustos'ta Frankfurt'tan taşındı |
| **Squarespace Domains** | `anthifel.com` tescili | Tescil sahibi iletişim bilgileri. **WHOIS gizliliği açık**, yani herkese açık değil | Squarespace, Inc. — ABD |
| **Resend** | Size gönderdiğimiz **her** e-postayı gönderir: giriş kodu, test sonucu, ve bizim kendi kopyamız | E-posta adresiniz; sonuç e-postasında ayrıca test sonucunuz, bandınız ve beş boyut puanınız | Resend, Inc. — ABD şirketi. Gönderim alan adımız **İrlanda (eu-west-1)** bölgesinde tanımlı |
| **Google — Apps Script ve E-Tablolar** | Test formunu alır ve arkasındaki kaydı tutar | E-posta adresiniz, rıza kaydınız, ve tamamlanmış bir testin sonucu ile bandı. **Tek tek cevaplarınız asla** | Google. Bölge Workspace sürümüne bağlı; **bizim sürümümüz (Business Starter) bu ayarı sunmuyor** |
| **Google — Workspace** | Kendi posta kutularımız, `privacy@` dahil | Bize yazdığınız her şey | Yukarıdaki gibi |
| **Google — Takvim randevu takvimi** | Her görüşme butonunun arkasındaki randevu penceresi | Pencereyi **açtığınız anda** IP adresi, tarayıcı bilgisi ve Google çerezleri; sonrasında Google'ın kendi formuna girdikleriniz | Google. Bölge seçimi sunulmuyor |
| **Google Analytics 4** | Ziyaret sayısını sayar ve hangi sayfaların okunduğunu söyler. **Yalnızca siz kabul ettikten sonra yüklenir, reddederseniz hiç yüklenmez** | IP adresiniz — Google saklamadan önce kısaltır —, tarayıcı ve cihaz bilgisi, açtığınız sayfalar ve cihazınızdaki bir çerezde duran rastgele bir tanımlayıcı. **Adınız ve e-posta adresiniz asla** | Google. Veri size en yakın bölgedeki sunucularda toplanır, **ABD'de işlenir** |
| **Supabase** | İç panelimizin veritabanı. **Ziyaretçi verisi buraya ulaşmaz** | Yalnızca çalışan hesaplarının e-posta adresleri | Birleşik Krallık — Londra |

**Bu liste `legal.py` içinde kodda duruyor** ve gizlilik sayfası build sırasında
oradan üretiliyor. Yani sayfa ile liste ayrışamaz. Legal'in metnindeki
`[İŞLEYEN LİSTESİ]` işareti bununla doluyor.

---

## Legal'in bilmesi gereken dört şey

**1. Resend yeni ve en hassas olanı.** 12 Ağustos'tan beri yayında. Alıcının
adresini **ve mailin gövdesini** görüyor — sonuç mailinde skor, bant ve beş
boyut puanı var. Google'a taşınmadı, Google'ın yerine geçti: mail artık Gmail'den
çıkmıyor.

Neden değiştirdik: `anthifel.com` iki haftalık ve gönderim itibarı yok. Gmail
maillerimizi kabul edip sessizce siliyordu — spam'e bile koymadan. Yapılandırmada
hata yoktu; SPF, DKIM, DMARC ve MX'in dördü de doğru. İtibar yapılandırılabilen
bir şey değil.

**2. Veri bölgesi üzerinde kontrolümüz yok.** Workspace Business Starter veri
bölgesi ayarını sunmuyor. Yükseltmeden değişmez. Bu bir eksik değil, bir olgu —
metnin buna göre yazılması gerekiyor.

**3. Üç işleyen ABD şirketi:** Squarespace, Resend ve Google. Resend'in gönderim
altyapısı İrlanda'da, ama şirket ABD'de.

**4. Kaldırılanlar.** Şu an listede **olmayan** ve daha önce konuşulmuş iki
şey: **reCAPTCHA** (hiç kurulmadı, 10 Ağustos'ta vazgeçildi) ve **Calendly**
(kurulmadı, yerine Google Takvim geçti). İkisi de metne girmemeli.

---

## Çerez tablosu — bir düzeltme

Bot kontrolü değişti ve çerez tablosundaki satır da değişti.

Eski metin, kontrolün *"tamamen tarayıcınızda çalıştığını ve hiç kimseye
ulaşmadığını"* söylüyordu. Bu, 10 Ağustos'taki proof-of-work için doğruydu.
**Artık doğru değil:** kontrol size e-posta ile gönderdiğimiz bir kod, ve o kodu
üretmek için kendi sunucumuza istek gidiyor.

Ziyaretçi açısından değişmeyen şey şu, ve metinde duran da bu: **çerez
yerleşmiyor ve cihazınızda hiçbir şey saklanmıyor.** Kodun kendisi bizde on beş
dakika duruyor, sonra siliniyor.

---

## Önceki teslim neden geçersizdi

10 Ağustos'ta liste verildi ve tamamlandı diye bildirildi. 12 Ağustos akşamı
dört satırı yanlıştı:

| Satır | 10 Ağustos'ta ne diyordu | Gerçek |
|---|---|---|
| Resend | Yoktu | Artık gönderdiğimiz her maili o gönderiyor |
| Kayıt kuruluşu | "Kayıt kuruluşuyla teyit edilecek" | Squarespace, WHOIS gizliliği **açık** |
| Apps Script | "sonucu e-posta ile gönderir" | Artık göndermiyor; Resend gönderiyor |
| Çerez tablosu | Bot kontrolü "hiç kimseye ulaşmaz" | Ulaşıyor — kendi endpoint'imize |

Hiçbiri o günkü dikkatsizlik değildi. Bir işleyen listesi, tarif ettiği şey hâlâ
inşa edilirken tam olarak bunu yapar. Alınan ders, listenin **kodun içinde,
gizlilik sayfasını üreten satırların yanında** durması: ayrı bir belgede dursaydı
bugün de eskimiş olurdu ve kimse fark etmezdi.

**Bu yüzden bundan sonra kural şu:** işleyen listesi değiştiğinde gizlilik
sayfası aynı build'de değişir, ve `check-legal.js` her işleyeni **adıyla** arar —
sayıyla değil. Liste ancak *o* liste ise işe yarar.

---

## LGL-037 — cevap: **sıfır**

Soru: Apps Script'in arkasındaki tabloda, bizim test girdilerimiz dışında
gerçek bir kişinin e-posta adresi ve rıza kaydı duruyor mu.

**Duran kayıt yok.** Tabloyu 16 Ağustos'ta açıp saydık. Tamamı şu:

| Sekme | Satır | Ne var |
|---|---|---|
| `Assessment` | **1** | `dengizeray@gmail.com` · 12 Ağustos 2026 17:48 · sayfa `https://anthifel.com/preview/?form=live` · skor 38, bant 30–49. Bu Developer'ın kendi testidir. |
| `Quotes` | **0** | Sekme hiç oluşmamış. Teklif formundan tek kayıt gelmemiş. |
| Okuma listesi | **0** | Aşağıya bakınız — bu formun yazacağı bir yer yok. |

Yani **ayrılacak bir şey yok**, düzeltilmiş form doğrudan devreye girebilir.

**Bunu söylerken bir şeyi de söylememiz gerekiyor.** Okuma listesi formunun
kaydı sıfır olmasının sebebi ilgi görmemesi değil: form gönderdiği paketi
sunucunun tanımadığı bir biçimde yolluyor (`source: 'reading-list'`), sunucu da
onu hiçbir işleyiciye eşleştiremeyip reddediyor. Ziyaretçi hata mesajı görüyor,
yani kimse sessizce kaybolmuyor — ama **pazarlama listesi diye bir liste bugün
teknik olarak yok.** Bu Developer'ın açık işi ve lansmandan önce kapanacak.

Sizin açınızdan iyi tarafı şu: liste sıfırdan kurulacağı için **pazarlama izni
ile gizlilik onayını ayrı kutulara** koymak bir düzeltme değil, doğrudan ilk
tasarım olacak. Dört maddelik metninize gerek kalmadan.

---

## GA4 — hangi belge güncel

**Güncel olan bu dosyadır, 12 Ağustos tarihli hâli değil.** Sıralama şöyleydi:
işleyen listesi 12 Ağustos'ta yazıldı, GA4 ise **15 Ağustos akşamı** kuruldu.
Aradaki üç gün, sizin gördüğünüz tutarsızlığın tamamı. Yukarıdaki tabloya
eklendi, `legal.py` içindeki liste de aynı satırı taşıyor — gizlilik sayfası o
listeden üretildiği için ikisi ayrışamıyor.

Ölçüm kimliği: `G-W376XEN94E`. Çerez tablosunda `anthifel_consent`, `_ga` ve
`_ga_W376XEN94E` duruyor, üçü de **"zorunlu değil"** olarak sınıflanmış.

**Banner onaya kadar GA'yı bloke ediyor mu: evet — ve "reddedilmiş modda yüklü"
şeklinde değil, hiç yüklenmemiş şekilde.** Ayrım önemli olduğu için açıyoruz:
sayfada durup "consent mode: denied" ile bekleyen bir etiket, Google'a giden ve
IP adresi taşıyan bir istektir. Bizde o istek hiç kurulmuyor.

Ne yaptığı, sırasıyla:

1. Cevap verilmeden önce Google'a **tek bir istek gitmiyor**, cihaza **tek bir
   çerez yazılmıyor**. Sayfanın kaynağında `googletagmanager` geçmiyor.
2. **Hayır** dendiğinde: karar hatırlanıyor, sonraki ziyaretlerde soru
   sorulmuyor ve hâlâ hiçbir şey yüklenmiyor. Varsa eski `_ga` çerezleri
   siliniyor.
3. **Evet** dendiğinde, ve ancak o zaman, `gtag` yükleniyor.
4. Cevap **altı ay** sonra düşüyor ve soru yeniden soruluyor. Süresi geçmiş bir
   cevap "hayır" değil, "cevapsız" sayılıyor.
5. Cevap çerezde değil, `localStorage`'da tutuluyor: çerez izni istemek için
   çerez yerleştirmek doğru olmazdı.
6. Footer'daki Çerezler bağlantısının yanındaki küçük işaret soruyu yeniden
   açıyor. Onayı geri almak, vermek kadar kolay olmak zorunda.

Bunların hepsi **her build'de 48 kontrolle** ölçülüyor (`check-consent.js`), ve
kontroller yayın sürümünde çalışıyor — önizlemede ölçüm kimliği hiç yok, o
yüzden orada "evet" yolu kanıtlanamaz.

**Sizin bilmenizi istediğimiz bir tasarım kararı var.** CEO 15 Ağustos'ta
bandın düzenini değiştirdi: "Kabul ediyorum" çerçeveli bir buton, "Hayır,
teşekkürler" onun yanında düz yazı. ICO'nun rehberi kabul ile reddin **eşit
belirginlikte** olmasını istiyor ve buton-yanında-yazı tam olarak eleştirdiği
kalıp. Savunulabilir tarafı şu, ve testler bunları ölçüyor: ikisi de aynı punto,
aynı beyaz, aynı satırda, tek tık, ikisi de dokunma eşiğinin üstünde, ikisi de
kaydırmadan görünüyor. Aralarındaki tek fark bir çerçeve. **Bunu onaylamak ya da
reddetmek sizin işiniz** — yazıyoruz ki karar sizin bilginiz dahilinde olsun.

---

## Türkçe künye metni — onayınıza

İstediğiniz metin bu. Bugüne kadar gitmemiş olmasının sebebi, üç alanın hâlâ
sizde bekliyor olması — ama **metnin kendisi o üç alan olmadan da onaylanabilir**,
ve onaylanırsa değerler geldiği gün yerine oturur.

Nerede duracağı: yeni bir sayfa **değil**. Gizlilik ve Kullanım Şartları
sayfalarının başındaki şirket bloğu olarak, footer'daki tek satırlık tescil
ibaresiyle birlikte. (Yeni sayfa CEO onayı gerektiriyor; gerekiyorsa söyleyin,
ayrıca soralım.)

> **Künye**
>
> Bu web sitesi **Anthifel Ltd** tarafından işletilmektedir.
> İngiltere ve Galler'de kayıtlı şirket.
> Şirket numarası: `[ŞİRKET NUMARASI]`
> Kayıtlı adres: `[KAYITLI ADRES]`
> ICO kayıt numarası: `[ICO KAYIT NUMARASI]`
> İletişim: `hello@anthifel.com` · Gizlilik konuları: `privacy@anthifel.com`

Footer'da duran tek satır, karşılaştırma için:
**"© 2026 Anthifel Ltd · İngiltere ve Galler'de tescillidir"**

İki not:

1. Köşeli parantezli üç alan doldurulmadan `privacy.html` ve `terms.html`
   **yayın sürümüne yazılmıyor** — build bunu reddediyor. Yani künye eksik
   değerle yayına çıkamaz, unutulması mümkün değil.
2. Gizlilik metniniz şirketin **20 Ağustos 2026**'da kurulacağını söylüyor ve
   About sayfası artık bu tarihi aynen yazıyor. Künyedeki tescil ibaresi de o
   günden itibaren doğru olur.

---

## Legal'den beklenen

1. Bu listeyi onaylamak ya da düzeltmek
2. Resend için işleyen sözleşmesi gerekip gerekmediğini söylemek
3. Veri bölgesi kontrolümüzün olmamasının metinde nasıl ifade edileceğini vermek
4. Hâlâ bekleyen üç bilgi: **şirket numarası, kayıtlı adres, ICO kayıt
   numarası** — bunlar girilmeden `privacy.html` ve `terms.html` yayın sürümüne
   yazılmıyor
5. Saklama süresini **gün olarak** vermek (`PURGE_AFTER_DAYS`, şu an 730)
6. **Yeni:** yukarıdaki **Türkçe künye metnini** onaylamak ya da düzeltmek
7. **Yeni:** çerez bandının düzenine — çerçeveli kabul, yanında düz yazı ret —
   hukuki olarak katılıp katılmadığınızı söylemek
