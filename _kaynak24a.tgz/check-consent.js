/**
 * check-consent.js — Anthifel
 *
 * One rule, tested from every angle it can be broken from: nothing Google-owned
 * is fetched, and no cookie is set, until a visitor has said yes.
 *
 * Not "loaded with consent mode denied" — not loaded. A tag sitting on the page
 * in a denied state is still a request to Google carrying an IP address, and
 * the privacy notice we publish says nothing is loaded until you accept. A
 * claim in a notice has to be true in the code, and this is the file that keeps
 * it true when somebody later pastes the standard snippet into the head because
 * that is what the documentation shows.
 *
 * Run against production: the preview build carries no measurement ID at all,
 * so it cannot prove the yes path.
 *
 *   node check-consent.js [dist/production]
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const DIR = path.resolve(process.argv[2] || 'dist/production');
let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${x ? '  → ' + x : ''}`)); };
const GOOGLE = /googletagmanager|google-analytics|analytics\.google|doubleclick/i;

const PAGES = ['index.html', 'about.html', 'ai-readiness-audit.html', 'cookies.html'];

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  console.log('\n— the tag is not in the page —');
  for (const f of PAGES) {
    const src = fs.readFileSync(path.join(DIR, f), 'utf-8');
    /* The snippet Google hands you is a <script src> in the head. If anyone
       pastes it in, this fails on every page at once, which is the point. */
    ok(`${f}: no gtag script tag written into the markup`,
       !/<script[^>]+googletagmanager/i.test(src),
       (src.match(/<script[^>]*googletagmanager[^>]*>/i) || [''])[0]);
  }

  console.log('\n— before an answer —');
  for (const f of PAGES) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const out = [];
    page.on('request', r => { if (GOOGLE.test(r.url())) out.push(r.url()); });
    await page.goto('file://' + path.join(DIR, f), { waitUntil: 'load' });
    await page.waitForTimeout(450);
    ok(`${f}: the question is asked`, await page.isVisible('#cbar'));
    ok(`${f}: nothing is fetched from Google`, out.length === 0, out.join(' '));
    ok(`${f}: no cookie is set`, (await page.context().cookies()).length === 0,
       JSON.stringify(await page.context().cookies()));
    await page.close();
  }

  console.log('\n— the two answers —');
  {
    /* One frame, two answers, and only the order differs.
       15 August: the CEO set the order — accept first, decline second.
       19 August: Legal ruled on the frame (LGL-057) and it is a condition of
       publishing the three legal pages. The version in between dressed the
       decline as plain text beside the button; Legal accepted every property
       measured below and objected to the border alone, because PECR s.6 asks
       that consent be freely given and a border is weight rather than order.
       Everything here is measured rather than reviewed, because this is the
       kind of thing that drifts one padding value at a time with nobody
       deciding to. */
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await page.goto('file://' + path.join(DIR, 'index.html'), { waitUntil: 'load' });
    await page.waitForTimeout(400);
    const m = await page.evaluate(() => {
      const box = el => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
        return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width),
                 h: Math.round(r.height), color: s.color, weight: s.fontWeight,
                 size: s.fontSize, opacity: s.opacity, vis: s.visibility,
                 bg: s.backgroundColor, border: s.border,
                 dec: s.textDecorationLine }; };
      const act = [...document.querySelectorAll('.cbar-act > *')].map(e => e.id || e.tagName);
      return { yes: box(document.getElementById('cYes')),
               no: box(document.getElementById('cNo')),
               order: act, vh: innerHeight };
    });
    ok('the accept is first and the decline second, then the link',
       m.order[0] === 'cYes' && m.order[1] === 'cNo' && m.order[2] === 'A', m.order.join(' '));
    ok('the same frame — LGL-057', m.yes.border === m.no.border,
       `${m.yes.border} vs ${m.no.border}`);
    ok('the same width', m.yes.w === m.no.w, `${m.yes.w} vs ${m.no.w}`);
    ok('the same background', m.yes.bg === m.no.bg, `${m.yes.bg} vs ${m.no.bg}`);
    ok('the same colour — the decline is not greyed out', m.yes.color === m.no.color,
       `${m.yes.color} vs ${m.no.color}`);
    ok('the same type, at the same size', m.yes.weight === m.no.weight && m.yes.size === m.no.size,
       JSON.stringify({ yes: m.yes.size + '/' + m.yes.weight, no: m.no.size + '/' + m.no.weight }));
    ok('the same height', m.yes.h === m.no.h, JSON.stringify(m));
    ok('side by side on one line', Math.abs(m.yes.y - m.no.y) <= 2, `${m.yes.y} vs ${m.no.y}`);
    ok('the decline is not faded', Number(m.no.opacity) === 1 && m.no.vis === 'visible',
       `${m.no.opacity} ${m.no.vis}`);
    ok('both clear the 44px touch floor', m.yes.h >= 44 && m.no.h >= 44, JSON.stringify(m));
    ok('both are on screen without scrolling',
       m.yes.y + m.yes.h <= m.vh && m.no.y + m.no.h <= m.vh, JSON.stringify(m));
    /* One click each. A decline that opens a second panel is two, and two is
       the oldest trick in this particular book. */
    ok('the decline answers on its own — no second screen',
       await page.evaluate(() => {
         document.getElementById('cNo').click();
         return document.getElementById('cbar').hidden === true &&
                (JSON.parse(localStorage.getItem('anthifel_consent') || '{}').ok === false);
       }));
    await page.close();
  }

  console.log('\n— no —');
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const out = [];
    page.on('request', r => { if (GOOGLE.test(r.url())) out.push(r.url()); });
    await page.goto('file://' + path.join(DIR, 'index.html'), { waitUntil: 'load' });
    await page.waitForTimeout(350);
    await page.click('#cNo');
    await page.waitForTimeout(500);
    ok('the band goes away', await page.isHidden('#cbar'));
    ok('still nothing from Google', out.length === 0, out.join(' '));
    const kept = await page.evaluate(() => localStorage.getItem('anthifel_consent'));
    ok('a no is remembered, the same as a yes', /"ok":false/.test(kept || ''), kept);
    await page.reload({ waitUntil: 'load' });
    await page.waitForTimeout(450);
    ok('and we do not ask again', await page.isHidden('#cbar'));
    ok('…and still load nothing', out.length === 0, out.join(' '));
    await page.close();
  }

  console.log('\n— yes —');
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const out = [];
    page.on('request', r => { if (GOOGLE.test(r.url())) out.push(r.url()); });
    await page.route(/googletagmanager|google-analytics/, r => r.fulfill({ status: 200, body: '' }));
    await page.goto('file://' + path.join(DIR, 'index.html'), { waitUntil: 'load' });
    await page.waitForTimeout(350);
    await page.click('#cYes');
    await page.waitForTimeout(700);
    ok('the tag loads, and only now', out.length >= 1, String(out.length));
    ok('…for our property', out.some(u => u.includes('G-W376XEN94E')), out.join(' '));
    ok('the band goes away', await page.isHidden('#cbar'));
    await page.reload({ waitUntil: 'load' });
    await page.waitForTimeout(600);
    ok('a yes is remembered too', await page.isHidden('#cbar'));
    await page.close();
  }

  console.log('\n— taking it back —');
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await page.goto('file://' + path.join(DIR, 'index.html'), { waitUntil: 'load' });
    await page.waitForTimeout(400);
    /* Consent has to be as easy to withdraw as it was to give. A policy page
       with no button on it is not that, so the footer's cookie link grows one. */
    const again = await page.$('.ftr .cbar-again');
    ok('the footer offers a way back', again !== null);
    /* It is a mark rather than a second worded link, which puts its whole name
       in aria-label. A control drawn as a picture with no name is a control
       only sighted people have. */
    const mark = await page.evaluate(() => {
      const b = document.querySelector('.ftr .cbar-again');
      if (!b) return null;
      const prev = b.previousElementSibling;
      const r = b.getBoundingClientRect();
      return { label: b.getAttribute('aria-label') || '', title: b.getAttribute('title') || '',
               svg: !!b.querySelector('svg'), text: b.textContent.trim(),
               after: prev ? (prev.getAttribute('href') || '') : '',
               h: Math.round(r.height), w: Math.round(r.width),
               en: b.hasAttribute('data-en') };
    });
    ok('…drawn, not spelled out a second time', mark && mark.svg && mark.text === '',
       JSON.stringify(mark));
    ok('…and it says its name to a screen reader',
       mark && /Cookie choice|Çerez tercihi/.test(mark.label) && mark.label === mark.title,
       mark && mark.label);
    ok('…standing against the Cookies link it belongs to',
       mark && /cookies\.html$/.test(mark.after), mark && mark.after);
    /* applyLang() writes textContent into anything carrying data-en. On a
       button whose content is a drawing, that replaces the drawing with a word
       the moment somebody switches language. */
    ok('…and carries no data-en, which would overwrite the drawing', mark && !mark.en);
    ok('…still hittable at 44px', mark && mark.h >= 44, mark && `${mark.w}×${mark.h}`);
    await page.click('#cYes');
    await page.waitForTimeout(300);
    await page.click('.ftr .cbar-again');
    await page.waitForTimeout(300);
    ok('pressing it asks again', await page.isVisible('#cbar'));
    ok('…and the old answer is forgotten first',
       (await page.evaluate(() => localStorage.getItem('anthifel_consent'))) === null);
    await page.close();
  }

  console.log('\n— what the notice promises —');
  {
    /* The cookie table names three things by name. If the code stops setting
       one, or starts setting a fourth, the table is wrong and a table nobody
       maintains is worse than no table. */
    const cookies = fs.readFileSync(path.join(DIR, 'cookies.html'), 'utf-8');
    for (const name of ['anthifel_consent', '_ga', '_ga_W376XEN94E']) {
      ok(`the cookie table names ${name}`, cookies.includes(name));
    }
    ok('…and says Google Analytics is not strictly necessary',
       /Not strictly necessary|Zorunlu de/i.test(cookies));
    /* privacy.html is refused in production while Legal's three details are
       brackets, so the processor list is read from the preview build — the same
       bytes, from the same source, minus the pages the build withholds. */
    const pv = path.join(path.dirname(DIR), 'preview', 'privacy.html');
    const privacy = fs.readFileSync(fs.existsSync(path.join(DIR, 'privacy.html'))
      ? path.join(DIR, 'privacy.html') : pv, 'utf-8');
    ok('the processor list names Google Analytics', privacy.includes('Google Analytics 4'));
  }

  await browser.close();
  console.log(`\n${fail ? '❌' : '✅'}  ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
