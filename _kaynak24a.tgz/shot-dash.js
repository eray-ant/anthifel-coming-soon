const { chromium } = require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const mock=require('./mock-supabase');
const ROOT=path.join(__dirname,'dist','preview'),PORT=8132;
const s=http.createServer((q,r)=>{let p=decodeURIComponent(q.url.split('?')[0]);if(p.endsWith('/'))p+='index.html';
 const f=path.join(ROOT,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.writeHead(404).end();return;}
 r.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});r.end(fs.readFileSync(f));});
s.listen(PORT,'127.0.0.1',async()=>{
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
 const pg=await b.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1.5});
 /* The door is a Supabase account now, not a password written into the page,
    so this script signs in the way the suites do — against the same in-memory
    project. It kept typing into #pw, which the page correctly hides, and then
    timed out; a screenshot tool that cannot open the thing it photographs is
    the reason a visual pass gets skipped. */
 mock.install(pg);
 await pg.goto(`http://127.0.0.1:${PORT}/dashboard/`,{waitUntil:'networkidle'});
 await mock.signIn(pg);
 await pg.waitForSelector('#gateScr',{state:'hidden'}); await pg.waitForTimeout(300);
 /* The menu is departments with their own drop-downs now, so `.dnav a[href=…]`
    matches nothing and this walked into a 30s timeout on the first section.
    Going by address is what the panel itself does when someone opens a
    bookmark, and it does not depend on the shape of the menu. */
 const open=async s=>{ await pg.goto(`http://127.0.0.1:${PORT}/dashboard/#${s}`,{waitUntil:'networkidle'});
                       await pg.waitForTimeout(450); };
 for(const s of ['ozet','icerik','site','seo','analitik','finans','blog']){
   await open(s);
   await pg.screenshot({path:`screenshots/d-${s}.png`, fullPage:['ozet','site','seo','analitik','finans','icerik'].includes(s)});
 }
 await open('crm');
 await pg.screenshot({path:'screenshots/d-crm-acilis.png'});
 await pg.click('#crm .wact .btn.ghost'); await pg.waitForTimeout(700);
 await pg.screenshot({path:'screenshots/d-crm.png'});
 await pg.setViewportSize({width:560,height:1000}); await pg.waitForTimeout(400);
 await open('ozet').catch(()=>{});
 await pg.screenshot({path:'screenshots/d-560.png'});
 await b.close();s.close();});
