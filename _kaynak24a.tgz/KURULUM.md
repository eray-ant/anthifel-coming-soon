# Landing v2 — kurulum

Coming-soon sayfası `/` adresinde kalıyor. Landing arka planda
`anthifel.com/preview/` adresinde duruyor; hazır olduğunda kökü devralıyor.

Aşağıdakilerin hepsi bir kez yapılır. **4. adım bitene kadar form görünür şekilde
kapalı** — açılıyor, doğruluyor, ama göndermek yerine `hello@anthifel.com`
adresine yönlendiriyor. Bu yüzden sayfayı bugün yayına almak güvenli.

---

## Ne üretiliyor

Tek kaynaktan iki build çıkıyor. Aradaki tek fark head bloğu ve önizleme bandı —
işaretleme, CSS, form ve metinler baytı baytına aynı. Yani preview'de onayladığın
şey, canlıya çıkan şeyin ta kendisi.

```
python3 build.py
```

| Build | Nereye | Ne farkı var |
|---|---|---|
| `dist/preview/` | `anthifel.com/preview/` | `noindex,nofollow,noarchive`, canonical yok, üstte siyah önizleme bandı |
| `dist/production/` | repo kökü — **lansmanda** | canonical + hreflang var, indekslenir, bant yok |

Her build dört dosya: `index.html`, `privacy.html`, `terms.html`, `cookies.html`.
Hepsi kendi kendine yeter — CSS, JS, fontlar ve görseller içine gömülü.

**Önizleme adresini değiştirmek istersen** `build.py` içindeki tek satır:

```python
PREVIEW_DIR = 'preview'
```

`preview` yerine ne yazarsan klasör adı o olur. Tahmin edilmesi zor bir şey
seçmek istersen (`on-izleme-8f2a` gibi) burası.

---

## 1. Preview'i yayına alma

1. GitHub'da `eray-ant/anthifel-coming-soon` reposunu aç.
2. **Add file → Create new file**, isim kutusuna `preview/index.html` yaz —
   eğik çizgi klasörü kendiliğinden oluşturur.
3. `dist/preview/index.html` içeriğini yapıştır, **Commit changes**.
4. Aynı şekilde `preview/privacy.html`, `preview/terms.html`,
   `preview/cookies.html`.

Daha kolayı: **Add file → Upload files** ile `dist/preview/` klasörünü sürükle.

Coming-soon `index.html` köke dokunulmuyor. `/` hâlâ o.

### Arama motorlarına kapatma

`noindex,nofollow,noarchive` etiketi dört sayfanın da başında duruyor, bu tek
başına yeterli. Repoda `robots.txt` varsa şu satırı da ekle
(`dist/preview/ROBOTS-SNIPPET.txt` içinde hazır duruyor):

```
User-agent: *
Disallow: /preview/
```

Yoksa oluşturmana gerek yok — meta etiketi işi görüyor.

### Deploy'u doğrula

`Anthifel_Website.md` §8 gereği: commit sayısı artmalı **ve** DigitalOcean
Activity'de **commit hash'i taşıyan** yeni bir satır belirmeli. "Deployed
configuration changes" satırı ayar değişikliğidir, kod deploy'u değil.

Sonra `anthifel.com/preview/` adresini Cmd+Shift+R ile aç.

---

## 2. `hello@` gerçekten gönderebiliyor mu

**reCAPTCHA gitti, yerine bir şey kurulmuyor.** Bot kontrolü artık testin
kendi akışının içinde: ziyaretçi adresini girip gizliliği onaylıyor, o adrese
altı haneli bir kod gidiyor, kod girilmeden test açılmıyor. Anahtar yok, üçüncü
tarafa istek yok, çerez yok. Sayfada yapılacak bir ayar da yok.

Ama bu, kurulumun en kırılgan yerini `hello@anthifel.com` adresine taşıyor:
**kod maili gitmezse ya da spam'e düşerse teste kimse giremez.** Yayına almadan
önce üçü de doğru olmalı.

1. **Gönderme izni.** Apps Script maili senin hesabından gönderiyor. `hello@`
   ayrı bir kutu ya da grup ise, Gmail → **Ayarlar → Hesaplar ve İçe Aktarma →
   Şununla e-posta gönder** altında `hello@anthifel.com` tanımlı ve **doğrulanmış**
   olmalı. Değilse `SEND_AS` çalışmaz ve mail kendi adresinden gider.
2. **DKIM.** Workspace Admin → **Uygulamalar → Google Workspace → Gmail → E-posta
   kimliğini doğrula** → anahtarı üret, çıkan TXT kaydını alan adına ekle,
   sonra **Kimlik doğrulamayı başlat**. DKIM'siz kod maili spam'e düşer; bu
   yüzden artık "iyi olur" değil, zorunlu.
3. **Test.** 5. bölümdeki adımlar bunu uçtan uca deniyor.

---

## 3. Google tarafı

### 3a. Tablo

1. **Anthifel — Website enquiries** adında bir Google E-Tablo aç.
2. URL'den ID'yi kopyala: `docs.google.com/spreadsheets/d/`**`BU_KISIM`**`/edit`

Başlık satırı ilk doğrulamada kendiliğinden yazılıyor:

```
Verified at · Email · Consent given · Consent at · Consent text ·
Language · Page · Referrer · Timezone · Score · Band · Completed at
```

Rızayı savunulabilir kılan iki sütun `Consent at` ve `Consent text`: kutunun
işaretlendiği tam an, ve o anda kişinin onayladığı tam metin. Sonradan
değiştirdiğimiz bir cümleye verilmiş rıza kanıt değildir.

**Satır ne zaman yazılıyor:** kod doğrulandığı anda, öncesinde değil. Adresini
girip kodu hiç girmeyen biri tabloda görünmez. Son üç sütun (`Score`, `Band`,
`Completed at`) testi bitirdiğinde aynı satıra ekleniyor.

**On iki sorunun cevabı hiçbir sütunda yok ve olmayacak.** Tabloya skor, bant ve
beş boyut ortalaması giriyor; hangi soruya ne cevap verildiği tarayıcıdan hiç
çıkmıyor.

### 3b. Apps Script

1. Tabloda **Uzantılar → Apps Script**.
2. Gelen taslağı sil, `Code.gs` içeriğini yapıştır, kaydet.
3. **Proje Ayarları → Komut dosyası özellikleri** → üç özellik ekle:

| Özellik | Değer |
|---|---|
| `SHEET_ID` | 3a'daki tablo ID'si |
| `NOTIFY_TO` | `hello@anthifel.com` — lead maili buraya gelir |
| `SEND_AS` | `hello@anthifel.com` — kod ve sonuç maili bu adresten gider. 2. bölümdeki izin verilmemişse bu satır çalışmaz |

4. **Dağıt → Yeni dağıtım → Web uygulaması**
   - Açıklama: `form endpoint v1`
   - Yürütme: **Ben**
   - Erişim: **Herkes**
5. İzin iste dediğinde onayla. Çıkan **/exec** adresini kopyala.
6. `body.html` içinde:

```js
var ENDPOINT = '__APPS_SCRIPT_URL__';   // ← /exec adresini buraya
```

7. `python3 build.py`, sonra `preview/index.html` dosyasını güncelle.

> **Herkesi bir kez yakalayan tuzak:** script'i düzenlemek canlı adresi
> güncellemez. **Dağıt → Dağıtımları yönet → düzenle → Sürüm: Yeni sürüm**
> demezsen adres eski kodu sunmaya devam eder.

### 3c. Saklama süresi tetikleyicisi

Apps Script'te **Tetikleyiciler → Tetikleyici ekle** → fonksiyon `purgeOldRows`,
zaman güdümlü, gün sayacı. `PURGE_AFTER_DAYS` değerinden (şu an **730 gün**)
eski satırları siler.

Bu sayı, yayımlanan Gizlilik Politikası'nda yazan süreyle **aynı olmak
zorunda**. Legal başka bir süre söylerse ikisini birden değiştir.

---

## 4. Formu açma

Yalnızca Gizlilik Politikası yayımlandıktan sonra. `body.html` içinde:

```js
var FORM_LIVE = false;   // ← true yap
```

Kapalı gelmesi bilinçli: rıza kutusu `privacy.html`'e link veriyor ve içi boş bir
sayfaya işaret eden rıza, aydınlatılmış rıza değil. Bu satır `true` olana kadar
form göndermeyi reddediyor.

---

## 5. Duyurmadan önce test

Testin girişi artık iki adım. İkisini de dene.

**Hazırlık testi — kod akışı**

1. Kişisel bir adresle (`hello@` ile değil) teste başla, gizliliği işaretle,
   **Kodu gönder**e bas.
2. Kod maili geldi mi — ve **`hello@anthifel.com` adresinden mi geldi**, spam'e
   mi düştü? Spam'e düştüyse 2. bölüme dön, DKIM eksiktir.
3. Bu noktada tabloya bak: **satır olmamalı.** Kod doğrulanmadan hiçbir şey
   yazılmıyor.
4. Yanlış bir kod gir. "Kod eşleşmedi" demeli ve kaç hakkın kaldığını
   söylemeli.
5. Doğru kodu gir. Test açılmalı, ve tabloya rıza zaman damgalı bir satır
   düşmeli.
6. On iki soruyu bitir. İki mail gelmeli: sana sonucun, `hello@`'ya lead
   maili. Tablodaki satırın son üç sütunu dolmalı.
7. **Lead mailini aç ve kontrol et:** skor, bant, en zayıf boyut ve beş boyut
   ortalaması olmalı; **hangi soruya ne cevap verildiği olmamalı.** Varsa
   durdur ve bana söyle — kırmızı çizgi orada.
8. **Türkçe de dene** — önce TR'ye geç. Hem kod maili hem sonuç maili Türkçe
   gelmeli.
9. Gizlilik kutusunu işaretlemeden ilerlemeyi dene. Reddetmeli.
10. Aynı adresten arka arkaya altı kod iste. Altıncısı sessizce yutulmalı
    (saatlik sınır), ama ekranda hata gibi görünmemeli.
11. Kodu isteyip 15 dakika bekle, sonra gir. "Süresi doldu" demeli.

**Teklif formu ve genel**

12. Hizmet sayfasındaki teklif formunu doldur; `hello@`'ya düşmeli.
13. Telefondan `anthifel.com/preview/` aç: hamburger menü, testin kod ekranı,
    görüşme bandı.

---

## 6. Blog sistemi

Blog, dashboard'daki editörden yazılır ve **statik sayfa olarak** yayımlanır.
Ziyaretçi bir yazıyı açtığında hiçbir yere sorgu gitmez — Google'a da, Apps
Script'e de. Yazı, repoda duran bir HTML dosyasıdır.

### Döngü

```
/dashboard/blog/  editör
        ↓ kaydet / yayımla
Apps Script  →  Google E-Tablo "posts"   (kaynak veri)
        ↓ yayımla
Apps Script  →  şablonları repodan okur, doldurur
        ↓ GitHub Contents API ile commit
DigitalOcean autodeploy  →  /blog/<slug>/ yayında
```

Yayımla'ya bastığında commit birkaç saniye içinde düşer, DigitalOcean bir-iki
dakikada dağıtır. Deploy'u yine commit hash'inden doğrula.

### 6.1 GitHub anahtarı

1. GitHub → **Settings → Developer settings → Personal access tokens →
   Fine-grained tokens → Generate new token**
2. **Repository access:** Only select repositories → `anthifel-coming-soon`
3. **Permissions → Repository permissions → Contents: Read and write.**
   Başka hiçbir izin verme.
4. Süreyi 1 yıl seç, takvime not düş — süresi dolunca yayımlama sessizce durur.
5. Çıkan `github_pat_...` değerini kopyala.

### 6.2 Panel anahtarı

Editörün Apps Script'e "benim" diyebilmesi için paylaşılan bir sır gerekiyor.
Uzun ve rastgele olsun:

```bash
openssl rand -hex 32
```

Bu değer iki yere girer: Script Properties'e `DASH_TOKEN`, ve
`dashboard_blog.html` içindeki `TOKEN` sabitine.

> Bu anahtar sayfanın kaynağında görünür. Dashboard `noindex` ve parola kapısının
> arkasında ama kapı istemci tarafında — yani bu anahtar **yayımlama yetkisidir,
> kasa değildir.** Kimseyle paylaşma, ve dashboard adresini dağıtma. Gerçek
> koruma gerekirse Cloudflare Access, `Anthifel_Website.md` §7'de yazdığı gibi.

### 6.3 Apps Script

1. `BlogCode.gs` dosyasını, `Code.gs` ile **aynı** Apps Script projesine ekle
   (Dosyalar → + → Komut dosyası, adı `BlogCode`).
2. `Code.gs` içindeki `doPost` fonksiyonunun **en başına**, form işlemlerinden
   önce şu satırı ekle:

   ```js
   if (d.kind === 'blog') return blogRouter_(d);
   ```

   `var d = JSON.parse(e.postData.contents);` satırının hemen altına.
3. **Proje Ayarları → Komut dosyası özellikleri**, mevcutlara ek olarak:

| Özellik | Değer |
|---|---|
| `DASH_TOKEN` | 6.2'deki rastgele değer |
| `GH_TOKEN` | 6.1'deki `github_pat_...` |
| `GH_REPO` | `eray-ant/anthifel-coming-soon` |
| `GH_BRANCH` | `main` |
| `SITE_BASE` | `https://anthifel.com` |
| `BLOG_PREFIX` | `preview/` — kök yayına geçince **boşalt** |

`BLOG_PREFIX` yazıların repoda nereye yazılacağını belirler. Şu an preview
altında çalıştığımız için `preview/`. Lansmanda bu alanı boşaltmazsan yazılar
`/preview/blog/` altına yazılmaya devam eder ve sitede görünmezler — **lansman
günü unutulması en olası ayar budur.**

4. **Dağıt → Dağıtımları yönet → düzenle → Sürüm: Yeni sürüm.** Kodu
   değiştirdin, yeni sürüm demezsen eski kod çalışmaya devam eder.

### 6.4 Şablonları repoya koy

Apps Script şablonları repodan okur. `dist/preview/blog/` içindeki şu iki dosya
repoda durmalı:

```
preview/blog/_tpl-index.html
preview/blog/_tpl-post.html
```

Bunlar `build.py` çıktısında zaten var; preview klasörünü yüklerken beraberinde
gidiyorlar. Kök yayına geçince aynı iki dosya `blog/` altında olacak.

### 6.5 Editörü bağla

`dashboard_blog.html` içinde:

```js
var ENDPOINT    = '__APPS_SCRIPT_URL__';   // Apps Script /exec adresi
var TOKEN       = '__DASH_TOKEN__';        // 6.2'deki değer
var SITE_PREFIX = '/preview/';             // BLOG_PREFIX ile aynı olmalı
```

`SITE_PREFIX` yalnızca editördeki görsel önizlemelerinin doğru yerden
yüklenmesi için var. `BLOG_PREFIX` ile aynı değeri taşımalı — lansmanda ikisi de
değişir: `BLOG_PREFIX` boşalır, `SITE_PREFIX` `'/'` olur.

`python3 build.py`, sonra `dist/preview/dashboard/blog/index.html` dosyasını
repoda `preview/dashboard/blog/index.html` olarak yükle.

### 6.6 Kurulumu doğrula

Apps Script editöründe `blogSelfTest` fonksiyonunu seç ve **Çalıştır**. Kayıtta
şunu görmelisin:

```
OK. Sheet reachable, GitHub reachable, templates found. Posts: 0
```

Hata verirse eksik olan özelliğin adını söyler. Bu adımı atlama — sorunu ilk
yazıyı yazdıktan sonra keşfetmek daha pahalı.

### 6.7 İlk yazı

1. `anthifel.com/preview/dashboard/blog/` adresini aç.
2. **+ Yeni yazı**. Başlığı yaz — URL kendiliğinden üretilir, Türkçe karakterler
   düzgün çevrilir (`Yapay zekâ dönüşümü` → `yapay-zeka-donusumu`).
3. Spot, kategori, tarih, metin. Metin **Markdown**: `##` ara başlık, `**kalın**`,
   `*italik*`, `[link](url)`, `>` alıntı, `-` liste, `---` ayraç, `![alt](görsel)`.
4. **Önizleme** sekmesinden nasıl görüneceğine bak.
5. **Taslağı kaydet** — tabloya yazar, siteye çıkmaz.
6. **Yayımla** — siteye çıkar.

Yazıyı geri çekmek için **Yayından kaldır**: taslağa döner, sayfa siteden
kalkar, metin sende kalır.

### 6.8 Türkçe–İngilizce eşleştirme

Aynı yazının iki dilini ayrı ayrı yazarsın: biri `tr`, biri `en`. Sonra
birinde **Çeviri eşi** alanından diğerini seç. Eşleştirme çift yönlü kurulur ve
`hreflang` etiketlerini bu üretir — Blog Plan §7'nin istediği yapı.

Eşi olmayan bir yazıda, makale sayfasındaki diğer dil düğmesi pasif görünür.
Bilinçli: olmayan bir çeviriye link vermek 404 üretir.

### 6.9 Görseller — kütüphane

Adres yazmıyorsun. **Kütüphaneden seç** ya da **Yeni yükle**.

**Yükleme.** Dosyayı seçince görsel ekrana gelir. Üstüne tıklayarak **odak
noktasını** işaretlersin — üç kırpma da o noktayı merkezde tutar. Yanda üç
önizleme canlı güncellenir:

| Nerede kullanılır | Oran | Üretilen boyut |
|---|---|---|
| Makale başı | 16:9 | 1600×900 |
| Öne çıkan yazı | 4:3 | 1200×900 |
| Liste kartı | 3:2 | 1200×800 |
| Kütüphane küçük resmi | 3:2 | 320×213 |

Kırpma ve sıkıştırma **tarayıcıda** yapılır, JPEG kalite 0.82. Yani orijinal
dosyan hiçbir yere gitmez, ve önizlemede gördüğün şey birebir yayına çıkan şey
olur. Dördü birden `blog/img/` altına commit edilir.

Odak noktası neden var: bir kart 3:2, makale başı 16:9. Aynı görselden ikisini
merkezden kesersen bir yüz ya da asıl özne kolayca kenarda kalır. Tek tıkla
seçtiğin nokta üçünde de ortada durur.

**Kütüphane.** Daha önce yüklediklerin bir ızgarada durur, tıkla ve kullan. Aynı
görseli hem Türkçe hem İngilizce yazıda kullanabilirsin — dosya bir kez saklanır.
Silme, o görseli kullanan bir yazı varsa reddedilir ve hangi yazı olduğunu söyler.

En az 1600 px genişlik öneriyorum; altında uyarı verir ama engellemez.

### 6.10 Zamanlama

Tarih alanı hem yayın tarihi hem zamanlayıcı. **Bugünden ileri bir tarih
seçersen** buton `Zamanla` olur ve altta bir şerit belirir: hangi gün yayına
gireceğini yazar. Kaydettiğinde yazı `Zamanlandı` etiketiyle listede durur,
sitede görünmez.

O gün gelince Apps Script'teki `publishDue` tetikleyicisi yazıyı yayına alır ve
siteyi yeniden üretir. Tetikleyiciyi bir kez kurman gerekiyor:

**Tetikleyiciler → Tetikleyici ekle** → fonksiyon `publishDue`, zaman güdümlü,
**gün sayacı**, saat aralığı `08:00–09:00`. Yayımlanacak bir şey yoksa hiçbir şey
yapmaz, commit de üretmez.

Günlük yeterli. Belirli bir saate ihtiyacın olursa saat sayacına çevirebilirsin;
o zaman en fazla bir saat gecikmeyle çıkar.

Tarihi geçmişe çekersen zamanlama düşer ve yazı ilk yayımlamada çıkar. Zamanlanmış
bir yazıyı geri almak için **Yayından kaldır** — taslağa döner.

### 6.11 Yazarlar

İki seçenek var: **Eray Dengiz** ve **Anthifel**. Serbest metin değil, açılır
liste — yazar adının iki farklı yazımıyla siteye düşmesini engelliyor. Kurumsal
sesle yazılan bir analiz `Anthifel`, birinci tekil şahıs yazılan bir saha notu
`Eray Dengiz` olur.

### 6.12 Neyin nerede olduğu

| Ne | Nerede |
|---|---|
| Yazıların kendisi | Google E-Tablo, `posts` sekmesi |
| Yayındaki sayfalar | Repo: `blog/<slug>/index.html`, `en/blog/<slug>/index.html` |
| Görseller | Repo: `blog/img/<ad>-{16x9,4x3,3x2,thumb}.jpg` |
| Makine okunur liste | `blog/posts.json` |
| Şablonlar | `blog/_tpl-index.html`, `blog/_tpl-post.html` |

Tablo kaynak, repo çıktıdır. Repodaki bir yazıyı elle düzenlersen bir sonraki
yayımlamada üzerine yazılır. Düzeltmeler her zaman editörden.

---

## 7. Lansman günü

1. `dist/production/` içindeki dört dosyayı repo **köküne** koy —
   coming-soon `index.html`'in üzerine yazılıyor.
2. `preview/` klasörünü sil.
3. `robots.txt` içindeki `Disallow: /preview/` satırını kaldır.
4. Deploy'u yine commit hash'inden doğrula.

Production build'de canonical ve hreflang var, `noindex` yok. Preview'de test
ettiğin başka hiçbir şey değişmiyor.

---

## Not — blog linkleri

Footer'daki beş blog linki ve menüdeki Blog `/blog/...` adreslerine gidiyor.
**Blog altyapısı henüz yok**, dolayısıyla bu linkler şimdilik 404 verir. Bu
bilinçli: adresler `Anthifel_Website.md` §9'daki URL yapısının doğrusu, blog
kurulunca (açık iş 8, 12 Ağustos) kendiliğinden çalışacaklar. Linkleri `#`
yapmadım — ölü link üretmek istemedim.

---

## Doğrulama araçları

```bash
npm install playwright
npx playwright install chromium

python3 build.py
node check-responsive.js dist/preview/index.html dist/preview/privacy.html
node check-behaviour.js  dist/preview/index.html
node check-behaviour.js  dist/production/index.html
node check-blog.js       dist/preview
node check-blog.js       dist/production
```

`check-responsive.js` her sayfayı 1440 / 1024 / 768 / 430 / 390 / 360 / 320
genişliklerinde yürüyor ve `screenshots/` klasörüne tam sayfa ekran görüntüsü
yazıyor. **NO OVERFLOW ANYWHERE** yazması şart.

`check-behaviour.js` 50 kontrol yapıyor: her çapa çözülüyor mu, `href="#"` kalmış
mı, her `data-en` düğümünün `data-tr` eşi var mı, Services §9.2'deki her cümle ve
fiyat birebir duruyor mu, form kapıları tutuyor mu, rıza kutusu işaretsiz mi ve
politika linki yerinde mi, hamburger açılıp kapanıyor mu, logo 15 px altına
düşüyor mu.

§9.2 kontrolleri işin asıl faydalı kısmı: biri hizmet cümlelerinden birini
kendince yeniden yazarsa build düşer. Site ilk seferinde tam bundan kaymıştı.

İki script de Chromium yolunu `executablePath` ile sabitliyor. Kendi makinende o
argümanı silip `npx playwright install chromium` komutunu bir kez çalıştırman
yeterli.

---

## Dosya haritası

| Dosya | Ne işe yarar |
|---|---|
| `body.html` | **Kaynak.** Landing sayfası. Düzenleme buradan yapılır |
| `stub_template.html` | **Kaynak.** Privacy / Terms / Cookies bekleme sayfası şablonu |
| `fonts.css` | Gömülü Cormorant Garamond + Inter, latin ve latin-ext |
| `assets/` | Logo ve monogram PNG'leri |
| `build.py` | İki build'i üretir |
| `Code.gs` | Apps Script form arka ucu |
| `check-responsive.js` | Taşma kontrolü + ekran görüntüleri |
| `check-behaviour.js` | Landing: 58 işlevsel kontrol |
| `check-blog.js` | Blog + editör: 76 kontrol |
| `blog_index.html` · `blog_post.html` | **Kaynak.** Blog listesi ve makale şablonu |
| `blog_parts.html` · `blog_common.css` | Blog sayfalarının ortak başlık, bülten, footer ve CSS'i |
| `dashboard_blog.html` | **Kaynak.** Dashboard yazı editörü |
| `BlogCode.gs` | Apps Script blog arka ucu |
| `dist/` | **Üretilen çıktı. Elle düzenlenmez**, her build'de silinip yeniden yazılır |
