/**
 * check-seo.js — Anthifel
 *
 * What a machine reads. Every other suite opens a page the way a person does;
 * this one reads the site the way a crawler and a share card do, which until
 * today was nobody's job and showed: the front page had no picture to share,
 * the service pages had no share tags at all, and there was no sitemap and no
 * robots.txt anywhere — only a note telling somebody to write one by hand.
 *
 * The rules it holds to:
 *   - a sitemap may only name pages that exist and that robots.txt allows
 *   - anything a stranger's machine has to fetch is an absolute URL and a real
 *     file, because the rest of this site is inlined and a data URI is useless
 *     to a crawler
 *   - K50 travels into structured data too: no price, anywhere, in any form
 *
 *   node check-seo.js [dist/production]
 */
const path = require('path');
const fs = require('fs');

const DIR = path.resolve(process.argv[2] || 'dist/production');
const SITE = 'https://anthifel.com/';
let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${x ? '  → ' + x : ''}`)); };
const read = f => fs.readFileSync(path.join(DIR, f), 'utf-8');

console.log('\n— robots.txt —');
ok('it exists at the root the crawler asks for', fs.existsSync(path.join(DIR, 'robots.txt')));
const robots = read('robots.txt');
/* 20 August, launch: `/preview/` is gone from the repository, so the line that
   closed it is gone from robots.txt. Asserting its *absence* rather than
   dropping the check, because a Disallow for a path that does not exist is not
   harmless — it is a public announcement that a staging copy is somewhere, and
   robots.txt is the first file anyone curious reads. The day a staging copy
   comes back, this fails and somebody has to think about it. */
ok('no staging copy is announced', !/^Disallow: \/preview\//m.test(robots), robots);
ok('the panel is still closed', /^Disallow: \/dashboard\//m.test(robots), robots);
ok('the panel is closed', /^Disallow: \/dashboard\//m.test(robots));
ok('it names the sitemap, absolutely', robots.includes('Sitemap: ' + SITE + 'sitemap.xml'));
// A rule with no agent applies to nobody. This is the mistake that makes a
// robots.txt look right and do nothing.
ok('the rules are addressed to somebody', /^User-agent: \*/m.test(robots));

console.log('\n— sitemap.xml —');
ok('it exists', fs.existsSync(path.join(DIR, 'sitemap.xml')));
const map = read('sitemap.xml');
const locs = [...map.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m => m[1]);
ok('it names something', locs.length > 5, String(locs.length));
ok('every address is absolute and ours', locs.every(l => l.startsWith(SITE)), locs.find(l => !l.startsWith(SITE)));

/* The contradiction a crawler reports back: a map that names a page the rules
   forbid it to read. Worth a test of its own because both files are correct on
   their own and only wrong together. */
const disallowed = robots.split('\n').filter(l => l.startsWith('Disallow:'))
  .map(l => l.replace('Disallow:', '').trim()).filter(Boolean);
ok('nothing in the map is disallowed by the rules',
   !locs.some(l => disallowed.some(d => l.replace(SITE, '/').startsWith(d))),
   locs.find(l => disallowed.some(d => l.replace(SITE, '/').startsWith(d))));

const missing = locs.map(l => l.replace(SITE, ''))
  .map(rel => rel === '' ? 'index.html' : (rel.endsWith('/') ? rel + 'index.html' : rel))
  .filter(rel => !fs.existsSync(path.join(DIR, rel)));
/* A published article is written by the publisher straight into the repository,
   so it is in the map and legitimately not in this build. Everything else that
   is named has to be here. */
ok('every page it names is in this build, or is a published article',
   missing.every(m => /^(en\/)?blog\/[a-z0-9-]+\/index\.html$/.test(m)), missing.join(' '));
ok('the two About addresses point at each other',
   /hreflang="tr" href="[^"]*hakkimizda\.html"/.test(map) &&
   /hreflang="en" href="[^"]*about\.html"/.test(map));
ok('the Journal is in it, in both languages',
   locs.includes(SITE + 'blog/') && locs.includes(SITE + 'en/blog/'));
ok('the panel is not in it', !locs.some(l => /dashboard/.test(l)));
ok('the staging copy is not in it', !locs.some(l => /\/preview\//.test(l)));

console.log('\n— the files a stranger has to fetch —');
for (const f of ['logo.png', 'share-card.webp']) {
  ok(`${f} is a real file`, fs.existsSync(path.join(DIR, f)));
  ok(`  …and not empty`, fs.statSync(path.join(DIR, f)).size > 2000,
     String(fs.existsSync(path.join(DIR, f)) && fs.statSync(path.join(DIR, f)).size));
}

console.log('\n— what every public page says about itself —');
const PUBLIC = ['index.html', 'about.html', 'hakkimizda.html',
                'ai-readiness-audit.html', 'discovery-sprint.html',
                'transformation-retainer.html', 'advisory-board-seat.html'];
for (const f of PUBLIC) {
  const html = read(f);
  const og = k => (html.match(new RegExp(`<meta property="og:${k}" content="([^"]*)"`)) || [])[1];
  ok(`${f}: has a title and a description to share`, !!og('title') && !!og('description'),
     `${og('title')} | ${og('description')}`);
  ok(`${f}: names a picture`, !!og('image'), og('image'));
  /* Absolute, and this is the whole reason logo.png and share-card.webp exist
     as files: every other image on this site is a data URI, which a crawler
     cannot fetch and will not render. */
  ok(`${f}: …at an address a crawler can fetch`, (og('image') || '').startsWith('https://'), og('image'));
  ok(`${f}: the card is the large one`,
     /twitter:card" content="summary_large_image"/.test(html));
  ok(`${f}: og:url is its own address`, (og('url') || '').startsWith(SITE), og('url'));
}

console.log('\n— structured data —');
const ld = f => [...read(f).matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)]
  .map(m => { try { return JSON.parse(m[1]); } catch (e) { return { broken: m[1].slice(0, 80) }; } });

const home = ld('index.html');
ok('the front page carries two blocks', home.length === 2, String(home.length));
ok('none of them is broken JSON', !home.some(o => o.broken), JSON.stringify(home.find(o => o.broken)));
const org = home.find(o => o['@type'] === 'Organization');
ok('one of them says who we are', !!org);
ok('it names the logo as a URL, not as bytes',
   org && org.logo === SITE + 'logo.png', org && String(org.logo).slice(0, 40));
ok('it says London, and does not invent a street',
   org && org.address.addressLocality === 'London' && !org.address.streetAddress,
   org && JSON.stringify(org.address));
ok('it names the founder', org && org.founder.name === 'Eray Dengiz');
ok('it points at the two accounts we actually have',
   org && org.sameAs.length === 2 && org.sameAs.every(u => /linkedin|x\.com/.test(u)));

for (const f of ['ai-readiness-audit.html', 'discovery-sprint.html',
                 'transformation-retainer.html', 'advisory-board-seat.html']) {
  const svc = ld(f).find(o => o['@type'] === 'Service');
  ok(`${f}: is described as a service`, !!svc);
  ok(`  …provided by the organisation on the front page`,
     svc && svc.provider['@id'] === SITE + '#organisation');
  /* K50. schema.org has an `offers` field with a price in it, and filling it
     would publish the number in the one place nobody looks at and everybody can
     read. The rule is the site never states a price; a machine-readable page is
     still the site. */
  ok(`  …with no price in it`, svc && !svc.offers && !JSON.stringify(svc).match(/price|\$|£|€/i));
}

/* ---- titles: the template never adds the brand -------------------------
 *
 * Marketing wrote this down as a standing rule on 21 August, after four
 * service pages went out reading "AI Readiness Audit · Anthifel · Anthifel".
 * The shell was appending " · Anthifel" while Business's own §2 titles already
 * carried it. Nobody saw it in the page — a browser tab shows about thirty
 * characters and the second brand fell off the end of it.
 *
 * Two assertions, because the bug has two halves. The first reads the built
 * pages: no title says the brand twice, in either language. The second reads
 * the templates: no title tag has the brand written beside a token, which is
 * the shape the appending took. The first would catch it today; the second
 * catches somebody re-introducing the habit on a page that has no title yet.
 *
 * The 60-character limit is Business's, from §2, and it is the reason this is
 * not merely cosmetic: a Turkish title plus an appended brand ran to 63. */
console.log('\n— titles —');
const TITLE_RE = /<title[^>]*?(?:data-en="([^"]*)")?[^>]*?(?:data-tr="([^"]*)")?[^>]*>([^<]*)<\/title>/;
for (const f of fs.readdirSync(DIR).filter(n => n.endsWith('.html'))
                 .concat(['blog/index.html', 'en/blog/index.html', 'meet/index.html'])) {
  let html;
  try { html = read(f); } catch { continue; }
  const m = html.match(TITLE_RE);
  if (!m) { ok(`${f}: has a title at all`, false); continue; }
  for (const [lang, t] of [['en', m[1] || m[3]], ['tr', m[2] || m[3]]]) {
    if (!t) continue;
    const brands = (t.match(/Anthifel/g) || []).length;
    ok(`${f} (${lang}): names the brand at most once`, brands <= 1, t);
    ok(`${f} (${lang}): fits Business's 60 characters`, t.length <= 60,
       `${t.length}: ${t}`);
  }
}
const TEMPLATES = fs.readdirSync(__dirname).filter(n => /_template\.html$|^blog_index\.html$|^body\.html$/.test(n));
for (const t of TEMPLATES) {
  const line = (fs.readFileSync(path.join(__dirname, t), 'utf-8')
    .split('\n').find(l => l.includes('<title')) || '');
  ok(`${t}: the title tag does not append the brand to a token`,
     !/__TITLE_(EN|TR)__[^"<]*Anthifel/.test(line), line.trim().slice(0, 90));
}

console.log(`\n${fail ? '❌' : '✅'}  ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
