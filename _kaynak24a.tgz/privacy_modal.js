/* The privacy modal's behaviour. Travels with its markup and its stylesheet;
   the three of them are one part, injected by build.py as a single block.

   It asks the page for nothing, on purpose. The four shells name their language
   variable four different ways and only two of them switch `[data-pane]` at
   all, so this reads the language off <html> — which every one of them sets —
   and watches that attribute for changes rather than waiting to be told. */
(function(){
'use strict';
var ovl = document.getElementById('povl');
if(!ovl) return;

/* ---- language ---- */
function lang(){ return document.documentElement.lang === 'tr' ? 'tr' : 'en'; }
/* Which document is open. One overlay, three bodies — see the markup for why. */
var DOCS = {
  privacy: { en: 'Privacy Policy', tr: 'Gizlilik Politikası' },
  terms:   { en: 'Terms of Use',   tr: 'Kullanım Şartları' },
  cookies: { en: 'Cookie Policy',  tr: 'Çerez Politikası' }
};
var doc_ = 'privacy';

function panes(){
  var l = lang(), p = ovl.querySelectorAll('.pmpane');
  for(var i=0;i<p.length;i++){
    var inDoc = p[i].closest('.pmdoc');
    /* A pane is shown when it is this language *and* in the document that is
       open. Checking only the language left the other two documents' English
       panes visible underneath, which is what the first version did. */
    p[i].hidden = (p[i].getAttribute('data-pane') !== l) ||
                  (inDoc && inDoc.getAttribute('data-doc') !== doc_);
  }
  var d = ovl.querySelectorAll('.pmdoc');
  for(var j=0;j<d.length;j++) d[j].hidden = (d[j].getAttribute('data-doc') !== doc_);
  var t = document.getElementById('pmTitle');
  if(t && DOCS[doc_]) t.textContent = DOCS[doc_][l] || DOCS[doc_].en;
  var f = document.getElementById('pmFull');
  if(f) f.setAttribute('href', f.getAttribute('data-' + doc_) || f.getAttribute('href'));
}
panes();
document.addEventListener('langchange', panes);
/* index.html dispatches that event; the service, legal and Journal shells do
   not. All four write the language onto <html>, so this is the one signal that
   reaches every page. */
try{
  new MutationObserver(panes).observe(document.documentElement,
    {attributes:true, attributeFilter:['lang']});
}catch(e){}

/* ---- open and close ---- */
var last = null;
function open_(which){
  doc_ = DOCS[which] ? which : 'privacy';
  last = document.activeElement;
  panes();
  ovl.hidden = false;
  document.body.style.overflow = 'hidden';
  var c = document.getElementById('pmClose');
  if(c) c.focus();
}
function close_(){
  ovl.hidden = true;
  document.body.style.overflow = '';
  if(last){ try{ last.focus(); }catch(err){} }
}

/* Any link to the privacy policy opens it here instead of navigating —
   Eray, 13 August. The exceptions are deliberate: a link that already opens in
   a new tab is left alone (the modal's own footer link is one), and so is the
   legal pages' own document switcher, where the visitor is choosing which
   document to read rather than checking one line before ticking a box. */
document.addEventListener('click', function(e){
  var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
  if(!a) return;
  var href = a.getAttribute('href') || '';
  var m = /(^|\/)(privacy|terms|cookies)\.html([?#].*)?$/.exec(href);
  if(!m) return;
  var which = m[2];
  if(a.target === '_blank') return;
  if(a.closest('.lgnav')) return;
  e.preventDefault();
  /* On that document's own page there is nothing to open. Send the reader to
     the text they asked for rather than reloading the page under them and
     losing whatever they had ticked. */
  if(new RegExp('(^|/)' + which + '\\.html$').test(location.pathname)){
    var doc = document.querySelector('main .doc:not([hidden])') || document.querySelector('main');
    if(doc && doc.scrollIntoView) doc.scrollIntoView({behavior:'smooth', block:'start'});
    return;
  }
  open_(which);
});

var cl = document.getElementById('pmClose'); if(cl) cl.addEventListener('click', close_);
var dn = document.getElementById('pmDone');  if(dn) dn.addEventListener('click', close_);
ovl.addEventListener('click', function(e){ if(e.target === ovl) close_(); });
document.addEventListener('keydown', function(e){ if(e.key === 'Escape' && !ovl.hidden) close_(); });

/* Wide tables get a scroller of their own rather than pushing the modal
   sideways. Legal's notice carries three of them. */
var tbl = ovl.querySelectorAll('.pmbody table');
for(var t=0;t<tbl.length;t++){
  var w = document.createElement('div'); w.className = 'tw';
  tbl[t].parentNode.insertBefore(w, tbl[t]); w.appendChild(tbl[t]);
}
})();
