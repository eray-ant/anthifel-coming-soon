/**
 * check-responsive.js — Anthifel
 *
 * Walks every page at the seven widths named in Anthifel_Website.md §6 and
 * reports horizontal overflow. Nothing ships without "NO OVERFLOW ANYWHERE"
 * plus a visual pass over the screenshots.
 *
 * Usage:  node check-responsive.js [file1.html file2.html ...]
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const WIDTHS = [1440, 1024, 768, 430, 390, 360, 320];
const FILES = process.argv.slice(2);
const SHOTS = path.join(__dirname, 'screenshots');

(async () => {
  if (!fs.existsSync(SHOTS)) fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  let problems = 0;

  for (const file of FILES) {
    const name = path.basename(file, '.html');
    console.log(`\n=== ${path.basename(file)} ===`);

    for (const w of WIDTHS) {
      const ctx = await browser.newContext({
        viewport: { width: w, height: 900 },
        deviceScaleFactor: 1,
      });
      const page = await ctx.newPage();
      const consoleErrors = [];
      // Offline sandbox: external hosts (reCAPTCHA) cannot resolve. Those are
      // environment noise, not page defects — real JS errors still surface.
      const NETWORK_NOISE = /ERR_TUNNEL_CONNECTION_FAILED|ERR_NAME_NOT_RESOLVED|ERR_INTERNET_DISCONNECTED|ERR_CONNECTION_REFUSED|recaptcha|gstatic|googleapis/i;
      page.on('console', (m) => {
        if (m.type() === 'error' && !NETWORK_NOISE.test(m.text())) consoleErrors.push(m.text());
      });
      page.on('pageerror', (e) => {
        if (!NETWORK_NOISE.test(String(e))) consoleErrors.push(String(e));
      });

      // Google's schedule is answered locally: the band must be measurable
      // without the sandbox reaching Google, and what is being measured is our
      // layout around the frame, not Google's page inside it.
      await page.route('**calendar.google.com/**', r =>
        r.fulfill({ status: 200, contentType: 'text/html', body: '<p>schedule</p>' }));
      await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
      await page.waitForTimeout(600);
      // The booking band is hidden until asked for, and hidden things cannot
      // overflow. It is opened here so this suite measures the page a visitor
      // who pressed the button actually gets.
      if (await page.$('#meet') !== null) {
        await page.click('[data-meet]').catch(() => {});
        await page.waitForTimeout(700);
      }

      const report = await page.evaluate((vw) => {
        const docW = document.documentElement.scrollWidth;
        const offenders = [];
        // An element cannot widen the document if an ancestor clips it.
        const clipped = (el) => {
          for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
            const o = getComputedStyle(p);
            if (/hidden|clip|auto|scroll/.test(o.overflowX + o.overflow)) return true;
          }
          return false;
        };
        const all = document.querySelectorAll('body *');
        for (const el of all) {
          const cs = getComputedStyle(el);
          if (cs.display === 'none' || cs.visibility === 'hidden' || cs.position === 'fixed') continue;
          const r = el.getBoundingClientRect();
          if (r.width === 0 && r.height === 0) continue;
          // Deliberately parked off-screen (honeypot, screen-reader-only): never scrolls LTR.
          if (r.left < -1000) continue;
          if (clipped(el)) continue;
          const right = r.left + r.width;
          if (right > vw + 1) {
            let sel = el.tagName.toLowerCase();
            if (el.id) sel += '#' + el.id;
            else if (el.className && typeof el.className === 'string') {
              const c = el.className.trim().split(/\s+/).slice(0, 2).join('.');
              if (c) sel += '.' + c;
            }
            offenders.push({
              sel,
              left: Math.round(r.left),
              right: Math.round(right),
              over: Math.round(right - vw),
              text: (el.textContent || '').trim().slice(0, 40),
            });
          }
        }
        // Deduplicate by selector, keep the worst
        const byS = {};
        for (const o of offenders) {
          if (!byS[o.sel] || o.over > byS[o.sel].over) byS[o.sel] = o;
        }
        return {
          docW,
          bodyScroll: document.body.scrollWidth,
          offenders: Object.values(byS).sort((a, b) => b.over - a.over).slice(0, 12),
        };
      }, w);

      const scrolls = report.docW > w + 1;
      const bad = scrolls || report.offenders.length > 0;
      if (bad) problems++;

      const tag = bad ? 'OVERFLOW' : 'ok      ';
      console.log(
        `  ${tag} ${String(w).padStart(4)}px  doc=${report.docW}` +
        (scrolls ? `  ← scrolls by ${report.docW - w}px` : '')
      );
      for (const o of report.offenders) {
        console.log(`           ↳ ${o.sel}  right=${o.right} (+${o.over})  "${o.text}"`);
      }
      if (consoleErrors.length) {
        problems++;
        console.log(`           ↳ JS ERRORS: ${consoleErrors.slice(0, 3).join(' | ')}`);
      }

      await page.screenshot({
        path: path.join(SHOTS, `${name}-${w}.png`),
        fullPage: true,
      });
      await ctx.close();
    }
  }

  await browser.close();
  console.log(
    problems === 0
      ? '\n✅  NO OVERFLOW ANYWHERE\n'
      : `\n❌  ${problems} viewport(s) with problems\n`
  );
  process.exit(problems === 0 ? 0 : 1);
})();
