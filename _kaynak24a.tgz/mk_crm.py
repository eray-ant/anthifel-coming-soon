#!/usr/bin/env python3
"""
mk_crm.py — one-off: lift the ANC engine out of the old dashboard app and
re-house it as a section of the new single-page dashboard.

The engine (data model, triage, DM rounds, advice engine, CSV in/out) is kept
byte-for-byte where it can be. What changes is the chrome: the left sidebar
becomes a horizontal strip under the section menu, the gold palette becomes the
site's terracotta, and the page lives inside the shared dashboard frame rather
than owning the viewport.

Run once. After that dash_sec_crm.html is the source and this script is history:
it records how the port was done and nothing more.

  python3 mk_crm.py
"""

import os, re

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(ROOT, 'legacy', 'anc.html')   # the old dashboard's copy, kept for the record

raw = open(SRC, encoding='utf-8').read()
app = re.search(r'<script>\n\(\(\) => \{\n"use strict";(.*)\n\}\)\(\);\n</script>', raw, re.S)
if not app:
    raise SystemExit('could not find the ANC application block')
js = app.group(1)

# ── 1. every element id is prefixed. The dashboard is one document now, so
#      "file" and "saveBtn" would otherwise be claimed twice — the blog editor
#      has both. The toolbar also cannot keep the class "top": that belongs to
#      the sticky section menu.
IDS = {'top':'crmtop', 'nav':'crmNav', 'page':'crmPage', 'status':'crmStatus',
       'file':'crmFile', 'loadBtn':'crmLoad', 'saveBtn':'crmSave',
       'savePop':'crmSavePop', 'drop':'crmDrop'}
for a, b in IDS.items():
    js = js.replace('$("#%s")' % a, '$("#%s")' % b)
js = js.replace('id:"drop"', 'id:"crmDrop"')

# ── 2. one toast for the whole dashboard, defined in the shared shell.
js = js.replace(
    'function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");\n'
    '  clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove("show"),1800);}',
    'function toast(m){ window.toast(m); }')

# ── 3. the sidebar becomes a horizontal strip. Same items, same counts, same
#      guard against navigating before a file is loaded.
old_nav = re.search(r'function renderNav\(\)\{.*?\n\}\n', js, re.S).group(0)
new_nav = '''function renderNav(){
  const n=$("#crmNav");n.innerHTML="";
  const yuklu=S.people.length>0;
  NAV.forEach((g,gi)=>{
    if(gi)n.append(el("span",{class:"navsep"}));
    if(g.grup)n.append(el("span",{class:"navcap"},g.grup));
    g.items.forEach(it=>{
      const c=it.count?it.count():null;
      n.append(el("a",{href:"#","aria-current":S.view===it.id?"page":null,
        onclick:e=>{e.preventDefault(); if(!yuklu&&it.id!=="ozet")return toast("Önce havuz dosyasını yükle.");
          S.view=it.id;S.sel.clear();filtreTemizle();S.rapidIdx=0;render();
          window.scrollTo({top:0,behavior:"smooth"});}},
        it.dot?el("span",{class:"dot "+it.dot}):null,
        el("span",{class:"lbl"},it.lbl),
        c!==null?el("span",{class:"cnt"},tr(c)):null));
    });
  });
}
'''
js = js.replace(old_nav, new_nav)

# ── 4. the page head already carries the section title, so the toolbar drops the
#      product name and names the view instead.
js = js.replace(
    't.append(el("div",{},el("h1",{},"Anthifel Network Center"),\n'
    '      el("div",{class:"desc"},"LinkedIn ağını çalışılabilir bir CRM\'e çeviren tek dosyalık arayüz")));',
    't.append(el("div",{},el("h1",{},"Başlangıç"),\n'
    '      el("div",{class:"desc"},"Havuz dosyasını yükle, ağ buradan çalışılır hale gelsin")));')

# ── 5. the welcome screen used a masked wordmark. The shell already shows the
#      real one in the menu, so the duplicate goes.
js = js.replace('    el("div",{class:"wordmark"}),\n', '')
js = js.replace('el("h2",{},"Network Center"),', 'el("h2",{},"CRM — Network Center"),')

for token in ('$("#crmtop")', 'function toast(m){ window.toast(m); }', 'class:"navsep"'):
    if token not in js:
        raise SystemExit('patch did not apply: ' + token)

HEAD = '''<style>
/* ============================================================
   CRM — Network Center

   The engine is the one that ran at /dashboard/ before; only the surface is
   new. Everything is scoped to #crm so the app's own class names (.card, .btn,
   .tag, .empty, .note) cannot reach the shared dashboard chrome above it.

   The palette is redeclared here rather than renamed through the engine: the
   application writes var(--gold) and var(--ink-2) in inline styles in a hundred
   places, so the cheapest correct move is to give those names new values inside
   #crm. No dark surfaces — Anthifel_Website.md §5.
   ============================================================ */
#crm{
  --plane:#F1F0EC; --surface:#FFFFFF; --surface-2:#FAF9F6; --surface-3:#F1EFEA;
  --ink:#1A1815; --ink-2:#57534C; --muted:#7A756C;
  --line:rgba(26,24,21,.10); --rule:rgba(26,24,21,.22); --ring:rgba(26,24,21,.13);
  --gold:#B84C2E; --gold-soft:#A03F24; --gold-dim:rgba(184,76,46,.09);
  --yakin:#2F6B3F; --hedef:#2A5C8A; --izleme:#6B4B8A; --pas:#7A756C;
  --good:#2F6B3F; --crit:#B0342A;
  --shadow:0 10px 30px rgba(26,24,21,.13); --r:3px;
  font-size:14px; line-height:1.5; color:var(--ink);
}
#crm button,#crm input,#crm select,#crm textarea{font:inherit;color:inherit}
#crm a{color:var(--gold)}
/* Not scoped: the download menu lives in the page head, outside #crm, and it is
   closed by adding this class. */
.hidden{display:none!important}
#crm .spacer{flex:1}

/* ---------- flow strip: what the sidebar used to be ---------- */
#crm .pnav{
  display:flex;align-items:center;gap:3px;flex-wrap:wrap;
  background:var(--surface);border:1px solid var(--line);border-radius:3px;
  padding:7px 9px;margin-bottom:14px;
}
#crm .pnav a{
  display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border-radius:2px;
  font-size:12.5px;font-weight:500;color:#57534C;white-space:nowrap;
  border:1px solid transparent;transition:background .14s,color .14s;
}
#crm .pnav a:hover{background:#FAF9F6;color:#1A1815}
#crm .pnav a[aria-current="page"]{background:#FAF7F4;color:#1A1815;font-weight:600;box-shadow:inset 0 -2px 0 #B84C2E}
#crm .pnav .lbl{min-width:0}
#crm .pnav .cnt{font-size:11px;color:#7A756C;font-variant-numeric:tabular-nums}
#crm .pnav a[aria-current="page"] .cnt{color:#57534C}
#crm .pnav .navcap{font-size:9.5px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:#7A756C;padding:0 7px 0 3px}
#crm .pnav .navsep{width:1px;height:20px;background:rgba(26,24,21,.12);margin:0 7px}
#crm .pnav .dot{width:7px;height:7px;border-radius:50%;flex:none}
#crm .dot.yakin{background:#2F6B3F}
#crm .dot.hedef{background:#2A5C8A}
#crm .dot.izleme{background:#6B4B8A}
#crm .dot.pas{background:#7A756C}
#crm .dot.fav{background:#B84C2E}

/* ---------- status line in the page head ---------- */
.status{display:flex;align-items:center;gap:8px;font-size:12px;color:#7A756C;margin-top:7px}
.status .led{width:7px;height:7px;border-radius:50%;background:#2F6B3F;flex:none}
.status .led.dirty{background:#B84C2E;box-shadow:0 0 0 3px rgba(184,76,46,.14)}

/* ---------- download menu ---------- */
.menu{position:relative}
.menu .pop{position:absolute;right:0;top:calc(100% + 6px);background:#FFFFFF;
  border:1px solid rgba(26,24,21,.22);border-radius:3px;padding:6px;min-width:300px;z-index:40;
  box-shadow:0 10px 30px rgba(26,24,21,.13);text-align:left}
.menu .pop button{display:block;width:100%;text-align:left;background:none;border:0;border-radius:2px;
  padding:9px 11px;cursor:pointer;font-size:13px;font-weight:500;color:#1A1815}
.menu .pop button:hover{background:#FAF9F6}
.menu .pop small{display:block;color:#7A756C;font-size:11.5px;margin-top:3px;line-height:1.45;font-weight:400}

/* ---------- toolbar (per view) ---------- */
#crm .crmtop{display:flex;align-items:center;gap:14px;padding:15px 18px;flex-wrap:wrap;
  background:var(--surface);border:1px solid var(--line);border-bottom:0;border-radius:3px 3px 0 0}
#crm .crmtop h1{margin:0;font-family:'Cormorant Garamond',Georgia,serif;font-weight:400;font-size:24px;line-height:1.15}
#crm .crmtop .desc{font-size:12.5px;color:var(--muted);margin-top:3px}
#crm .search{position:relative}
#crm .search input{width:260px;padding:8px 13px 8px 30px;background:var(--surface-2);
  border:1px solid var(--ring);border-radius:2px;font-size:13px}
#crm .search .mag{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:13px;pointer-events:none}
#crm input:focus,#crm select:focus,#crm textarea:focus{outline:2px solid var(--gold);outline-offset:1px;border-color:var(--gold)}

#crm .page{background:var(--plane);border:1px solid var(--line);border-radius:0 0 3px 3px;
  padding:18px;min-height:280px}
/* List views fill a fixed slice of the viewport and scroll inside themselves;
   a page-length table would put the filter bar out of reach. */
#crm .page.flush{padding:0;overflow:hidden;display:flex;flex-direction:column;
  height:calc(100vh - 330px);min-height:440px;background:var(--surface)}
#crm .sayfaAkis{flex:1;min-height:0;display:flex;flex-direction:column}

/* ---------- buttons ---------- */
#crm .btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;
  background:var(--surface);border:1px solid var(--ring);border-radius:2px;padding:9px 15px;
  cursor:pointer;font-size:13px;font-weight:500;white-space:nowrap;color:var(--ink);
  transition:background .14s,border-color .14s,color .14s}
#crm .btn:hover{background:var(--surface-2);border-color:var(--rule)}
#crm .btn:disabled{opacity:.4;cursor:not-allowed}
#crm .btn.gold{background:var(--gold);border-color:var(--gold);color:#FFFFFF;font-weight:500}
#crm .btn.gold:hover{background:var(--gold-soft);border-color:var(--gold-soft)}
#crm .btn.ghost{background:none;border-color:transparent;color:var(--ink-2)}
#crm .btn.ghost:hover{background:var(--surface-2);color:var(--ink)}
#crm .btn.sm{padding:6px 11px;font-size:12px}
#crm .btn.icon{padding:6px 10px}
#crm .btn.yakin{color:var(--yakin);border-color:rgba(47,107,63,.45)}
#crm .btn.hedef{color:var(--hedef);border-color:rgba(42,92,138,.45)}
#crm .btn.izleme{color:var(--izleme);border-color:rgba(107,75,138,.45)}
#crm .btn.fav{color:var(--gold);border-color:rgba(184,76,46,.45)}

/* ---------- cards ---------- */
#crm .card{background:var(--surface);border:1px solid var(--line);border-radius:3px;overflow:hidden;min-width:0}
#crm .card>.hd{display:flex;align-items:center;gap:10px;padding:14px 17px;border-bottom:1px solid var(--line);
  font-size:11px;font-weight:700;color:var(--ink-2);letter-spacing:.16em;text-transform:uppercase}
#crm .card>.bd{padding:17px}
#crm .grid{display:grid;gap:14px;min-width:0}
#crm .grid>*{min-width:0}
#crm .g2{grid-template-columns:1fr 1fr}
@media(max-width:1080px){#crm .g2{grid-template-columns:1fr}}

/* ---------- KPI ---------- */
#crm .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px}
#crm .kpi{background:var(--surface);border:1px solid var(--line);border-radius:3px;padding:15px 17px;min-width:0}
#crm .kpi .lab{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.14em;font-weight:600;margin-bottom:7px}
#crm .kpi .val{font-family:'Cormorant Garamond',Georgia,serif;font-size:31px;font-weight:400;line-height:1.05}
#crm .kpi .val small{font-family:'Inter',system-ui,sans-serif;font-size:13px;color:var(--muted)}
#crm .kpi .sub{font-size:11.5px;color:var(--muted);margin-top:6px;line-height:1.45}
#crm .kpi.gold .val{color:var(--gold)}
#crm .kpi.yakin .val{color:var(--yakin)}
#crm .kpi.hedef .val{color:var(--hedef)}

/* ---------- charts ---------- */
#crm .stack{display:flex;height:14px;border-radius:2px;overflow:hidden;gap:2px}
#crm .stack i{display:block;height:100%}
#crm .legend{display:flex;gap:16px;flex-wrap:wrap;margin-top:13px}
#crm .legend span{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--ink-2)}
#crm .legend b{font-weight:600;color:var(--ink);font-variant-numeric:tabular-nums}
#crm .legend .sw{width:9px;height:9px;border-radius:2px;flex:none}
#crm .bars{display:flex;flex-direction:column;gap:9px}
#crm .bar{display:flex;align-items:center;gap:11px;font-size:12.5px}
#crm .bar .nm{flex:0 0 132px;color:var(--ink-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#crm .bar .tr{flex:1;height:8px;background:var(--surface-3);border-radius:2px;overflow:hidden;min-width:0}
#crm .bar .tr i{display:block;height:100%;background:var(--gold)}
#crm .bar .vl{flex:0 0 48px;text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}
#crm .progress{height:6px;background:var(--surface-3);border-radius:2px;overflow:hidden}
#crm .progress i{display:block;height:100%;background:var(--gold);transition:width .3s}

/* ---------- filter bar ---------- */
#crm .fbar{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid var(--line);
  flex-wrap:wrap;background:var(--surface)}
#crm .fdrop{position:relative}
#crm .fdrop>button{display:flex;align-items:center;gap:7px}
#crm .fdrop>button .cap{font-size:10.5px;background:var(--gold);color:#FFFFFF;border-radius:99px;
  padding:0 6px;font-weight:700;line-height:16px}
#crm .fpop{position:absolute;left:0;top:calc(100% + 6px);z-index:30;background:var(--surface);
  border:1px solid var(--rule);border-radius:3px;box-shadow:var(--shadow);padding:8px;min-width:230px;
  max-height:330px;overflow:auto}
#crm .fpop label{display:flex;align-items:center;gap:9px;padding:6px 8px;border-radius:2px;cursor:pointer;font-size:13px}
#crm .fpop label:hover{background:var(--surface-2)}
#crm .fpop label input{accent-color:var(--gold);width:14px;height:14px}
#crm .fpop label .n{margin-left:auto;color:var(--muted);font-size:11.5px;font-variant-numeric:tabular-nums}
#crm .fpop.ayar{min-width:318px;max-height:min(560px,72vh)}
#crm .fpop.ayar .ayarbas{font-size:10px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-2);padding:4px 8px 2px}
#crm .fpop.ayar .ayarnot{font-size:11.5px;color:var(--muted);line-height:1.45;padding:0 8px 8px}
#crm .chip{border:1px solid var(--ring);background:none;border-radius:99px;padding:5px 12px;
  font-size:12.5px;cursor:pointer;color:var(--ink-2)}
#crm .chip:hover{border-color:var(--rule)}
#crm .chip[aria-pressed="true"]{background:var(--gold-dim);color:var(--gold);border-color:rgba(184,76,46,.45);font-weight:600}
#crm .factive{display:flex;gap:7px;flex-wrap:wrap;padding:10px 16px;border-bottom:1px solid var(--line);background:var(--surface-2)}
#crm .ftag{display:flex;align-items:center;gap:7px;font-size:12px;background:var(--surface);
  border:1px solid var(--ring);border-radius:99px;padding:3px 6px 3px 11px;color:var(--ink-2)}
#crm .ftag b{color:var(--ink);font-weight:600}
#crm .ftag button{background:none;border:0;cursor:pointer;color:var(--muted);font-size:14px;line-height:1;padding:0 4px}
#crm .ftag button:hover{color:var(--crit)}

/* ---------- bulk action bar ---------- */
#crm .bulk{display:flex;align-items:center;gap:8px;padding:11px 16px;border-bottom:1px solid var(--line);
  background:var(--gold-dim);flex-wrap:wrap}
#crm .bulk .n{font-weight:600;font-size:13px}

/* ---------- virtual table ---------- */
#crm .thead{display:flex;align-items:center;gap:12px;padding:9px 16px;border-bottom:1px solid var(--rule);
  background:var(--surface-2);user-select:none}
#crm .thead span,#crm .thead .tcell,#crm .thead .c-ls{
  font-size:10px;font-weight:700;line-height:1.3;color:var(--muted);text-transform:uppercase;
  letter-spacing:.12em;white-space:nowrap;cursor:pointer;text-align:left}
#crm .thead .tcell.sayi{text-align:right}
#crm .thead span:hover{color:var(--ink-2)}
#crm .vlist{position:relative;overflow:auto;background:var(--surface);flex:1;min-height:0}
#crm .vsp{position:relative;width:100%}
#crm .trow{position:absolute;left:0;right:0;display:flex;align-items:center;gap:12px;padding:0 16px;
  height:40px;border-bottom:1px solid var(--line);font-size:13px}
#crm .trow:hover{background:var(--surface-2)}
#crm .trow.sel{background:var(--gold-dim)}
#crm .c-chk{flex:0 0 18px;min-width:0;display:flex;align-items:center}
#crm .c-chk input{accent-color:var(--gold);width:14px;height:14px;margin:0;cursor:pointer}
#crm .c-star{flex:0 0 18px;min-width:0;text-align:center;cursor:pointer;color:var(--rule);font-size:14px;user-select:none}
#crm .c-star.on{color:var(--gold)}
#crm .tcell{color:var(--ink-2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#crm .tcell.ad{font-weight:500;color:var(--ink)}
#crm .tcell.ad a{color:inherit}
#crm .tcell.ad a:hover{color:var(--gold)}
#crm .tcell.sonuk{color:var(--muted);font-size:12.5px}
#crm .tcell.sayi{text-align:right;color:var(--muted);font-size:12.5px;font-variant-numeric:tabular-nums}
#crm .c-ls{flex:0 0 132px}
#crm .c-ls select{width:100%;background:var(--surface);border:1px solid var(--ring);border-radius:2px;
  padding:4px 6px;font-size:11.5px;cursor:pointer}
#crm .listwrap{background:var(--surface);border-top:1px solid var(--line);flex:1;min-height:0;
  display:flex;flex-direction:column}

#crm .pill{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;padding:2.5px 10px;
  border-radius:99px;border:1px solid var(--ring);color:var(--ink-2);white-space:nowrap}
#crm .pill.yakin{color:var(--yakin);border-color:rgba(47,107,63,.42)}
#crm .pill.hedef{color:var(--hedef);border-color:rgba(42,92,138,.42)}
#crm .pill.izleme{color:var(--izleme);border-color:rgba(107,75,138,.42)}
#crm .pill.pas{color:var(--muted)}
#crm .pill.gold{color:var(--gold);border-color:rgba(184,76,46,.42)}

/* ---------- triage ---------- */
#crm .subtabs{display:flex;gap:3px;background:var(--surface-2);padding:3px;border-radius:2px;border:1px solid var(--ring)}
#crm .subtabs button{background:none;border:0;border-radius:2px;padding:6px 14px;cursor:pointer;
  font-size:12.5px;color:var(--ink-2);font-weight:500}
#crm .subtabs button[aria-selected="true"]{background:var(--surface);color:var(--ink);
  box-shadow:0 1px 2px rgba(26,24,21,.14);font-weight:600}
#crm .bigcard{background:var(--surface);border:1px solid var(--line);border-radius:3px;padding:30px 32px}
#crm .bigcard h2{margin:0;font-family:'Cormorant Garamond',Georgia,serif;font-size:32px;font-weight:400;line-height:1.1}
#crm .bigcard .role{font-size:15px;color:var(--ink-2);margin-top:7px}
#crm .tags{display:flex;gap:7px;flex-wrap:wrap;margin-top:17px}
#crm .tag{font-size:11.5px;padding:4px 11px;border-radius:99px;border:1px solid var(--ring);
  color:var(--ink-2);background:var(--surface-2);letter-spacing:0;text-transform:none;font-weight:400}
#crm .tag.hot{color:var(--crit);border-color:rgba(176,52,42,.38)}
#crm .tag.warm{color:var(--gold);border-color:rgba(184,76,46,.38)}
#crm .keys{display:flex;gap:9px;flex-wrap:wrap;margin-top:22px}
#crm .keybtn{display:flex;align-items:center;gap:9px;background:var(--surface-2);border:1px solid var(--ring);
  border-radius:2px;padding:10px 16px;cursor:pointer;font-size:13.5px;font-weight:500;color:var(--ink)}
#crm .keybtn:hover{background:var(--surface-3)}
#crm .keybtn kbd{font-size:10px;border:1px solid var(--rule);border-radius:2px;padding:1px 6px;
  color:var(--muted);background:var(--surface);font-family:inherit}
#crm .keybtn.yakin{color:var(--yakin);border-color:rgba(47,107,63,.45)}
#crm .keybtn.hedef{color:var(--hedef);border-color:rgba(42,92,138,.45)}
#crm .keybtn.izleme{color:var(--izleme);border-color:rgba(107,75,138,.45)}
#crm .keybtn.fav{color:var(--gold);border-color:rgba(184,76,46,.45)}
#crm .recent{margin-top:20px;border-top:1px solid var(--line);padding-top:14px}
#crm .recent h4{margin:0 0 9px;font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.14em;font-weight:700}
#crm .recent .r{display:flex;align-items:center;gap:10px;padding:5px 0;font-size:12.5px;color:var(--ink-2)}
#crm .recent .r b{font-weight:500;color:var(--ink)}
#crm .recent .r button{background:none;border:0;color:var(--gold);cursor:pointer;font-size:12px;padding:0}

/* ---------- DM ---------- */
#crm textarea{width:100%;background:var(--surface-2);border:1px solid var(--ring);border-radius:2px;
  padding:13px 14px;resize:vertical;font-size:13.5px;line-height:1.62}
#crm .inp{width:100%;padding:9px 12px;background:var(--surface-2);border:1px solid var(--ring);
  border-radius:2px;font-size:13px}
#crm .dmlist{max-height:min(560px,calc(100vh - 340px));overflow:auto}
#crm .dmrow{display:flex;gap:10px;align-items:center;padding:9px 16px;cursor:pointer;border-bottom:1px solid var(--line)}
#crm .dmrow:hover{background:var(--surface-2)}
#crm .dmrow[aria-current="true"]{background:var(--surface-2);box-shadow:inset 3px 0 0 var(--gold)}
#crm .dmrow.done{opacity:.42}
#crm .dmrow .g{width:21px;height:21px;flex:0 0 21px;border-radius:2px;display:grid;place-items:center;
  font-size:11px;font-weight:700;color:#FFFFFF}
#crm .g.A{background:var(--gold)}#crm .g.B{background:var(--hedef)}#crm .g.C{background:var(--pas)}
#crm .dmrow .who{min-width:0;flex:1}
#crm .dmrow .nm{font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#crm .dmrow .cm{font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#crm details.card>summary{list-style:none}
#crm details.card>summary::-webkit-details-marker{display:none}

/* ---------- helpers ---------- */
#crm .empty{padding:52px 24px;text-align:center;color:var(--muted);font-size:13.5px}
#crm .empty h3{color:var(--ink);font-size:16px;font-weight:500;margin:0 0 8px}
#crm .empty p{max-width:480px;margin:0 auto;line-height:1.6}
/* The shared shell keeps .note for deviation warnings — dashed terracotta box.
   Inside the CRM the same class is ordinary small print, so the box is undone. */
#crm .note{margin:0;padding:0;border:0;background:none;font-size:12.5px;color:var(--muted);line-height:1.6}

/* ---------- opening screen ---------- */
#crm .welcome{display:grid;place-items:center;padding:40px 24px}
#crm .wbox{max-width:620px;text-align:center}
#crm .wbox h2{font-family:'Cormorant Garamond',Georgia,serif;font-size:28px;font-weight:400;margin:0 0 10px}
#crm .wbox p{color:var(--ink-2);font-size:14px;margin:0 auto 24px;line-height:1.65}
#crm .drop{border:1px dashed var(--rule);border-radius:3px;padding:34px 28px;background:var(--surface);transition:.15s}
#crm .drop.over{border-color:var(--gold);background:var(--gold-dim)}
#crm .wact{display:flex;gap:10px;justify-content:center;margin-top:8px;flex-wrap:wrap}

@media (max-width:760px){
  #crm .crmtop{padding:13px 14px}
  #crm .page{padding:14px}
  #crm .page.flush{height:auto;min-height:0;max-height:none}
  #crm .vlist{max-height:60vh;flex:none}
  #crm .search input{width:100%}
  #crm .search{flex:1 0 100%}
  #crm .grid[style*="330px"]{grid-template-columns:1fr!important}
  .menu .pop{right:auto;left:0;min-width:min(300px,calc(100vw - 60px))}
}
</style>
<div class="phead">
  <div>
    <h1>CRM</h1>
    <p>LinkedIn ağını çalışılabilir bir listeye indirger, lansman DM turlarını yönetir.<br>
       Veri tarayıcının dışına çıkmaz; çalışma dosyası senin diskinde durur.</p>
    <div class="status" id="crmStatus"></div>
  </div>
  <div class="acts">
    <button class="btn btn-s" id="crmLoad">Havuz yükle</button>
    <span class="menu">
      <button class="btn btn-p" id="crmSave" disabled>İndir ▾</button>
      <div class="pop hidden" id="crmSavePop"></div>
    </span>
    <button class="btn btn-s" id="crmUndo" disabled title="Son işlemi geri al">↺</button>
  </div>
</div>

<main id="crm">
  <nav class="pnav" id="crmNav"></nav>
  <div class="crmtop" id="crmtop"></div>
  <div class="page" id="crmPage"></div>
</main>

<input type="file" id="crmFile" accept=".csv,text/csv" hidden>

<script>
/* CRM — built the first time the section is opened, not on page load. */
window.dashInit.crm = function(){
"use strict";
__APP__
};
</script>
'''

# The page-head undo button mirrors the toolbar one, so the control is reachable
# without hunting for the view that happens to be open.
js += '''

/* The page head carries its own undo button; keep it in step with the engine. */
(function(){
  var b=document.getElementById("crmUndo");
  b.addEventListener("click",function(){ undo(); });
  var _r=render;
  render=function(){ _r(); b.disabled=!S.undo.length;
    b.title=S.undo.length?"Geri al: "+S.undo[S.undo.length-1].label:"Geri alınacak işlem yok"; };
  render();
})();
'''

out = HEAD.replace('__APP__', js)
open(os.path.join(ROOT, 'dash_sec_crm.html'), 'w', encoding='utf-8').write(out)
print('dash_sec_crm.html  %d KB' % (len(out) // 1024))
