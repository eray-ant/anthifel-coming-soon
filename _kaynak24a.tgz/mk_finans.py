#!/usr/bin/env python3
"""
mk_finans.py — one-off: fold Finance's cash panel into the Finans section.

Finance handed over a standalone page (`legacy/finance-panel.html`) that is a
browser copy of `Anthifel_Finansal_Model.xlsx`: 36 months, two scenarios, 106
expense lines, and a cash line that recomputes as you switch a line off or edit
it. The engine is not touched. What changes is the housing and one thing the
handover asked for explicitly:

  README §1  "Panel salt istemci. Dashboard'a gömerken off/on/edits/custom
              durumunu kendi kalıcı katmanınızda tutun."
  README §2  "localStorage kullanılmadı — bilinçli. Kalıcılık dashboard'un işi."

So persistence is added here, in the dashboard, and nowhere else. Today that is
this browser; the shape written out is exactly the one Finance's export/import
already speaks, so moving it to the Sheet later is a change of one function.

Three mechanical changes, same as the CRM and the planner:

  ids     prefixed. "tiles", "bar", "reset", "months" belong to nobody in a
          document that holds four applications.
  scope   the stylesheet is confined to #fin at build time.
  timing  nothing is computed until the section is opened.

NOT A GENERATOR ANY MORE — READ THIS BEFORE RUNNING IT
------------------------------------------------------
This produced the first version of `dash_sec_finans.html` and is kept for the
record: it says what was changed in the port and what was left alone. The
section has since been worked on by hand — the lines-first view, the category
totals, the column headings, the SVG icons and the fixed-cost screen are all
newer than this file. **Running it will overwrite that work.** If Finance ships
a new payload, take the payload across; do not regenerate the section.

  python3 mk_finans.py
"""

import os, re

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(ROOT, 'legacy', 'finance-panel.html')

raw = open(SRC, encoding='utf-8').read()
css = re.search(r'<style>\n?(.*?)</style>', raw, re.S).group(1)
app = re.search(r'<script>\n?(.*?)</script>', raw, re.S).group(1)
body = re.search(r'<body>(.*?)</div><script>', raw, re.S).group(1)

# ── 1. the page's own frame goes; the dashboard supplies one ─────────────────
for pat in (r'\*\{[^}]*\}\n?', r'body\{[^}]*\}\n?', r'\.wrap\{[^}]*\}\n?',
            r'h1\{[^}]*\}\n?', r'\.sub\{[^}]*\}\n?'):
    css = re.sub(pat, '', css, count=1)

# The panel declared its custom properties on :root. Confined to #fin that
# selector matches nothing and every border, muted label and chart colour below
# it resolves to nothing — the panel comes up flat, with no error anywhere.
css = re.sub(r'^:root\{', '#fin{', css, count=1, flags=re.M)
# and panel interfaces do not go dark.
css = re.sub(r'@media\(prefers-color-scheme:dark\)\{:root\{[^}]*\}\}\n?', '', css, count=1)
if ':root' in css:
    raise SystemExit(':root survived; it would be scoped away at build time')

# The panel styles bare <button>. Confined to #fin that becomes "#fin button",
# which outranks the shell's .btn on specificity and repaints the flow strip and
# every dashboard button that shares this section.
css = re.sub(r'(?m)^button(\{|:hover|\.on)',
             lambda m: 'button:not(.btn):not([data-flow])' + m.group(1), css)

# ── 2. ids ───────────────────────────────────────────────────────────────────
IDS = ['tiles', 'pMevcut', 'pPaket', 'allOn', 'reset', 'realCash', 'exp', 'imp',
       'impf', 'sHalf', 'sFull', 'ch', 'tip', 'months']
def finid(i):
    return 'fin' + i[0].upper() + i[1:]

for i in IDS:
    n = finid(i)
    app = app.replace("getElementById('%s')" % i, "getElementById('%s')" % n)
    app = app.replace('getElementById("%s")' % i, 'getElementById("%s")' % n)
    body = body.replace('id="%s"' % i, 'id="%s"' % n)

# The panel also passes ids around as bare strings, through two helpers and one
# equality check. Renaming only the getElementById calls leaves those dangling,
# and the buttons come up dead with no error until you click one.
app = re.sub(r"(onclickBind\(')(\w+)(')",
             lambda m: m.group(1) + finid(m.group(2)) + m.group(3), app)
app = re.sub(r"(seg\(')(\w+)(','?)(\w+)(')",
             lambda m: m.group(1) + finid(m.group(2)) + m.group(3) + finid(m.group(4)) + m.group(5), app)
app = app.replace("e.target.id==='realCash'", "e.target.id==='finRealCash'")

left = re.findall(r"'(%s)'" % '|'.join(IDS), app)
if left:
    raise SystemExit('id strings still unrenamed: ' + ', '.join(sorted(set(left))))

# Its two document-level listeners must not fire while another section is open.
for ev in ('click', 'change'):
    app = app.replace(
        "document.addEventListener('%s',e=>{" % ev,
        "document.addEventListener('%s',e=>{\n  if(document.getElementById('sec-finans').hidden)return;" % ev)

# The panel reaches across the document for its own rows; inside one document
# those selectors have to be confined to its own subtree.
app = re.sub(r"document\.querySelectorAll\('(\.[^']+)'\)",
             r"document.querySelectorAll('#fin \1')", app)
app = re.sub(r"document\.querySelector\('(\.[^']+)'\)",
             r"document.querySelector('#fin \1')", app)

# The panel's own `.sec` is a category heading inside a month row. The dashboard
# shell uses `.sec` for its section panes and counts them to prove one is open,
# so the two cannot share the name.
css = css.replace('\n.sec{', '\n.fsec{')
app = app.replace('<div class="sec">', '<div class="fsec">')

# ── 3. persistence, which the handover asked the dashboard to provide ────────
persist = '''

/* ── persistence ──────────────────────────────────────────────────────────
   Finance's panel exports { mode, real, off, on, edits, custom } and reads the
   same shape back. That is the whole state, so that is what is stored: no
   second format, no mapping to keep in step. It lives in this browser for now.
   When the Sheet is live, save() and load() are the only two functions that
   change — and the file the panel exports stays interchangeable with what is
   stored, which is what makes the move safe.
   ──────────────────────────────────────────────────────────────────────── */
var FIN_KEY = 'anth_fin_model_v1';

function finState(){
  return { mode: mode, real: real, scen: scen,
           off: Array.from(off), on: Array.from(on),
           edits: edits, custom: custom };
}
function finSave(){
  try{ localStorage.setItem(FIN_KEY, JSON.stringify(finState())); }
  catch(e){ window.toast('Tarayıcı kaydetmeye izin vermedi.'); }
  finStamp();
}
function finLoad(){
  var raw;
  try{ raw = localStorage.getItem(FIN_KEY); }catch(e){ return false; }
  if(!raw) return false;
  try{
    var d = JSON.parse(raw);
    if(d.mode) mode = d.mode;
    if(d.scen) scen = d.scen;
    if(typeof d.real === 'boolean') real = d.real;
    off = new Set(d.off || []);
    on = new Set(d.on || []);
    edits = d.edits || {};
    custom = d.custom || [];
    custom.forEach(function(c){ if(c.no >= nextNo) nextNo = c.no + 1; });
    return true;
  }catch(e){ return false; }
}
function finStamp(){
  var el = document.getElementById('finSaved');
  if(!el) return;
  var n = off.size + on.size + Object.keys(edits).length + custom.length;
  el.textContent = n ? n + ' değişiklik kayıtlı' : 'Değişiklik yok';
}

/* Every path that touches the model already calls render(); saving there means
   no button has to remember to. */
var _finRender = render;
render = function(){ _finRender(); finSave(); };

window.dashInit.finans = function(){
  finLoad();
  document.getElementById('finPMevcut').classList.toggle('on', mode === 'mevcut');
  document.getElementById('finPPaket').classList.toggle('on', mode === 'paket');
  document.getElementById('finSHalf').classList.toggle('on', scen === 'si');
  document.getElementById('finSFull').classList.toggle('on', scen === 'sj');
  document.getElementById('finRealCash').checked = real;
  render();
};
'''

# The panel drew itself on load; now the dashboard says when.
app = re.sub(r'\nrender\(\);\s*$', persist, app)
if 'window.dashInit.finans' not in app:
    raise SystemExit('could not find the panel\'s initial render() call')

# ── 4. the section ───────────────────────────────────────────────────────────
body = body.strip()
# The extraction stops at `</div><script>`, which is the closing tag of the page's
# own <div class="wrap">. Its opening tag is still at the top of what we took, so
# the section would ship with one unclosed div — everything placed after the panel
# ends up *inside* it. That is invisible until a second sibling exists: the Defter
# and Sabit flows became children of the model flow and disappeared with it.
body = re.sub(r'^<div class="wrap">\s*', '', body, count=1)
body = re.sub(r'<h1>.*?</h1>\s*', '', body, count=1, flags=re.S)
body = re.sub(r'<p class="sub">.*?</p>\s*', '', body, count=1, flags=re.S)

# and it must never happen again silently.
_open = len(re.findall(r'<div\b', body))
_close = len(re.findall(r'</div>', body))
if _open != _close:
    raise SystemExit('panel markup is unbalanced: %d <div> vs %d </div>' % (_open, _close))

OUT = '''<style>
/* ============================================================
   Finans — nakit modeli

   Finance's panel, re-housed. The engine, the payload and the three formulas
   are theirs and are untouched; `Anthifel_Finansal_Model.xlsx` is still the one
   true source and the payload is regenerated there, not here.

   Everything is confined to #fin at build time: the panel's class names are
   .card, .bar, .dot, .note, which four other things in this document also use.
   ============================================================ */
%s
/* ---------- housing ---------- */
#fin{font-size:14px;line-height:1.55;color:#1A1815}
#fin .pnav{display:flex;align-items:center;gap:3px;flex-wrap:wrap;background:#FFFFFF;
  border:1px solid rgba(26,24,21,.10);border-radius:3px;padding:7px 9px;margin-bottom:14px}
#fin .pnav button{background:none;border:1px solid transparent;border-radius:2px;padding:7px 12px;
  font-family:inherit;font-size:12.5px;font-weight:500;color:#57534C;cursor:pointer;white-space:nowrap;
  transition:background .14s,color .14s}
#fin .pnav button:hover{background:#FAF9F6;color:#1A1815}
#fin .pnav button[aria-selected="true"]{background:#FAF7F4;color:#1A1815;font-weight:600;
  box-shadow:inset 0 -2px 0 #B84C2E}
#fin .flow{display:none}
#fin .flow.on{display:block}
</style>

<div class="phead">
  <div>
    <h1>Finans</h1>
    <p>Nakit modeli ve basit gelir/gider defteri.<br>
       Model Finance'ın; buradaki değişiklikler bu tarayıcıda saklanır.</p>
    <div class="status"><span class="led" id="finLed"></span><span id="finSaved">Değişiklik yok</span></div>
  </div>
  <div class="acts">
    <button class="btn btn-s" id="fiCsv" type="button">Defteri CSV indir</button>
  </div>
</div>

<div id="fin">
  <nav class="pnav" role="tablist">
    <button type="button" role="tab" data-flow="model" aria-selected="true">Nakit modeli</button>
    <button type="button" role="tab" data-flow="defter" aria-selected="false">Defter</button>
    <button type="button" role="tab" data-flow="sabit" aria-selected="false">Sabit giderler</button>
  </nav>

  <div class="flow on" data-flow="model">
%s
  </div>

  <div class="flow" data-flow="defter">
__DEFTER__
  </div>

  <div class="flow" data-flow="sabit">
__SABIT__
  </div>
</div>

<script>
/* Finance's cash panel, wrapped. The panel was handed over as a page, so its
   names were top-level globals — and Icerik, which has to stay top-level, has a
   render() of its own. Loading order decided which one won. Nothing here is
   reached from markup, so a closure costs nothing and removes the collision. */
(function(){
%s
})();
</script>

<script>
/* The flow strip, and the ledger that was here before the model arrived. */
(function(){
  var box = document.getElementById('fin');
  var tabs = [].slice.call(box.querySelectorAll('.pnav button'));
  var flows = [].slice.call(box.querySelectorAll('.flow'));
  tabs.forEach(function(t){
    t.addEventListener('click', function(){
      tabs.forEach(function(x){ x.setAttribute('aria-selected', String(x === t)); });
      flows.forEach(function(f){ f.classList.toggle('on', f.getAttribute('data-flow') === t.getAttribute('data-flow')); });
    });
  });
})();
__LEDGER_JS__
</script>
''' % (css.strip(), body, app.strip())

open(os.path.join(ROOT, 'dash_sec_finans_new.html'), 'w', encoding='utf-8').write(OUT)
print('dash_sec_finans_new.html  %d KB' % (len(OUT) // 1024))
