# Lansman günü — sıra

Bu dosya lansman sabahı açılıp yukarıdan aşağı takip edilmek için yazıldı.
Karar içermez; kararlar zaten verilmiş olacak. Yalnızca sıra ve doğrulama.

**Öncesinde kapalı olması gerekenler.** Aşağıdaki dördü tamam değilse lansman
başlamaz:

- Legal'in üç bilgisi girilmiş ve `python3 build.py` production'ı **hata
  vermeden** yazıyor (`DEV-067`)
- `FORM_LIVE = true` ve uçtan uca bir tur iki dilde yapılmış
- Resend gizlilik metnine ve §23'e işlenmiş, Legal onaylamış
- Blog altyapısı çalışıyor ve ilk yazı yayımlanmış (`DEV-043`, `DEV-044`)

---

## 1 · Son build ve testler

```
python3 build.py
```

Production için **hiçbir uyarı çıkmamalı**. "NOT WRITTEN TO PRODUCTION" satırı
görünüyorsa dur: Legal'in bilgileri eksik demektir.

Sonra dokuz süit, sırayla:

```
node check-responsive.js     → NO OVERFLOW ANYWHERE
node check-behaviour.js dist/production/index.html
node check-code.js dist/production/index.html
node check-links.js
node check-legal.js
node check-service.js
node check-blog.js
node check-dash.js
node mobile-pass.js
```

Biri bile kırmızıysa lansman durur. Ekran görüntülerine de bak — yeşil bir süit
ile bozuk görünen bir sayfa birbirini dışlamaz.

---

## 2 · `BLOG_PREFIX` boşaltılır

Blog editörünün Script Properties'inde `BLOG_PREFIX` şu an `preview/`. Bu
değerle blog **görünmeyen bir yere** yayımlar.

- Apps Script → blog projesi → Proje Ayarları → `BLOG_PREFIX` **boş** olsun
- Editördeki `SITE_PREFIX` de aynı anda boşaltılır — ikisi eşit kalmak zorunda

Bu adım unutulursa lansmandan sonra yayımlanan hiçbir yazı sitede görünmez ve
sebebi haftalarca fark edilmez.

---

## 3 · Production köke yazılır

`dist/production/` içeriği deponun **köküne** kopyalanır. Yani:

| Nereden | Nereye |
|---|---|
| `dist/production/index.html` | `index.html` — coming-soon'un yerine |
| `dist/production/ai-readiness-audit.html` | `ai-readiness-audit.html` |
| `dist/production/privacy.html` · `terms.html` · `cookies.html` | kök |
| `dist/production/blog/` | `blog/` |
| `dist/production/en/` | `en/` |
| `dist/production/dashboard/` | `dashboard/` |

**Coming-soon sayfası silinmez, üzerine yazılır.** `index.html` production
build'in kendisi olur.

---

## 4 · `/preview/` silinir

`preview/` dizininin tamamı depodan kaldırılır. İki sebep: aynı içeriğin iki
adreste durması aramada ikisini birden zayıflatır, ve `?form=live` anahtarı
yalnızca preview build'inde vardır — onu yayında bırakmak, formu açık bırakmakla
aynı kapıyı ikinci kez açmaktır.

`robots.txt` içindeki `Disallow: /preview/` satırı da aynı anda silinir.

---

## 5 · Panel yönlendirmeleri

`dashboard/blog/index.html` ve `dashboard/crm/index.html` şu an yönlendirme
stub'ı. Production build bunların yerine geçer; 3. adımda `dashboard/` dizini
kopyalandığında kendiliğinden olur. Kopyalandığını gözle doğrula.

---

## 6 · Deploy

`deploy.command`'a çift tıkla. `DEPLOY_MSG.txt` içine lansman mesajını önceden
yaz.

Sonra **DigitalOcean → Apps → anthifel-main → Activity** ekranından deploy'un
commit hash'iyle çıktığını doğrula. Bu kural: deploy, Activity'de hash görülene
kadar tamamlanmış sayılmaz.

---

## 7 · Yayındaki siteyi oku

```
check-live.command   → https://anthifel.com/
```

Sunucunun döndürdüğü her sayfa, deploy edilen dosyalarla **byte byte** aynı
olmalı. Ayrıca kontrol eder: yer tutucu kalmamış, endpoint gerçek adres,
`FORM_TEST` production'da **false**, footer her sayfada, ve `noindex`
**kalkmış**.

`noindex` hâlâ duruyorsa site aramaya hiç girmez. Bu adımın en pahalı hatası.

---

## 8 · Elle son tur

Telefondan ve masaüstünden, iki dilde:

- Ana sayfa açılıyor, hero satırı yazılıyor
- Menü ve alt bilgi her sayfada
- Hazırlık testi: adres → kod maili → kod → on iki soru → sonuç
- Sonuç maili ve lead maili geliyor
- Görüşme bandı açılıyor ve takvim yükleniyor
- Hizmet sayfası ve üç hukuki sayfa açılıyor
- Blog ve ilk yazı açılıyor
- `anthifel.com/preview/` **404 veriyor**

---

## 9 · Lansmandan sonraki ilk gün

- **Resend → Logs**: gerçek ziyaretçilere giden maillerin teslim edildiğini
  gözle doğrula. İlk gün itibar en kırılgan olduğu andır
- **Google Search Console**: alan adını ekle, site haritasını gönder
- Tabloya düşen ilk gerçek satırı kontrol et — rıza zaman damgası ve metni
  doğru mu
- İlk lead mailini aç ve **on iki cevabın orada olmadığını** bir kez daha
  gözle doğrula

---

## Geri dönüş

Bir şey ters giderse: eski `index.html` git geçmişinde duruyor. Son commit geri
alınır ve coming-soon sayfası bir dakikada geri gelir. Veri kaybı olmaz —
tabloda ne varsa kalır, mailler zaten gitmiştir.
