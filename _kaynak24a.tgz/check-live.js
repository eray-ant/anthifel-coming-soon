/**
 * check-live.js — Anthifel
 *
 * The one check that reads the server instead of the build.
 *
 * Every other suite walks files in a container. That is fast and it is right
 * for almost everything, but it cannot see the one thing that matters on the
 * day: what the server actually returns. `check-comingsoon.js` was green while
 * the served page still carried a sentence we had retired, and on 12 August
 * half a day went into arguing about an animation that was live and correct,
 * because nobody could read the served HTML.
 *
 *   node check-live.js https://anthifel.com/preview/
 *   node check-live.js https://anthifel.com/            (at launch)
 *
 * It fetches — no browser, no JavaScript — and asks the questions a fetch can
 * answer honestly:
 *
 *   · every page responds 200
 *   · the served HTML is byte-identical to the build in dist/
 *   · no placeholder survived
 *   · the endpoint is a real address
 *   · the form switch matches the build, and the live-test switch is stamped out
 *   · every page carries the full footer
 *   · noindex is present on the preview and absent on production
 *
 * The byte comparison is the point. Everything else follows from it — if the
 * served file and the built file are the same bytes, every other suite's result
 * applies to what visitors are getting. If they are not, nothing else does.
 */
const https = require('https');
const path = require('path');
const fs = require('fs');

const BASE = (process.argv[2] || 'https://anthifel.com/preview/').replace(/\/?$/, '/');
const DIST = path.resolve(process.argv[3] ||
  (BASE.includes('/preview/') ? 'dist/preview' : 'dist/production'));

const PAGES = ['', 'ai-readiness-audit.html', 'privacy.html', 'terms.html',
               'cookies.html', 'blog/', 'en/blog/'];
const LOCAL = { '': 'index.html', 'blog/': 'blog/index.html', 'en/blog/': 'en/blog/index.html' };

let pass = 0, fail = 0, warn = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };
const note = m => { warn++; console.log(`  · ${m}`); };

/**
 * Say what differs, not merely that something does.
 *
 * Two byte counts are a fact and not an answer: on 13 August seven pages came
 * back red at once and the next hour went into guessing which of three possible
 * causes it was. Everything needed to answer that is in the two buffers, so it
 * is printed rather than reasoned about — the first place they part company,
 * what each side has there, and whether the served copy looks like an older
 * build of ours or like something that was changed in transit.
 */
function diff(name, served, built) {
  const a = served.toString('utf8'), b = built.toString('utf8');
  let i = 0;
  const n = Math.min(a.length, b.length);
  while (i < n && a[i] === b[i]) i++;

  // Where the difference starts, in a form that can be found in an editor.
  const line = b.slice(0, i).split('\n').length;
  const at = Math.max(0, i - 40);
  const cut = t => JSON.stringify(t.slice(at, at + 140)).slice(1, -1);
  console.log(`      first difference at byte ${i}, around line ${line}`);
  console.log(`      served: …${cut(a)}`);
  console.log(`      built : …${cut(b)}`);

  // The three causes worth telling apart at a glance.
  const marks = [
    ['a build token the server still has', /__[A-Z_]+__/, a],
    ['an injected script tag the build has no copy of',
     /<script[^>]+src="https?:\/\/(?!script\.google)/, a],
  ];
  marks.forEach(([what, re, hay]) => { if (re.test(hay)) console.log(`      · served copy carries ${what}`); });

  // A stale deploy and an altered file look the same in a byte count and very
  // different here: a stale deploy differs in the copy, an alteration differs
  // in the markup around it.
  const older = /7 working days|Seven working days|2–4 weeks|Genel Bakış/.test(a);
  if (older) console.log('      · served copy still has wording this build replaced — it is an older deploy');

  // The cheapest question of all, asked last because it is only interesting
  // when the answer is yes: is the served file this exact build with something
  // stuck on the end? That is a different problem from a stale deploy and gets
  // looked for in a different place.
  if (served.length > built.length && served.slice(0, built.length).equals(built)) {
    console.log(`      · the served copy is this build plus ${served.length - built.length} bytes appended`);
  }
}

/* Cloudflare's Email Address Obfuscation, seen on 13 August.
 *
 * Every mailto link and every bare address in the served HTML comes back as
 * `/cdn-cgi/l/email-protection` with the real address hex-encoded in an
 * attribute, plus a script to decode it in the browser. The origin file is
 * untouched — the rewrite happens in front of it — so a byte comparison fails
 * on six pages at once and says nothing about the deploy.
 *
 * These two functions bring both sides to the same shape: every address, however
 * it is written, becomes the word EMAIL. What is left is compared honestly, and
 * whether Cloudflare is doing this at all is reported separately, because it is
 * a finding rather than a nuisance: it puts a third party in front of the site
 * and injects a script into pages that are supposed to load nothing.
 */
let cloudflare = false;

function deCloudflare(html) {
  return deEmail(html
    .replace(/<script[^>]*cdn-cgi[^>]*>\s*<\/script>/g, '')
    .replace(/<a\b[^>]*(?:href="\/cdn-cgi\/l\/email-protection[^"]*"|class="__cf_email__")[^>]*>[\s\S]*?<\/a>/g, 'EMAIL')
    .replace(/<span class="__cf_email__"[^>]*>[\s\S]*?<\/span>/g, 'EMAIL'));
}

function deEmail(html) {
  return html
    .replace(/<a\b[^>]*href="mailto:[^"]*"[^>]*>[\s\S]*?<\/a>/g, 'EMAIL')
    .replace(/[\w.+-]+@anthifel\.com/g, 'EMAIL');
}

function get(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'anthifel-check-live' } }, res => {
      if ([301, 302, 307, 308].includes(res.statusCode) && res.headers.location && redirects < 4) {
        res.resume();
        return resolve(get(new URL(res.headers.location, url).toString(), redirects + 1));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks), headers: res.headers }));
    }).on('error', reject);
  });
}

(async () => {
  const isPreview = BASE.includes('/preview/');
  console.log(`\n— ${BASE} —`);
  console.log(`  comparing against ${path.relative(process.cwd(), DIST)}\n`);

  let index = null;
  const journal = {};

  for (const p of PAGES) {
    const url = BASE + p;
    const localName = LOCAL[p] || p;
    const localPath = path.join(DIST, localName);
    let res;
    try { res = await get(url); }
    catch (e) { ok(`${p || '/'} responds`, false, e.message); continue; }

    ok(`${p || '/'} responds 200`, res.status === 200, 'HTTP ' + res.status);
    if (res.status !== 200) continue;

    const served = res.body;
    if (p === '') index = served.toString('utf8');
    if (p === 'blog/' || p === 'en/blog/') journal[p] = served.toString('utf8');

    /* The two Journal indexes are not the build's to prove.
       build.py writes them so the suites have something to open, but the pages
       a reader gets are written by the publisher from blog/_tpl-index.html —
       and the shell stamp goes into the *template*, not into the build's
       fallback copy. So these two can never be byte-identical, and asking for it
       here contradicts the Journal block further down, which asserts the
       opposite: matching the build means the publisher has not run and the
       reader is looking at an empty Journal. One of the two had to go, and it is
       this one — a comparison that is designed to fail teaches people to ignore
       a red line, which is the most expensive thing a suite can do. */
    if (p === 'blog/' || p === 'en/blog/') {
      note(`${p} — yayıncının kopyası, build ile karşılaştırılmıyor (aşağıda kendi kontrolü var)`);
      continue;
    }

    if (!fs.existsSync(localPath)) {
      note(`${p || '/'} — nothing to compare against at ${localName}, skipped`);
      continue;
    }
    const built = fs.readFileSync(localPath);
    const same = served.equals(built);
    if (same) {
      ok(`${p || '/'} is byte-identical to the build`, true);
      continue;
    }
    /* Not identical. Before calling it a failure, ask whether the difference is
       something in front of the origin rewriting our HTML rather than our
       build being stale — the two look the same in a byte count and need
       opposite responses. */
    const a = deCloudflare(served.toString('utf8'));
    const b = deEmail(built.toString('utf8'));
    if (a === b) {
      cloudflare = true;
      ok(`${p || '/'} is the build, with every email address rewritten in front of it`, true);
      continue;
    }
    ok(`${p || '/'} is byte-identical to the build`, false,
       `served ${served.length}, built ${built.length}`);
    diff(p || '/', served, built);
  }

  if (!index) {
    console.log('\n  the home page did not load; nothing else can be checked\n');
    process.exit(1);
  }

  console.log('\n— what the served page says about itself —');
  ok('no placeholder survived', !/__[A-Z_]+__/.test(index),
     (index.match(/__[A-Z_]+__/g) || []).slice(0, 3).join(' '));
  ok('the endpoint is a real address',
     /script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec/.test(index));
  /* 20 August, launch. This asserted the form was *off* — right up to the
     moment it was supposed to be on. What the served page has to agree with is
     the build that was deployed, not a state we happened to be in last week, so
     the expectation is read from dist/ and compared against what the server
     returned. A drift either way is the failure: a live site with the form shut,
     or a preview build serving a live form. */
  const localIndex = fs.existsSync(path.join(DIST, 'index.html'))
    ? fs.readFileSync(path.join(DIST, 'index.html'), 'utf-8') : '';
  const builtLive = /var FORM_LIVE\s*=\s*true;/.test(localIndex);
  const servedLive = /var FORM_LIVE\s*=\s*true;/.test(index);
  if (localIndex) {
    ok(`the form is ${builtLive ? 'open' : 'switched off'}, the same as the build`,
       servedLive === builtLive, `served=${servedLive} built=${builtLive}`);
  } else {
    note('no local build to compare the form switch against; reporting what is served');
    ok(`the served form is ${servedLive ? 'open' : 'switched off'}`, true);
  }
  ok(`the live-test switch is ${isPreview ? 'available here' : 'stamped out'}`,
     new RegExp('var FORM_TEST {2}= ' + (isPreview ? 'true' : 'false') + ';').test(index));
  ok('the hero line is there', /id="heroEyebrow"/.test(index) && /twghost/.test(index));
  ok('the full footer is there', /class="ftr-g"/.test(index) && /class="soc"/.test(index));
  ok(`noindex is ${isPreview ? 'present' : 'absent'}`,
     /content="noindex/.test(index) === isPreview);

  /* The Journal, which is the one place where matching the build is the wrong
     answer.

     build.py writes blog/index.html and en/blog/index.html so the suites and the
     local preview have something to open, and its copies have no cards on them —
     the cards come from the publisher, inside Google, on Yayımla. So "byte-
     identical to the build" on these two means the publisher has not written
     since the last deploy, and the reader is looking at an empty Journal. On
     19 August that state was diagnosed three times in one day as three different
     bugs. It is asked directly now. */
  console.log('\n— the Journal is the publisher\'s copy, not the build\'s —');
  for (const p of ['blog/', 'en/blog/']) {
    const served = journal[p];
    if (!served) { note(`${p} did not load; nothing to say about it`); continue; }
    const localPath = path.join(DIST, LOCAL[p]);
    const shell = fs.existsSync(localPath) ? fs.readFileSync(localPath, 'utf-8') : null;
    if (shell && deCloudflare(served) === deEmail(shell)) {
      ok(`${p} carries published pieces`, false,
         'yayıncının kopyası değil, build\'in boş kabuğu — panelde "Journal\'ı yeniden yaz"');
      continue;
    }
    /* Not the shell. Say what is on it, because "different from the build" is
       not the same as "has articles on it". */
    const links = (served.match(/href="[^"]*\/(?:\?lang=tr)?"/g) || []).length;
    ok(`${p} carries published pieces`, /GRID:START/.test(served) && links > 0,
       `bağlantı ${links}`);

    /* And the covers, which is the one that got us. 20 August: the launch moved
       the site to the root and /preview/ was deleted with it — including
       preview/blog/img/, where every cover the editor had uploaded lived. The
       build's blog/img/ carries only the share-default placeholder, so the
       Journal came back with the cards intact and every picture broken. The
       cards are the publisher's, the covers are the repository's, and nothing
       was checking that the second half arrived. Fetched rather than inferred:
       an <img> whose src 404s is exactly the failure, and only the server can
       say. */
    const covers = [...served.matchAll(/<img[^>]+src="([^"]+\.webp)"/g)]
      .map(m => m[1]).filter(u => !/^data:/.test(u));
    const uniq = [...new Set(covers)].slice(0, 6);
    if (!uniq.length) {
      note(`${p} — no cover images on the page to check`);
    } else {
      const missing = [];
      for (const u of uniq) {
        const abs = u.startsWith('http') ? u
          : new URL(u.replace(/^\.\//, ''), BASE + p).toString();
        try { const r = await get(abs); if (r.status !== 200) missing.push(`${u} → ${r.status}`); }
        catch (e) { missing.push(`${u} → ${e.message}`); }
      }
      ok(`${p} covers actually load`, missing.length === 0, missing.join(', '));
    }
  }

  if (cloudflare) {
    console.log('\n— something is rewriting our HTML in front of the origin —');
    console.log('  Cloudflare Email Address Obfuscation is on. Every address is replaced with');
    console.log('  /cdn-cgi/l/email-protection and a decoding script is injected into the page.');
    console.log('');
    /* 20 August. The first line here used to say the privacy notice was made
       false by this, and that was an overstatement written before anyone had
       read the notice back. What the notice actually promises is about
       *analytics*: nothing analytics-related is loaded until you answer, not
       one request to Google, nothing written to your device. The decode script
       is served from our own address under /cdn-cgi/, sets no cookie, and is
       not analytics — so the published text still holds. Saying otherwise sends
       somebody to Legal with a problem that is not there, which costs more than
       saying nothing. What is left is real, and the middle one is the one that
       matters. */
    console.log('  Three consequences, in the order they matter:');
    console.log('  · with JavaScript off, hello@ and privacy@ read as [email protected].');
    console.log('    privacy@ is the address the privacy notice tells people to write to,');
    console.log('    so this one is worth fixing rather than noting.');
    console.log('  · a byte comparison can no longer prove the deploy on its own.');
    console.log('    Every address is rewritten before the bytes reach the reader.');
    console.log('  · the notice is NOT made false by this. It promises that nothing');
    console.log('    analytics-related loads before consent; the decode script is served');
    console.log('    from our own address, sets no cookie, and is not analytics.');
    console.log('');
    console.log('  Turn it off: Cloudflare dashboard → the anthifel.com zone → Scrape Shield');
    console.log('  → Email Address Obfuscation → off. If the zone is not yours to change,');
    console.log('  it is DigitalOcean fronting the app and the setting is on their side.');
  }

  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed${warn ? `, ${warn} skipped` : ''}\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
