/**
 * check-behaviour.js — Anthifel
 * Functional pass: language switch, menu anchors, link targets, the assessment
 * gate, its consent rules, and the shared heading scale.
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const FILE = 'file://' + path.resolve(process.argv[2] || 'index.html');
let pass = 0, fail = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  page.on('pageerror', e => { if (!/recaptcha|gstatic|google/i.test(String(e))) errs.push(String(e)); });
  // Everything the page tries to send, so the "records nothing" rule can be
  // checked rather than trusted.
  const posted = [];
  page.on('request', r => { if (r.method() === 'POST') posted.push(r.postData() || ''); });
  // And everywhere it tries to go. Fonts are inlined and nothing is loaded from
  // a CDN, so a plain page view must not reach a third party at all: an IP
  // address arriving at someone else's server is a disclosure, whether or not
  // the visitor ever touches the form.
  const offsite = [];
  page.on('request', r => {
    const u = r.url();
    if (!/^(file|data|blob|about):/.test(u)) offsite.push(u.split('?')[0]);
  });
  // The booking modal really does embed Google's schedule. The suite must not
  // depend on Google being up, or reach it at all, so the schedule is answered
  // locally — what is being tested is when the request is made and what it
  // asks for, both of which are ours.
  await page.route('**calendar.google.com/**', r =>
    r.fulfill({ status: 200, contentType: 'text/html', body: '<p>schedule</p>' }));
  await page.goto(FILE, { waitUntil: 'load' });
  await page.waitForTimeout(500);

  console.log('\n— nothing leaves the page on a plain visit —');
  ok('no third-party request on load', offsite.length === 0, offsite.join(' '));

  console.log('\n— dead links —');
  const hrefs = await page.$$eval('a[href]', as => as.map(a => a.getAttribute('href')));
  ok('no href="#" placeholders left', !hrefs.includes('#'), hrefs.filter(h => h === '#').length + ' found');
  for (const a of new Set(hrefs.filter(h => h.startsWith('#') && h.length > 1))) {
    ok(`anchor ${a} resolves`, await page.$(a) !== null);
  }
  const dir = path.dirname(path.resolve(process.argv[2] || 'index.html'));
  for (const r of new Set(hrefs.filter(h => /^[\w-]+\.html$/.test(h)))) {
    ok(`${r} exists alongside index.html`, fs.existsSync(path.join(dir, r)));
  }
  // Every internal link is relative, so the same file works at /preview/ and at
  // the root. An absolute /blog was a 404 for every visitor under /preview/.
  const absolute = hrefs.filter(h => h.startsWith('/'));
  ok('no absolute internal links', absolute.length === 0, absolute.join(' '));
  /* The Journal has two front pages. The menu carries the English one as its
     href and the Turkish one in data-href-tr, and both are relative — an
     absolute /blog was a 404 for every visitor under /preview/, and a single
     address was Turkish headlines under an English menu. */
  ok('Blog in the nav points at the blog beside this page',
    hrefs.includes('en/blog/'), hrefs.filter(h => /blog/.test(h)).join(' '));
  ok('…and at the Turkish one for a Turkish reader',
    (await page.$$eval('[data-href-tr]', as => as.map(a => a.getAttribute('data-href-tr'))))
      .includes('blog/?lang=tr'));
  /* Relative, and however many there are. The count was four while the four
     planned titles stood in; the list comes from what is published now, so the
     number is the Journal's business and the shape is this test's. An English
     piece links under en/blog/, which is the same rule one level along. */
  const ftrPosts = hrefs.filter(h => /^(en\/)?blog\/[a-z0-9-]+\/$/.test(h));
  ok('footer blog links are relative too', ftrPosts.length >= 1,
     hrefs.filter(h => /blog\//.test(h)).join(' '));

  console.log('\n— withdrawn words, must stay withdrawn —');
  // Marketing's eighth round. Both of these were live copy; a word that has
  // been retired comes back the moment someone reuses an old block, and the
  // only reliable guard is a test that reads the page.
  const pageText = await page.content();
  for (const w of ['boutique', 'butik']) {
    ok(`"${w}" hiçbir sayfa metninde yok`, !new RegExp(w, 'i').test(pageText));
  }

  console.log('\n— removed by CEO, must stay removed —');
  const body = await page.textContent('body');
  ok('no "Get in touch" section', !/get in touch|i̇letişime geçin/i.test(body));
  ok('no independence statement', !/take no commission|komisyon almay/i.test(body));
  ok('no prices anywhere', !/\$\s?\d|₺\s?\d/.test(body), (body.match(/\$\s?[\d,.]+/g) || []).join(' '));
  // Business changed both on 12 August: the Audit is four working days and the
  // Sprint is 7–12 working days, no longer a range in weeks. The old numbers
  // are asserted absent, because the failure mode here is a page that keeps a
  // stale duration in one place after it was fixed in another.
  // The Turkish half lives in data-tr, so it is checked in the source, not in
  // what the English page happens to be rendering.
  // Comments are not copy. Every check below reads the source, because the
  // Turkish half lives in data-tr and never renders — but a build comment is
  // neither rendered nor shipped as words, and twice in one day a comment
  // explaining a banned phrase has failed the check that bans it.
  const src = (await page.content()).replace(/<!--[\s\S]*?-->/g, '');
  // The word as well as the digit. "Seven working days" sat in the Approach
  // block for a day after every "7 working days" had been replaced, because a
  // check that reads digits does not read English.
  ok('Audit is four working days',
     /4 working days/.test(body) && /4 iş günü/.test(src) &&
     !/7 working days/.test(src) && !/7 iş günü/.test(src) &&
     !/Seven working days/i.test(src) && !/Yedi iş günü/i.test(src));
  /* §12c asked that four days never stand alone, and its three sentences were
     on this page for a few hours. The CEO took them off on 13 August: every
     service now has its own page, the Audit page opens with the same three
     sentences, and a catalogue row that carries a paragraph stops being a
     catalogue. What is asserted here is the consequence — the landing page
     names the duration and nothing else, and the sentences live on the page
     the row opens. If they come back to the row, this fails. */
  ok('the catalogue row is a row, not a paragraph',
     (await page.$('.svc .row:first-child .svc-note')) === null);
  ok('and the narrative is not on this page at all',
     !/the scope did not|kapsam küçülmedi/.test(src));
  ok('the Approach block states no duration of its own',
     !/working days|iş günü/i.test(await page.textContent('.step:nth-child(3) .step-b p')),
     await page.textContent('.step:nth-child(3) .step-b p'));
  ok('Sprint is 7–12 working days, not weeks',
     /7–12 working days/.test(body) && /7–12 iş günü/.test(src) &&
     !/2–4 weeks/.test(src) && !/2–4 hafta/.test(src));
  // Marketing §8.12a replaced the Discovery card's Turkish line when the
  // duration came down. Their words, not a paraphrase of them — and the new
  // line deliberately names no duration, because the service card beside it
  // already does.
  ok('the Discovery card no longer counts in weeks',
     /İşinizin içinde, sizin ekibinizle\./.test(src) &&
     !/İşinizin içinde haftalar\. Üzerinde/.test(src));
  ok('the two long engagements are unchanged',
     /6\+ months/.test(body) && /12\+ months/.test(body) &&
     /6\+ ay/.test(src) && /12\+ ay/.test(src));

  console.log('\n— service rows that go somewhere —');
  // A row is a link only when its page exists. The arrow is the promise; these
  // assertions are what keeps the promise from outliving the page behind it.
  const rows = await page.$$eval('.svc .row', els => els.map(e => ({
    tag: e.tagName.toLowerCase(),
    href: e.getAttribute('href') || '',
    arrow: !!e.querySelector('.arw'),
    title: (e.querySelector('h3') || {}).textContent || '',
  })));
  ok('four service rows', rows.length === 4, String(rows.length));
  const links = rows.filter(r => r.tag === 'a');
  ok('every linked row has an arrow', links.length > 0 && links.every(r => r.arrow));
  ok('no unlinked row shows an arrow',
     rows.filter(r => r.tag !== 'a').every(r => !r.arrow));
  ok('all four rows are links now that all four pages exist',
     links.length === 4, links.length + ' of ' + rows.length);
  ok('each row opens its own service',
     rows.map(r => r.href).join('|') ===
     'ai-readiness-audit.html|discovery-sprint.html|transformation-retainer.html|advisory-board-seat.html',
     rows.map(r => r.href).join('|'));
  for (const r of links) {
    const target = path.resolve(path.dirname(path.resolve(process.argv[2] || 'index.html')), r.href);
    ok(`  ${r.href} exists on disk`, fs.existsSync(target), target);
  }
  // The arrow is invisible until the row is hovered, and it must not take
  // layout with it — otherwise every title shifts under the mouse.
  const arwHidden = await page.$eval('.svc a.row .arw', e => getComputedStyle(e).opacity);
  ok('arrow starts invisible', arwHidden === '0', arwHidden);
  await page.hover('.svc a.row');
  await page.waitForTimeout(320);
  const arwShown = await page.$eval('.svc a.row .arw', e => getComputedStyle(e).opacity);
  ok('arrow appears on hover', Number(arwShown) > 0.9, arwShown);

  console.log('\n— shared heading scale —');
  const [approachH, servicesH] = await Promise.all([
    page.$eval('.step h3', e => getComputedStyle(e).fontSize),
    page.$eval('.row-b h3', e => getComputedStyle(e).fontSize),
  ]);
  ok(`Approach and Services headings match (${approachH})`, approachH === servicesH,
    `approach ${approachH} vs services ${servicesH}`);
  const fams = await Promise.all([
    page.$eval('.step h3', e => getComputedStyle(e).fontFamily),
    page.$eval('.row-b h3', e => getComputedStyle(e).fontFamily),
  ]);
  ok('…and share a family', fams[0] === fams[1], fams.join(' vs '));
  const weights = await Promise.all([
    page.$eval('.step h3', e => getComputedStyle(e).fontWeight),
    page.$eval('.row-b h3', e => getComputedStyle(e).fontWeight),
  ]);
  ok('…and a weight', weights[0] === weights[1], weights.join(' vs '));

  const [approachP, servicesP] = await Promise.all([
    page.$eval('.step p', e => getComputedStyle(e).fontSize),
    page.$eval('.row-b p', e => getComputedStyle(e).fontSize),
  ]);
  ok(`Approach and Services body copy match (${approachP})`, approachP === servicesP,
    `approach ${approachP} vs services ${servicesP}`);

  console.log('\n— full-bleed, no side bands —');
  for (const w of [2560, 1920, 1440]) {
    await page.setViewportSize({ width: w, height: 900 });
    await page.waitForTimeout(200);
    const m = await page.evaluate(() => {
      const q = document.querySelector('.quote');
      const r = q.getBoundingClientRect();
      return {
        doc: document.documentElement.scrollWidth,
        left: Math.round(r.left),
        right: Math.round(window.innerWidth - r.right),
        col: Math.round(document.querySelector('.hero h1').getBoundingClientRect().left),
      };
    });
    ok(`${w}px — dark band runs edge to edge`, m.left === 0 && m.right === 0,
      `left ${m.left}, right ${m.right}`);
    ok(`${w}px — text column stays 1136px, centred`, m.col === Math.round((w - 1136) / 2),
      `text starts at ${m.col}, expected ${Math.round((w - 1136) / 2)}`);
  }
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.waitForTimeout(200);
  ok('1280px — gutter falls back to 72px', await page.evaluate(() =>
    Math.round(document.querySelector('.hero h1').getBoundingClientRect().left) === 72));

  console.log('\n— K47, Brand Guidelines §8 —');
  const visible = await page.evaluate(() => {
    const c = document.body.cloneNode(true);
    c.querySelectorAll('style,script').forEach(e => e.remove());
    // Legal's notice now lives in the consent modal, in full and verbatim. It is
    // not Marketing's copy and rule 2 does not reach it — that conflict is
    // recorded in Anthifel_Website.md and is Legal's and Marketing's to settle.
    // Sweeping it in here would mean this suite failing on a decision it has no
    // say in.
    c.querySelectorAll('#povl').forEach(e => e.remove());
    // data-en / data-tr carry the copy for the language that is not showing,
    // so they have to be swept too or half the site escapes the check.
    let extra = '';
    c.querySelectorAll('[data-en]').forEach(e => {
      extra += ' ' + (e.getAttribute('data-en') || '') + ' ' + (e.getAttribute('data-tr') || '');
    });
    return (c.textContent + extra);
  });
  ok('rule 2 — no em dash in any customer-facing copy', !visible.includes('\u2014'),
    (visible.match(/.{40}\u2014.{40}/) || [''])[0]);
  ok('rule 1 — no "wrong"', !/\bwrong\b/i.test(visible));
  ok('rule 1 — no "yanlış"', !/yanlış/i.test(visible));
  ok('rule 3 — the withdrawn sentence is gone',
    !/biggest risk|en büyük risk/i.test(visible));
  ok('rule 3 — no "not with the technology" construction',
    !/not with the technology|teknolojiyle değil|teknolojiyi değil/i.test(visible));

  console.log('\n— §8 copy, verbatim —');
  for (const s of [
    'AI transformation is not one department’s job. It reaches the whole company at once.',
    'AI dönüşümü tek bir birimin işi değil. Şirketin tamamını aynı anda ilgilendiriyor.',
    // The band lasted one afternoon. §9a asked for the strapline as its own
    // element; built, it read as a caption under the headline rather than the
    // line the brand leads with, and the CEO put it back. So the full sentence
    // is one string again — in English verbatim, in Turkish translated.
    'We organise the human side of AI transformation inside companies. It is new for everyone, and we stand with you while every part of the business adapts.',
    'Şirketlerin içinde AI dönüşümünün insan tarafını organize ediyoruz. Dönüşüm herkes için yeni. Şirketinizin bütün birimleri AI’a uyum sağlarken yanınızdayız.',
  ]) ok(`§8: "${s.slice(0, 42)}${s.length > 42 ? '…' : ''}"`, visible.includes(s));

  console.log('\n— Also block is not bold —');
  ok('Executive Workshop is not bold', await page.evaluate(() => {
    const els = [...document.querySelectorAll('.also-b b, .also-b strong')];
    return els.length === 0;
  }));

  console.log('\n— privacy opens in place —');
  await page.click('#aIntro [data-start]');
  await page.waitForTimeout(500);
  ok('modal hidden until asked', await page.isHidden('#povl'));
  await page.check('#consent');
  await page.click('#f-consent label a[href="privacy.html"]');
  await page.waitForTimeout(300);
  ok('clicking the policy opens the modal', await page.isVisible('#povl'));
  ok('the page did not navigate away', page.url().includes('index.html'));
  ok('the consent tick survived', await page.isChecked('#consent'));
  ok('modal carries the policy copy', /privacy@anthifel.com/.test(await page.textContent('#povl')));
  ok('full page still reachable from the modal',
    await page.$('#povl a[href="privacy.html"][target="_blank"]') !== null);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(250);
  ok('Escape closes it', await page.isHidden('#povl'));
  await page.uncheck('#consent');          // hand the form back as it was found
  await page.click('#cancel');
  await page.waitForTimeout(400);

  console.log('\n— the call is booked in the page —');
  const SCHED = 'calendar.google.com/appointments/schedules/';
  const meetHrefs = await page.$$eval('[data-meet]', as => as.map(a => a.getAttribute('href')));
  /* One, from 20 August: the hero. The footer's "Book a call" was the second
     and now goes to /meet/ instead — the CEO's call, and the reason holds: the
     footer is on every page including the Journal and the legal pages, and
     "open a band further down this page" is a different promise on each of
     them. What is still asserted is that whatever keeps `data-meet` points at
     the real schedule, because that attribute is what opens the band. */
  ok('the footer sends people to the booking page',
     (await page.$$eval('.ftr a[href$="meet/"]', a => a.length)) === 1,
     await page.$$eval('.ftr a', a => a.map(x => x.getAttribute('href')).join(' ')));
  ok('every booking link points at the schedule', meetHrefs.length === 1 &&
    meetHrefs.every(h => h && h.includes(SCHED)), meetHrefs.join(' | '));
  ok('the dead meet/ link is gone', !meetHrefs.some(h => /(^|\/)meet\/$/.test(h || '')));
  ok('one URL, not three', new Set(meetHrefs).size === 1);
  ok('the band is closed until asked', await page.isHidden('#meet'));
  // The whole point of building our own frame: Google is not contacted until the
  // visitor asks for the calendar. A src sitting in the markup would break that
  // and look identical on screen.
  ok('no calendar request before the click',
    !offsite.some(u => u.includes('calendar.google.com')), offsite.join(' '));
  ok('no iframe in the page before the click', await page.$('#meet iframe') === null);
  await page.click('.hero-cta a[data-meet]');
  await page.waitForTimeout(500);
  // A band in the page rather than a layer over it: what follows moves down,
  // the page keeps scrolling, and the same button closes it again.
  ok('clicking opens the band', await page.isVisible('#meet'));
  ok('the page is not locked behind it',
     await page.evaluate(() => document.body.style.overflow === ''));
  ok('the page did not navigate away', page.url().includes('index.html'));
  const frameSrc = await page.getAttribute('#meet iframe', 'src');
  ok('the schedule is embedded, not linked', (frameSrc || '').includes(SCHED), frameSrc);
  ok('embedded with gv=true', /[?&]gv=true/.test(frameSrc || ''), frameSrc);
  // The picker was drawing itself in Turkish on the English page: without hl,
  // Google falls back to the browser's language rather than the page's.
  ok('the picker is asked for the page\'s language', /[?&]hl=en\b/.test(frameSrc || ''), frameSrc);
  await page.click('.lang button[data-lang="tr"]');
  await page.waitForTimeout(500);
  ok('…and follows the switch while it is open',
     /[?&]hl=tr\b/.test(await page.getAttribute('#meet iframe', 'src') || ''),
     await page.getAttribute('#meet iframe', 'src'));
  await page.click('.lang button[data-lang="en"]');
  await page.waitForTimeout(400);
  ok('the calendar was requested, once asked',
    offsite.some(u => u.includes('calendar.google.com')));
  ok('our frame is around it, not Google’s', await page.isVisible('#meet .meethd h2'));
  // A framed page can be refused by the browser and leave an empty box. There
  // has to be a way out that does not depend on the frame having worked.
  ok('a way out if the frame is refused',
    (await page.getAttribute('#mmOut', 'href') || '').includes(SCHED));
  ok('the close button is there', await page.isVisible('#meetClose'));
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  ok('Escape closes it', await page.isHidden('#meet'));
  // The same button again is the shortest way out for someone who opened it to
  // look, so it has to toggle rather than re-open onto itself.
  // Opening scrolls the page down to the band, so the hero button ends up under
  // the sticky header. Back to the top before aiming at it again — otherwise
  // the click lands on the header and this asserts nothing.
  const meetBtn = async () => {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(350);
    await page.click('.hero-cta a[data-meet]');
    await page.waitForTimeout(700);
  };
  await meetBtn();
  ok('the button reopens it', await page.isVisible('#meet'));
  await meetBtn();
  ok('…and the same button closes it', await page.isHidden('#meet'));

  console.log('\n— language —');
  ok('starts in English', (await page.getAttribute('html', 'lang')) === 'en');
  const enH1 = (await page.textContent('.hero h1')).trim();
  await page.click('.lang button[data-lang="tr"]');
  await page.waitForTimeout(250);
  ok('html lang flips to tr', (await page.getAttribute('html', 'lang')) === 'tr');
  // §11, 9 August: the Turkish tagline came back and the eighth round's decision
  // is void. Third position for this assertion in two days — the rule keeps
  // moving, so what is asserted is the rule as it stands, dated in the comment.
  ok('hero headline translates again', /araçla başlar/i.test(await page.textContent('.hero h1')));
  // The tagline requirement now lives on the hero only. Business BUS-042 §2,
  // 21 August, writes the <title> of every page itself and says it enters
  // verbatim; Marketing's meta corrections of the same date changed the home
  // description and left this title standing. So the title is asserted as the
  // exact string Business wrote, not as a pattern — a pattern would pass on a
  // title nobody approved. The tagline is still checked on the h1 above.
  ok('title is Business’s Turkish title, verbatim',
     (await page.title()) === 'Yapay Zeka Dönüşüm Danışmanlığı · Anthifel', await page.title());
  ok('hero sentence still translates',
     /Dönüşüm herkes için yeni/i.test(await page.textContent('.hero p')));
  // §11c: one tagline per surface. The English one appears nowhere in the
  // Turkish page's visible copy.
  ok('Türkçe sayfada İngilizce tagline yok',
     !/needs a guide/i.test(await page.evaluate(() => document.body.innerText)));
  // §9a as amended by the CEO on 9 August and confirmed on 13 August after the
  // band was tried and removed: the sentence opens the hero sentence, and unlike
  // a band it does translate. A test that only looked for the English would pass
  // on a Turkish page that had lost it.
  /* 20 Ağustos: CEO cümleyi "Şirketlerin içinde … organize ediyoruz" diye
     yeniden yazdı. Aranan parça, cümlenin **konusu** olan kısım — kim, nerede —
     çünkü değişen kelime sırası değil, o kısmın kaybolması bir hata olur. */
  ok('alt metin hero cümlesinin başında', /Şirketlerin içinde AI dönüşümünün insan tarafını/
     .test(await page.textContent('.hero p')), await page.textContent('.hero p'));
  ok('ayrı bir bant yok', (await page.$('.hero .strap')) === null);
  // §10a: the Turkish service lines show on the Turkish page only
  ok('hizmet tanım satırları Türkçe sayfada', (await page.$$eval('.svc-tr',
     n => n.filter(x => x.textContent.trim()).length)) === 4);
  // The service names are fixed English on both pages — Business's standing
  // instruction, K34. A future Turkish sweep must not "finish the job".
  for (const n of ['AI Readiness Audit', 'Discovery Sprint', 'Transformation Retainer',
                   'Advisory Board Seat', 'Executive Workshop']) {
    ok(`hizmet adı Türkçe sayfada da İngilizce: ${n}`,
       (await page.textContent('#services')).includes(n));
  }
  const untranslated = await page.$$eval('[data-en]', els =>
    els.filter(e => !e.hasAttribute('data-tr')).map(e => e.tagName + ':' + (e.textContent || '').slice(0, 30)));
  ok('every data-en node has data-tr', untranslated.length === 0, untranslated.join(' | '));
  await page.click('.lang button[data-lang="en"]');
  await page.waitForTimeout(250);
  ok('switches back to English', (await page.textContent('.hero h1')).trim() === enH1);

  console.log('\n— K47 item 7, Turkish page —');
  await page.click('.lang button[data-lang="tr"]');
  await page.waitForTimeout(300);
  const trAll = await page.evaluate(() => {
    const c = document.body.cloneNode(true);
    c.querySelectorAll('style,script').forEach(e => e.remove());
    let x = '';
    c.querySelectorAll('[data-tr]').forEach(e => { x += ' ' + (e.getAttribute('data-tr') || ''); });
    return c.textContent + x;
  });
  for (const [bad, why] of [
    ['skor', '7c: score, use sonuç'],
    ['en ucuz yolu', '7b: brand does not argue on price'],
    ['Doğru insanlar', '7b: remnant of the withdrawn sentence'],
    ['Tekliften önce', '7a: spelling'],
    ['İşin içinde.', '7a: half sentence'],
    ['Herhangi birinden sonra', '7c'],
    // ['görüşme ayarla', '7c: ayarlamak is not used for appointments'],
    //   Suspended, 9 August 2026. The CEO named the buttons "Görüşme Ayarla",
    //   which is the exact phrase 7c forbids and gives a reason for. This is not
    //   a drift, it is an instruction, so the guard is parked rather than
    //   deleted — Marketing rules on 7c and it goes back or comes out. Nothing
    //   else in 7c is relaxed by this line.
    ['tek başına durur', '7c'],
    ['kısa bir okuma', '7c'],
    ["England and Wales'te", '7e: Turkish imprint'],
    ['coming-soon sayfası', '7e: preview banner'],
  ]) ok(`7x: no "${bad}" — ${why}`, !trAll.toLowerCase().includes(bad.toLowerCase()));

  for (const s of [
    'Teklif öncesi teşhis.',
    'İşinizin içinde, sizin ekibinizle. Üzerinde isimler olan bir yol haritası.',
    // 21 Ağustos, Marketing: hizmet adları çevrilmez ("Denetim" → "Audit") ve
    // bu satır süreyi söylüyor. Türkçe kart artık "Dört iş günü." diyor,
    // İngilizcesi demiyor — BUS-034 kilidi yüzünden. İkisi de ölçülüyor ki
    // fark bir tercih mi yoksa unutulmuş bir satır mı, sorulabilsin.
    'Dört iş günü. Nerede durduğunuzun kanıta dayalı fotoğrafı.',
    'Roller yerine oturmuş, ekip birbirine bağlı.',
    'İşe alımlar yapılmış, roller birbirine bağlanmış.',
    'İstediğiniz aşamada durabilirsiniz.',
    'On iki soru, üç dakika, dürüst bir sonuç.',
    'Her biri tek başına alınabilir; çoğu şirket listenin başından başlar.',
    'Görüşme planla',
    // LGL-003, 19 Ağustos: "tescillidir" → "kayıtlı şirkettir". Legal's wording,
    // because in Turkish "tescilli" beside a brand name reads as a *trademark*
    // registration and we hold none. 20 Ağustos: the sentence grew into the
    // trading disclosure and now ends "bir şirkettir", so what is asserted is
    // the two words the ruling was actually about, not the sentence they sat
    // in — the sentence is Marketing's to write, the verb is Legal's.
    'İngiltere ve Galler’de kayıtlı'.replace('’', "'"),
    'Kullanım Şartları',
    // The trading disclosure, in Turkish. Companies (Trading Disclosures)
    // Regulations, and the duty runs from incorporation rather than from launch.
    'Şirket Numarası: 17411895',
    'Unit 501 Leroy House, 434-436 Essex Road,',
    'Yönetim ekibinizle, genel bir eğitim değil, sizin senaryolarınız üzerine.',
  ]) ok(`§8.7: "${s.slice(0, 40)}${s.length > 40 ? '…' : ''}"`, trAll.includes(s));
  // The word Legal ruled out. Asserting its absence as well as the replacement's
  // presence, because a page can carry both and the ruling was about the one.
  ok('§8.7: "tescillidir" geri gelmemiş', !/tescillidir/i.test(trAll));
  // §8.7c asked that the Turkish call-to-action say the call is free. On
  // 9 August the CEO renamed the buttons "Görüşme Ayarla", which drops the word.
  // That is a live conflict with §8.7c and Marketing has been told; until they
  // rule, what is asserted is the CEO's wording, so a silent drift back is still
  // caught. The promise itself did not go away — it moved into the modal, and
  // that is what the second line checks.
  // 20 Ağustos: CEO cümle düzenine geçti — "Görüşme ayarla".
  ok('§8.7c (CEO, 20 Ağustos): görüşme butonları "Görüşme ayarla" diyor',
     (await page.$$eval('a.btn[data-meet]', els => els.map(e => e.getAttribute('data-tr'))))
       .every(t => t === 'Görüşme ayarla'),
     (await page.$$eval('a.btn[data-meet]', els => els.map(e => e.getAttribute('data-tr')))).join(' | '));
  ok('ücretsiz olduğu hâlâ bir yerde yazıyor',
     /ücretsiz/i.test(await page.evaluate(() =>
       document.querySelector('#meet .mmintro').getAttribute('data-tr'))));

  // 7e — one name for the free assessment, short form allowed in narrow places
  const names = await page.evaluate(() => {
    const nav = document.querySelector('.nav a[href="#assessment"]').textContent.trim();
    const cta = document.querySelector('.hero-cta a[href="#assessment"]').textContent.trim();
    const eyebrow = document.querySelector('#aIntro .eyebrow').textContent.trim();
    const step = document.querySelector('.step h3').textContent.trim();
    return { nav, cta, eyebrow, step };
  });
  ok('7e: no bare "Test" left anywhere',
    ![names.nav, names.cta, names.eyebrow, names.step].includes('Test'), JSON.stringify(names));
  ok('7e: every name is AI Hazırlık Testi or the sanctioned short form',
    [names.nav, names.cta, names.eyebrow, names.step]
      .every(n => /^(AI )?[Hh]azırlık [Tt]esti( →)?$/.test(n)), JSON.stringify(names));

  /* 7d — the footer's Journal titles read in the language the page is in.
     It used to name one of the four planned titles, which stopped being true
     the moment a real piece was published and the list started coming from
     posts.json. What has to hold either way is the property, not the string:
     every title carries both languages and shows the right one. */
  const ftr = await page.$$eval('.ftr ul a', as =>
    as.map(a => ({ shown: a.textContent.trim(),
                   en: a.getAttribute('data-en'), tr: a.getAttribute('data-tr') })));
  ok('7d: the footer lists the Journal', ftr.length > 0);
  ok('7d: every title carries both languages',
     ftr.every(t => t.en && t.tr), JSON.stringify(ftr.map(t => t.shown)));
  ok('7d: and the Turkish page shows the Turkish one',
     ftr.every(t => t.shown === t.tr), JSON.stringify(ftr.map(t => t.shown)));
  ok('7d: the title with no counterpart is gone',
    !ftr.some(t => /ninety days/i.test(t.shown)));

  ok('English page untouched by item 7', await page.evaluate(() => {
    const en = [...document.querySelectorAll('[data-en]')].map(e => e.getAttribute('data-en')).join(' ');
    return en.includes('Twelve questions, three minutes, an honest score.');
  }));

  /* 14d, and it is a withdrawal rather than a rewrite. Both sentences were
     live for twelve days after their Turkish halves had been corrected, which
     is the failure mode this pair of assertions exists to catch: a card whose
     two languages say different things reads as fine in either language on its
     own. Written as "the old wording is gone" and not only "the new wording is
     there", because a page can carry both. */
  const enAll = await page.evaluate(() =>
    [...document.querySelectorAll('[data-en]')].map(e => e.getAttribute('data-en')).join(' '));
  ok('14d: the price line is gone from Audit', !/cheapest way/i.test(enAll));
  ok('14d: …replaced by the evidence line, without a duration in it',
     enAll.includes('An evidence-based read of where you stand.') &&
     !/Four working days\./.test(enAll));
  ok('14d: the "right people" remnant is gone from Transformation',
     !enAll.includes('The right people, connected. A steady rhythm.'));
  ok('14d: …replaced by the line that matches the Turkish already on the card',
     enAll.includes('Roles settled, the team connected. A rhythm that holds.'));

  await page.click('.lang button[data-lang="en"]');
  await page.waitForTimeout(300);

  console.log('\n— Services §9.2 copy, verbatim —');
  for (const s of [
    'An honest picture of where you stand, and the first three things to fix.',
    'Weeks inside your business. A roadmap with owners, costs and dates.',
    // Marketing, 21 August §5. The Turkish half of the Retainer card was
    // corrected on the 20th and the English half was not, so the K47 wording
    // withdrawn on 3 August survived on one side of one card. This line held
    // the old sentence and failed the moment the card was fixed — which is
    // what it is for. Below is the §9.2 text as it now stands — Marketing's
    // own wording, one word changed from mine on the 21st: "Hires made" keeps
    // the beat of "İşe alımlar yapılmış" where "Hiring done" read clipped.
    'Hires made, roles connected. A rhythm that holds.',
    'A seat at your table. A few hours a month, and the phone when it matters.',
    'A day with your leadership. Your scenarios, not a generic course.',
    'On the human side of AI transformation.',
  ]) ok(`verbatim: "${s.slice(0, 44)}${s.length > 44 ? '…' : ''}"`, (await page.textContent('body')).includes(s));

  console.log('\n— assessment gate opens before the assessment —');
  ok('intro visible on load', await page.isVisible('#aIntro'));
  ok('no "Your answers are processed" note under the CTA',
    !/Your answers are processed|Cevaplarınız yalnızca/.test(await page.textContent('#aIntro')));
  ok('gate hidden on load', await page.isHidden('#aGate'));
  ok('assessment hidden on load', await page.isHidden('#aQuiz'));
  await page.click('#aIntro [data-start]');
  await page.waitForTimeout(500);
  ok('the intro button opens the gate', await page.isVisible('#aGate'));
  ok('intro is replaced, not stacked', await page.isHidden('#aIntro'));
  ok('assessment still not reached', await page.isHidden('#aQuiz'));
  ok('no step counter on the gate', await page.$('#aGate .prog') === null);

  console.log('\n— gate refuses to pass —');
  await page.click('#next'); await page.waitForTimeout(150);
  ok('blocks empty email', (await page.textContent('#e-email')).length > 0);
  ok('blocks missing consent', (await page.textContent('#e-consent')).length > 0);
  ok('does not reach the assessment', await page.isHidden('#aQuiz'));
  await page.fill('#email', 'not-an-email');
  await page.click('#next'); await page.waitForTimeout(150);
  ok('rejects malformed email', (await page.textContent('#e-email')).length > 0);
  await page.fill('#email', 'test@example.com');
  await page.click('#next'); await page.waitForTimeout(150);
  ok('valid email clears its error', (await page.textContent('#e-email')).length === 0);
  ok('consent alone still blocks', await page.isHidden('#aQuiz'));

  console.log('\n— consent, the three conditions —');
  ok('1. box starts unticked', !(await page.isChecked('#consent')));
  ok('2. policy link sits inside the label', await page.$('#f-consent label a[href="privacy.html"]') !== null);
  await page.check('#consent');
  await page.waitForTimeout(100);
  ok('3. consent moment is captured', await page.evaluate(() => {
    // consentAt lives in closure; assert the observable contract instead —
    // ticking clears the error and the submit path carries a timestamp.
    return document.getElementById('e-consent').textContent === '';
  }));
  // The bot check, 11 August. It is the mail itself: a six-digit code to the
  // address, which is the same address the result has to reach anyway. Nothing
  // is asked of Google, so a plain page view still reaches nobody.
  console.log('\n— the bot check is the code, not a widget —');
  ok('no captcha widget on the gate', await page.$('#pow') === null);
  ok('no reserved captcha gap either', await page.$('.cap') === null);
  const botOffsite = () => offsite.filter(u => !u.includes('calendar.google.com'))
                                  .filter(u => /google|gstatic|recaptcha/i.test(u));
  ok('the gate reaches nobody', botOffsite().length === 0, botOffsite().join(' '));
  ok('the code screen exists and is not shown yet', await page.isHidden('#aCode'));
  ok('it asks for one field', await page.$('#aCode input#code') !== null);
  ok('the field takes a one-time code', 
     await page.getAttribute('#code', 'autocomplete') === 'one-time-code');
  ok('and opens a number pad on a phone',
     await page.getAttribute('#code', 'inputmode') === 'numeric');
  ok('there is a way back to the address', await page.$('#aCode #codeBack') !== null);
  ok('and a way to ask for a new code', await page.$('#aCode #resend') !== null);
  // Both buttons start the assessment from the visitor's point of view — the
  // code screen is a step on the way, not a separate errand. What the second
  // one adds is that it checks the code first, and it says so.
  ok('the first button says what the visitor is doing',
     /Start the assessment/.test(await page.textContent('#next')));
  ok('the second says it checks the code, then does the same thing',
     /Verify and start/.test(await page.textContent('#verify')));
  ok('neither one talks about sending anything',
     !/Send the code/.test(await page.textContent('#next')) &&
     !/Send the code/.test(await page.textContent('#verify')));

  // From 11 August the built page carries the real Apps Script address. That is
  // by design — the form has to post somewhere — but it makes one thing worth
  // asserting out loud: the switch, not the address, is what keeps a preview
  // visit silent.
  console.log('\n— the endpoint is wired —');
  ok('the endpoint is a real address, not a placeholder', await page.evaluate(() =>
    /script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec/.test(document.documentElement.innerHTML)));
  ok('no placeholder survived anywhere in the page', await page.evaluate(() =>
    !/__[A-Z_]+__/.test(document.documentElement.innerHTML)));
  ok('the live-test switch needs an explicit URL to open it', await page.evaluate(() =>
    /var TEST_MODE {2}= FORM_TEST && \/\[\?&\]form=live/.test(document.documentElement.innerHTML)));

  /* 20 August, launch. Until today FORM_LIVE was false, so the gate stepped
     straight past the code screen and this block asserted that — "the code step
     is skipped while the endpoint is not wired". That was a description of a
     switch, not of the product: with the switch on, the visitor goes through the
     code, and a suite that only knows the bypass has never tested the thing
     anyone will actually use.

     So the endpoint is answered locally instead. Nothing reaches Google — the
     route intercepts before the request leaves — but the page takes the real
     path: send-code, the code screen, verify-code, the questionnaire. It reads
     the switch out of the build rather than assuming it, so the same file works
     on both builds and neither one is silently skipped. */
  const formLive = await page.evaluate(() =>
    /var FORM_LIVE {2}= true;/.test(document.documentElement.innerHTML));
  console.log(`\n— gate passes into the assessment (FORM_LIVE ${formLive}) —`);
  if (formLive) {
    await page.route('**script.google.com/**', async r => {
      const body = JSON.parse(r.request().postData() || '{}');
      const reply = body.action === 'verify-code'
        ? { ok: body.code === '123456' } : { ok: true, sent: true };
      await r.fulfill({ status: 200, contentType: 'application/json',
                        body: JSON.stringify(reply) });
    });
    await page.click('#next'); await page.waitForTimeout(1200);
    ok('the code step opens', await page.isVisible('#aCode'),
       `aGate=${await page.isVisible('#aGate')} e-email=${await page.textContent('#e-email')} e-consent=${await page.textContent('#e-consent')} e-send=${await page.textContent('#e-send')}`);
    ok('gate is put away', await page.isHidden('#aGate'));
    /* A wrong code must not open the questionnaire. This is the assertion the
       bypass made impossible to write. */
    /* Six digits submit themselves — there is nothing left to decide once the
       last one is typed, and the button is only there for a correction. So the
       code is filled and nothing is clicked; clicking after the fill raced the
       auto-submit and waited thirty seconds for a button the flow had already
       taken off the screen. */
    await page.fill('#code', '000000');
    await page.waitForTimeout(600);
    ok('a wrong code does not open the assessment', await page.isHidden('#aQuiz'));
    ok('…and says so on the code screen',
       (await page.textContent('#e-code')).trim().length > 0);
    ok('…and the button comes back for a second try',
       await page.isVisible('#verify') && !(await page.$eval('#verify', b => b.disabled)));
    await page.fill('#code', '123456');
    await page.waitForTimeout(800);
    ok('the right code opens the assessment', await page.isVisible('#aQuiz'));
  } else {
    await page.click('#next'); await page.waitForTimeout(500);
    ok('assessment step is reached', await page.isVisible('#aQuiz'));
    ok('gate is put away', await page.isHidden('#aGate'));
    ok('the code step is skipped while the form is switched off',
       await page.isHidden('#aCode'));
    ok('and no mail was attempted', posted.length === 0, posted.join(' | '));
    ok('preview notice shown while FORM_LIVE is false', await page.isVisible('#devnote'));
  }
  ok('the first question is drawn', await page.isVisible('#qAsk'));

  console.log('\n— the twelve questions —');
  // Structure first: twelve questions, and the dimension counts the
  // methodology fixes at 3 / 3 / 2 / 2 / 2.
  const seen = [];
  const answerAll = async pick => {
    // pick(i) → 1, 2 or 3 (worst, middle, best)
    await page.evaluate(() => {
      document.getElementById('aGate').hidden = true;
      document.getElementById('aQuiz').hidden = false;
    });
    for (let i = 0; i < 12; i++) {
      seen.push({
        n: (await page.textContent('#qNow')).trim(),
        dim: (await page.textContent('#qDim')).trim(),
        opts: (await page.$$('#qOpts .qopt')).length,
      });
      await page.click(`#qOpts .qopt:nth-child(${pick(i)})`);
      await page.waitForTimeout(40);
    }
    await page.waitForTimeout(150);
  };

  await answerAll(() => 3);                      // every answer at 100
  ok('twelve questions, numbered 1..12',
     seen.map(x => x.n).join(',') === '1,2,3,4,5,6,7,8,9,10,11,12', seen.map(x => x.n).join(','));
  ok('three options on every question', seen.every(x => x.opts === 3));
  const counts = seen.reduce((m, x) => (m[x.dim] = (m[x.dim] || 0) + 1, m), {});
  ok('dimension counts are 3 / 3 / 2 / 2 / 2',
     counts['Strategy & Ownership'] === 3 && counts['People & Capacity'] === 3 &&
     counts['Data & Process Foundation'] === 2 && counts['Economics & Measurement'] === 2 &&
     counts['Technology & Infrastructure'] === 2, JSON.stringify(counts));

  console.log('\n— scoring —');
  ok('all best answers score 100', (await page.textContent('.res .score')).startsWith('100'),
     await page.textContent('.res .score'));
  ok('85+ band text is Business’s, verbatim',
     (await page.textContent('.res h3')) === 'You are further along than most. You may not need us.');
  ok('no ceiling when nothing is weak', await page.$('.capnote') === null);
  ok('one call to action, not two', (await page.$$('.res .cta .btn')).length === 1);
  ok('the limit sentence is present',
     (await page.textContent('.limit')).includes('±15 points'));
  ok('five dimension bars', (await page.$$('.res .dimrow')).length === 5);

  // Weakest dimension, worst answers only there: raw 90, ceiling 59.
  const rerun = async pick => {
    await page.evaluate(() => { location.hash = ''; });
    await page.evaluate(() => { document.getElementById('aQuiz').hidden = true; });
    await page.click('#aIntro [data-start]').catch(() => {});
    await page.evaluate(() => {
      document.getElementById('aGate').hidden = true;
      document.getElementById('aQuiz').hidden = false;
    });
    await page.evaluate(() => { document.getElementById('qRes').hidden = true; });
    await page.reload({ waitUntil: 'load' });
    await page.click('[data-start]');
    await page.fill('#email', 'test@example.com');
    await page.check('#consent');
    await page.click('#next');
    await page.waitForTimeout(300);
    /* With the form live the gate has a code screen in it, so a rerun has to
       walk through it the way a visitor does. The stub above answers
       verify-code, and six digits submit themselves. */
    if (await page.isVisible('#aCode')) {
      await page.fill('#code', '123456');
      await page.waitForTimeout(700);
    }
    for (let i = 0; i < 12; i++) {
      await page.click(`#qOpts .qopt:nth-child(${pick(i)})`);
      await page.waitForTimeout(40);
    }
    await page.waitForTimeout(150);
  };

  await rerun(i => (i >= 10 ? 1 : 3));           // technology at 0, the rest at 100
  ok('a weak dimension caps the score at 59',
     (await page.textContent('.res .score')).startsWith('59'), await page.textContent('.res .score'));
  ok('the ceiling is stated, with the raw score and the reason',
     (await page.textContent('.capnote')).includes('90') &&
     (await page.textContent('.capnote')).includes('Technology & Infrastructure'),
     await page.textContent('.capnote'));

  await rerun(i => (i < 3 ? 1 : 3));             // strategy at 0, the rest at 100
  ok('weak strategy caps the score at 49',
     (await page.textContent('.res .score')).startsWith('49'), await page.textContent('.res .score'));
  ok('the strategy ceiling names strategy',
     (await page.textContent('.capnote')).includes('Strategy & Ownership'));
  ok('0–29 band is not reached by a capped 49',
     (await page.textContent('.res h3')) === 'The ground is not laid yet.',
     await page.textContent('.res h3'));

  await rerun(() => 1);                          // everything at 0
  ok('all worst answers score 0', (await page.textContent('.res .score')).startsWith('0'));
  ok('0–29 band text is Business’s, verbatim',
     (await page.textContent('.res h3')) === 'You are not ready for AI. That is the expensive kind of not-ready.');
  // §C.3: the low band's only way out is the call. It used to be #contact,
  // which is the footer — a scroll, not a conversation. It is the booking
  // window now, and the band still gets exactly one button.
  ok('0–29 sends you to a conversation, not a service',
     /calendar\.google\.com\/appointments/.test(await page.getAttribute('.res .cta .btn', 'href') || ''),
     await page.getAttribute('.res .cta .btn', 'href'));
  ok('0–29 offers no second button',
     (await page.$$('.res .cta .btn')).length === 1);
  // §C.5: the ±15 sentence was on screen, the ceiling was not. Both now are.
  ok('the result screen states the 79 ceiling',
     /79/.test(await page.textContent('.res .limit')), await page.textContent('.res .limit'));

  // Two live instructions contradict each other here. The Developer brief §A.4
  // says the band copy goes in verbatim and Developer does not change it;
  // Brand Guidelines §8 says no em dash appears anywhere on the site. Three of
  // the five band paragraphs contain one. The copy is entered as instructed and
  // the exception is pinned to exactly those sentences: nothing else on the
  // result screen may carry an em dash, and Marketing has been asked to settle
  // it. Anthifel_Website.md §22.
  const resAll = await page.textContent('.res');
  const bandCopy = (await page.textContent('.res .lede')) + (await page.textContent('.res .cta .btn'));
  ok('the only em dashes on the result screen are Business’s own band copy',
     !resAll.split(bandCopy).join('').replace(await page.textContent('.res .lede'), '')
            .replace(await page.textContent('.res .cta .btn'), '').includes('\u2014'),
     (resAll.replace(await page.textContent('.res .lede'), '')
            .replace(await page.textContent('.res .cta .btn'), '')
            .match(/.{30}\u2014.{30}/) || [''])[0]);

  // §C.1 and §C.3: the band that used to send people to a catalogue row now
  // sends them to the page that was written for it, with the quote request
  // beside it. This is the whole point of the round.
  // The first three questions are Strategy. Nothing there and everything
  // elsewhere trips the strategy ceiling, which lands the score on 49 —
  // the top of the band being tested.
  await rerun(i => (i < 3 ? 1 : 3));
  {
    const btns = await page.$$eval('.res .cta .btn', bs =>
      bs.map(b => ({ href: b.getAttribute('href'), cls: b.className })));
    if (btns.length === 2 && /ai-readiness-audit/.test(btns[0].href || '')) {
      ok('30–49 leads to the Audit page', true);
      ok('…with the quote request beside it', /#teklif/.test(btns[1].href || ''), btns[1].href);
      ok('…primary filled, secondary outlined',
        /btn-p/.test(btns[0].cls) && /btn-s/.test(btns[1].cls), JSON.stringify(btns));
    } else {
      ok('30–49 leads to the Audit page', false, JSON.stringify(btns));
    }
  }
  // Until BUS-033 landed, three bands pointed at the catalogue row the reader
  // was already standing in. Every band now names a service and opens that
  // service's own page. The assertion is that none of them points back at the
  // list — a button that returns you to where you came from is the bug §C.1 is
  // about, and it is the kind that comes back when a band is edited.
  ok('no band sends the reader back to the catalogue row',
     (await page.evaluate(() =>
       (document.documentElement.innerHTML.match(/href:'#services'/g) || []).length)) === 0);
  // Driving the quiz into a chosen band is fragile — the ceiling rule means the
  // answers that reach a band are not obvious — and scoring is already tested
  // above. What is under test here is the wiring, so it is read off the source
  // and then checked against the disk: a band naming a page that is not built
  // is the failure this catches.
  // The negative lookahead skips the secondary buttons, which are the same
  // constant with '#teklif' appended. Without it every service counts twice.
  const bandHrefs = (await page.content())
    .match(/href:(?:AUDIT|SPRINT|RETAINER|ADVISORY|MEET)\b(?!\s*\+)/g) || [];
  ok('every band names a destination, none of them the catalogue',
     bandHrefs.length === 5, bandHrefs.join(' '));
  ok('the five bands go, in order, to the call and then the four services',
     bandHrefs.join('|') === 'href:MEET|href:AUDIT|href:SPRINT|href:RETAINER|href:ADVISORY',
     bandHrefs.join('|'));
  for (const f of ['ai-readiness-audit.html', 'discovery-sprint.html',
                   'transformation-retainer.html', 'advisory-board-seat.html']) {
    ok(`  ${f} is on disk for the band that names it`,
       fs.existsSync(path.resolve(path.dirname(path.resolve(process.argv[2] || 'index.html')), f)));
  }
  // The seat is not sold directly — Business's §3 — so it is the one service
  // band with no quote button. A page that says "not sold directly" under a
  // button that says "request a quote" argues with itself.
  const quoteButtons = (await page.content()).match(/second:\{ en:'Request a quote'/g) || [];
  ok('three services offer a quote, the Advisory seat does not',
     quoteButtons.length === 3, String(quoteButtons.length));
  // Put the screen back the way the next block expects to find it.
  await rerun(() => 1);

  console.log('\n— the test records nothing —');
  ok('no answer and no score in storage', await page.evaluate(() => {
    const keys = Object.keys(localStorage).concat(Object.keys(sessionStorage));
    // anthifel_lang is the language switch, and it is the only thing allowed.
    return keys.every(k => k === 'anthifel_lang');
  }));
  /* Parsed, not grepped. This used to search the raw body for the words
     "answers" or "score", which was free while FORM_LIVE was false and nothing
     was posted at all. With the form live the gate posts a consent record, and
     Legal's consent sentence contains the word "answers" — so the suite failed
     on a payload that is exactly what it should be. What matters is not the
     word; it is that no key carries the twelve answers or a score out of the
     browser. So the keys are read. */
  const carriesAnswers = b => {
    let o; try { o = JSON.parse(b); } catch (e) { return /\banswers\b/.test(b); }
    const bad = [];
    const walk = (v, path) => {
      if (v && typeof v === 'object') {
        for (const k of Object.keys(v)) {
          /* Score and band are allowed to leave, and are disclosed as leaving:
             the privacy notice says we receive "the result and band of a
             completed assessment" and — in bold — "never your individual
             answers". So what is forbidden is the answers, by key or by shape:
             a twelve-long array is the twelve answers whatever it is called. */
          if (/^(answers|responses|replies|cevaplar)$/i.test(k)) bad.push(path + '.' + k);
          if (Array.isArray(v[k]) && v[k].length === 12) bad.push(path + '.' + k + '[12]');
          if (/^q\d+$/i.test(k)) bad.push(path + '.' + k);
          walk(v[k], path + '.' + k);
        }
      }
    };
    walk(o, '');
    return bad.length > 0;
  };
  ok('no request carried the answers', posted.every(b => !carriesAnswers(b)),
     posted.join(' | ').slice(0, 120));

  console.log('\n— the result screen speaks Turkish too —');
  await page.click('.lang button[data-lang="tr"]');
  await page.waitForTimeout(300);
  ok('the band headline switches language',
     (await page.textContent('.res h3')) === 'AI’ya hazır değilsiniz. Ve bu, pahalı olan hazır değillik türü.',
     await page.textContent('.res h3'));
  ok('the limit sentence switches too', (await page.textContent('.limit')).includes('±15 puan'));
  await page.click('.lang button[data-lang="en"]');
  await page.waitForTimeout(250);

  console.log('\n— cancel —');
  await page.reload({ waitUntil: 'load' });
  await page.click('[data-start]'); await page.waitForTimeout(200);
  await page.click('#cancel'); await page.waitForTimeout(400);
  ok('cancel returns to the intro', await page.isVisible('#aIntro'));

  console.log('\n— honeypot —');
  ok('honeypot exists and is parked off-screen', await page.evaluate(() => {
    const e = document.querySelector('input[name=website]');
    if (!e) return false;
    // The gate may be collapsed at this point, so measure the rule, not the box.
    return parseFloat(getComputedStyle(e.closest('.hp')).left) < -1000;
  }));

  console.log('\n— mobile menu —');
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(200);
  ok('nav hidden behind burger', await page.isHidden('#nav'));
  await page.click('#burger'); await page.waitForTimeout(250);
  ok('burger opens nav', await page.isVisible('#nav'));
  await page.click('#nav a[href="#services"]'); await page.waitForTimeout(400);
  ok('nav closes after a tap', await page.isHidden('#nav'));

  // The hero line types itself, 11 August. The thing worth guarding is not that
  // it animates — it is that the page underneath it does not move while it
  // does, and that the sentence is still readable to a machine that cannot see
  // the animation at all.
  console.log('\n— the hero line types itself —');
  {
    // By now the suite has scrolled the page. The line stops when it is off
    // screen — that is deliberate — so go back to the top before watching it.
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(700);
    const eb = await page.$('#heroEyebrow');
    ok('the hero line is there', eb !== null);
    const full = await page.getAttribute('#heroEyebrow', 'aria-label');
    ok('the finished sentence is offered whole, not letter by letter',
       full === 'AI transformation advisory · London', String(full));
    ok('the ghost carries it, so the text is in the document',
       (await page.textContent('#heroEyebrow .twghost')) === full);
    ok('and both layers are hidden from a screen reader',
       (await page.getAttribute('#heroEyebrow .twghost', 'aria-hidden')) === 'true' &&
       (await page.getAttribute('#heroEyebrow .twlive', 'aria-hidden')) === 'true');

    const partial = await page.textContent('#heroEyebrow .twlive');
    ok('it is mid-sentence, not finished at once',
       partial.length < full.length && full.startsWith(partial), JSON.stringify(partial));

    // The measurement that matters: sample the headline through a whole cycle.
    const ys = [];
    for (let k = 0; k < 14; k++) {
      ys.push(await page.evaluate(() =>
        Math.round(document.querySelector('.hero h1').getBoundingClientRect().y + window.scrollY)));
      await page.waitForTimeout(500);
    }
    ok('the headline never moves while the line types, holds and clears',
       new Set(ys).size === 1, ys.join(','));

    const grew = await page.evaluate(() => document.documentElement.scrollWidth);
    ok('and nothing it draws widens the page', grew <= 1280, String(grew));

    // It clears and starts again rather than typing once and stopping.
    const lens = new Set();
    for (let k = 0; k < 16; k++) {
      lens.add((await page.textContent('#heroEyebrow .twlive')).length);
      await page.waitForTimeout(450);
    }
    ok('it reaches the end of the sentence', lens.has(full.length), [...lens].join(','));
    ok('and clears back down before starting again',
       [...lens].some(n => n < 3), [...lens].join(','));

    ok('exactly one caret, and one pair of layers',
       (await page.$$('#heroEyebrow .twcaret')).length === 1 &&
       (await page.$$('#heroEyebrow > span')).length === 2);

    // Nothing should be running for a line nobody is looking at.
    await page.evaluate(() => window.scrollTo(0, 4000));
    await page.waitForTimeout(700);
    const off = await page.textContent('#heroEyebrow .twlive');
    await page.waitForTimeout(900);
    ok('it stops once it has scrolled out of sight',
       (await page.textContent('#heroEyebrow .twlive')) === off, JSON.stringify(off));
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(800);
    ok('and picks up again when it comes back',
       (await page.textContent('#heroEyebrow .twlive')) !== off);
  }

  // Reduced motion changes what happens after the sentence finishes, not
  // whether it is written. The first version hid the animation entirely, and
  // that failed in the worst way available: the line looked exactly the same
  // as a script that had never run, so nobody could tell them apart.
  console.log('\n— reduced motion still gets the line —');
  {
    const rp = await browser.newPage({ viewport: { width: 1280, height: 900 }, reducedMotion: 'reduce' });
    await rp.route('**calendar.google.com/**', r =>
      r.fulfill({ status: 200, contentType: 'text/html', body: 'x' }));
    await rp.goto(FILE, { waitUntil: 'load' });
    await rp.waitForTimeout(400);
    const full = await rp.getAttribute('#heroEyebrow', 'aria-label');
    const seen = new Set();
    for (let k = 0; k < 18; k++) {
      seen.add((await rp.textContent('#heroEyebrow .twlive')).length);
      await rp.waitForTimeout(420);
    }
    ok('it types under reduced motion too', seen.size > 3, [...seen].join(','));
    ok('it reaches the end', seen.has(full.length), [...seen].join(','));
    ok('and it loops rather than stopping there',
       [...seen].some(n => n < 3), [...seen].join(','));
    // The one concession: the letters move, the caret does not blink at them.
    ok('the caret is held still',
       (await rp.evaluate(() =>
         getComputedStyle(document.querySelector('#heroEyebrow .twcaret')).animationName)) === 'none');
    await rp.close();
  }

  console.log('\n— wordmark floor (15 px) —');
  const marks = await page.$$eval('img[alt="Anthifel"]', is => is.map(i => i.getBoundingClientRect().height));
  ok('every wordmark ≥ 15 px', marks.every(h => h >= 15), marks.map(h => h.toFixed(1)).join(', '));

  console.log('\n— js —');
  ok('no page errors', errs.length === 0, errs.join(' | '));

  await browser.close();
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
