/**
 * check-dash.js — the dashboard, driven the way it will actually be used.
 *
 * One document, eight sections. The test walks the menu, opens every section,
 * exercises the two applications (CRM and the blog editor) and the three that
 * keep state (to-do, checklists, ledger), and checks overflow at each stop and
 * at five widths. Served over HTTP, never file://, so relative links behave.
 *
 *   node check-dash.js
 */
const { chromium } = require('playwright');
const mock = require('./mock-supabase');
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, 'dist', 'preview');
const PORT = 8131;
const DASH = `http://127.0.0.1:${PORT}/dashboard/`;
const WIDTHS = [1440, 1180, 900, 560, 380];
const PASS = 'anthifel2026';

const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript' };

function serve() {
  return new Promise(res => {
    const s = http.createServer((req, rp) => {
      let p = decodeURIComponent(req.url.split('?')[0]);
      if (p.endsWith('/')) p += 'index.html';
      const f = path.join(ROOT, p);
      if (!f.startsWith(ROOT) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
        rp.writeHead(404).end('not found'); return;
      }
      rp.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream' });
      rp.end(fs.readFileSync(f));
    });
    s.listen(PORT, '127.0.0.1', () => res(s));
  });
}

const results = [];
const ok = (n, c, d) => results.push({ n, c, d: d || '' });

async function overflow(page, label) {
  const bad = await page.evaluate(() => {
    const out = [];
    const vw = document.documentElement.clientWidth;
    // A clipping ancestor makes an out-of-bounds child harmless: the browser
    // never paints it outside the box. Only unclipped escapes are bugs.
    const clipped = el => {
      for (let n = el.parentElement; n; n = n.parentElement) {
        const s = getComputedStyle(n);
        if (s.overflowX !== 'visible' || s.overflow !== 'visible') return true;
      }
      return false;
    };
    document.querySelectorAll('body *').forEach(el => {
      const s = getComputedStyle(el);
      if (s.display === 'none' || s.visibility === 'hidden' || s.position === 'fixed') return;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.left < -1000) return;
      if (r.right > vw + 1 && !clipped(el)) {
        out.push(el.tagName.toLowerCase() + '.' + (el.className || '').toString().split(' ')[0]
                 + ' → ' + Math.round(r.right - vw) + 'px');
      }
    });
    return out.slice(0, 4);
  });
  ok(`${label}: taşma yok`, bad.length === 0, bad.join(' | '));
}

// The menu is two rows now: a department picks the row below it, and the row
// below picks the section. Reaching a section means walking both.
const DEPT = { ozet: 'ozet', crm: 'sales', icerik: 'marketing', blog: 'marketing',
               finans: 'finance', site: 'developer', seo: 'developer', analitik: 'developer' };

const go = async (page, sec) => {
  const d = DEPT[sec];
  // Same two moves a person makes: point at the department, then pick. The
  // header alone is enough when the section wanted is the department's first.
  await page.hover(`.dept[data-dept="${d}"] button`);
  await page.waitForTimeout(200);
  if (await page.isVisible(`.dept[data-dept="${d}"] .dmenu a[href="#${sec}"]`)) {
    await page.click(`.dept[data-dept="${d}"] .dmenu a[href="#${sec}"]`);
  } else {
    await page.click(`.dept[data-dept="${d}"] button`);
  }
  await page.waitForTimeout(260);
};

(async () => {
  const server = await serve();
  const browser = await chromium.launch({
    executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  // A rejected sign-in is a 400, and the browser logs every non-2xx as a
  // console error whether or not the page handled it. Those are excluded by
  // origin rather than by message, because what the panel does with a failed
  // request is asserted directly — the error text on the door, the toast on
  // the ledger — and a silent failure would fail those instead.
  page.on('console', m => {
    if (m.type() !== 'error') return;
    const at = (m.location() && m.location().url) || '';
    if (/supabase\.co/.test(at)) return;
    errs.push(m.text());
  });
  // Seeded, so the run proves the ledger is read from the server on a machine
  // that has never seen it — not merely written to it. The panel binds itself
  // at parse time, before anyone has signed in, and this row is the difference
  // between asking the server later and not asking at all.
  const sb = mock.install(page, { ledger: [{
    id: 'seed-1', entry_date: '2026-07-01', kind: 'gider', description: 'Sunucudan gelen',
    category: 'Seyahat', amount: 120, currency: 'GBP' }] });

  // ── the door ───────────────────────────────────────────────────────────────
  await page.goto(DASH, { waitUntil: 'networkidle' });
  ok('kapı: girişsiz açılmıyor', await page.isVisible('#gateScr'));
  ok('kapı: kapalıyken hiçbir bölüm çizilmiyor',
     (await page.$$('.sec:not([hidden])')).length === 0);
  ok('kapı: hesapla giriliyor, sayfaya yazılmış parolayla değil',
     await page.isVisible('#em') && await page.isHidden('#pw'));
  await mock.signIn(page, { password: 'yanlis' });
  await page.waitForFunction(() => document.getElementById('gateErr').textContent.length > 0);
  ok('kapı: yanlış parola reddediliyor',
     (await page.textContent('#gateErr')).includes('hatalı'), await page.textContent('#gateErr'));
  ok('kapı: hata Türkçe, sunucunun İngilizcesi değil',
     !(await page.textContent('#gateErr')).includes('Invalid login'));
  ok('kapı: reddedilince parola alanı temizleniyor', (await page.inputValue('#pw2')) === '');
  await mock.signIn(page);
  await page.waitForSelector('#gateScr', { state: 'hidden' });
  ok('kapı: doğru hesap açıyor', true);
  ok('kapı: oturum jeton olarak saklandı',
     await page.evaluate(() => !!JSON.parse(localStorage.getItem('anth_sb_session') || 'null')));

  // ── the frame ──────────────────────────────────────────────────────────────
  ok('adres: bölüm açılırken sayfa değişmiyor', page.url().startsWith(DASH), page.url());
  ok('menü: beş departman', (await page.$$('#dnav .dept')).length === 5);
  // Five listed sections, not eight: a department with one section is a button
  // that goes there, and carries its address in data-goes rather than a list of
  // one. The other four sections are still reachable — the next assertion is
  // what proves it, not this one.
  ok('menü: beş listelenmiş bölüm', (await page.$$('#dnav .dmenu a')).length === 5);
  ok('menü: listesiz departmanlar bir adres taşıyor',
     (await page.$$eval('#dnav .dept', ds => ds
        .filter(d => !d.querySelector('.dmenu'))
        .map(d => d.querySelector('button').getAttribute('data-goes')).join('|')))
     === '#ozet|#crm|#finans');
  ok('menü: hiçbir departman tek öğelik liste açmıyor',
     (await page.$$eval('#dnav .dept', ds => ds
        .map(d => d.querySelectorAll('.dmenu a').length)
        .filter(n => n === 1).length)) === 0);
  ok('menü: departman adları',
     (await page.$$eval('#dnav .dept > button', a => a.map(x => x.firstChild.textContent.trim()))).join('|')
     === 'Summary|Sales|Marketing|Finance|Developer',
     (await page.$$eval('#dnav .dept > button', a => a.map(x => x.firstChild.textContent.trim()))).join('|'));
  ok('menü: açılışta hiçbir liste açık değil',
     (await page.$$('#dnav .dept.open')).length === 0);
  ok('açılış: Summary işaretli',
     await page.getAttribute('.dept[data-dept="ozet"] button', 'aria-current') === 'true');

  // ── the dropdowns: hover opens them, the header is a link ──────────────────
  await page.hover('.dept[data-dept="developer"] button');
  await page.waitForTimeout(260);
  ok('menü: üzerine gelince açılıyor', await page.isVisible('.dept[data-dept="developer"] .dmenu'));
  ok('menü: üzerine gelmek bölüm değiştirmiyor', await page.isVisible('#sec-ozet'));
  ok('menü: aria-expanded doğru',
     await page.getAttribute('.dept[data-dept="developer"] button', 'aria-expanded') === 'true');
  await page.click('.dept[data-dept="developer"] .dmenu a[href="#analitik"]');
  await page.waitForTimeout(240);
  ok('menü: seçince gidiyor ve kapanıyor',
     await page.isVisible('#sec-analitik') && !(await page.isVisible('.dept[data-dept="developer"] .dmenu')));
  await page.hover('.dept[data-dept="developer"] button');
  await page.waitForTimeout(240);
  await page.click('.dept[data-dept="developer"] button');
  await page.waitForTimeout(240);
  ok('menü: başlığa basmak ilk bölüme götürüp listeyi kapatıyor',
     await page.isVisible('#sec-site') && !(await page.isVisible('.dept[data-dept="developer"] .dmenu')));
  await page.hover('.dept[data-dept="marketing"] button');
  await page.waitForTimeout(240);
  ok('menü: ikinci departman açılınca ilki kapanıyor',
     (await page.$$('#dnav .dept.open')).length === 1);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(160);
  ok('menü: Escape kapatıyor', (await page.$$('#dnav .dept.open')).length === 0);
  await page.click('.dept[data-dept="sales"] button');
  await page.waitForTimeout(240);
  ok('menü: tek bölümlü departman doğrudan gidiyor',
     (await page.$('.dept[data-dept="sales"] .dmenu')) === null && await page.isVisible('#sec-crm'));
  await page.hover('.dept[data-dept="marketing"] button');
  await page.waitForTimeout(260);
  ok('menü: hover başka departmana geçince tek liste açık',
     (await page.$$eval('#dnav .dept.open', n => n.map(x => x.dataset.dept))).join() === 'marketing');
  // the 6px gap under the button must not drop the menu on the way down
  await page.hover('.dept[data-dept="marketing"] .dmenu a[href="#blog"]');
  await page.waitForTimeout(260);
  ok('menü: liste öğesine inerken kapanmıyor',
     await page.isVisible('.dept[data-dept="marketing"] .dmenu'));
  await page.mouse.move(700, 700);
  await page.waitForTimeout(420);
  ok('menü: fareyi çekince kapanıyor', (await page.$$('#dnav .dept.open')).length === 0);

  // ── the bar itself ─────────────────────────────────────────────────────────
  ok('üst çubuk: ayırıcı çizgi tam yükseklikte', await page.evaluate(() => {
    const v = document.querySelector('.vsep'), t = document.querySelector('.top-in');
    if (!v) return false;
    return Math.abs(v.getBoundingClientRect().height - t.getBoundingClientRect().height) < 1
           && Math.round(v.getBoundingClientRect().width) === 1;
  }));
  ok('üst çubuk: ayırıcı menüden önce geliyor', await page.evaluate(() => {
    const v = document.querySelector('.vsep'), n = document.getElementById('dnav');
    return v.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING ? true : false;
  }));
  ok('üst çubuk: Site, Settings ve Sign out ikonlu',
     (await page.$$eval('.dutil a, .dutil button',
        ns => ns.map(n => n.textContent.trim() + ':' + (n.querySelector('svg') ? 1 : 0)).join('|')))
     === 'Site:1|Settings:1|Sign out:1',
     await page.$$eval('.dutil a, .dutil button', ns => ns.map(n => n.textContent.trim()).join('|')));
  ok('açılış: yalnızca tek bölüm görünür', (await page.$$('.sec:not([hidden])')).length === 1);
  ok('marka: wordmark 15px', Math.round(await page.evaluate(
     () => document.querySelector('.top img').getBoundingClientRect().height)) === 15);
  const topBg = await page.evaluate(() => getComputedStyle(document.querySelector('.top')).backgroundColor);
  ok('panel: üst çubuk koyu değil', topBg === 'rgb(255, 255, 255)', topBg);

  // ── every section opens, in place ──────────────────────────────────────────
  const SECS = ['ozet', 'crm', 'blog', 'icerik', 'site', 'seo', 'analitik', 'finans'];
  for (const s of SECS) {
    await go(page, s);
    ok(`bölüm ${s}: açılıyor`, await page.isVisible(`#sec-${s}`));
    // Only a listed section can be marked in a list. For the three that have
    // no list, the department button carrying the mark is the whole signal, and
    // that is asserted on the next line for every section alike.
    if (await page.$(`.dept[data-dept="${DEPT[s]}"] .dmenu a[href="#${s}"]`)) {
      ok(`bölüm ${s}: menüde işaretli`,
         await page.getAttribute(`.dept[data-dept="${DEPT[s]}"] .dmenu a[href="#${s}"]`, 'aria-current') === 'page');
    }
    ok(`bölüm ${s}: departmanı işaretli`,
       await page.getAttribute(`.dept[data-dept="${DEPT[s]}"] button`, 'aria-current') === 'true');
    ok(`bölüm ${s}: tek departman işaretli`,
       (await page.$$('#dnav .dept > button[aria-current="true"]')).length === 1);
    ok(`bölüm ${s}: tek bölüm görünür`, (await page.$$('.sec:not([hidden])')).length === 1);
    ok(`bölüm ${s}: başlık var`, !!(await page.textContent(`#sec-${s} .phead h1`)).trim());
    await overflow(page, `bölüm ${s}`);
  }
  ok('adres: hash bölümü taşıyor', page.url().endsWith('#finans'), page.url());

  // ── the hash survives a reload, and the door remembers ─────────────────────
  await page.goto(DASH + '#seo', { waitUntil: 'networkidle' });
  ok('yeniden yükleme: kapı sormuyor', await page.isHidden('#gateScr'));
  ok('yeniden yükleme: oturum tarayıcıyı aşıyor', await page.evaluate(
     () => !!JSON.parse(localStorage.getItem('anth_sb_session') || 'null')));
  ok('yeniden yükleme: SEO açık', await page.isVisible('#sec-seo'));
  ok('yeniden yükleme: başlık bölümü söylüyor', (await page.title()).startsWith('SEO'), await page.title());
  await page.goto(DASH + '#yokboyle', { waitUntil: 'networkidle' });
  ok('bilinmeyen bölüm: Summary\'ye düşüyor', await page.isVisible('#sec-ozet'));

  // ── Summary: countdown and the to-do list ──────────────────────────────
  await go(page, 'ozet');
  /* Three states, not one. A digit was the whole test until 20 August, when
     the launch date arrived and the tile correctly said "Bugün" with no digit
     in it — the assertion failed on the one day it was describing. And once
     the date passes, counting up from it is the wrong answer, so that case is
     asserted too rather than left to whatever the code happens to do. */
  const gun = await page.textContent('#ozGun');
  ok('summary: geri sayım üç durumdan birini söylüyor',
     /\d+\s*gün/.test(gun) || /Bugün/.test(gun) || /Tarih bekliyor/.test(gun), gun);
  ok('summary: geçmiş tarihten gün saymıyor', !/gün geçti/.test(gun), gun);

  /* A Summary is read for thirty seconds and acted on. Two tools were dropped
     on 10 August and both were still listed as "missing" ten days later, so the
     panel was asking for work nobody wanted. Naming them here is what stops
     them coming back with the next copy-paste. */
  const ozet = await page.textContent('#sec-ozet');
  for (const dead of ['reCAPTCHA', 'Calendly']) {
    ok(`summary: vazgeçilen ${dead} eksikler arasında değil`, !ozet.includes(dead));
  }
  await page.fill('#ozText', 'Test maddesi');
  await page.fill('#ozDate', '2020-01-01');
  await page.click('#ozForm button[type=submit]');
  await page.waitForTimeout(150);
  ok('genel bakış: madde eklendi', (await page.$$('#ozList li')).length === 1);
  ok('genel bakış: tarihi geçen kırmızı', await page.isVisible('#ozList .late'));
  ok('genel bakış: açık iş sayacı arttı', (await page.textContent('#ozAcik')) === '1');
  await page.click('#ozList .x');
  await page.waitForTimeout(120);
  ok('genel bakış: madde silindi', (await page.$$('#ozList li')).length === 0);

  // ── checklists remember themselves ─────────────────────────────────────────
  await go(page, 'site');
  await page.check('#s1');
  await page.waitForTimeout(120);
  ok('site: kontrol listesi sayacı işliyor',
     (await page.textContent('#siteCount')).startsWith('1 / '), await page.textContent('#siteCount'));
  await page.reload({ waitUntil: 'networkidle' });
  await go(page, 'site');
  ok('site: kutu yeniden yüklemede hatırlanıyor', await page.isChecked('#s1'));
  await page.uncheck('#s1');

  // ── Analitik: the snippet generator ────────────────────────────────────────
  await go(page, 'analitik');
  await page.fill('#gaId', 'saçma');
  await page.click('#gaGen');
  ok('analitik: geçersiz ID reddediliyor', (await page.textContent('#gaHint')).includes('değil'));
  ok('analitik: kopyala kapalı', await page.isDisabled('#gaCopy'));
  await page.fill('#gaId', 'g-4xy7qk2m0p');
  await page.click('#gaGen');
  const snippet = await page.textContent('#gaOut');
  ok('analitik: kod üretildi', snippet.includes('G-4XY7QK2M0P') && snippet.includes('gtag'));
  ok('analitik: ID büyük harfe çevrildi', (await page.inputValue('#gaId')) === 'G-4XY7QK2M0P');
  ok('analitik: kopyala açıldı', !(await page.isDisabled('#gaCopy')));

  // ── Finans: the cash model Finance handed over ─────────────────────────────
  await go(page, 'finans');
  ok('finans: üç akış var', (await page.$$('#sec-finans .pflow button')).length === 3);
  ok('finans: nakit modeli açık', await page.isVisible('#finTiles'));
  ok('finans: dört kart çizildi', (await page.$$('#finTiles .tile')).length === 4);
  ok('finans: grafik çizildi', (await page.$$('#finCh *')).length > 10);

  // ── the lines come first, months are the other view ────────────────────────
  ok('finans: açılışta kalemler listesi', await page.isVisible('#finLines'));
  ok('finans: ay listesi kapalı', await page.isHidden('#finMonths'));
  ok('finans: bütün kalemler listelendi', (await page.$$('#finLines .li')).length === 106,
     String((await page.$$('#finLines .li')).length));
  ok('finans: dokuz kategori başlığı ve bir genel toplam',
     (await page.$$('#finLines .fsec:not(.ftot)')).length === 9,
     String((await page.$$('#finLines .fsec:not(.ftot)')).length));
  ok('finans: her satır sıklığını taşıyor',
     (await page.$$eval('#finLines .li', ns => ns.every(n =>
        ['Aylık', 'Yıllık', 'Tek seferlik'].includes(n.children[2].textContent.trim())))));
  ok('finans: kalem başlık satırı üç yılı ayırıyor',
     (await page.$$eval('#finLineHead span', ns => ns.map(n => n.textContent.trim()))).join('|')
     === '|Kalem|Sıklık|Bugünkü ₺|Ağu 26 – Tem 27|Ağu 27 – Tem 28|Ağu 28 – Tem 29|Toplam ₺|',
     (await page.$$eval('#finLineHead span', ns => ns.map(n => n.textContent.trim()))).join('|'));
  // the arithmetic the CEO checked by hand: $100 a month is not $100 × 36 in
  // lira, because the model carries a rate that moves
  ok('finans: yıl sütunlarının toplamı toplam sütununa eşit', await page.evaluate(() => {
    const n = s => +s.replace(/[^\d]/g, '');
    const row = [...document.querySelectorAll('#finLines .li')]
      .find(r => r.querySelector('.nm').textContent.includes('Claude Max'));
    const c = [...row.children];
    // each cell is rounded to whole lira on its own, so the three can miss the
    // total by a lira or two; anything larger is a real disagreement
    return Math.abs(n(c[4].textContent) + n(c[5].textContent) + n(c[6].textContent)
                    - n(c[7].textContent)) <= 3;
  }));
  ok('finans: bugünkü sütunu aylık tutarı veriyor', await page.evaluate(() => {
    const row = [...document.querySelectorAll('#finLines .li')]
      .find(r => r.querySelector('.nm').textContent.includes('Claude Max'));
    const t = row.children[3].textContent;
    return t.includes('4.630') && t.includes('/ ay');
  }), await page.evaluate(() => [...document.querySelectorAll('#finLines .li')]
      .find(r => r.querySelector('.nm').textContent.includes('Claude Max')).children[3].textContent));
  ok('finans: yıllık akış üç satır', (await page.$$('#finYears tr')).length === 3);
  ok('finans: kategori tablosu dolu', (await page.$$('#finCats tr')).length === 10,
     String((await page.$$('#finCats tr')).length));

  // The subtotals sit in right-aligned columns and have to look it, and the
  // list has to add itself up — a column of subtotals with no total at the foot
  // is a sum the reader is asked to do.
  ok('finans: ara toplamlar sütuna hizalı', await page.evaluate(() => {
    const cell = document.querySelector('#finLines .fsec .csum');
    return getComputedStyle(cell).textAlign === 'right';
  }));
  // The export is what Finance reads, so its two jobs are checked: the panel
  // must be able to import it back, and a stale handover must be visible as one.
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#finExp')]);
  const dlPath = '/tmp/check-dash-devir.json';
  await dl.saveAs(dlPath);
  const devir = JSON.parse(fs.readFileSync(dlPath, 'utf8'));
  ok('devir: dosya adı tarih taşıyor', /^anthifel-finance-secim-\d{4}-\d{2}-\d{2}\.json$/.test(dl.suggestedFilename()),
     dl.suggestedFilename());
  ok('devir: panelin içe aktardığı anahtarlar duruyor',
     ['mode', 'real', 'off', 'on', 'edits', 'custom'].every(k => k in devir));
  ok('devir: Finance için özet var',
     devir._devir && devir._devir.tarih && devir._devir.senaryo &&
     devir._devir.toplam_gider_try && typeof devir._devir.dip_nakit_try === 'number',
     JSON.stringify(devir._devir || {}).slice(0, 120));
  ok('devir: üç yıl toplamı kendi içinde tutarlı', (() => {
    const t = devir._devir.toplam_gider_try;
    return Math.abs(t.yil1 + t.yil2 + t.yil3 - t.uc_yil) <= 3;
  })());

  // Handing over writes into the shared folder. The picker cannot be driven
  // from a test, so the folder is a stub — what is checked is this code: that
  // the handle is asked for once and reused, that the file lands under the
  // dated name, and that the contents are the same payload the download makes.
  await page.evaluate(() => {
    window.__written = [];
    window.__pickerCalls = 0;
    const dir = {
      queryPermission: async () => 'granted',
      requestPermission: async () => 'granted',
      getFileHandle: async (name) => ({
        createWritable: async () => ({
          write: async t => window.__written.push({ name, text: t }),
          close: async () => {},
        }),
      }),
    };
    window.showDirectoryPicker = async () => { window.__pickerCalls++; return dir; };
  });
  await page.click('#finHand');
  await page.waitForTimeout(500);
  await page.click('#finHand');
  await page.waitForTimeout(500);
  const wrote = await page.evaluate(() => ({ w: window.__written, p: window.__pickerCalls }));
  ok('devir: klasöre iki kez yazıldı', wrote.w.length === 2, String(wrote.w.length));
  ok('devir: klasör bir kez soruldu, sonra hatırlandı', wrote.p === 1, String(wrote.p));
  ok('devir: klasöre yazılan ad tarihli',
     /^anthifel-finance-secim-\d{4}-\d{2}-\d{2}\.json$/.test(wrote.w[0].name), wrote.w[0].name);
  ok('devir: klasöre yazılan içerik indirilenle aynı şekilde',
     (() => { const j = JSON.parse(wrote.w[0].text);
              return ['mode','real','off','on','edits','custom'].every(k => k in j) && !!j._devir; })());
  // and where the browser has no such API it is a download, not a dead button
  await page.evaluate(() => { delete window.showDirectoryPicker; window.__toast = null;
    const t = window.toast; window.toast = m => { window.__toast = m; t(m); }; });
  await page.click('#finHand');
  await page.waitForTimeout(400);
  ok('devir: API yoksa indirmeye düşüyor',
     /desteklemiyor/.test(await page.evaluate(() => window.__toast || '')),
     await page.evaluate(() => window.__toast || ''));

  ok('finans: listenin sonunda genel toplam var',
     (await page.$$('#finLines .fsec.ftot')).length === 1);
  ok('finans: genel toplam kategorilerin toplamına eşit', await page.evaluate(() => {
    const n = s => +String(s).replace(/[^\d]/g, '');
    const secs = [...document.querySelectorAll('#finLines .fsec')];
    const tot = secs.pop();
    const sum = secs.reduce((a, f) => a + n(f.children[7].textContent), 0);
    return Math.abs(sum - n(tot.children[7].textContent)) <= 9;
  }));

  // a month is a filter, not a different screen
  const allLines = (await page.$$('#finLines .li')).length;
  await page.selectOption('#finMonthSel', '5');
  await page.waitForTimeout(300);
  const some = (await page.$$('#finLines .li')).length;
  ok('finans: ay seçimi listeyi süzüyor', some > 0 && some < allLines, `${some} / ${allLines}`);
  ok('finans: ay seçilince yıl sütunları kalkıyor',
     (await page.$$('#finLines .li .yr')).length === 0
     && (await page.getAttribute('#finLines', 'class')).includes('one')
     && (await page.$$eval('#finLines .li', ns => ns[0].children.length)) === 6);
  ok('finans: başlık seçili ayı söylüyor',
     (await page.textContent('#finListTtl')).includes('Oca 2027'), await page.textContent('#finListTtl'));
  await page.selectOption('#finMonthSel', '');
  await page.waitForTimeout(300);
  ok('finans: süzgeç kalkıyor', (await page.$$('#finLines .li')).length === allLines);

  await page.click('#finVAy');
  await page.waitForTimeout(350);
  ok('finans: 36 ay listelendi', (await page.$$('#finMonths .mrow')).length === 36,
     String((await page.$$('#finMonths .mrow')).length));
  ok('finans: ay başlık satırı',
     (await page.$$eval('#finMonthHead span', ns => ns.map(n => n.textContent.trim()))).join('|')
     === '#|Tarih|Gelir ($)|Gider (₺)|Kapanış nakdi (₺)|');
  ok('finans: kalem listesi kapandı', await page.isHidden('#finLines'));

  // the icon buttons are 23px boxes; a glyph that does not sit in one is the
  // bug that put this assertion here
  await page.click('#finMonths .mrow[data-m="5"] .mhead');
  await page.waitForTimeout(300);
  const ibs = await page.$$eval('#finMonths .mrow[data-m="5"] .ib', ns => ns.slice(0, 6).map(n => {
    const b = n.getBoundingClientRect(), s = n.querySelector('svg');
    if (!s) return 'no-svg';
    const r = s.getBoundingClientRect();
    return Math.round(Math.abs((r.left + r.width / 2) - (b.left + b.width / 2))) + ',' +
           Math.round(Math.abs((r.top + r.height / 2) - (b.top + b.height / 2)));
  }));
  ok('finans: satır ikonları kutularında ortalı', ibs.every(v => v === '0,0'), ibs.join(' '));
  await page.click('#finVKalem');
  await page.waitForTimeout(300);

  // the model recomputes, and what the browser holds survives a reload
  const dipHalf = await page.textContent('#finTiles .tile:first-child .v');
  await page.click('#finPPaket');
  await page.waitForTimeout(250);
  ok('finans: mod değişince nakit yeniden hesaplanıyor',
     (await page.textContent('#finTiles .tile:first-child .v')) !== dipHalf);
  ok('finans: değişiklik kaydedildi',
     (await page.textContent('#finSaved')).length > 0);
  await page.click('#finPMevcut');
  await page.waitForTimeout(250);

  // ── Finans: the ledger ─────────────────────────────────────────────────────
  await page.click('#sec-finans .pflow button[data-flow="defter"]');
  await page.waitForTimeout(200);
  ok('finans: defter akışı açılıyor', await page.isVisible('#fiForm'));
  ok('finans: model akışı kapandı', !(await page.isVisible('#finTiles')));
  ok('defter: sunucudaki kayıt bu tarayıcıya geldi',
     (await page.$$('#fiRows tr')).length === 1
     && (await page.textContent('#fiRows')).includes('Sunucudan gelen'),
     await page.textContent('#fiRows'));
  ok('defter: kategori önce, Ekle sonra',
     (await page.$$eval('#fiForm > *', ns => ns.map(n => (n.querySelector('label') || n).textContent.trim())))
       .join('|') === 'Tarih|Tür|Kategori|Açıklama|Tutar (£)|Ekle',
     (await page.$$eval('#fiForm > *', ns => ns.map(n => (n.querySelector('label') || n).textContent.trim()))).join('|'));
  // clear the seeded row so the counts below start from nothing
  await page.click('#fiRows .x');
  await page.waitForTimeout(400);
  ok('finans: boş durum görünür', await page.isVisible('#fiEmpty'));
  await page.fill('#fiDesc', 'Discovery Sprint');
  await page.fill('#fiAmt', '1000');
  await page.click('#fiForm button[type=submit]');
  await page.selectOption('#fiType', 'gider');
  await page.selectOption('#fiCat', 'Yazılım ve araçlar');
  await page.fill('#fiDesc', 'Workspace');
  await page.fill('#fiAmt', '250');
  await page.click('#fiForm button[type=submit]');
  await page.waitForTimeout(150);
  ok('finans: iki kayıt listelendi', (await page.$$('#fiRows tr')).length === 2);
  ok('finans: gelir toplamı', (await page.textContent('#fiGelir')).includes('1.000'), await page.textContent('#fiGelir'));
  ok('finans: gider toplamı', (await page.textContent('#fiGider')).includes('250'), await page.textContent('#fiGider'));
  ok('finans: net doğru', (await page.textContent('#fiNet')).includes('750'), await page.textContent('#fiNet'));
  ok('finans: kategori dağılımı çizildi', (await page.$$('#fiCats tr')).length === 1);
  await page.click('#fiRows .x');
  await page.click('#fiRows .x');
  await page.waitForTimeout(120);
  ok('finans: kayıtlar silindi', await page.isVisible('#fiEmpty'));

  // ── the store ──────────────────────────────────────────────────────────────
  // The ledger is a record, so it has to be on the server, and the panel has to
  // say so rather than claim it. Both halves are checked.
  await page.selectOption('#fiType', 'gelir');
  await page.fill('#fiDesc', 'Sunucu testi');
  await page.fill('#fiAmt', '4200');
  await page.click('#fiForm button[type=submit]');
  await page.waitForTimeout(400);
  ok('defter: kayıt sunucuya yazıldı', sb.ledger.length === 1, JSON.stringify(sb.ledger));
  ok('defter: tablo şeması eşlendi', sb.ledger[0] &&
     sb.ledger[0].entry_date && sb.ledger[0].kind === 'gelir' &&
     sb.ledger[0].description === 'Sunucu testi' && Number(sb.ledger[0].amount) === 4200 &&
     sb.ledger[0].currency === 'GBP', JSON.stringify(sb.ledger[0]));
  ok('defter: sunucuya giden kayıt uyarısız',
     !(await page.textContent('#fiRows')).includes('yalnızca bu tarayıcıda'));
  await page.click('#fiRows .x');
  await page.waitForTimeout(400);
  ok('defter: silme sunucuya da gitti', sb.ledger.length === 0);

  // A write the server refuses must leave a mark that outlives the toast.
  await page.route('**/rest/v1/ledger', r =>
    r.request().method() === 'POST'
      ? r.fulfill({ status: 500, contentType: 'application/json', body: '{"message":"nope"}' })
      : r.fallback());
  await page.fill('#fiDesc', 'Sunucu reddetti');
  await page.fill('#fiAmt', '11');
  await page.click('#fiForm button[type=submit]');
  await page.waitForTimeout(500);
  ok('defter: sunucuya yazılamayan kayıt satırda işaretli',
     (await page.textContent('#fiRows')).includes('yalnızca bu tarayıcıda'),
     await page.textContent('#fiRows'));
  await page.unroute('**/rest/v1/ledger');
  await page.click('#fiRows .x');
  await page.waitForTimeout(300);

  // the model is working state, so it is a blob — debounced, because dragging a
  // value fires render() dozens of times and none of them is worth a round trip
  await page.click('#sec-finans .pflow button[data-flow="model"]');
  await page.waitForTimeout(250);
  await page.click('#finVAy');
  await page.click('#finPPaket');
  await page.waitForTimeout(1400);
  ok('model: sunucuya yazıldı', !!sb.kv.fin_model, Object.keys(sb.kv).join(','));
  ok('model: yazılan şey panelin dışa aktardığı şekil',
     !!sb.kv.fin_model && 'mode' in sb.kv.fin_model && 'off' in sb.kv.fin_model
     && 'edits' in sb.kv.fin_model && 'custom' in sb.kv.fin_model,
     Object.keys(sb.kv.fin_model || {}).join(','));
  ok('model: panel nerede kayıtlı olduğunu söylüyor',
     (await page.textContent('#finSaved')).includes('sunucuda'), await page.textContent('#finSaved'));
  // A burst of changes is one write, not one per render. Measured across a
  // burst rather than across the run, because separate actions minutes apart
  // *should* each be written.
  const pushed0 = sb.calls.filter(c => c === 'POST:dash_state').length;
  for (let i = 0; i < 4; i++) {
    await page.click(i % 2 ? '#finPMevcut' : '#finPPaket');
    await page.waitForTimeout(60);
  }
  await page.waitForTimeout(1400);
  const burst = sb.calls.filter(c => c === 'POST:dash_state').length - pushed0;
  ok('model: art arda değişiklikler tek yazma', burst === 1, String(burst));
  await page.click('#finPMevcut');
  await page.waitForTimeout(1200);
  await page.click('#finVKalem');
  await page.waitForTimeout(300);

  await page.click('#sec-finans .pflow button[data-flow="sabit"]');
  await page.waitForTimeout(250);
  ok('finans: sabit giderler akışı açılıyor',
     (await page.$$('#sec-finans .pfpane[data-flow="sabit"] .panel')).length === 4);
  ok('finans: defter akışı kapandı', !(await page.isVisible('#fiForm')));
  ok('finans: yıllık ve tek seferlik kalemler modelden geldi',
     (await page.$$('#fxRows tr')).length > 30, String((await page.$$('#fxRows tr')).length));
  ok('finans: aylık kalem bu listede yok',
     !(await page.$$eval('#fxRows tr', ns => ns.some(n => n.children[1].textContent.trim() === 'Aylık'))));
  ok('finans: sonraki on iki ay dolu', (await page.$$('#fnextRows tr')).length === 12);
  await overflow(page, 'finans · sabit giderler');
  await page.click('#sec-finans .pflow button[data-flow="model"]');
  await page.waitForTimeout(250);

  // ── İçerik and SEO: the reference sections carry their content ─────────────
  await go(page, 'icerik');
  ok('içerik: akış şeridi çizildi', (await page.$$('#cosNav a')).length === 13);
  ok('içerik: plan tohumdan yüklendi', +(await page.textContent('#cosAll')) > 100,
     await page.textContent('#cosAll'));
  ok('içerik: panel görünümü çizildi', !!(await page.evaluate(() => document.getElementById('cosMain').children.length)));
  await page.click('#cosNav a[data-v="cal"]');
  await page.waitForTimeout(200);
  ok('içerik: takvim açılıyor', (await page.textContent('#cosTtl')) === 'Takvim');
  await page.click('#cosNav a[data-v="board"]');
  await page.waitForTimeout(200);
  ok('içerik: akış tahtası beş sütun', (await page.$$('#cos .col')).length === 5,
     String((await page.$$('#cos .col')).length));
  await page.click('#cosNav a[data-v="rules"]');
  await page.waitForTimeout(200);
  ok('içerik: kurallar kütüphanesi açılıyor', (await page.textContent('#cosTtl')).startsWith('Kural'));
  const rules = await page.textContent('#cosMain');
  ok('içerik: metin denetimi kurallarda', rules.includes('yasak kelimeler') && rules.includes('Coğrafi referans yok'));
  await page.click('#cosNav a[data-v="list"]');
  await page.waitForTimeout(200);
  await page.click('#cosMain [data-id]');
  await page.waitForTimeout(250);
  ok('içerik: kayda tıklayınca düzenleme açılıyor', await page.isVisible('#cosDlg .fr, #cosDlg textarea'));
  await page.keyboard.press('Escape');
  await page.waitForTimeout(200);
  await overflow(page, 'içerik · liste');
  await go(page, 'seo');
  ok('seo: kural tablosu dolu', (await page.$$('#sec-seo .tbl tbody tr')).length > 8);

  // ── CRM ────────────────────────────────────────────────────────────────────
  await go(page, 'crm');
  ok('crm: karşılama ekranı', await page.isVisible('#crm .welcome'));
  ok('crm: İndir kapalı', await page.isDisabled('#crmSave'));
  await page.click('#crm .wact .btn.ghost');                       // örnek veriyle dene
  await page.waitForSelector('#crm .kpis');
  ok('crm: örnek veri yüklendi', (await page.textContent('#crmStatus')).includes('kişi'));
  ok('crm: akış şeridinde on akış', (await page.$$('#crm .pnav a')).length === 10);
  ok('crm: KPI sayısı', (await page.$$('#crm .kpi')).length === 5);
  await overflow(page, 'crm · genel bakış');

  const flows = ['havuz', 'favori', 'l-yakin', 'l-hedef', 'l-izleme', 'l-pas', 'yol', 'triyaj', 'dm'];
  for (let i = 0; i < flows.length; i++) {
    await page.click(`#crm .pnav a:nth-of-type(${i + 2})`);
    await page.waitForTimeout(120);
    const empty = await page.evaluate(() => !document.querySelector('#crmPage').children.length);
    ok(`crm akış ${flows[i]}: içerik çiziliyor`, !empty);
    await overflow(page, `crm akış ${flows[i]}`);
  }

  await page.click('#crm .pnav a:nth-of-type(2)');                 // Havuz
  await page.waitForSelector('#crm .thead');
  const rows = await page.evaluate(() => document.querySelectorAll('#crm .trow').length);
  ok('crm: satırlar sanal çiziliyor', rows > 5 && rows < 60, String(rows));
  await page.fill('#crm .search input', 'Paribu');
  await page.waitForTimeout(320);
  const count = (await page.textContent('#crm .fbar > span:last-child')).trim();
  ok('crm: arama süzüyor', /\/ 6\.000 kişi$/.test(count) && !count.startsWith('6.000'), count);
  ok('crm: toplu aksiyon çubuğu açıldı', await page.isVisible('#crm .bulk'));
  const before = await page.textContent('#crm .pnav a:nth-of-type(4)');
  await page.click('#crm .bulk .btn.hedef');
  await page.waitForTimeout(150);
  ok('crm: toplu aksiyon sayacı değiştirdi',
     (await page.textContent('#crm .pnav a:nth-of-type(4)')) !== before);
  await page.click('#crmUndo');
  await page.waitForTimeout(150);
  ok('crm: geri al sayacı geri getirdi',
     (await page.textContent('#crm .pnav a:nth-of-type(4)')) === before);

  await page.click('#crm .pnav a:nth-of-type(9)');                 // Triyaj
  await page.waitForTimeout(120);
  await page.click('#crm .subtabs button:nth-child(2)');           // Hızlı triyaj
  await page.waitForSelector('#crm .bigcard');
  const p1 = await page.textContent('#crm .bigcard h2');
  await page.keyboard.press('1');
  await page.waitForTimeout(150);
  ok('crm: klavye triyajı ilerliyor', p1 !== (await page.textContent('#crm .bigcard h2')));

  await page.click('#crm .pnav a:nth-of-type(10)');                // DM
  await page.waitForSelector('#crm .dmlist');
  const msg = await page.inputValue('#crm textarea');
  ok('crm: DM mesajı şablondan dolduruldu', msg.length > 80 && !msg.includes('{ilkAd}'));
  await overflow(page, 'crm · DM');

  // The CRM's keyboard shortcuts must not fire while another section is open.
  await go(page, 'finans');
  await page.keyboard.press('1');
  await page.waitForTimeout(120);
  ok('crm: kısayollar başka bölümdeyken sessiz', errs.length === 0, errs.slice(0, 2).join(' | '));

  // ── the blog editor ────────────────────────────────────────────────────────
  await go(page, 'blog');
  ok('blog: editör açıldı', await page.isVisible('#sec-blog .blogcols'));
  ok('blog: kurulum uyarısı görünür', await page.isVisible('#offNote'));
  /* 20 Ağustos. Anahtarsız bir panelde liste boş kalıyor ve "Henüz yazı yok"
     diyordu — yazılar var, bu tarayıcı soramıyor. Yanlış cevap, doğru cevaptan
     daha pahalı: olmayan bir hatayı aratıyor. */
  ok('blog: anahtar yokken liste "yazı yok" demiyor',
     !/Henüz yazı yok/.test(await page.textContent('#sec-blog #listEmpty')),
     await page.textContent('#sec-blog #listEmpty'));
  ok('blog: …sebebini söylüyor',
     /panel anahtarı/i.test(await page.textContent('#sec-blog #listEmpty')),
     await page.textContent('#sec-blog #listEmpty'));
  await page.click('#newBtn');
  await page.waitForTimeout(150);
  await page.fill('#title', 'Yapay zekâ dönüşümü neden bir insan problemi?');
  await page.waitForTimeout(150);
  ok('blog: slug başlıktan türetildi',
     (await page.inputValue('#slug')) === 'yapay-zeka-donusumu-neden-bir-insan-problemi',
     await page.inputValue('#slug'));
  ok('blog: yazar listesi iki isim', (await page.$$('#author option')).length === 2);
  await page.click('#tabPrev');
  await page.waitForTimeout(150);
  ok('blog: önizleme sekmesi çalışıyor', await page.isVisible('#panedPrev'));
  await page.click('#tabWrite');

  /* DEV-090 — the Journal shell button.
     The bug this closes was not that the rewrite was hard; it was that the
     rewrite could only be reached through a post. So what is asserted here is
     reachability without one, and refusal without a key: this build has no
     DASH_TOKEN, so pressing it must say so rather than fire a request into the
     dark. The publisher's own behaviour is check-publish's job. */
  /* DEV-041, 20 Ağustos. Panelin görsel öneki `__SITE_PREFIX__` ile damgalanıyor
     ve damga `'/%s/' % PREVIEW_DIR if PREVIEW_DIR else '/'` yazıyordu — Python'da
     `%`, koşuldan daha sıkı bağlar, yani sonuç her iki build'de de `/preview/`
     idi. Yayındaki panel sitenin /preview/ altında olduğunu sanıyor, arka uç
     kökte yazıyordu; panel bunu her açılışta söylüyordu ve haklıydı. Damga
     artık hangi build olduğuna bakıyor, ve burada **build'e göre** ölçülüyor:
     sabit bir değer beklemek, aynı hatayı ikinci kez yapmak olurdu. */
  const dashPrefix = await page.evaluate(() =>
    (document.documentElement.innerHTML.match(/var SITE_PREFIX = '([^']*)'/) || [])[1]);
  // ROOT, not DASH: the address served is /dashboard/ in both builds — what
  // says which build this is, is the directory being served from.
  const isPreviewBuild = /(^|[\\/])preview([\\/]|$)/.test(ROOT);
  ok('blog: görsel öneki build ile aynı',
     dashPrefix === (isPreviewBuild ? '/preview/' : '/'),
     `panel=${dashPrefix} build=${isPreviewBuild ? 'preview' : 'production'}`);

  ok('blog: Journal yeniden yazma düğmesi başlıkta',
     await page.isVisible('#sec-blog #rewriteBtn'));
  ok('blog: düğme bir yazı açmadan erişilebilir',
     await page.evaluate(() => {
       const b = document.getElementById('rewriteBtn');
       return !b.disabled && !b.closest('.blogcols');
     }));
  const listBefore = (await page.$$('#sec-blog .plist li')).length;
  await page.click('#rewriteBtn');
  await page.waitForTimeout(200);
  ok('blog: anahtarsızken yazmaz, sebebini söyler',
     /anahtar/i.test(await page.textContent('#sec-blog #msg')),
     await page.textContent('#sec-blog #msg'));
  ok('blog: düğme kendini kilitli bırakmıyor',
     !(await page.$eval('#rewriteBtn', b => b.disabled)));
  ok('blog: hiçbir taslak açılmadı, liste aynı',
     (await page.$$('#sec-blog .plist li')).length === listBefore);

  await overflow(page, 'blog');

  // ── responsive ─────────────────────────────────────────────────────────────
  for (const w of WIDTHS) {
    await page.setViewportSize({ width: w, height: 900 });
    await page.waitForTimeout(220);
    await overflow(page, `blog ${w}px`);
  }
  await page.setViewportSize({ width: 560, height: 900 });
  await page.waitForTimeout(200);
  ok('mobil: menü hamburgerin arkasında', !(await page.isVisible('.dept[data-dept="sales"] button')));
  await page.click('#dburger');
  await page.waitForTimeout(150);
  ok('mobil: hamburger menüyü açıyor', await page.isVisible('.dept[data-dept="sales"] button'));
  await page.click('.dept[data-dept="ozet"] button');
  await page.waitForTimeout(200);
  ok('mobil: seçince menü kapanıyor', !(await page.isVisible('.dept[data-dept="sales"] button')));
  await overflow(page, 'mobil · genel bakış');

  // ── Content: four groups, four rows ────────────────────────────────────────
  // Back to a desktop first: the mobile pass above left the viewport at 380px,
  // where the menu is behind the burger and none of this is reachable.
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.waitForTimeout(200);
  await go(page, 'icerik');
  await page.waitForTimeout(300);
  {
    const rows = await page.$$eval('#cosNav .navrow', rs => rs.map(r => ({
      cap: (r.querySelector('.navcap') || {}).textContent || '',
      links: r.querySelectorAll('a').length,
      top: Math.round(r.getBoundingClientRect().top),
    })));
    ok('içerik: dört grup, dört satır', rows.length === 4, JSON.stringify(rows.map(r => r.cap)));
    ok('içerik: gruplar sırayla', rows.map(r => r.cap.trim()).join('|')
       === 'Yönetim|Kanallar|Plan|Kütüphane', rows.map(r => r.cap).join('|'));
    // The point of the change: each group starts on its own line, so no section
    // can wrap up under the group above it.
    ok('içerik: her grup kendi satırında',
       rows.every((r, i) => i === 0 || r.top > rows[i - 1].top), JSON.stringify(rows.map(r => r.top)));
    ok('içerik: hiçbir bölüm kaybolmadı',
       rows.reduce((n, r) => n + r.links, 0) === 13,
       String(rows.reduce((n, r) => n + r.links, 0)));
  }
  await overflow(page, 'içerik · gruplar');

  // ── Settings: what this browser holds ──────────────────────────────────────
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(DASH, { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);
  await page.click('#settingsBtn');
  await page.waitForTimeout(300);
  ok('ayarlar: üst çubuktaki düğme açıyor', await page.isVisible('#sec-settings'));
  // The menu is English; a section whose own heading is Turkish contradicts the
  // label the reader just clicked. Bodies are still Turkish and that is the
  // remaining half of the job — the headings are not.
  {
    const heads = {};
    for (const sec of ['ozet', 'crm', 'icerik', 'finans', 'analitik', 'site', 'seo', 'settings']) {
      heads[sec] = (await page.textContent(`#sec-${sec} .phead h1`) || '').trim();
    }
    ok('bölüm başlıkları menüyle aynı dilde',
       ['Summary', 'CRM', 'Content', 'Finance', 'Analytics', 'Site', 'SEO', 'Settings']
         .join('|') === Object.values(heads).join('|'), JSON.stringify(heads));
  }
  ok('ayarlar: hiçbir departman işaretli kalmıyor',
     (await page.$$('#dnav .dept > button[aria-current="true"]')).length === 0);
  ok('ayarlar: sekme adı bölümün kendi başlığından geliyor',
     (await page.title()).startsWith('Settings'), await page.title());
  ok('ayarlar: anahtar yokken "not set" diyor',
     /not set/.test(await page.textContent('#setKeyState')));
  await page.fill('#setKey', 'test-panel-key-123456');
  await page.click('#setKeySave');
  await page.waitForTimeout(220);
  ok('ayarlar: anahtar bu tarayıcıya yazılıyor',
     await page.evaluate(() => localStorage.getItem('anthifel_dash_token')) === 'test-panel-key-123456');
  ok('ayarlar: kaydedince durum değişiyor',
     /held in this browser/.test(await page.textContent('#setKeyState')));
  ok('ayarlar: alan kaydettikten sonra anahtarı göstermiyor',
     await page.inputValue('#setKey') === '');
  // The blog editor and this page must name the same key, or one of them is
  // configuring something nobody reads. Asserted on the source rather than by
  // opening the editor: with a key set the editor would go live and call the
  // Apps Script, and a test suite must not reach a real endpoint.
  ok('ayarlar: blog editörü aynı anahtar adını okuyor', await page.evaluate(() => {
    const src = document.documentElement.outerHTML;
    const names = new Set((src.match(/anthifel_dash_token/g) || []).map(String));
    return names.size === 1 && (src.match(/anthifel_dash_token/g) || []).length >= 2;
  }));
  await page.click('#setKeyClear');
  await page.waitForTimeout(200);
  ok('ayarlar: unut düğmesi anahtarı siliyor',
     await page.evaluate(() => localStorage.getItem('anthifel_dash_token')) === null);
  await overflow(page, 'ayarlar');

  // ── old links still work ───────────────────────────────────────────────────
  await page.goto(`http://127.0.0.1:${PORT}/dashboard/crm/`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  ok('eski bağlantı: /dashboard/crm/ panele yönleniyor',
     page.url().endsWith('/dashboard/#crm'), page.url());
  await page.goto(`http://127.0.0.1:${PORT}/dashboard/blog/`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  ok('eski bağlantı: /dashboard/blog/ panele yönleniyor',
     page.url().endsWith('/dashboard/#blog'), page.url());

  // ── the old dashboard no longer competes with this one ────────────────────
  // Two shapes are acceptable before launch: the folder is gone, or it holds
  // nothing but redirects. Anything else means the panel is live twice, which
  // is what happened on 5 August when a hand upload landed on the root.
  const OLD = path.join(__dirname, '..', 'repo', 'dashboard');
  ok('eski panel: kökte ya yok ya da yalnızca yönlendirme',
     !fs.existsSync(OLD) || !fs.readdirSync(OLD).some(f => {
       const p = path.join(OLD, f);
       return fs.statSync(p).isFile() && fs.statSync(p).size > 2048;
     }),
     fs.existsSync(OLD) ? fs.readdirSync(OLD).join(', ') : 'yok');
  if (fs.existsSync(OLD)) {
    const stubs = ['index.html', 'overview.html', 'crm.html', 'content.html', 'website.html',
                   'seo.html', 'analytics.html', 'finance.html',
                   'apps/anc.html', 'apps/content-os.html'];
    const stray = fs.readdirSync(OLD).filter(f => f !== 'apps' && !stubs.includes(f));
    ok('eski panel: geriye yalnızca yönlendirmeler kaldı', stray.length === 0, stray.join(', '));
    const all = stubs.every(f => {
      const p = path.join(OLD, f);
      return fs.existsSync(p) && fs.readFileSync(p, 'utf8').includes('/preview/dashboard/');
    });
    ok('eski panel: her sayfa yeni panele yönleniyor', all);
  }

  ok('konsol: hata yok', errs.length === 0, errs.slice(0, 3).join(' | '));

  await browser.close();
  server.close();

  const fail = results.filter(r => !r.c);
  results.forEach(r => console.log(`${r.c ? ' ok ' : 'FAIL'}  ${r.n}${r.d ? '   — ' + r.d : ''}`));
  console.log(`\n${results.length - fail.length}/${results.length} passed`);
  if (!fail.length) console.log('NO OVERFLOW ANYWHERE');
  process.exit(fail.length ? 1 : 0);
})();
