/**
 * check-comingsoon.js — the page that is actually live.
 *
 * The coming-soon page at the repo root is the only Anthifel page the public
 * can see, and it is the one page not produced by build.py. It was missed by
 * the first Brand Guidelines sweep for exactly that reason, so it now has its
 * own guard.
 *
 *   node check-comingsoon.js [path]
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

/* 20 August. This read '../repo/index.html', resolved against the *working
   directory* rather than against this file — so running it from the project
   root pointed it at /root/repo/index.html, a copy last touched on 5 August.
   The suite that guards the only page the public can actually reach had been
   passing against a two-week-old file, and passing is exactly what made it
   invisible. Anchored to __dirname now, and it refuses to run rather than
   silently test nothing. */
const DEFAULT_FILE = path.join(__dirname, 'repo', 'index.html');
const TARGET = path.resolve(process.argv[2] || DEFAULT_FILE);
if (!fs.existsSync(TARGET)) {
  console.error(`check-comingsoon: ${TARGET} yok. Yol yanlışsa test hiçbir şeyi kontrol etmez.`);
  process.exit(2);
}
const FILE = 'file://' + TARGET;
let pass = 0, fail = 0;
const ok = (n, c, d) => { c ? pass++ : fail++; console.log(`  ${c ? '✓' : '✗'} ${n}${d ? '  — ' + d : ''}`); };

(async () => {
  const browser = await chromium.launch({
    executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  await page.goto(FILE, { waitUntil: 'load' });
  const body = await page.textContent('body');

  console.log('\n— Brand Guidelines §8, the four site-wide rules —');
  ok('no em dash', !/—/.test(body), (body.match(/.{0,24}—.{0,24}/g) || []).join(' | '));
  ok('no "wrong"', !/\bwrong\b/i.test(body));
  ok('no "X not Y" framing against technology',
     !/not with technology|not just the technology|rather than technology/i.test(body));
  ok('the withdrawn sentence is gone',
     !/biggest risk is not choosing|not with technology, but with the people/i.test(body));

  console.log('\n— §8.3 hero —');
  ok('tagline is the sanctioned one', /AI needs a guide,\s*not just tools/i.test(body.replace(/\s+/g, ' ')));
  ok('sub-line is the replacement from §8.3',
     body.includes('Transformation is new for everyone.') &&
     body.includes('while every part of your company adapts to AI'));

  console.log('\n— no prices, ever —');
  ok('no figure with a currency', !/[$£€₺]\s?\d/.test(body), (body.match(/[$£€₺]\s?[\d,.]+/g) || []).join(' '));
  ok('no "from" pricing', !/\bfrom \$|\bstarting at\b|başlangıç fiyat/i.test(body));

  console.log('\n— the basics —');
  ok('one h1', (await page.$$('h1')).length === 1);
  ok('contact address present', /hello@anthifel\.com/.test(body));
  const marks = await page.$$eval('img', is => is.map(i => i.getBoundingClientRect().height));
  ok('every mark ≥ 15 px', marks.every(h => h >= 15), marks.map(h => h.toFixed(1)).join(', '));
  ok('no page errors', errs.length === 0, errs.join(' | '));

  /* The trading disclosure, 20 August. This page is the only public page the
     company has, and the duty to publish these four facts started on the day
     of incorporation rather than on the day of launch. Each one is checked
     separately: a footer that lost the number but kept the address would still
     look like a footer, and that is exactly how this kind of line rots. */
  console.log('\n— the trading disclosure —');
  const foot = await page.textContent('footer');
  ok('the registered name', /Anthifel Ltd/.test(foot), foot);
  ok('the company number', /17411895/.test(foot), foot);
  ok('where it is registered', /England and Wales/.test(foot), foot);
  ok('the registered office', /Leroy House.*London N1 3FY/.test(foot), foot);

  for (const w of [1440, 900, 560, 380]) {
    await page.setViewportSize({ width: w, height: 900 });
    await page.waitForTimeout(150);
    const bad = await page.evaluate(() => {
      const vw = document.documentElement.clientWidth;
      return [...document.querySelectorAll('body *')].filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.right > vw + 1 && getComputedStyle(el).position !== 'fixed';
      }).map(el => el.tagName.toLowerCase()).slice(0, 3);
    });
    ok(`${w}px: no overflow`, bad.length === 0, bad.join(', '));
  }

  await browser.close();
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed`);
  if (fail === 0) console.log('NO OVERFLOW ANYWHERE');
  process.exit(fail === 0 ? 0 : 1);
})();
