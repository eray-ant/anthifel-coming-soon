/**
 * check-links.js — Anthifel
 *
 * Every internal link in every built page, resolved against the built tree.
 *
 * This exists because of `meet/`. It was linked from three places, it never
 * existed, and it stayed broken for days with a full green suite — because the
 * old check understood exactly two shapes: a `#anchor`, and a bare `foo.html`
 * sitting beside index.html. A link to a directory, a link with a fragment on
 * the end, a link one level up: none of them were resolved, and none of them
 * were reported as unchecked either. A test that silently skips what it cannot
 * parse is worse than no test, because it is counted as a pass.
 *
 * What it resolves:
 *
 *   foo.html          → dist/<t>/foo.html
 *   foo.html#bit      → that file, and #bit must exist inside it
 *   blog/             → dist/<t>/blog/index.html
 *   ../index.html     → relative to the page doing the linking
 *   #bit              → an element with that id on the same page
 *   https://…, mailto:, tel:  → left alone, and counted so the number is visible
 *
 * Three things it knows about, because they are true by design rather than
 * broken. Each one is printed rather than hidden, and each disappears on its
 * own when the thing it is waiting for happens:
 *
 *   1. `blog/_tpl-*.html` are templates. They are written to `blog/<slug>/`
 *      when a post is published, so their links are resolved from that depth,
 *      not from where the template file sits.
 *   2. The four footer blog links point at posts that have not been published.
 *      Listed as pending, not as failures — until the blog goes live, at which
 *      point they must resolve and this list must be empty.
 *   3. `privacy.html`, `terms.html` and `cookies.html` are missing from the
 *      production build on purpose: the build refuses to write a page that
 *      still carries Legal's placeholders. Links to them are dead in
 *      production today and will not be at launch.
 *
 * Anything else is a failure.
 */
const path = require('path');
const fs = require('fs');

const TARGETS = ['dist/preview', 'dist/production'];
let pass = 0, fail = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };

function walk(dir, out) {
  for (const name of fs.readdirSync(dir)) {
    const fp = path.join(dir, name);
    const st = fs.statSync(fp);
    if (st.isDirectory()) walk(fp, out);
    else if (name.endsWith('.html')) out.push(fp);
  }
  return out;
}

/* Scripts and styles are stripped first. Without that, every `href="' + x + '"`
   inside an inline script is read as a link and the report fills with things
   that are not links at all — which is how a checker gets ignored. */
function markupOnly(html) {
  return html.replace(/<script\b[\s\S]*?<\/script>/gi, ' ')
             .replace(/<style\b[\s\S]*?<\/style>/gi, ' ');
}

/* Read with a regex rather than a browser on purpose: this has to see links in
   markup that JavaScript never renders — the templates, the panes that start
   hidden, the half of every page that is in the other language. */
function hrefs(html) {
  const out = [];
  const re = /<a\b[^>]*?\shref\s*=\s*("([^"]*)"|'([^']*)')/gi;
  let m;
  while ((m = re.exec(html))) out.push(m[2] !== undefined ? m[2] : m[3]);
  return out;
}

function ids(html) {
  const out = new Set();
  let m;
  const re = /\sid\s*=\s*("([^"]*)"|'([^']*)')/gi;
  while ((m = re.exec(html))) out.add(m[2] !== undefined ? m[2] : m[3]);
  const re2 = /<a\b[^>]*?\sname\s*=\s*("([^"]*)"|'([^']*)')/gi;
  while ((m = re2.exec(html))) out.add(m[2] !== undefined ? m[2] : m[3]);
  return out;
}

const EXTERNAL = /^(https?:|mailto:|tel:|data:|javascript:)/i;

/* The dashboard is one page whose sections are drawn by JavaScript and
   addressed by hash. `#crm` is a route, not an element, and the page falls back
   to the overview for anything it does not know. `check-dash.js` tests that
   behaviour directly, including the fallback, so resolving those fragments
   here would report a fault that does not exist. */
const HASH_ROUTED = /(^|\/)dashboard\//;

const PENDING = [
  // Written to match the path from anywhere, not only from the site root: the
  // Journal's own footer reaches its posts as ../blog/<slug>/ and the anchored
  // pattern let those four through as real failures.
  { when: p => /(^|\/)blog\/[a-z0-9-]+\/(index\.html)?$/.test(p),
    why: 'blog post not published yet — §10 item 17' },
  { when: p => /^(privacy|terms|cookies)\.html$/.test(p),
    why: "Legal's three details are missing, so production refuses to write it — §10 item 45",
    only: 'dist/production' },
  // The About page is written to preview with a flat square in place of the
  // portrait and withheld from production entirely until the real one lands.
  // Its footer link is on every page either way, which is correct: the link is
  // right and the page is late. The day the picture arrives this row stops
  // matching and the suite goes back to demanding the file.
  { when: p => p === 'about.html', only: 'dist/production',
    why: 'the founder portrait has not arrived, so production refuses to write the page' },
];

for (const t of TARGETS) {
  const root = path.resolve(t);
  if (!fs.existsSync(root)) { console.log(`\n— ${t}: not built, skipped —`); continue; }
  console.log(`\n— ${t} —`);

  const pages = walk(root, []);
  const cache = {};
  const read = fp => (cache[fp] !== undefined ? cache[fp] : (cache[fp] = fs.readFileSync(fp, 'utf8')));

  let checked = 0, external = 0;
  const broken = [];
  const pending = [];

  for (const pageFile of pages) {
    const raw = read(pageFile);
    const html = markupOnly(raw);
    const rel = path.relative(root, pageFile);
    const own = ids(html);

    /* A template is resolved from where it will be written, not from where it
       is stored. All four live in blog/ because that is where the publisher
       reads them; only one of them is served from there.
         _tpl-index.html     → blog/index.html                 (as stored)
         _tpl-post.html      → blog/<slug>/index.html          one deeper
         _tpl-index-en.html  → en/blog/index.html              one deeper
         _tpl-post-en.html   → en/blog/<slug>/index.html       two deeper
       Checking them where they sit would call every English prefix broken and
       every Turkish one fine, which is the wrong answer twice. */
    const TPL_AS = [
      [/(^|\/)blog\/_tpl-post\.html$/,     ['blog', 'a-slug', 'index.html']],
      [/(^|\/)blog\/_tpl-index-en\.html$/, ['en', 'blog', 'index.html']],
      [/(^|\/)blog\/_tpl-post-en\.html$/,  ['en', 'blog', 'a-slug', 'index.html']]
    ];
    const as = TPL_AS.find(([re]) => re.test(rel));
    const from = as ? path.join(root, ...as[1]) : pageFile;

    for (const href of new Set(hrefs(html))) {
      if (EXTERNAL.test(href)) { external++; continue; }

      if (href.startsWith('#')) {
        checked++;
        if (href.length > 1 && !HASH_ROUTED.test(rel) && !own.has(href.slice(1))) {
          broken.push(`${rel} → ${href} (no such id on this page)`);
        }
        continue;
      }

      let p = href.split('#')[0].split('?')[0];
      const frag = href.includes('#') ? href.split('#')[1] : null;
      if (p === '') { checked++; continue; }

      const base = p.startsWith('/') ? path.join(root, p)
                                     : path.resolve(path.dirname(from), p);
      const candidates = [];
      if (p.endsWith('/')) candidates.push(path.join(base, 'index.html'));
      else {
        candidates.push(base);
        if (!path.extname(base)) candidates.push(path.join(base, 'index.html'));
      }

      checked++;
      const hit = candidates.find(c => fs.existsSync(c) && fs.statSync(c).isFile());
      if (!hit) {
        /* Matched on where the link lands, not on how it was written:
           `../privacy.html` and `privacy.html` are the same missing page. */
        const landed = path.relative(root, candidates[0]).replace(/\\/g, '/');
        const known = PENDING.find(k => (!k.only || k.only === t) && (k.when(p) || k.when(landed)));
        const line = `${rel} → ${href}`;
        if (known) pending.push(`${line}  (${known.why})`);
        else broken.push(`${line} (nothing at ${candidates.map(c => path.relative(root, c)).join(' or ')})`);
        continue;
      }
      if (frag && !HASH_ROUTED.test(path.relative(root, hit))) {
        if (!ids(markupOnly(read(hit))).has(frag)) {
          broken.push(`${rel} → ${href} (${path.relative(root, hit)} has no id="${frag}")`);
        }
      }
    }
  }

  ok(`${pages.length} pages walked, ${checked} internal links resolved`, checked > 0);

  // Every page a visitor can land on carries the same way out. Before 12 August
  // the service page and the three legal pages had only a copyright line: no
  // address, no menu, no blog, nothing but the header to get back into the site.
  /* 404.html is the one exception, and it is a decision rather than an
     oversight. The full footer is the way *back into* a site you are already
     in; a 404 is a dead end, and the kindest thing on it is one way home and
     the three legal links, not a menu of everything. It is checked below on its
     own terms instead of being waved through. */
  /* 20 August, second pass: the 404 is a public page again. It was built on a
     minimal template with a bare header, on the reasoning that a dead end does
     not need a menu; the CEO ruled the other way, and he is right about the
     reader — somebody who mistyped an address usually knows where they were
     going. So it carries the same header and footer as everything else and is
     held to the same rule. */
  const PUBLIC = pages.filter(f => {
    const r = path.relative(root, f).replace(/\\/g, '/');
    return !/_tpl-/.test(r) && !/(^|\/)dashboard\//.test(r);
  });
  const noFooter = PUBLIC.filter(f => {
    const h = read(f);
    return !/class="ftr-g"/.test(h) || !/class="soc"/.test(h);
  }).map(f => path.relative(root, f));
  /* The 404, on its own terms. It is served at every wrong address on the site,
     so its links have to be absolute — a relative "index.html" from
     /blog/nope/ points at nothing — and it has to offer a way out at all. */
  const nf = pages.find(f => path.relative(root, f).replace(/\\/g, '/') === '404.html');
  if (nf) {
    const h = read(nf);
    const hrefs = [...h.matchAll(/href="([^"]+)"/g)].map(m => m[1])
      // The favicon is a data: URI — the fonts and the mark are inlined on
      // every page in this site, so "link" here means a link, not every href.
      .filter(u => !/^(https?:|mailto:|tel:|data:|#)/.test(u));
    ok('404: every link on it is absolute',
       hrefs.length > 0 && hrefs.every(u => u.startsWith('/')), hrefs.join(' '));
    ok('404: there is a way home', hrefs.includes('/'));
    ok('404: the menu is the site\'s menu',
       ['/#approach', '/#services', '/#assessment', '/en/blog/', '/#contact']
         .every(u => hrefs.includes(u)), hrefs.join(' '));
    ok('404: and the three legal pages are reachable',
       ['/privacy.html', '/terms.html', '/cookies.html'].every(u => hrefs.includes(u)),
       hrefs.join(' '));
    ok('404: it is not indexed', /name="robots"[^>]*noindex/.test(h));
  } else {
    ok('404: the page exists', false, 'dist içinde 404.html yok');
  }

  ok(`all ${PUBLIC.length} public pages carry the full site footer`,
     noFooter.length === 0, noFooter.join(', '));
  ok('every internal link resolves to a file that exists', broken.length === 0,
     '\n      ' + broken.join('\n      '));
  console.log(`      ${external} external links left alone — http, mailto, tel`);
  if (pending.length) {
    console.log(`      ${pending.length} waiting on something, by design:`);
    for (const p of [...new Set(pending)]) console.log('        · ' + p);
  }
}

console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
process.exit(fail === 0 ? 0 : 1);
