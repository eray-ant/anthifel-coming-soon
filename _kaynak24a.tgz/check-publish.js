/**
 * check-publish.js — Anthifel
 *
 * Runs the publisher. The real one: `blogPublish_` out of BlogCode.gs, the same
 * bytes that run inside Apps Script, against the templates this build just
 * wrote and a set of posts that exercises both languages.
 *
 * Why this exists. Everything else in the suite reads pages the Python build
 * produced. The Journal's articles are not produced by that build — they are
 * rendered by a script running inside Google, from templates it reads out of
 * GitHub, and written straight back to the repo. That path had no test at all,
 * and it is the only path on this site where a mistake is published before
 * anyone sees it: the publisher writes files, it does not visit them.
 *
 * It had two mistakes when this was written, both in the English half, both
 * invisible to every existing check:
 *   - relFromBlog_ linked an English post as '../en/blog/<slug>/' from an index
 *     already sitting at /en/blog/, which resolves to /en/en/blog/.
 *   - one template pair was used for two depths, so every English page pointed
 *     its logo, menu, footer and privacy link one level too high.
 *
 * Neither is subtle once the page is on disk and something follows the links.
 * So that is what this does: render, write to dist/publish-test/, then walk
 * every relative href and src and assert the file is there.
 *
 *   node check-publish.js [dist/preview]
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const vm = require('vm');

const DIST = path.resolve(process.argv[2] || 'dist/preview');
const OUT = path.resolve('dist/publish-test');
const SITE = 'https://anthifel.com';

let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${x ? '  → ' + x : ''}`)); };

/* ---------- the posts ----------
   Four, on purpose: a Turkish pair-mate and an English one, so hreflang has
   something to point at in both directions; a second Turkish post so the index
   has a featured piece AND a card; and one with no hero image, because a post
   without a picture is the normal case for the first week and the placeholder
   path is the one nobody tries. */
const POSTS = [
  { id: 'p1', slug: 'ai-donusumu-insan-meselesi', lang: 'tr', pair: 'p2',
    title: 'AI dönüşümü bir insan meselesidir',
    excerpt: 'Zor olan makineler değil, kararı verecek insanlar.',
    body: '## Başlangıç\n\nBir **AI kararı** tek bir birimde başlar.\n\n- kapasite\n- sıra\n- sahiplik\n\nSonra markaya uzanır.',
    category: 'Organisation', author: 'Eray Dengiz', date: '2026-08-10',
    hero: 'blog/img/kapak', seo: 'AI dönüşümünün insan tarafı.', read: 6, status: 'published' },
  { id: 'p2', slug: 'ai-transformation-people-problem', lang: 'en', pair: 'p1',
    title: 'Why AI transformation is a people problem',
    excerpt: 'The hard part was never the machines.',
    body: '## Where it starts\n\nAn **AI decision** starts in one department.\n\n- capacity\n- sequence\n- ownership\n',
    category: 'Organisation', author: 'Eray Dengiz', date: '2026-08-10',
    hero: 'blog/img/kapak', seo: 'The human side of AI transformation.', read: 6, status: 'published' },
  { id: 'p3', slug: 'pilot-mezarligi', lang: 'tr', pair: '',
    title: 'Pilot mezarlığı',
    excerpt: 'Şirketler AI projelerini neden gömüyor.',
    body: 'Bir pilot, bitmeden önce cevaplaması gereken soruyu söylemelidir.',
    category: 'Field notes', author: 'Anthifel', date: '2026-08-04',
    hero: '', seo: 'Pilot projeler neden ölüyor.', read: 4, status: 'published' },
  { id: 'p4', slug: 'twelve-signals-ready-for-ai', lang: 'en', pair: '',
    title: 'Twelve signals your company is ready for AI',
    excerpt: 'Readiness is visible before it is measurable.',
    body: 'A company that is ready looks different before anyone scores it.',
    category: 'Strategy', author: 'Anthifel', date: '2026-08-01',
    hero: '', seo: 'Twelve signals of AI readiness.', read: 5, status: 'published' },
  // Dated tomorrow: scheduled, and must not appear anywhere in this build.
  { id: 'p5', slug: 'yarin-yayinlanacak', lang: 'tr', pair: '',
    title: 'Yarın yayınlanacak',
    excerpt: 'Bugün görünmemeli.',
    body: 'Bu yazı yarının tarihini taşıyor.',
    category: 'Strategy', author: 'Anthifel', date: '2099-01-01',
    hero: '', seo: 'Henüz değil.', read: 2, status: 'scheduled' }
];

/* ---------- Apps Script, stubbed ----------
   Only what BlogCode.gs actually touches. `prop_` and `json_` live in Code.gs,
   which is not loaded here: this suite is about the render, and pulling in the
   mail file would drag Gmail, PDFs and the sheet with it. */
function sandbox(written) {
  const props = {
    SHEET_ID: 'sheet-under-test', DASH_TOKEN: 'x', GH_TOKEN: 'x',
    GH_REPO: 'eray-ant/anthifel-coming-soon', GH_BRANCH: 'main',
    SITE_BASE: SITE, BLOG_PREFIX: 'preview/'
  };
  const ctx = {
    console,
    prop_: k => props[k] || '',
    json_: o => ({ getContent: () => JSON.stringify(o), _o: o }),
    Logger: { log: () => {} },
    Session: { getScriptTimeZone: () => 'Europe/London' },
    Utilities: {
      formatDate: (d, tz, fmt) => new Date(d).toISOString().slice(0, 10),
      base64Encode: s => Buffer.from(s, 'utf-8').toString('base64'),
      newBlob: s => ({ getDataAsString: () => s })
    },
    SpreadsheetApp: {},
    UrlFetchApp: {},
    // The sheet is not exercised here; allPosts_ is replaced below.
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, 'BlogCode.gs'), 'utf-8'), ctx,
                  { filename: 'BlogCode.gs' });

  /* Replaced after the file is evaluated, so the functions inside it call these
     instead — a contextified global is exactly what a top-level function in
     Apps Script resolves against. */
  ctx.allPosts_ = () => POSTS.slice().sort((a, b) => String(b.date).localeCompare(String(a.date)));
  ctx.today_ = () => '2026-08-15';
  ctx.ghRead_ = p => {
    // The publisher reads under BLOG_PREFIX; the build wrote to dist/preview.
    const local = path.join(DIST, p.replace(/^preview\//, ''));
    return fs.existsSync(local) ? fs.readFileSync(local, 'utf-8') : null;
  };
  ctx.ghWrite_ = (p, content) => { written.set(p, content); return true; };
  return ctx;
}

/* ---------- link walking ---------- */
function localFor(fileRel, href) {
  // Ignore anything that is not a path into this build.
  if (/^(https?:|mailto:|tel:|data:|javascript:|#)/i.test(href)) return null;
  const clean = href.split('#')[0].split('?')[0];
  if (!clean) return null;
  let target = path.posix.normalize(path.posix.join(path.posix.dirname(fileRel), clean));
  if (target.endsWith('/')) target += 'index.html';
  /* Only what the publisher writes can be checked for existence: the Journal's
     own pages and the image folder they share. Everything else — index.html,
     about.html, the three legal pages — belongs to the Python build, which does
     not run here. Those are reported separately, by shape rather than by file,
     because a link that climbs one level too far is exactly the bug this suite
     was written for and it must not be waved through as "not ours". */
  const mine = /^(blog\/|en\/blog\/)/.test(target);
  return { target, escaped: !mine };
}

(async () => {
  console.log('\n=== the publisher, run here ===');

  const written = new Map();
  const ctx = sandbox(written);
  const res = ctx.blogPublish_();
  const out = res._o;

  ok('it ran and said so', out && out.ok === true, JSON.stringify(out && out.error));
  ok('it wrote every language and every post', written.size === 7,
     [...written.keys()].join(' '));

  console.log('\n— what it wrote —');
  const paths = [...written.keys()].sort();
  const expect = [
    'preview/blog/index.html',
    'preview/blog/ai-donusumu-insan-meselesi/index.html',
    'preview/blog/pilot-mezarligi/index.html',
    'preview/en/blog/index.html',
    'preview/en/blog/ai-transformation-people-problem/index.html',
    'preview/en/blog/twelve-signals-ready-for-ai/index.html',
    'preview/blog/posts.json'
  ];
  for (const e of expect) ok(e, written.has(e), paths.join(' '));
  ok('the scheduled post is nowhere in it',
     !paths.some(p => /yarin-yayinlanacak/.test(p)) &&
     ![...written.values()].some(c => /yarin-yayinlanacak/.test(c)));

  /* Everything under BLOG_PREFIX, laid out the way the repo lays it out, so the
     link walk below is walking the real shape and not a flattened copy. */
  fs.rmSync(OUT, { recursive: true, force: true });
  for (const [p, content] of written) {
    const dest = path.join(OUT, p.replace(/^preview\//, ''));
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, content);
  }
  // The images the pages point at. The publisher writes these separately, on
  // upload; here they only have to exist so a resolved src can be checked.
  for (const v of ['16x9', '4x3', '3x2', 'thumb']) {
    const f = path.join(OUT, 'blog/img/kapak-' + v + '.webp');
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, '');
  }

  console.log('\n— every link resolves —');
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const pages = [...written.keys()].filter(p => p.endsWith('.html'))
                 .map(p => p.replace(/^preview\//, ''));
  const broken = [], escaped = [];
  for (const rel of pages) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await page.goto('file://' + path.join(OUT, rel), { waitUntil: 'load' });
    const refs = await page.evaluate(() =>
      [...document.querySelectorAll('a[href], img[src], link[href][rel="canonical"], link[href][rel="alternate"]')]
        .map(e => ({ tag: e.tagName, v: e.getAttribute('href') || e.getAttribute('src') })));
    for (const r of refs) {
      const t = localFor(rel, r.v);
      if (!t) continue;
      if (t.escaped) { escaped.push(`${rel} → ${r.v} :: ${t.target}`); continue; }
      if (!fs.existsSync(path.join(OUT, t.target))) broken.push(`${rel} → ${r.v} (${t.target})`);
    }
    await page.close();
  }
  /* A link that climbs above the Journal is not broken — it is the rest of the
     site, which this build does not write. It is reported so the count is
     honest, and its shape is checked instead. */
  ok('nothing points at a file that is not there', broken.length === 0, broken.slice(0, 6).join(' | '));
  ok('links that leave the Journal land at the site root, not above it',
     escaped.every(e => {
       const to = e.split(' :: ')[1];
       // After normalising against the page's own directory, a link out of the
       // Journal must resolve to something at the top of the build. If it still
       // starts with '..' it climbed past the site root and is broken.
       return !to.startsWith('..');
     }), escaped.slice(0, 8).join(' | '));

  console.log('\n— the English half, which is where it was wrong —');
  const enIdx = written.get('preview/en/blog/index.html');
  ok('the English index links its posts without leaving /en/blog/',
     /href="ai-transformation-people-problem\/"/.test(enIdx),
     (enIdx.match(/href="[^"]*ai-transformation[^"]*"/) || [''])[0]);
  ok('…and never builds an /en/en/ path', !/en\/en\//.test(enIdx));
  ok('it uses the two-deep template, not the Turkish one',
     /href="\.\.\/\.\.\/privacy\.html"/.test(enIdx),
     (enIdx.match(/href="[^"]*privacy\.html"/) || [''])[0]);
  const enPost = written.get('preview/en/blog/ai-transformation-people-problem/index.html');
  ok('the English article uses the three-deep template',
     /href="\.\.\/\.\.\/\.\.\/privacy\.html"/.test(enPost),
     (enPost.match(/href="[^"]*privacy\.html"/) || [''])[0]);
  ok('its images climb out to the shared image folder, once',
     /src="\.\.\/\.\.\/\.\.\/blog\/img\/kapak-16x9\.webp"/.test(enPost),
     (enPost.match(/src="[^"]*kapak[^"]*"/) || [''])[0]);
  ok('…and the folder is not in the path twice',
     !/blog\/img\/blog\/img\//.test(enPost + enIdx));

  /* WebP everywhere a human sees a picture — and only there. 20 August added a
     fifth derivative, `-og.jpg`, because LinkedIn does not read WebP for link
     previews and the first post shared as an empty box. So the rule is no
     longer "no .jpg on the page"; it is "no .jpg in an <img>". The share card
     is a meta tag and is checked further down. */
  ok('every picture on the page is WebP',
     !/<img[^>]+src="[^"]*\.jpe?g"/.test(enPost + enIdx),
     (enPost.match(/<img[^>]+src="[^"]*\.jpe?g"/) || [''])[0]);
  ok('…and the only JPEG named anywhere is the share card',
     (enPost.match(/[^"]*\.jpe?g"/g) || []).every(u => /-og\.jpg"$/.test(u)),
     (enPost.match(/[^"]*\.jpe?g"/g) || []).join(' '));

  console.log('\n— the Turkish half —');
  const trIdx = written.get('preview/blog/index.html');
  const trPost = written.get('preview/blog/ai-donusumu-insan-meselesi/index.html');
  /* One step down, and carrying its language: the Turkish address is
     /blog/<slug>/?lang=tr, so that a link pasted into an email opens in Turkish
     whatever the person opening it last chose on this site. */
  ok('the index links its posts one step down', /href="pilot-mezarligi\/\?lang=tr"/.test(trIdx));
  ok('the article uses the two-deep template',
     /href="\.\.\/\.\.\/privacy\.html"/.test(trPost),
     (trPost.match(/href="[^"]*privacy\.html"/) || [''])[0]);
  ok('the featured piece is the newest one, and only once',
     (trIdx.match(/class="feat"/g) || []).length === 1);
  ok('the second post is a card, not a second featured piece',
     /data-cat="Field notes"/.test(trIdx));

  console.log('\n— head: canonical, hreflang, language —');
  /* The prefix belongs in these too. While the site is staged under /preview/
     the pages live there, and a canonical that names an address which does not
     exist yet is worse than none: it is the one line on the page whose whole
     job is to say where the page really is. At launch BLOG_PREFIX empties and
     these become the final URLs, unchanged in every other respect. */
  ok('the Turkish article is canonical where it is actually served',
     trPost.includes(`<link rel="canonical" href="${SITE}/preview/blog/ai-donusumu-insan-meselesi/">`),
     (trPost.match(/<link rel="canonical"[^>]*>/) || [''])[0]);
  ok('the English article is canonical where it is actually served',
     enPost.includes(`<link rel="canonical" href="${SITE}/preview/en/blog/ai-transformation-people-problem/">`),
     (enPost.match(/<link rel="canonical"[^>]*>/) || [''])[0]);
  ok('a paired post names both languages',
     /hreflang="tr"/.test(enPost) && /hreflang="en"/.test(enPost));
  ok('…and x-default is the Turkish one, on both pages, the way build.py stamps it',
     enPost.includes(`hreflang="x-default" href="${SITE}/preview/blog/ai-donusumu-insan-meselesi/"`) &&
     trPost.includes(`hreflang="x-default" href="${SITE}/preview/blog/ai-donusumu-insan-meselesi/"`),
     (enPost.match(/x-default[^>]*/) || [''])[0]);
  ok('an unpaired post claims only its own language',
     (written.get('preview/blog/pilot-mezarligi/index.html').match(/hreflang=/g) || []).length === 1);
  ok('<html lang> follows the post', /<html lang="en"/.test(enPost) && /<html lang="tr"/.test(trPost));
  ok('the English index is tagged English', /<html lang="en"/.test(enIdx));

  console.log('\n— what a share carries —');
  // LinkedIn and X read the page rather than being handed anything, so what the
  // page says about itself is the whole story. og:image was missing entirely,
  // which with summary_large_image is a grey rectangle under our headline.
  /* JPEG, not WebP, and that is the whole point of the `og` variant. LinkedIn
     showed nothing at all for the first post and X showed the headline with a
     blank space; the tags were right and the format was not. */
  ok('the article names a JPEG share card',
     /<meta property="og:image" content="https:\/\/[^"]+-og\.jpg">/.test(enPost),
     (enPost.match(/og:image[^>]*/) || [''])[0]);
  ok('…and it is absolute, because a crawler resolves nothing',
     !/content="(\.|\/)/.test((enPost.match(/<meta property="og:image"[^>]*>/) || [''])[0]));
  ok('a post with no cover still names one, so a share is never blank',
     /og:image" content="[^"]+share-default\.webp"/.test(
       written.get('preview/blog/pilot-mezarligi/index.html')));
  ok('the X link carries the headline, not a bare URL',
     /x\.com\/intent\/tweet\?text=[^"&]+&url=/.test(enPost),
     (enPost.match(/x\.com[^"]*/) || [''])[0]);
  ok('every share URL points at the address the page is actually served from',
     enPost.includes('preview%2Fen%2Fblog%2F') || enPost.includes(encodeURIComponent(SITE + '/preview/en/blog/')),
     (enPost.match(/url=[^"&]*/) || [''])[0]);

  console.log('\n— Keep reading, when there is nothing to keep reading —');
  ok('a post with a sibling keeps the section', /class="rel"/.test(enPost));
  ok('…with cards under it, not an empty grid', /class="rel-g">\s*<a class="card"/.test(enPost));
  /* The first post ever published has no sibling, and that is the state this
     block exists for. Rendered here on its own rather than waited for: an empty
     "Keep reading" reads as a page that failed to load. */
  {
    const solo = new Map();
    const s2 = sandbox(solo);
    s2.allPosts_ = () => [POSTS[2]];
    s2.blogPublish_();
    const only = solo.get('preview/blog/pilot-mezarligi/index.html');
    ok('the only post in the Journal drops the section entirely', !/class="rel"/.test(only));
    ok('…and the markers it was cut at are still in the file, once',
       (only.match(/REL:START/g) || []).length === 1);
  }

  console.log('\n— the lead image —');
  ok('a post with a cover shows it', /class="lead-wrap"><img/.test(enPost));
  ok('a post without one still gets the frame, not a hole',
     /class="lead-wrap"><div class="ph"/.test(written.get('preview/blog/pilot-mezarligi/index.html')));

  console.log('\n— the body the editor previewed —');
  ok('markdown became markup', /<h2[^>]*>Where it starts<\/h2>/.test(enPost) ||
     /<h2>Where it starts<\/h2>/.test(enPost), (enPost.match(/Where it starts[^<]*/) || [''])[0]);
  ok('bold survived', /<strong>AI decision<\/strong>/.test(enPost));
  ok('the list became a list', (enPost.match(/<li>capacity<\/li>/) || []).length === 1);
  ok('a post without a picture gets the placeholder, not a broken image',
     /class="ph"/.test(trIdx) && !/src=""/.test(trIdx));

  console.log('\n— the pages themselves —');
  for (const rel of pages) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const errs = [];
    page.on('pageerror', e => errs.push(String(e)));
    const offsite = [];
    page.on('request', r => { if (!/^(file|data|blob|about):/.test(r.url())) offsite.push(r.url()); });
    await page.goto('file://' + path.join(OUT, rel), { waitUntil: 'load' });
    await page.waitForTimeout(200);
    ok(`${rel}: no page errors`, errs.length === 0, errs.join(' | '));
    ok(`${rel}: nothing is fetched from anywhere`, offsite.length === 0, offsite.join(' '));
    const over = await page.evaluate(() =>
      document.documentElement.scrollWidth - document.documentElement.clientWidth);
    ok(`${rel}: no sideways overflow`, over <= 1, String(over));
    // The reading list and the privacy notice travel with every page. They
    // reached the Journal through the templates, which is the only way they
    // can reach a page this build does not write.
    ok(`${rel}: carries the reading list`, await page.$('.news') !== null);
    ok(`${rel}: carries the privacy notice`, await page.$('#povl') !== null);
    await page.close();
  }

  console.log('\n— posts.json —');
  const idx = JSON.parse(written.get('preview/blog/posts.json'));
  ok('it lists the live posts and nothing else', idx.length === 4, String(idx.length));
  ok('every url is absolute and canonical',
     idx.every(p => p.url.startsWith(SITE + '/')), JSON.stringify(idx.map(p => p.url)));
  ok('the English ones live under /en/blog/',
     idx.filter(p => p.lang === 'en').every(p => p.url.includes('/en/blog/')));

  await browser.close();
  console.log(`\n${fail ? '❌' : '✅'}  ${pass} passed, ${fail} failed`);
  console.log(`   rendered into ${path.relative(process.cwd(), OUT)}/ — open it and look, it is a real site`);
  process.exit(fail ? 1 : 0);
})();
