# Eray — yapılacaklar · 11 Ağustos 2026

Sıra önemli. 1 ve 2 bitmeden 3 çalışmaz, 3 bitmeden 4 açılmaz.

Ayrıntılı ekranlar `KURULUM.md` içinde; bu liste onun kısası.

---

## 1. `hello@` gerçekten gönderebiliyor mu · **20 dakika**

Kod maili gitmezse teste kimse giremez. Kurulumun en kırılgan yeri artık burası.

- [ ] **Gönderme izni.** Gmail → Ayarlar → Hesaplar ve İçe Aktarma → *Şununla
      e-posta gönder* → `hello@anthifel.com` tanımlı ve **doğrulanmış** olmalı.
- [ ] **DKIM.** Workspace Admin → Uygulamalar → Google Workspace → Gmail →
      *E-posta kimliğini doğrula* → anahtarı üret → çıkan TXT kaydını alan adına
      ekle → *Kimlik doğrulamayı başlat*.

> DKIM'siz kod maili spam'e düşer. Eskiden "iyi olur"du, artık zorunlu.

---

## 2. Apps Script'i yayınla · **30 dakika**

- [ ] **Tabloyu aç:** *Anthifel — Website enquiries* adında bir Google E-Tablo.
      URL'deki `/d/` ile `/edit` arasındaki ID'yi kopyala.
- [ ] **Kodu yapıştır:** Tabloda Uzantılar → Apps Script → gelen taslağı sil →
      sana gönderdiğim `Code.gs` içeriğini yapıştır → kaydet.
- [ ] **Üç özellik gir:** Proje Ayarları → Komut dosyası özellikleri.

| Özellik | Değer |
|---|---|
| `SHEET_ID` | tablonun ID'si |
| `NOTIFY_TO` | `hello@anthifel.com` |
| `SEND_AS` | `hello@anthifel.com` |

- [ ] **Dağıt:** Dağıt → Yeni dağıtım → Web uygulaması. Yürütme **Ben**, erişim
      **Herkes**. İzin isteyince onayla.
- [ ] **`/exec` adresini bana yolla.** Sayfaya ben gireceğim.
- [ ] **Saklama tetikleyicisi:** Tetikleyiciler → ekle → fonksiyon
      `purgeOldRows`, zaman güdümlü, günlük.

> **Herkesi bir kez yakalayan tuzak:** kodu düzenlemek canlı adresi
> güncellemez. Sonraki her değişiklikte *Dağıtımları yönet → düzenle → Sürüm:
> Yeni sürüm* demen gerekiyor, yoksa adres eski kodu sunmaya devam eder.

---

## 3. Deploy zinciri · **karar + 10 dakika**

10 ve 11 Ağustos'ta köprü altı kez düştü; her düştüğünde ne klasöre yazabildim
ne deploy edebildim. İki yoldan birini seç:

- [ ] **(a)** Depoya buradan push edebilmem — bir ince ayarlı GitHub token'ı.
      Sonrasında hiçbir şey senin masaüstünün açık olmasına bağlı kalmaz.
- [ ] **(b)** `deploy.sh` build'i kendisi çeksin. Köprü yine gerekir ama tek
      komutla, dosya dosya değil.

Bu karar çıkana kadar her build sana zip olarak geliyor ve `preview` elle
güncelleniyor.

---

## 4. Onaylar — bunlar sende, kimseyi beklemiyor

- [ ] **Üç mailin metni.** Kod maili, sonuç maili, lead maili — TR ve EN.
      Gönderdiğim `anthifel-test-mailleri.html` dosyasında beşi birden duruyor.
      Marketing'e mi gitsin, sen mi onaylıyorsun?
- [ ] **İki buton metni.** Test girişinde artık *Kodu gönder →* ve
      *Teste başla →* yazıyor. Eski metin (*AI Hazırlık Testi →*) butonun ne
      yaptığını söylemiyordu.
- [ ] **Bot kontrolünün kod olarak kalması.** Onaylarsan Asana'da DEV-028 ve
      DEV-031 kapanır.
- [ ] **Hero satırının yazma hızı.** Harf başına 62 ms, tamamlanınca 2,3 saniye
      bekliyor, sonra siliyor. GIF'i gönderdim. Hızlı/yavaş dersen değiştiririm.

---

## 5. Başka departmanlardan iste — hepsi seni bekliyor

| Kimden | Ne | Neyi bloke ediyor |
|---|---|---|
| **Legal** | Şirket numarası, kayıtlı adres, ICO kayıt numarası | `privacy.html` ve `terms.html` yayın sürümü yazılmıyor; yapı reddediyor |
| **Legal** | Saklama süresi, gün olarak | `PURGE_AFTER_DAYS` şu an 730; politikadaki sayıyla aynı olmak zorunda |
| **Legal** | ICO numarası 20 Ağustos'a yetişmezse cümle silinsin mi | Kendi notu silmeyi söylüyor, teyit lazım |
| **Business** | Discovery Sprint, Transformation Retainer, Advisory Board Seat sayfa metinleri | Üç bandın sonuç butonu hâlâ katalog satırına gidiyor |
| **Business** | On iki sorunun boyut eşlemesinin teyidi, Services 9.2 Türkçesi | Sorular Developer taslağı olarak duruyor |
| **Marketing** | §9a Türkçe alt metin, 7c "görüşme ayarla" yasağı, §8.7c ifadesi, uzun tire kararı, beşinci alt bilgi blog başlığı | Beşi de sitede duruyor, kaynakla çelişiyor |

---

## 6. Konsoldan okunacaklar — hiçbiri henüz okunmadı

- [ ] **DigitalOcean bölgesi.** Londra değilse uygulama yeniden kurulup DNS
      taşınacak. **Bu iş lansmandan sonra değil, önce yapılır.**
- [ ] **Google Workspace sürümü ve veri bölgesi**, Admin konsolundan.
- [ ] **Alan adı WHOIS gizliliği.** Tescil sahibi bilgileri kişisel veri.
- [ ] **`privacy@anthifel.com`** takma ad değil, gerçek ve okunan bir Google
      Grubu olsun; okuyacak kişi belli olsun.

---

## Bende kalanlar — sen bir şey yapmıyorsun

Blog altyapısı (GitHub token'ı geldiğinde), canlı URL'i okuyan test, ölü
bağlantı kontrolünün klasör linklerini görmesi, Google takviminin canlı
kaynaktan iframe'e girip girmediğinin teyidi, lansman mekaniği, kayıtlı adresin
alt bilgiye eklenmesi.

---

## Bunlar bitince ne oluyor

1 + 2 biterse `FORM_LIVE` açılabilir hale gelir — ama gizlilik politikası
yayımlanmadan açılmaz, o da Legal'in üç bilgisine bağlı. Yani gerçek sıra:

**1 → 2 → Legal'in üç bilgisi → `FORM_LIVE = true` → uçtan uca test → lansman.**

3 bu zincirin içinde değil ama her adımı yavaşlatıyor.
