/**
 * Anthifel — blog backend
 * Add this file alongside Code.gs in the same Apps Script project.
 *
 * The loop:
 *   dashboard editor  →  doPost(kind:'blog')  →  Sheet "posts"
 *   publish           →  render from templates in the repo
 *                     →  commit to GitHub Contents API
 *                     →  DigitalOcean autodeploys
 *
 * The site stays fully static. Nothing is fetched at runtime, so an article
 * keeps working if this script, Google, or the sheet ever goes away.
 *
 * EXTRA SCRIPT PROPERTIES (Project Settings → Script Properties)
 *   DASH_TOKEN     long random string, also pasted into the dashboard page
 *   GH_TOKEN       GitHub fine-grained PAT, Contents: read and write, this repo only
 *   GH_REPO        eray-ant/anthifel-coming-soon
 *   GH_BRANCH      main
 *   SITE_BASE      https://anthifel.com
 *   BLOG_PREFIX    ''  while staging under /preview/, or 'preview/' — see below
 *
 * OPTIONAL
 *   SUPABASE_URL   overrides the project the keep-awake ping reads from
 *   SUPABASE_KEY   its publishable key. Both have working defaults below, so
 *                  these exist for the day the project is replaced, not for
 *                  setup. Neither is a secret; see the note above supabasePing.
 *
 * TRIGGERS  run once each, from the editor's function list:
 *   installPublishTrigger()   daily — scheduled posts go live
 *   installSupabasePing()     every 3 days — the free Supabase project stays awake
 *   checkTriggers()           says which of the two is missing
 *
 * BLOG_PREFIX is the repo path the pages are written under. Leave it empty to
 * publish at the site root; set it to 'preview/' to publish inside the preview
 * build while the coming-soon page still owns '/'.
 */

var SHEET_POSTS = 'posts';
var CATEGORIES = ['Strategy', 'Organisation', 'Technology', 'People', 'Field notes'];
var AUTHORS    = ['Eray Dengiz', 'Anthifel'];

/* Image derivatives. The editor crops to these before upload, so a card never
   scales a 1600px file down and an article never stretches a small one up.
   Ratios come from the blog design: card 3:2, featured 4:3, article lead 16:9. */
var IMG_VARIANTS = [
  { key: '16x9',  w: 1600, h: 900 },
  { key: '4x3',   w: 1200, h: 900 },
  { key: '3x2',   w: 1200, h: 800 },
  { key: 'thumb', w: 320,  h: 213 },
  /* The share card, and the only one that is not WebP.
     20 August: the first post went out and LinkedIn showed nothing at all while
     X showed the headline and the link with a blank space where the picture
     goes. The cause is not the tags — they are all there and correct — it is
     the format. LinkedIn does not read WebP for link previews, and X will not
     render it in a large card either. So this one variant is JPEG, at the
     1200×630 both of them ask for, and og:image points here rather than at the
     16x9 the article uses. The page keeps WebP everywhere a human sees it;
     only the crawlers get the heavier file, once. */
  { key: 'og',    w: 1200, h: 630, ext: 'jpg' }
];

/** The extension a variant is actually written with. */
function imgExt_(key) {
  for (var i = 0; i < IMG_VARIANTS.length; i++) {
    if (IMG_VARIANTS[i].key === key) return IMG_VARIANTS[i].ext || IMG_EXT;
  }
  return IMG_EXT;
}
var IMG_DIR = 'blog/img/';

/* WebP, not JPEG. The editor already crops in the browser, so the format is a
   one-word decision made here and read everywhere: a cover at 1600px is around
   a third of the JPEG for the same picture, and the pages carry it inline in a
   card, a featured block and an article lead. Written once, so the writer, the
   reader and the delete path cannot disagree about the extension. */
var IMG_EXT = 'webp';

/* ============================ entry point ============================ */
/**
 * Called by doPost in Code.gs when the payload carries kind:'blog'.
 * Wire it by adding this at the top of doPost, before the form handling:
 *
 *   if (d.kind === 'blog') return blogRouter_(d);
 */
function blogRouter_(d) {
  if (d.token !== prop_('DASH_TOKEN') || !prop_('DASH_TOKEN')) {
    return json_({ ok: false, error: 'unauthorised' });
  }
  try {
    switch (d.action) {
      /* `prefix` is sent so the editor can compare it with its own SITE_PREFIX.
         The two describe the same folder from two sides — one says where a file
         is written in the repository, the other where the browser asks for it —
         and when they drift the pictures are uploaded successfully to a path
         nobody can see. That is DEV-041, and it is checked rather than
         remembered now. */
      case 'list':    return json_({ ok: true, posts: allPosts_(), images: listImages_(),
                                     ai: !!prop_('GEMINI_KEY'),
                                     prefix: prop_('BLOG_PREFIX') || '' });
      case 'settings': return settingsGet_();
      case 'setsettings': return settingsSet_(d.data);
      case 'write':   return aiWrite_(d.data);
      case 'translate': return aiTranslate_(d.data);
      case 'illustrate': return aiIllustrate_(d.data);
      case 'save':    return blogSave_(d.data);
      case 'delete':  return blogDelete_(d.data);
      case 'publish': return blogPublish_();
      case 'images':  return json_({ ok: true, images: listImages_() });
      case 'upload':  return imageUpload_(d.data);
      case 'unimage': return imageDelete_(d.data);
      default:        return json_({ ok: false, error: 'unknown_action' });
    }
  } catch (err) {
    console.error(err);
    return json_({ ok: false, error: String(err.message || err) });
  }
}

/* ============================== storage ============================== */
var COLS = ['id', 'slug', 'lang', 'title', 'excerpt', 'body', 'category', 'author',
            'date', 'hero', 'seo', 'pair', 'read', 'status', 'created', 'updated'];

function postsSheet_() {
  var ss = SpreadsheetApp.openById(prop_('SHEET_ID'));
  var sh = ss.getSheetByName(SHEET_POSTS);
  if (!sh) {
    sh = ss.insertSheet(SHEET_POSTS);
    sh.appendRow(COLS);
    sh.getRange(1, 1, 1, COLS.length).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function allPosts_() {
  var sh = postsSheet_();
  if (sh.getLastRow() < 2) return [];
  var vals = sh.getRange(2, 1, sh.getLastRow() - 1, COLS.length).getValues();
  return vals.map(function (r) {
    var o = {};
    COLS.forEach(function (c, i) { o[c] = r[i]; });
    if (o.date instanceof Date) o.date = Utilities.formatDate(o.date, 'UTC', 'yyyy-MM-dd');
    o.date = String(o.date || '');
    return o;
  }).filter(function (p) { return p.id; })
    .sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
}

/** Today in the script's timezone, as yyyy-MM-dd. */
function today_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
}
/** A post is live when it is published (or scheduled) and its date has arrived. */
function isLive_(p) {
  return (p.status === 'published' || p.status === 'scheduled') && String(p.date) <= today_();
}

function blogSave_(p) {
  if (!p.title || !p.slug || !p.excerpt || !p.body) {
    return json_({ ok: false, error: 'missing_fields' });
  }
  if (CATEGORIES.indexOf(p.category) < 0) p.category = CATEGORIES[0];
  if (AUTHORS.indexOf(p.author) < 0) p.author = AUTHORS[0];
  p.lang = p.lang === 'en' ? 'en' : 'tr';
  p.status = (p.status === 'published' || p.status === 'scheduled') ? p.status : 'draft';

  // A future date means scheduled, whichever button was pressed. Nothing goes
  // live early, and nothing sits waiting once its day has passed.
  if (p.status !== 'draft') {
    p.status = String(p.date) > today_() ? 'scheduled' : 'published';
  }

  var sh = postsSheet_();
  var rows = allPosts_();
  var now = new Date().toISOString();

  // A slug is a URL. Two live posts cannot share one within a language.
  var clash = rows.filter(function (r) {
    return r.slug === p.slug && r.lang === p.lang && r.id !== p.id;
  });
  if (clash.length) return json_({ ok: false, error: 'slug_taken' });

  if (!p.id) {
    p.id = 'p' + Date.now() + Math.floor(Math.random() * 1000);
    p.created = now;
    p.updated = now;
    sh.appendRow(COLS.map(function (c) { return p[c] === undefined ? '' : p[c]; }));
  } else {
    var idx = -1, all = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues();
    for (var i = 0; i < all.length; i++) if (all[i][0] === p.id) { idx = i + 2; break; }
    if (idx < 0) return json_({ ok: false, error: 'not_found' });
    var existing = sh.getRange(idx, 1, 1, COLS.length).getValues()[0];
    p.created = existing[COLS.indexOf('created')] || now;
    p.updated = now;
    sh.getRange(idx, 1, 1, COLS.length)
      .setValues([COLS.map(function (c) { return p[c] === undefined ? '' : p[c]; })]);
  }

  // Keep the pairing symmetrical, so hreflang points both ways.
  if (p.pair) syncPair_(sh, p.id, p.pair);

  var res = blogPublish_();
  var out = { ok: true, posts: allPosts_(), post: p };
  try { out.publish = JSON.parse(res.getContent()); } catch (e) {}
  return json_(out);
}

function syncPair_(sh, idA, idB) {
  var ids = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues();
  var pairCol = COLS.indexOf('pair') + 1;
  for (var i = 0; i < ids.length; i++) {
    if (ids[i][0] === idB) { sh.getRange(i + 2, pairCol).setValue(idA); return; }
  }
}

function blogDelete_(d) {
  var sh = postsSheet_();
  var ids = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues();
  for (var i = 0; i < ids.length; i++) {
    if (ids[i][0] === d.id) { sh.deleteRow(i + 2); break; }
  }
  blogPublish_();
  return json_({ ok: true, posts: allPosts_() });
}

/* ============================== render =============================== */
function esc_(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Markdown → HTML. Deliberately the same small subset the editor previews. */
function md_(src) {
  var lines = String(src || '').replace(/\r\n?/g, '\n').split('\n');
  var out = [], i = 0;

  function inline(s) {
    return esc_(s)
      .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, '<img src="$2" alt="$1">')
      .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2">$1</a>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>');
  }

  while (i < lines.length) {
    var l = lines[i];
    if (/^```/.test(l)) {
      var buf = []; i++;
      while (i < lines.length && !/^```/.test(lines[i])) { buf.push(lines[i]); i++; }
      i++; out.push('<pre><code>' + esc_(buf.join('\n')) + '</code></pre>'); continue;
    }
    if (/^\s*$/.test(l)) { i++; continue; }
    if (/^---+\s*$/.test(l)) { out.push('<hr>'); i++; continue; }
    var h = l.match(/^(#{2,3})\s+(.*)$/);
    if (h) { out.push('<h' + h[1].length + '>' + inline(h[2]) + '</h' + h[1].length + '>'); i++; continue; }
    if (/^>\s?/.test(l)) {
      var q = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, '')); i++; }
      out.push('<blockquote>' + inline(q.join(' ')) + '</blockquote>'); continue;
    }
    if (/^[-*]\s+/.test(l)) {
      var ul = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i])) { ul.push(lines[i].replace(/^[-*]\s+/, '')); i++; }
      out.push('<ul>' + ul.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</ul>');
      continue;
    }
    if (/^\d+[.)]\s+/.test(l)) {
      var ol = [];
      while (i < lines.length && /^\d+[.)]\s+/.test(lines[i])) { ol.push(lines[i].replace(/^\d+[.)]\s+/, '')); i++; }
      out.push('<ol>' + ol.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</ol>');
      continue;
    }
    var p = [];
    while (i < lines.length && !/^\s*$/.test(lines[i]) &&
           !/^(#{2,3}\s|>|[-*]\s|\d+[.)]\s|```|---+\s*$)/.test(lines[i])) { p.push(lines[i]); i++; }
    out.push('<p>' + inline(p.join(' ')) + '</p>');
  }
  return out.join('\n');
}

var MONTHS = {
  en: ['January','February','March','April','May','June','July','August','September','October','November','December'],
  tr: ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık']
};
function niceDate_(iso, lang) {
  var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso));
  if (!m) return String(iso || '');
  var d = parseInt(m[3], 10), mo = MONTHS[lang === 'en' ? 'en' : 'tr'][parseInt(m[2], 10) - 1];
  return d + ' ' + mo + ' ' + m[1];
}
function readLabel_(mins, lang) {
  return lang === 'en' ? (mins + ' min read') : (mins + ' dk okuma');
}
function postPath_(p) {
  return (p.lang === 'en' ? 'en/blog/' : 'blog/') + p.slug + '/index.html';
}
function postUrl_(p) {
  /* BLOG_PREFIX belongs in here too. It was missing, so while the site is
     staged under /preview/ every canonical, every hreflang and both share links
     pointed at https://anthifel.com/blog/<slug>/ — an address that does not
     exist yet. The pages were fine; everything that named them was wrong, which
     is the harder kind to notice because the page you are looking at works.
     At launch the prefix goes empty and these become the final URLs. */
  return prop_('SITE_BASE') + '/' + (prop_('BLOG_PREFIX') || '') +
         (p.lang === 'en' ? 'en/blog/' : 'blog/') + p.slug + '/';
}

function placeholder_(ratio) {
  return '<div class="ph" style="aspect-ratio:' + ratio + '"></div>';
}

/**
 * Images live once, at blog/img/, and are shared by both languages. `hero`
 * holds the base name only; the variant and extension are added here so a
 * card never loads the 1600px file and an article never stretches the 320px one.
 *
 * up = how far the page being written sits below the site root:
 *   blog/index.html            → 'img/'
 *   blog/<slug>/index.html     → '../img/'
 *   en/blog/index.html         → '../../blog/img/'
 *   en/blog/<slug>/index.html  → '../../../blog/img/'
 */
function imgSrc_(base, variant, up) {
  if (!base) return '';
  /* The two halves disagreed about what `hero` holds. The image library hands
     the editor 'blog/img/<name>' — folder included, because the panel needs a
     URL it can show — and the editor stored that string in the sheet. Here `up`
     already ends in the image folder, so the two were concatenated and every
     published article asked for blog/img/blog/img/<name>. It never 404'd in
     testing because nothing had been published yet.
     Read tolerantly, write strictly: the folder is stripped if it is there, and
     `up` is the only thing that decides where the file is looked for. */
  var name = String(base).replace(/^\/+/, '').replace(new RegExp('^' + IMG_DIR), '');
  return up + name + '-' + variant + '.' + IMG_EXT;
}

function imgDirFrom_(lang, isPost) {
  if (lang === 'en') return isPost ? '../../../blog/img/' : '../../blog/img/';
  return isPost ? '../img/' : 'img/';
}

/**
 * Konu adları, iki dilde.
 *
 * Kategori tek bir değer olarak saklanıyor ve saklanması gereken de bu:
 * kartların filtresi, e-tablodaki sütun ve indeksteki çip aynı dizeye bakıyor.
 * Ama sayfaya basılan şey okuyucunun dilinde olmalı — Türkçe bir yazının
 * üstünde "ORGANISATION" yazıyordu, üstelik CSS büyütmesi Türkçe kuralına
 * göre çalıştığı için "ORGANİSATİON" diye, noktalı İ ile. Yanlış dil ve
 * yanlış harf.
 *
 * İndeksteki çipler bu eşlemeyi zaten taşıyordu (blog_index.html); burada
 * aynısı, kartlar ve yazı sayfası için. Eşleşmeyen bir değer olduğu gibi
 * geçer — uydurmaktansa İngilizcesini göstermek yeğdir.
 */
var CATEGORY_TR = {
  'Strategy': 'Strateji',
  'Organisation': 'Organizasyon',
  'Technology': 'Teknoloji',
  'People': 'İnsan',
  'Field notes': 'Saha notları'
};
function catTr_(c) { return CATEGORY_TR[c] || c; }

/** Konu etiketi: filtre için İngilizce değer, okuyucu için kendi dili. */
function catSpan_(p, cls) {
  return '<span' + (cls ? ' class="' + cls + '"' : '') +
    ' data-en="' + esc_(p.category) + '" data-tr="' + esc_(catTr_(p.category)) + '">' +
    esc_(p.category) + '</span>';
}

function cardHtml_(p, base, imgUp) {
  var img = p.hero
    ? '<img class="lead" src="' + esc_(imgSrc_(p.hero, '3x2', imgUp)) + '" alt="' + esc_(p.title) + '" loading="lazy">'
    : placeholder_('3/2');
  return '<a class="card" data-cat="' + esc_(p.category) + '" href="' + esc_(base + relFromBlog_(p)) + '">' +
    img +
    '<div>' +
      catSpan_(p, 'cat') +
      '<h4>' + esc_(p.title) + '</h4>' +
      '<p>' + esc_(p.excerpt) + '</p>' +
      '<div class="byl"><span>' + esc_(niceDate_(p.date, p.lang)) + '</span><s>·</s><span>' +
        esc_(readLabel_(p.read || 1, p.lang)) + '</span></div>' +
    '</div></a>';
}

/**
 * Link from an index to one of its own posts.
 *
 * Each index carries one language and only that language — `set` is filtered by
 * lang before anything is rendered — so an index and the posts under it always
 * sit in the same directory: /blog/ → /blog/<slug>/, /en/blog/ → /en/blog/<slug>/.
 * One relative step, whichever language it is.
 *
 * It used to return '../en/blog/<slug>/' for an English post. That was right
 * while both languages shared the Turkish index and wrong from the day the
 * English index moved to /en/blog/, where it resolves to /en/en/blog/. Every
 * English link was a 404 and nothing said so, because a publisher writes files
 * rather than visiting them.
 */
function relFromBlog_(p) {
  /* The Turkish address carries its language, the English one does not need to:
     /blog/<slug>/?lang=tr and /en/blog/<slug>/ are the two addresses the CEO
     set on 16 August. The article forces the furniture into its own language
     anyway, so this is not what makes the page correct — it is what makes a
     link somebody pastes into an email correct on its own.
     The canonical and the hreflang tags stay clean: postUrl_ has no parameter,
     and two addresses for one page is a thing to hand a reader, not a crawler. */
  return p.slug + '/' + (p.lang === 'tr' ? '?lang=tr' : '');
}

function featuredHtml_(p, imgUp) {
  var img = p.hero
    ? '<img class="lead" src="' + esc_(imgSrc_(p.hero, '4x3', imgUp)) + '" alt="' + esc_(p.title) + '">'
    : '<div class="ph" style="aspect-ratio:4/3"><span>LEAD IMAGE — 1200×900</span></div>';
  return '<a class="feat" href="' + esc_(relFromBlog_(p)) + '"><div class="feat-in">' +
    img +
    '<div>' +
      '<div class="kicker"><b>' + (p.lang === 'en' ? 'Latest' : 'Son yazı') + '</b><i></i>' +
        '<s data-en="' + esc_(p.category) + '" data-tr="' + esc_(catTr_(p.category)) + '">' +
        esc_(p.category) + '</s></div>' +
      '<h2>' + esc_(p.title) + '</h2>' +
      '<p>' + esc_(p.excerpt) + '</p>' +
      '<div class="byl"><span>' + esc_(p.author || 'Eray Dengiz') + '</span><s>·</s><span>' +
        esc_(niceDate_(p.date, p.lang)) + '</span><s>·</s><span>' +
        esc_(readLabel_(p.read || 1, p.lang)) + '</span></div>' +
    '</div></div></a>';
}

/* ============================== publish ============================== */
/**
 * Time-driven trigger. Flips scheduled posts whose day has arrived to published
 * and rebuilds. Add a daily trigger on this function — Triggers → Add trigger →
 * publishDue, time-driven, day timer. Nothing happens on a day with nothing due.
 */
function publishDue() {
  var sh = postsSheet_();
  if (sh.getLastRow() < 2) return;
  var statusCol = COLS.indexOf('status') + 1;
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, COLS.length).getValues();
  var flipped = 0;
  var t = today_();
  for (var i = 0; i < rows.length; i++) {
    var status = rows[i][COLS.indexOf('status')];
    var date = rows[i][COLS.indexOf('date')];
    if (date instanceof Date) date = Utilities.formatDate(date, 'UTC', 'yyyy-MM-dd');
    if (status === 'scheduled' && String(date) <= t) {
      sh.getRange(i + 2, statusCol).setValue('published');
      flipped++;
    }
  }
  if (flipped) {
    blogPublish_();
    Logger.log('publishDue: ' + flipped + ' post(s) went live.');
  }
}

function blogPublish_() {
  var live = allPosts_().filter(isLive_);
  var byId = {};
  live.forEach(function (p) { byId[p.id] = p; });

  /* One piece, one picture.
     A post and its translation are the same piece of writing, but the image is
     attached to whichever of the two the editor was open on when it was
     generated. The first piece went out with the cover on the Turkish record
     and nothing on the English one, so /blog/ showed the photograph and
     /en/blog/ showed the striped placeholder — the same article, illustrated in
     one language and not the other.
     A missing cover borrows its pair's. The path is built from the reading
     language's own prefix further down, so the same base name resolves
     correctly at both depths. */
  live.forEach(function (p) {
    if (!p.hero && p.pair && byId[p.pair] && byId[p.pair].hero) p.hero = byId[p.pair].hero;
  });

  /* Four templates, one per depth the Journal is served at. The English pages
     sit a level deeper than the Turkish ones, and a template carries its own
     '../' prefixes, so borrowing the Turkish pair for English produces a page
     whose logo, menu, footer and privacy link all point one level too high. */
  var TPL = {
    tr: { index: 'blog/_tpl-index.html',    post: 'blog/_tpl-post.html' },
    en: { index: 'blog/_tpl-index-en.html', post: 'blog/_tpl-post-en.html' }
  };
  var tpl = {}, missing = [];
  ['tr', 'en'].forEach(function (lang) {
    tpl[lang] = {};
    ['index', 'post'].forEach(function (kind) {
      var p = blogPath_(TPL[lang][kind]);
      tpl[lang][kind] = ghRead_(p);
      if (!tpl[lang][kind]) missing.push(p);
    });
  });
  if (missing.length) {
    /* Named, not counted. "templates_missing" sent us looking at the token once
       already; what was actually wrong was the path. */
    return json_({ ok: false, error: 'templates_missing — cannot read ' +
                   missing.join(', ') + ' from ' + prop_('GH_REPO') +
                   ' (branch ' + prop_('GH_BRANCH') + '). Deploy the build first.' });
  }

  var files = [];

  ['tr', 'en'].forEach(function (lang) {
    var set = live.filter(function (p) { return p.lang === lang; });
    var idxPath = (lang === 'en' ? 'en/blog/' : 'blog/') + 'index.html';

    // ---- index ----
    var idxImg = imgDirFrom_(lang, false);
    var html = tpl[lang].index;
    var featured = set.length ? featuredHtml_(set[0], idxImg) : '';
    var rest = set.slice(set.length ? 1 : 0);
    var cards = rest.map(function (p) { return cardHtml_(p, '', idxImg); }).join('\n');

    html = replaceBlock_(html, 'FEATURED', featured);
    html = replaceBlock_(html, 'GRID', '<div class="grid" id="grid">\n' + cards + '\n</div>');
    html = html.replace('__FOOTER_POSTS__', footerPosts_(set, ''));
    html = html.replace(/<html lang="[^"]*"/, '<html lang="' + lang + '"');
    files.push({ path: idxPath, content: html });

    // ---- posts ----
    var postImg = imgDirFrom_(lang, true);
    set.forEach(function (p, i) {
      var pair = p.pair && byId[p.pair] ? byId[p.pair] : null;
      var url = postUrl_(p);
      var related = set.filter(function (x) { return x.id !== p.id; })
                       .slice(0, 3)
                       .map(function (x) { return cardHtml_(x, '../', postImg); }).join('\n');

      var hreflang = '<link rel="alternate" hreflang="' + lang + '" href="' + url + '">';
      if (pair) {
        hreflang += '\n<link rel="alternate" hreflang="' + pair.lang + '" href="' + postUrl_(pair) + '">';
        /* x-default is the Turkish page, whichever page we are writing. The
           rest of the site says the same thing — build.py stamps x-default on
           the front page and on the Journal index at the Turkish address — and
           two files disagreeing about which page a search engine should show
           someone with no matching language is worse than either answer. */
        hreflang += '\n<link rel="alternate" hreflang="x-default" href="' +
                    (lang === 'tr' ? url : postUrl_(pair)) + '">';
      }

      /* No cover is the normal case for the first weeks, and it used to render
         as nothing at all: the title sat straight on top of the first
         paragraph. The card and the featured block have always drawn the
         patterned placeholder in that case; the article now does the same, so
         the three agree and the page keeps its shape. */
      var lead = p.hero
        ? '<figure class="lead-wrap"><img src="' + esc_(imgSrc_(p.hero, '16x9', postImg)) +
          '" alt="' + esc_(p.title) + '"></figure>'
        : '<figure class="lead-wrap">' + placeholder_('16/9') + '</figure>';

      /* The picture a share card shows. LinkedIn and X read og:image from the
         page rather than being handed one, and the tag was missing entirely —
         with twitter:card set to summary_large_image, a missing image is a
         blank grey rectangle with our headline under it. Absolute, because a
         crawler does not resolve a relative path against our idea of the page.
         With no cover the site's own card stands in, so a share always carries
         something drawn on purpose. */
      /* The share card is the `og` variant — JPEG, 1200×630 — not the 16x9 the
         article shows. See IMG_VARIANTS: LinkedIn does not read WebP for link
         previews, which is why the first post shared as an empty box. */
      var ogImage = p.hero
        ? prop_('SITE_BASE') + '/' + (prop_('BLOG_PREFIX') || '') + IMG_DIR +
          String(p.hero).replace(/^\/+/, '').replace(new RegExp('^' + IMG_DIR), '') +
          '-og.' + imgExt_('og')
        : prop_('SITE_BASE') + '/' + (prop_('BLOG_PREFIX') || '') + 'blog/img/share-default.' + IMG_EXT;

      var jsonld = JSON.stringify({
        '@context': 'https://schema.org', '@type': 'BlogPosting',
        headline: p.title, description: p.seo || p.excerpt,
        datePublished: p.date, inLanguage: lang,
        author: { '@type': 'Person', name: p.author || 'Eray Dengiz' },
        publisher: { '@type': 'Organization', name: 'Anthifel' },
        mainEntityOfPage: url
      });

      var out = tpl[lang].post
        .replace(/\{\{LANG\}\}/g, lang)
        .replace(/\{\{TITLE\}\}/g, esc_(p.title))
        .replace(/\{\{SEO_DESC\}\}/g, esc_(p.seo || p.excerpt))
        .replace(/\{\{CANONICAL\}\}/g, url)
        .replace(/\{\{HREFLANG\}\}/g, hreflang)
        .replace(/\{\{ISO_DATE\}\}/g, p.date)
        .replace(/\{\{JSONLD\}\}/g, jsonld)
        .replace(/\{\{CATEGORY\}\}/g, esc_(p.category))
        .replace(/\{\{CATEGORY_TR\}\}/g, esc_(catTr_(p.category)))
        .replace(/\{\{EXCERPT\}\}/g, esc_(p.excerpt))
        .replace(/\{\{AUTHOR\}\}/g, esc_(p.author || 'Eray Dengiz'))
        .replace(/\{\{DATE\}\}/g, esc_(niceDate_(p.date, lang)))
        .replace(/\{\{READ\}\}/g, esc_(readLabel_(p.read || 1, lang)))
        .replace(/\{\{LEAD_IMAGE\}\}/g, lead)
        .replace(/\{\{URLENC\}\}/g, encodeURIComponent(url))
        .replace(/\{\{TITLEENC\}\}/g, encodeURIComponent(p.title))
        .replace(/\{\{SHAREENC\}\}/g, encodeURIComponent(p.title + ' — ' + (p.excerpt || '')))
        .replace(/\{\{OG_IMAGE\}\}/g, ogImage)
        .replace(/\{\{TRANSLATION_URL\}\}/g, pair ? postUrl_(pair) : '')
        .replace(/\{\{RELATED\}\}/g, related)
        .replace('__FOOTER_POSTS__', footerPosts_(set, '../'))
        .replace(/\{\{BODY\}\}/g, md_(p.body));

      /* "Keep reading" with nothing under it is worse than no section: it
         reads as a page that failed to load rather than as a Journal with one
         piece in it. On the first post, and on any post that is the only one in
         its language, the whole block comes out. */
      if (!related) out = replaceBlock_(out, 'REL', '');

      files.push({ path: postPath_(p), content: out });
    });
  });

  /* posts.json is not for the site to read at runtime — nothing on this site
     fetches anything. It is the list the next build reads so that the footer on
     every page outside the Journal can show what is actually published instead
     of what was planned. `id` and `pair` are in it for one reason: a piece and
     its translation are one line in that footer, and without the pairing the
     build cannot tell two languages of the same piece from two pieces. */
  files.push({ path: 'blog/posts.json', content: JSON.stringify(live.map(function (p) {
    return { id: p.id, pair: p.pair || '', slug: p.slug, lang: p.lang, title: p.title,
             date: p.date, category: p.category, url: postUrl_(p) };
  }), null, 2) });

  var written = [];
  files.forEach(function (f) {
    var full = blogPath_(f.path);
    if (ghWrite_(full, f.content)) written.push(full);
  });

  return json_({ ok: true, published: live.length, written: written.length, files: written });
}

/** base is '' on the blog index and '../' on an article, which sits a level deeper. */
function footerPosts_(set, base) {
  return set.slice(0, 5).map(function (p) {
    return '<li><a href="' + esc_((base || '') + relFromBlog_(p)) + '">' + esc_(p.title) + '</a></li>';
  }).join('\n');
}

/** Swap everything between <!-- NAME:START --> and <!-- NAME:END -->. */
function replaceBlock_(html, name, inner) {
  var re = new RegExp('<!--\\s*' + name + ':START[\\s\\S]*?-->[\\s\\S]*?<!--\\s*' + name + ':END\\s*-->');
  return html.replace(re, '<!-- ' + name + ':START -->\n' + inner + '\n<!-- ' + name + ':END -->');
}

/* ============================== images =============================== */
/**
 * The editor crops and compresses in the browser, then sends one base64 WebP per
 * variant. Doing the crop client-side keeps the originals off our servers and
 * means what the writer previews is exactly what ships.
 *
 * data = { name: 'kapak', files: { '16x9': '<base64>', '4x3': …, '3x2': …, 'thumb': … } }
 */
function imageUpload_(data) {
  var base = slugifyName_(data.name || 'gorsel');
  if (!base) base = 'gorsel';
  base = base + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd-HHmmss');

  var missing = IMG_VARIANTS.filter(function (v) { return !data.files || !data.files[v.key]; });
  if (missing.length) {
    return json_({ ok: false, error: 'missing_variants: ' + missing.map(function (v) { return v.key; }).join(',') });
  }

  IMG_VARIANTS.forEach(function (v) {
    var b64 = String(data.files[v.key]).replace(/^data:image\/\w+;base64,/, '');
    ghWriteBinary_(blogPath_(IMG_DIR) + base + '-' + v.key + '.' + (v.ext || IMG_EXT), b64);
  });

  return json_({ ok: true, base: IMG_DIR + base, images: listImages_() });
}

/** Every image in blog/img/, grouped back into one entry per upload. */
function listImages_() {
  var res = UrlFetchApp.fetch(
    ghApi_(blogPath_(IMG_DIR.replace(/\/$/, ''))) + '?ref=' + prop_('GH_BRANCH'),
    { headers: ghHeaders_(), muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) return [];   // folder does not exist yet

  var files;
  try { files = JSON.parse(res.getContentText()); } catch (e) { return []; }
  if (!files.length) return [];

  var seen = {};
  files.forEach(function (f) {
    var m = new RegExp('^(.*)-(16x9|4x3|3x2|thumb)\\.' + IMG_EXT + '$').exec(f.name);
    if (!m) return;
    var base = m[1];
    if (!seen[base]) seen[base] = { base: IMG_DIR + base, name: base, variants: [] };
    seen[base].variants.push(m[2]);
  });

  return Object.keys(seen)
    .map(function (k) { return seen[k]; })
    .filter(function (e) { return e.variants.indexOf('thumb') >= 0; })
    .sort(function (a, b) { return b.name.localeCompare(a.name); });
}

/** Removes all four variants. Refuses while a post still points at the image. */
function imageDelete_(data) {
  var base = String(data.base || '').replace(/^\/+/, '');
  if (!base) return json_({ ok: false, error: 'no_base' });

  var used = allPosts_().filter(function (p) { return p.hero === base; });
  if (used.length) {
    return json_({ ok: false, error: 'in_use: ' + used.map(function (p) { return p.title; }).join(', ') });
  }

  IMG_VARIANTS.forEach(function (v) {
    ghDelete_(blogPath_(base) + '-' + v.key + '.' + IMG_EXT);
  });
  return json_({ ok: true, images: listImages_() });
}

function slugifyName_(s) {
  var map = { 'ç':'c','Ç':'c','ğ':'g','Ğ':'g','ı':'i','İ':'i','ö':'o','Ö':'o','ş':'s','Ş':'s','ü':'u','Ü':'u' };
  return String(s || '').replace(/[çÇğĞıİöÖşŞüÜ]/g, function (c) { return map[c]; })
    .toLowerCase().replace(/\.[a-z0-9]+$/, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50);
}

/* =============================== Gemini ==============================
 * Off unless GEMINI_KEY is set. Nothing here runs on its own and nothing here
 * publishes: both actions hand text or an image back to the editor, and a
 * person still presses Yayımla. That is deliberate — the model is a drafting
 * tool, and a draft that publishes itself is not a draft.
 *
 * The key lives here, in Script Properties, and never reaches a browser. The
 * editor only ever learns whether one exists.
 */
/* Model names are configuration, not code. Google renames and retires these on
   its own schedule, and when a name goes the request comes back 404 with no
   hint about which of the two models was wrong. They are Script Properties now,
   with the last known-good names as defaults, so a rename is one field and not
   a redeploy. `listGeminiModels()` prints what this key can actually call. */
function geminiTextModel_()  { return prop_('GEMINI_TEXT_MODEL')  || 'gemini-2.5-flash'; }
function geminiImageModel_() { return prop_('GEMINI_IMAGE_MODEL') || 'gemini-2.5-flash-image'; }

/* The second choice, used only when the first is busy after every retry. A
   newer flash model is the better writer and also the more popular one, which
   is the same reason it is the one that runs out of capacity. Falling back to
   an older sibling is a slightly worse sentence; failing is no sentence. */
function geminiTextFallback_()  { return prop_('GEMINI_TEXT_FALLBACK')  || 'gemini-2.5-flash'; }
function geminiImageFallback_() { return prop_('GEMINI_IMAGE_FALLBACK') || 'gemini-2.5-flash-image'; }

/**
 * Ask the first model; if it is busy rather than wrong, ask the second.
 *
 * Only a capacity answer earns the fallback. A 404 or a 400 is our mistake and
 * repeating it against another model would hide it, which is how a wrong prompt
 * or a retired name survives for a week.
 */
function geminiTry_(primary, fallback, payload) {
  try {
    return { model: primary, json: gemini_(primary, payload) };
  } catch (err) {
    var msg = String(err.message || err);
    /* A quota is not a busy signal. The fallback runs on the same key and the
       same project, so it is the same quota: trying it spends another 23
       seconds to be told the same thing. */
    var busy = /gemini_http_(500|502|503|504)/.test(msg) ||
               (/gemini_http_429/.test(msg) && !/quota|billing/i.test(msg));
    if (!busy || !fallback || fallback === primary) throw err;
    console.warn('Falling back from ' + primary + ' to ' + fallback + ': ' + err.message);
    return { model: fallback, json: gemini_(fallback, payload) };
  }
}

/* Waits between attempts. Three tries, then the fallback model.
   503 means the model is busy, not that anything is wrong: Google's own advice
   is to try again later, and "later" for a flash model is usually seconds. It
   is not something to hand to the writer as an error — it is something to wait
   through. The waits are short and the whole thing stays well inside Apps
   Script's six-minute ceiling. */
var GEMINI_BACKOFF = [2000, 6000, 15000];

/**
 * 5xx and a rate-limited 429 are worth another go. 400, 403 and 404 are not:
 * those are us.
 *
 * A 429 is two different answers wearing one number. "You are going too fast"
 * clears in seconds and waiting is exactly right. "You have used up your quota
 * for the day, check your billing" does not clear at all, and retrying it four
 * times turns a one-line answer into a twenty-three second wait followed by the
 * same one-line answer — twice, because the fallback model shares the quota.
 * So the body is read, not just the status.
 */
function geminiRetryable_(code, body) {
  if (code === 500 || code === 502 || code === 503 || code === 504) return true;
  if (code !== 429) return false;
  return !/quota|billing|exceeded your current/i.test(String(body || ''));
}

function gemini_(model, payload) {
  var key = prop_('GEMINI_KEY');
  if (!key) throw new Error('gemini_off — GEMINI_KEY is not set in Script Properties');

  var res, code, body;
  for (var attempt = 0; attempt <= GEMINI_BACKOFF.length; attempt++) {
    if (attempt) Utilities.sleep(GEMINI_BACKOFF[attempt - 1]);
    res = UrlFetchApp.fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent',
      { method: 'post', contentType: 'application/json',
        headers: { 'x-goog-api-key': key },
        payload: JSON.stringify(payload), muteHttpExceptions: true });
    code = res.getResponseCode();
    body = res.getContentText();
    if (!geminiRetryable_(code, body)) break;
    console.warn('Gemini ' + model + ' returned ' + code + ', attempt ' + (attempt + 1) +
                 ' of ' + (GEMINI_BACKOFF.length + 1));
  }
  if (code < 200 || code >= 300) {
    console.warn('Gemini ' + model + ' refused with ' + code + ': ' + body.slice(0, 500));
    /* The model name and Google's own sentence, carried up to the editor. It
       used to throw 'gemini_http_404' and nothing else, which says a request
       failed and not which of the two models does not exist — and 404 here
       almost always means the name, not the key. */
    var why = '';
    try { why = (JSON.parse(body).error || {}).message || ''; } catch (e) {}
    throw new Error('gemini_http_' + code + ' · ' + model +
                    (why ? ' · ' + why.slice(0, 200) : '') +
                    (code === 404 ? ' · run listGeminiModels() in Apps Script to see the names this key can call' : '') +
                    (geminiRetryable_(code, body) ? ' · tried ' + (GEMINI_BACKOFF.length + 1) + ' times over 23 seconds' : '') +
                    (code === 429 && !geminiRetryable_(code, body)
                      ? ' · this is a quota, not a rate limit: waiting will not clear it, and the fallback model shares it'
                      : ''));
  }
  return JSON.parse(body);
}

function geminiText_(prompt) {
  var j = geminiTry_(geminiTextModel_(), geminiTextFallback_(),
                     { contents: [{ parts: [{ text: prompt }] }] }).json;
  var parts = ((((j.candidates || [])[0] || {}).content || {}).parts) || [];
  var out = '';
  parts.forEach(function (p) { if (p.text) out += p.text; });
  if (!out) throw new Error('gemini_empty');
  return out.trim();
}

/**
 * Translate a post between Turkish and English.
 *
 * The house rules travel with the prompt rather than being cleaned up
 * afterwards: no em dash, no emoji, service names never translated. A model
 * asked for house style up front is cheaper to correct than one asked for
 * prose and then edited.
 */
function aiTranslate_(d) {
  var from = d.lang === 'en' ? 'English' : 'Turkish';
  var to   = d.lang === 'en' ? 'Turkish' : 'English';
  var rules = [
    'You are translating one article for Anthifel, an AI transformation advisory.',
    'Translate from ' + from + ' into ' + to + '.',
    'House rules, all of them mandatory:',
    '- Never use an em dash. Use a comma, a full stop or a colon.',
    '- Never use emoji or exclamation marks.',
    '- Do not translate these service names, leave them exactly as written: ' +
      'AI Readiness Audit, Discovery Sprint, Transformation Retainer, Advisory Board Seat, Executive Workshop.',
    '- Keep the Markdown structure exactly: the same headings, lists, quotes and links, in the same order.',
    '- Translate the meaning, not the words. Plain sentences. No marketing register.',
    'Return the three fields below, each on its own line, with nothing else:',
    'TITLE: <the translated title>',
    'EXCERPT: <the translated standfirst>',
    'BODY:',
    '<the translated body, in Markdown>'
  ].join('\n');
  var src = 'TITLE: ' + (d.title || '') + '\nEXCERPT: ' + (d.excerpt || '') + '\nBODY:\n' + (d.body || '');
  var out = geminiText_(rules + '\n\n---\n\n' + src);

  var m = out.match(/TITLE:\s*([\s\S]*?)\nEXCERPT:\s*([\s\S]*?)\nBODY:\s*\n?([\s\S]*)$/);
  if (!m) return json_({ ok: false, error: 'translate_unparsed' });
  return json_({ ok: true, post: {
    lang: d.lang === 'en' ? 'tr' : 'en',
    title: m[1].trim(), excerpt: m[2].trim(), body: m[3].trim()
  }});
}

/**
 * Draw a cover image and hand the raw picture back to the editor.
 *
 * It stops here rather than writing to the library, because the library wants
 * four crops and Apps Script has no canvas to make them with. The editor
 * already crops every uploaded file to those four sizes; a generated cover goes
 * through that same code and arrives in the library as the same kind of thing.
 * Nothing downstream has to know which it was.
 */
/* ======================= prompts, and settings ======================= */
/**
 * The two prompts the editor uses live in Script Properties, next to the key
 * they are spent with, and are edited from Settings rather than from here.
 *
 * They are defaults, not constants: the first three pieces will teach us more
 * about what to ask for than any amount of writing it out now, and a prompt
 * that can only be changed by editing this file is a prompt that never changes.
 * What is not editable is the house style — no em dash, no emoji, service names
 * untranslated — because that is a brand rule, not a preference, and it is
 * appended to whatever the field says.
 */
var PROMPT_KEYS = { write: 'PROMPT_WRITE', image: 'PROMPT_IMAGE' };

var PROMPT_DEFAULTS = {
  write: [
    'You are writing one piece for The Journal, the writing of Anthifel, a London',
    'AI transformation advisory. The reader is a director or above at a company of',
    '50 to 500 people who has to make an AI decision this quarter and has not made',
    'one before.',
    '',
    'Write what we are seeing inside companies. Concrete, specific, and useful to',
    'someone who has to act on Monday. One idea, followed the whole way down.',
    '',
    'Not this: a listicle, a definition of AI, a product pitch, a prediction about',
    'the next five years, or anything that could have been written without having',
    'been inside a company.',
    '',
    'Open with the situation, not with a definition. End on what the reader',
    'should do or notice, without a call to action.'
  ].join('\n'),
  image: [
    'A cover image for an article on an AI transformation advisory\'s journal.',
    'Style: quiet, editorial, photographic or abstract. Warm neutral palette on a',
    'limestone background near #F5F1EA, with a single terracotta accent near #B84C2E.',
    'No text, no words, no letters, no logos, no charts, no user interface, no robots,',
    'no glowing brains and no circuit boards.',
    'Landscape, 16:9.'
  ].join('\n')
};

/* Style is not a setting. It is appended after whatever the prompt field says,
   so an edited prompt cannot quietly drop the rules the whole site follows. */
var HOUSE_RULES = [
  'House rules, all of them mandatory:',
  '- Never use an em dash. Use a comma, a full stop or a colon.',
  '- Never use emoji, exclamation marks or bold headings shouted in capitals.',
  '- Never invent a client, a number, a case study or a quotation.',
  '- Never name a price, and never promise a result.',
  '- Leave these service names exactly as written, in any language: AI Readiness Audit,',
  '  Discovery Sprint, Transformation Retainer, Advisory Board Seat, Executive Workshop.',
  '- Markdown only: ## for sections, - for lists. No HTML, no front matter, no title line.'
].join('\n');

function prompt_(which) {
  return prop_(PROMPT_KEYS[which]) || PROMPT_DEFAULTS[which];
}

function settingsGet_() {
  return json_({ ok: true, settings: {
    write: prompt_('write'),
    image: prompt_('image'),
    writeDefault: PROMPT_DEFAULTS.write,
    imageDefault: PROMPT_DEFAULTS.image,
    ai: !!prop_('GEMINI_KEY'),
    blogPrefix: prop_('BLOG_PREFIX') || '',
    siteBase: prop_('SITE_BASE') || '',
    repo: prop_('GH_REPO') || '',
    branch: prop_('GH_BRANCH') || ''
  }});
}

function settingsSet_(d) {
  var props = PropertiesService.getScriptProperties();
  ['write', 'image'].forEach(function (k) {
    if (typeof d[k] === 'string') {
      /* An empty field means "go back to the default", not "ask the model for
         nothing". Deleting the property is how the default comes back. */
      if (d[k].trim()) props.setProperty(PROMPT_KEYS[k], d[k].trim());
      else props.deleteProperty(PROMPT_KEYS[k]);
    }
  });
  return settingsGet_();
}

/**
 * Write the piece. The plan row is the brief: its title, its pillar and whatever
 * Content wrote in the notes column.
 *
 * English first, always. The Turkish is a translation of a finished English
 * piece rather than a second draft written in parallel, so the two say the same
 * thing — which is the whole reason hreflang points them at each other.
 */
function aiWrite_(d) {
  var words = Math.max(250, Math.min(2500, parseInt(d.words, 10) || 900));
  var brief = [
    prompt_('write'),
    '',
    HOUSE_RULES,
    '',
    /* Length is a control, not prose. It used to be a sentence inside the brief,
       where editing the brief could silently drop it or contradict it; it comes
       from the field beside the button now and is stated after the brief, in
       one place, every time. */
    'Length: about ' + words + ' words. Within 10% either way.',
    '',
    'The piece:',
    'WORKING TITLE: ' + (d.title || ''),
    (d.pillar ? 'PILLAR: ' + d.pillar : ''),
    (d.notes ? 'WHAT THE PLAN SAYS THIS PIECE IS FOR: ' + d.notes : ''),
    (d.category ? 'CATEGORY: ' + d.category : ''),
    '',
    'Return exactly these four fields, each starting on its own line, nothing else:',
    'TITLE: <a title in sentence case, under 70 characters, no colon-subtitle>',
    'EXCERPT: <one standfirst sentence, under 160 characters>',
    'SEO: <one sentence for the search result, under 160 characters>',
    'BODY:',
    '<the article, in Markdown, starting with a paragraph and not with a heading>'
  ].filter(Boolean).join('\n');

  var out = geminiText_(brief);
  var m = out.match(/TITLE:\s*([\s\S]*?)\nEXCERPT:\s*([\s\S]*?)\nSEO:\s*([\s\S]*?)\nBODY:\s*\n?([\s\S]*)$/);
  if (!m) return json_({ ok: false, error: 'write_unparsed' });

  var body = m[4].trim();
  /* The model is told not to, and sometimes does anyway. A title repeated as an
     H1 inside the body would be the second one on the page. */
  body = body.replace(/^#\s+.*\n+/, '');
  return json_({ ok: true, post: {
    lang: 'en',
    title: m[1].trim(), excerpt: m[2].trim(), seo: m[3].trim(), body: body
  }});
}

function aiIllustrate_(d) {
  var brief = [
    prompt_('image'),
    'Subject: ' + (d.title || ''),
    (d.excerpt ? 'Context: ' + d.excerpt : '')
  ].filter(Boolean).join('\n');

  var j = geminiTry_(geminiImageModel_(), geminiImageFallback_(),
                     { contents: [{ parts: [{ text: brief }] }] }).json;
  var parts = ((((j.candidates || [])[0] || {}).content || {}).parts) || [];
  var b64 = '';
  parts.forEach(function (p) {
    if (!b64 && p.inlineData && p.inlineData.data) b64 = p.inlineData.data;
  });
  if (!b64) return json_({ ok: false, error: 'no_image_returned' });

  return json_({ ok: true, name: (d.slug || 'kapak'), b64: b64 });
}

/* ============================== GitHub =============================== */

/**
 * Every repo path this script touches goes through here. It used to be true
 * for writes only, and the templates were read at a bare 'blog/_tpl-*.html'
 * while being written under 'preview/blog/'. With BLOG_PREFIX set, publishing
 * answered `templates_missing` about files that were sitting in the repo, and
 * blogSelfTest threw pointing at the token. Neither was the reason.
 * One prefix, one function, or the two halves drift again.
 */
function blogPath_(path) {
  return (prop_('BLOG_PREFIX') || '') + path;
}

function ghApi_(path) {
  return 'https://api.github.com/repos/' + prop_('GH_REPO') + '/contents/' + path;
}
function ghHeaders_() {
  return {
    Authorization: 'Bearer ' + prop_('GH_TOKEN'),
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28'
  };
}

/**
 * Every call to GitHub goes through here, and the reason is a 503.
 *
 * GitHub answers "No server is currently available to service your request"
 * often enough that a publish writing seven files will meet one. It is not an
 * error in anything we did and the same request succeeds a moment later, so it
 * should never have reached the editor as a red line saying the post was not
 * saved.
 *
 * Three tries, widening: 1.5s, 4s, 9s. Only for a server error or a rate
 * limit — a 404 is an answer, and retrying a bad token three times is just
 * being slow about it.
 */
function ghFetch_(url, params) {
  var wait = [1500, 4000, 9000], res, code;
  for (var i = 0; ; i++) {
    res = UrlFetchApp.fetch(url, params);
    code = res.getResponseCode();
    if (code < 500 && code !== 429) return res;
    if (i >= wait.length) return res;
    console.warn('GitHub ' + code + ' on ' + url + ' — retrying in ' + wait[i] + 'ms');
    Utilities.sleep(wait[i]);
  }
}

/**
 * Absent is 404. Everything else is a failure and says so.
 *
 * This returned null on any answer that was not 200, which quietly turned a
 * server error into a fact about the repository: a 503 here said "the file is
 * not there", and the writer below then left the sha out and got a 422 it
 * could not explain.
 */
function ghRead_(path) {
  var res = ghFetch_(ghApi_(path) + '?ref=' + prop_('GH_BRANCH'), {
    headers: ghHeaders_(), muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  if (code === 404) return null;
  if (code !== 200) {
    throw new Error('GitHub ' + code + ' reading ' + path + ': ' +
                    res.getContentText().slice(0, 200));
  }
  var j = JSON.parse(res.getContentText());
  return Utilities.newBlob(Utilities.base64Decode(j.content.replace(/\n/g, ''))).getDataAsString('UTF-8');
}

/** The same rule as ghRead_: absent is 404, a server error is an error. */
function ghSha_(path) {
  var res = ghFetch_(ghApi_(path) + '?ref=' + prop_('GH_BRANCH'), {
    headers: ghHeaders_(), muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  if (code === 404) return null;
  if (code !== 200) {
    throw new Error('GitHub ' + code + ' checking ' + path + ': ' +
                    res.getContentText().slice(0, 200));
  }
  return JSON.parse(res.getContentText()).sha;
}

/**
 * Write a file. Skips the commit when the content is byte-identical, so
 * republishing does not produce empty commits or pointless deploys.
 */
function ghWrite_(path, content) {
  var existing = ghRead_(path);
  if (existing === content) return false;

  var payload = {
    message: 'blog: publish ' + path,
    content: Utilities.base64Encode(Utilities.newBlob(content).getBytes()),
    branch: prop_('GH_BRANCH')
  };
  var sha = ghSha_(path);
  if (sha) payload.sha = sha;

  var res = ghFetch_(ghApi_(path), {
    method: 'put', contentType: 'application/json',
    headers: ghHeaders_(), payload: JSON.stringify(payload), muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  if (code !== 200 && code !== 201) {
    throw new Error('GitHub ' + code + ' on ' + path + ': ' + res.getContentText().slice(0, 200));
  }
  return true;
}

/** Commit an already-base64 payload (images) without decoding it first. */
function ghWriteBinary_(path, b64) {
  var payload = { message: 'blog: image ' + path, content: b64, branch: prop_('GH_BRANCH') };
  var sha = ghSha_(path);
  if (sha) payload.sha = sha;
  var res = ghFetch_(ghApi_(path), {
    method: 'put', contentType: 'application/json',
    headers: ghHeaders_(), payload: JSON.stringify(payload), muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  if (code !== 200 && code !== 201) {
    throw new Error('GitHub ' + code + ' on ' + path + ': ' + res.getContentText().slice(0, 200));
  }
  return true;
}

function ghDelete_(path) {
  var sha = ghSha_(path);
  if (!sha) return false;
  var res = ghFetch_(ghApi_(path), {
    method: 'delete', contentType: 'application/json', headers: ghHeaders_(),
    payload: JSON.stringify({ message: 'blog: remove ' + path, sha: sha, branch: prop_('GH_BRANCH') }),
    muteHttpExceptions: true
  });
  return res.getResponseCode() === 200;
}

/** Run once from the editor to confirm every property and permission is right. */
function blogSelfTest() {
  var need = ['SHEET_ID', 'DASH_TOKEN', 'GH_TOKEN', 'GH_REPO', 'GH_BRANCH', 'SITE_BASE'];
  var missing = need.filter(function (k) { return !prop_(k); });
  if (missing.length) throw new Error('Missing script properties: ' + missing.join(', '));

  postsSheet_();

  /* All four, not one. The publisher needs a template per depth, and reading
     only the first one is how a missing English pair stays hidden until an
     English post is published and every link on it points one level too high. */
  var want = ['blog/_tpl-index.html', 'blog/_tpl-index-en.html',
              'blog/_tpl-post.html',  'blog/_tpl-post-en.html'];
  var gone = want.filter(function (t) { return !ghRead_(blogPath_(t)); });
  if (gone.length) {
    throw new Error('Cannot read ' + gone.map(blogPath_).join(', ') + ' from ' + prop_('GH_REPO') +
                    ' (branch ' + prop_('GH_BRANCH') + ') — deploy the build, then run this again.');
  }

  var trig = publishTrigger_() ? 'installed' : 'MISSING — run installPublishTrigger()';
  var ai   = prop_('GEMINI_KEY') ? 'set' : 'not set (the editor buttons stay off)';
  var mdl  = 'text = ' + geminiTextModel_() + ' (falls back to ' + geminiTextFallback_() + ')' +
             ', image = ' + geminiImageModel_() + ' (falls back to ' + geminiImageFallback_() + ')';
  Logger.log([
    'OK.',
    'Sheet reachable, GitHub reachable, all four templates found.',
    'Posts: ' + allPosts_().length,
    'BLOG_PREFIX: "' + (prop_('BLOG_PREFIX') || '') + '"  → pages are written under ' + blogPath_('blog/'),
    'Daily publishDue trigger: ' + trig,
    'GEMINI_KEY: ' + ai,
    'Gemini models: ' + mdl + '  (listGeminiModels() prints what the key can call)'
  ].join('\n'));
}

/* ---------------------------- the daily trigger ----------------------------
 * DEV-040. It used to be six clicks in a menu, which meant the only record of
 * whether it had been done was somebody's memory. Two functions instead: one
 * that installs it and one that says what is installed. Both are safe to run
 * again — installing twice is the failure mode that quietly fires the publisher
 * twice a day and takes a while to notice.
 */
function publishTrigger_() {
  var all = ScriptApp.getProjectTriggers();
  for (var i = 0; i < all.length; i++) {
    if (all[i].getHandlerFunction() === 'publishDue') return all[i];
  }
  return null;
}

/** Install the daily trigger, or say it is already there. Idempotent. */
function installPublishTrigger() {
  var existing = publishTrigger_();
  if (existing) {
    Logger.log('Already installed. Nothing to do.');
    return 'already installed';
  }
  ScriptApp.newTrigger('publishDue').timeBased().everyDays(1).atHour(7).create();
  Logger.log('Installed: publishDue runs daily, around 07:00 in the script timezone (' +
             Session.getScriptTimeZone() + ').');
  return 'installed';
}

/** Remove it. Here so the pair is complete and nobody hunts through a menu. */
function removePublishTrigger() {
  var t = publishTrigger_();
  if (!t) { Logger.log('Not installed. Nothing to remove.'); return 'absent'; }
  ScriptApp.deleteTrigger(t);
  Logger.log('Removed. Scheduled posts will not go live on their own until it is back.');
  return 'removed';
}

/* ===================== keeping Supabase awake ======================= */
/**
 * DEV-091.
 *
 * The panel's store is a free Supabase project, and a free project pauses
 * after seven days without activity. Paused is not lost — the data stays and a
 * button in their console brings it back — but it is the panel refusing to
 * open on the morning somebody needs it, which is the same thing to the person
 * standing in front of it.
 *
 * The alternative on the table was $25 a month for Pro. This is twenty lines
 * instead, and the CEO chose it on 20 August.
 *
 * Two decisions worth writing down:
 *
 * Every three days, not every seven. Seven days of inactivity is the limit,
 * so a weekly trigger is a race with it — and one skipped run, one Apps Script
 * outage, one quota day, and the gap becomes fourteen. Three days means two
 * consecutive failures still land inside the window.
 *
 * The publishable key, not a service key. This request is meant to prove the
 * project is being used, not to read anything. Row level security answers it
 * with an empty list, which is exactly right: the call counts as activity, and
 * a secret that could read the tables never has to live in this script.
 */
var SUPABASE_URL_DEFAULT = 'https://gjnejpainbkzriwqdaes.supabase.co';
var SUPABASE_KEY_DEFAULT = 'sb_publishable_XPgThYIe8CS9vpKlodRtFg_jF2wxd5u';

function supabaseUrl_() { return prop_('SUPABASE_URL') || SUPABASE_URL_DEFAULT; }
function supabaseKey_() { return prop_('SUPABASE_KEY') || SUPABASE_KEY_DEFAULT; }

/**
 * One read. Logs the outcome and remembers it, because a trigger that fails
 * silently for three weeks looks exactly like a trigger that is working.
 */
function supabasePing() {
  var url = supabaseUrl_() + '/rest/v1/dash_state?select=key&limit=1';
  var stamp = Utilities.formatDate(new Date(), 'UTC', "yyyy-MM-dd'T'HH:mm:ss'Z'");
  var note;
  try {
    var res = UrlFetchApp.fetch(url, {
      headers: { 'apikey': supabaseKey_(), 'Accept': 'application/json' },
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    /* 200 with an empty list is the expected answer and is a success: the
       request reached the project, which is the whole point. 401 and 404 are
       not — they mean the URL or the key is wrong, and a wrong address has
       been keeping nothing awake. */
    note = (code === 200 ? 'ok ' : 'FAIL ') + code + ' ' + stamp +
           (code === 200 ? '' : ' — ' + res.getContentText().slice(0, 120));
  } catch (err) {
    note = 'FAIL ' + stamp + ' — ' + String(err.message || err);
  }
  PropertiesService.getScriptProperties().setProperty('SUPABASE_PING', note);
  Logger.log('supabasePing: ' + note);
  return note;
}

function supabasePingTrigger_() {
  var all = ScriptApp.getProjectTriggers();
  for (var i = 0; i < all.length; i++) {
    if (all[i].getHandlerFunction() === 'supabasePing') return all[i];
  }
  return null;
}

/** Install it, or say it is already there. Idempotent, like its neighbour. */
function installSupabasePing() {
  var existing = supabasePingTrigger_();
  if (existing) {
    Logger.log('Already installed. Nothing to do.');
    return 'already installed';
  }
  ScriptApp.newTrigger('supabasePing').timeBased().everyDays(3).atHour(4).create();
  /* Run it once now rather than waiting three days to find out the URL is
     wrong. The first run is the only one anybody watches. */
  var first = supabasePing();
  Logger.log('Installed: supabasePing runs every 3 days, around 04:00 (' +
             Session.getScriptTimeZone() + '). First run: ' + first);
  return 'installed';
}

/** Remove it. Here so the pair is complete. */
function removeSupabasePing() {
  var t = supabasePingTrigger_();
  if (!t) { Logger.log('Not installed. Nothing to remove.'); return 'absent'; }
  ScriptApp.deleteTrigger(t);
  Logger.log('Removed. The Supabase project will pause after seven quiet days.');
  return 'removed';
}

/**
 * What this key can actually call, straight from Google.
 *
 * A 404 from generateContent means the name, not the key: the key is checked
 * before the route. Rather than guessing from documentation that changes, ask.
 * Run it, read the log, and put the two names you want into GEMINI_TEXT_MODEL
 * and GEMINI_IMAGE_MODEL in Script Properties.
 */
function listGeminiModels() {
  var key = prop_('GEMINI_KEY');
  if (!key) throw new Error('GEMINI_KEY is not set in Script Properties.');
  var res = UrlFetchApp.fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200',
    { headers: { 'x-goog-api-key': key }, muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) {
    throw new Error('ListModels failed with ' + res.getResponseCode() + ': ' +
                    res.getContentText().slice(0, 400));
  }
  var models = (JSON.parse(res.getContentText()).models || []).filter(function (m) {
    return (m.supportedGenerationMethods || []).indexOf('generateContent') >= 0;
  });
  Logger.log('In use now:  text = ' + geminiTextModel_() + '   image = ' + geminiImageModel_());
  Logger.log('Models this key can call with generateContent (' + models.length + '):');
  Logger.log(models.map(function (m) {
    return '  ' + m.name.replace(/^models\//, '');
  }).sort().join('\n'));
  Logger.log('Anything with "image" in the name is the one to put in GEMINI_IMAGE_MODEL.');
}

/**
 * What is installed, in one line each — and what should be and is not.
 *
 * Listing what exists answers half the question. The half that costs a morning
 * is the trigger that was never installed, or was removed by whoever last
 * cleaned up the project, because nothing about the log distinguishes that from
 * a project that only ever needed one.
 */
var EXPECTED_TRIGGERS = [
  { fn: 'publishDue',   what: 'scheduled posts go live',  fix: 'installPublishTrigger()' },
  { fn: 'supabasePing', what: 'Supabase stays awake',     fix: 'installSupabasePing()' }
];

function checkTriggers() {
  var all = ScriptApp.getProjectTriggers();
  var have = {};
  all.forEach(function (t) { have[t.getHandlerFunction()] = t.getEventType(); });

  Logger.log(all.length
    ? all.map(function (t) { return '  ' + t.getHandlerFunction() + '  ' + t.getEventType(); }).join('\n')
    : '  (no triggers at all)');

  var missing = EXPECTED_TRIGGERS.filter(function (e) { return !have[e.fn]; });
  if (!missing.length) {
    Logger.log('Both expected triggers are installed.');
  } else {
    Logger.log('MISSING:');
    missing.forEach(function (e) {
      Logger.log('  ' + e.fn + ' — ' + e.what + '. Run ' + e.fix);
    });
  }

  /* The last thing the ping said. A trigger that exists and fails every time
     reads as a healthy list above, so the outcome is printed with it. */
  var last = prop_('SUPABASE_PING');
  Logger.log('supabasePing, last outcome: ' + (last || '(never run)'));
}
