#!/usr/bin/env bash
# deploy.command — Anthifel
#
# Çift tıkla. Hepsi bu. Terminale hiçbir şey yazmıyorsun.
#
# Neden ayrı bir dosya: macOS'ta .sh dosyaları çift tıklamayla çalışmaz,
# .command dosyaları çalışır. İçerik deploy.sh ile aynı işi yapıyor; fark
# sadece nasıl başlatıldığı.
#
# Neden hâlâ senin makinenden: hem buluttaki konteynerin hem de masaüstü
# köprüsünün git trafiği bir proxy'den geçiyor ve ikisi de bu depoya
# 403 veriyor. Push edebilen tek yer senin kendi makinen.

cd "$(dirname "$0")"

echo "Anthifel — deploy"
echo "─────────────────────────────────────────"
echo

rm -f .git/index.lock

for f in deploy.sh deploy.command DEPLOY_MSG.txt; do
  grep -qxF "$f" .git/info/exclude 2>/dev/null || echo "$f" >> .git/info/exclude
done

# Pull first, always.
#
# The blog publisher commits straight to GitHub from inside Google, so this
# folder falls one step behind every time a post goes out — and the first sign
# of it is a push rejected at the end of a deploy, which is the worst moment to
# find out. --autostash puts the new build aside, replays the publisher's
# commits underneath it, and puts it back on top.
# The Journal's two index pages belong to the publisher.
#
# It writes them from inside Google and commits them straight to GitHub: the
# featured piece and the grid of cards are on them, and this machine only ever
# sees those after the pull above. The site build writes the same two files —
# it has to, so the test suites and the local preview have something to open —
# but its copies have no cards on them. On 15 August a deploy pushed exactly
# that and the Journal went empty in both languages.
#
# So they go back to what was committed, every time, before the pull — a
# working tree with local edits on those two files is exactly what turns the
# rebase below into a conflict. If
# the build changed the header, the footer or the stylesheet, press Yayınla in
# the panel once after this and the two pages catch up.
for f in preview/blog/index.html preview/en/blog/index.html \
         blog/index.html en/blog/index.html; do
  if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
    git checkout -- "$f" 2>/dev/null
  fi
done
if [ -n "$(git status --porcelain -- preview/blog/index.html preview/en/blog/index.html 2>/dev/null)" ]; then
  echo "! Journal indeksleri korunamadı — Developer'a söyle."
else
  echo "— Journal indeksleri yayıncıya bırakıldı —"
fi
echo

echo "— sunucudan çekiliyor —"
if ! git pull --rebase --autostash; then
  echo
  echo "✗ Çekilemedi. Büyük ihtimalle aynı dosyada iki değişiklik var."
  echo "  Yayıncının yazdığı dosyayı almak için:"
  echo "    git checkout --ours preview/blog/index.html preview/en/blog/index.html"
  echo "    git add preview/blog/index.html preview/en/blog/index.html"
  echo "    git rebase --continue"
  echo "  Sonra bu dosyaya tekrar çift tıkla. Dizinler bir sonraki yayında"
  echo "  şablondan yeniden basılıyor, yani kaybedilen bir şey olmuyor."
  echo
  echo "Bu pencereyi kapatabilirsin."
  exit 1
fi
echo

if [ -n "$(git status --porcelain)" ]; then
  git add -A
  echo "— değişenler —"
  git status --short
  echo
  if [ -s DEPLOY_MSG.txt ]; then
    git commit -F DEPLOY_MSG.txt
    rm -f DEPLOY_MSG.txt
  else
    git commit -m "Site güncellemesi"
  fi
else
  echo "Çalışma ağacı temiz."
fi

ahead="$(git log --oneline @{u}..HEAD 2>/dev/null || true)"
if [ -z "$ahead" ]; then
  echo
  echo "Sunucu zaten güncel. Push edilecek bir şey yok."
  echo
  echo "Bu pencereyi kapatabilirsin."
  exit 0
fi

echo "— push edilecek —"
echo "$ahead"
echo

if git push; then
  echo
  echo "✓ Push tamam. Canlıya çıkması bir iki dakika sürer."
  echo "  DigitalOcean → Apps → Activity ekranından commit hash ile doğrula."
else
  echo
  echo "✗ Push olmadı. Yukarıdaki hatayı Developer'a olduğu gibi yolla."
fi

# Journal sayfaları bu build'in kabuğunda mı?
#
# Bu dosya siteyi deploy eder; Journal'ın sayfalarını ise yayıncı yazar ve
# yalnızca panelden Yayınla'ya basıldığında. Yani başlık, alt bilgi ya da stil
# değiştiğinde yayındaki her yazı eski kabukta kalır — düzeltme yapılmamış gibi
# görünür. Bir günde üç kez "hâlâ düzelmemiş" dedirtti.
#
# build.py dört şablona kısa bir damga koyuyor, yayıncı da onu yazdığı her
# sayfaya kopyalıyor. Burada karşılaştırıyoruz.
stamp="$(grep -o 'journal-shell: [0-9a-f]*' preview/blog/_tpl-post.html 2>/dev/null | head -1 | awk '{print $2}')"
if [ -n "$stamp" ]; then
  behind=""
  for f in preview/blog/index.html preview/en/blog/index.html \
           preview/blog/*/index.html preview/en/blog/*/index.html; do
    [ -f "$f" ] || continue
    case "$f" in *_tpl*) continue;; esac
    grep -q "journal-shell: $stamp" "$f" 2>/dev/null || behind="$behind
    $f"
  done
  echo
  if [ -n "$behind" ]; then
    echo "⚠  JOURNAL ESKİ KABUKTA. Panelden bir kez Yayınla'ya bas."
    echo "   Bu sayfalar bu build'in başlığını/alt bilgisini/stilini taşımıyor:$behind"
  else
    echo "✓ Journal sayfaları bu build'in kabuğunda."
  fi
fi

echo
echo "Bu pencereyi kapatabilirsin."
