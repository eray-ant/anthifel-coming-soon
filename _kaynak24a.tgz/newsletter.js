/* The reading list's form. Injected into every shell that carries the band.
   It was inside the blog's script and nowhere else, which is why the band could
   not travel: markup, styles and behaviour have to move together or the part
   arrives half-alive.

   It asks the page for nothing. The three shells name their language variable
   three different ways — `LANG`, `window.__LANG`, and nothing at all on the
   legal pages — so this reads the language off <html> instead, which every one
   of them sets. `ENDPOINT` and `FORM_LIVE` are read defensively for the same
   reason: a page without them is a page where the form says so and sends
   nothing, which is the correct behaviour anyway.

   ---- the consent record, 19 August ----

   Until today this form sent a packet the endpoint did not recognise and the
   endpoint rejected it. The visitor saw a failure, so nobody was lost quietly,
   but there was no reading list: not an empty one, none.

   Rebuilt against `Anthifel_Legal_DataProcessing.md` §3, which asks for five
   things to be recorded, because a consent that cannot be shown is the same as
   no consent:

     when            the moment the box was ticked, not the moment of sending
     which wording   `consent-en-v1` / `consent-tr-v1`
     which channel   `web-form`
     what was given  the affirmative act itself, captured rather than inferred
     which notice    the version of the privacy notice on the page at the time

   The wording is Legal's and lives in the markup; this file records which
   version of it the person actually saw, which is why the identifiers are here
   and not invented at the far end. */
var nf=document.getElementById('nf');
if(nf){
  var nemail=document.getElementById('nemail'),ncons=document.getElementById('ncons'),
      npriv=document.getElementById('npriv'),
      nmsg=document.getElementById('nmsg'),nbtn=document.getElementById('nbtn');
  var consentAt=null;
  /* Versions travel with the words. Change one, change the other — the point of
     a version is that an old record still resolves to the sentence that was on
     the screen. */
  var CONSENT_VERSION={en:'consent-en-v1',tr:'consent-tr-v1'};
  var PRIVACY_VERSION='__PRIVACY_VERSION__';
  var NT={
    email:{en:'Please enter a valid email address.',tr:'Lütfen geçerli bir e-posta adresi girin.'},
    cons:{en:'Please tick the first box so we may write to you.',tr:'Size yazabilmemiz için ilk kutuyu işaretleyin.'},
    priv:{en:'Please confirm you have read the Privacy Policy.',tr:'Gizlilik Politikası\'nı okuduğunuzu onaylayın.'},
    off:{en:'The list opens shortly. Nothing was recorded.',tr:'Liste çok yakında açılıyor. Hiçbir şey kaydedilmedi.'},
    good:{en:'Thank you, you are on the list.',tr:'Teşekkürler, listeye alındınız.'},
    fail:{en:'Something did not go through. Please email hello@anthifel.com.',tr:'Bir şeyler ters gitti. Lütfen hello@anthifel.com adresine yazın.'},
    /* A second sentence, for the failure we now know happens. On 21 August a
       subscription never arrived: the execution log has no doPost at that
       minute at all, so it was stopped on the visitor's side — a network or a
       browser extension that will not reach script.google.com. "Something did
       not go through" left that person with nothing to do. This one names the
       thing they can act on. Developer's draft; Marketing has not approved it. */
    blocked:{en:'We could not reach the server. Your network or an extension may be blocking it — try another connection, or email hello@anthifel.com.',tr:'Sunucuya ulaşılamadı. Ağınız ya da bir tarayıcı eklentisi engelliyor olabilir — başka bir bağlantıyla deneyin ya da hello@anthifel.com adresine yazın.'},
    sending:{en:'…',tr:'…'},
    sub:{en:'Subscribe',tr:'Abone ol'}
  };
  function nlang(){return document.documentElement.lang==='tr'?'tr':'en';}
  function nt(k){return NT[k][nlang()]||NT[k].en;}
  function say(msg,good){nmsg.textContent=msg;nmsg.className='nmsg '+(good?'good':'bad');}
  /* The moment of the tick, not the moment of the send. Unticking clears it:
     a timestamp for a box that is not ticked is a record of something that did
     not happen. */
  ncons.addEventListener('change',function(){consentAt=this.checked?new Date().toISOString():null;});
  nf.addEventListener('submit',function(e){
    e.preventDefault();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(nemail.value.trim())){say(nt('email'),false);return;}
    if(!ncons.checked){say(nt('cons'),false);return;}
    if(npriv&&!npriv.checked){say(nt('priv'),false);return;}
    if(nf.querySelector('[name=website]').value) return;
    var ep=(typeof ENDPOINT!=='undefined')?ENDPOINT:'';
    var live=(typeof FORM_LIVE!=='undefined')?FORM_LIVE:false;
    /* One deliberate way past the switch, and only on the preview build:
       `?form=live` runs the real thing — a real row in the sheet — so the chain
       can be tested before the Privacy Policy is published, which is what
       FORM_LIVE is actually waiting for. `FORM_TEST` is stamped false into
       production, so on the live site this branch cannot be reached from any
       address. The front page has had this since 11 August; the band is on
       every page, so it needs it on every page too. */
    if(!live && typeof FORM_TEST!=='undefined' && FORM_TEST &&
       /[?&]form=live(?:&|$)/.test(window.location.search)) live=true;
    if(!live||!ep||ep.charAt(0)==='_'){say(nt('off'),true);return;}
    nbtn.disabled=true;nbtn.textContent=nt('sending');
    var lang=nlang();
    /* The sentence as it stood on the screen, read out of the label rather than
       repeated here. Two copies of a legal sentence drift, and the copy that
       drifts is always the one nobody is looking at. */
    var wording=nf.querySelector('#ncons').parentNode.querySelector('label').textContent.trim();
    /* ---- one retry, then a failure that leaves a trace ------------------

       21 August, 11:26. Somebody filled this in, was told "Something did not
       go through", and no row reached the sheet. Nothing was written down
       anywhere: we learned about it because he screenshotted his own screen
       and sent it to the CEO. Both halves of that are worth fixing.

       The retry is for the transport, not for a refusal. If the server
       answered and said no — a malformed address, a missing consent field —
       sending the identical packet a second time gets the identical no. But a
       rejected fetch, a reply that is not JSON, a 5xx: those are a moment in
       time, and a moment is worth waiting out once. The server keys the list
       on the address, so a retry that lands twice cannot produce two rows.

       And when it does finally fail, the page says so somewhere other than on
       the visitor's screen. No address goes with it: they did not complete a
       consented submission, so we have no basis to keep it and no use for it. */
    var payload = {
        action:'reading-list',
        source:'reading-list',
        email:nemail.value.trim(),
        consent:true,
        consentAt:consentAt||new Date().toISOString(),
        consentText:wording,
        consentVersion:CONSENT_VERSION[lang]||CONSENT_VERSION.en,
        channel:'web-form',
        affirmative:'checkbox:true',
        privacyVersion:PRIVACY_VERSION,
        privacyAck:!!(npriv&&npriv.checked),
        lang:lang,
        tz:(Intl.DateTimeFormat().resolvedOptions().timeZone||''),
        page:location.href,referrer:document.referrer||''};

    function post(){
      return fetch(ep,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},
        body:JSON.stringify(payload)})
        .then(function(r){
          return r.json().then(function(d){return {http:r.status,body:d};},
                               function(){
                                 var e=new Error('the answer was not JSON (http '+r.status+')');
                                 e.retry=true; throw e;
                               });
        },function(){
          /* Not "the server said no" — the request never got there. This is
             the 21 August failure, and it is the one the visitor can act on. */
          var e=new Error('the request never reached the server');
          e.retry=true; e.blocked=true; throw e;
        })
        .then(function(res){
          if(res.body&&res.body.ok) return res;
          /* The server answered. A 5xx is the server having a bad second; a
             reason in the body is the server having read the packet and
             declined it, and that will not change on a second try. */
          var e=new Error(res.body&&res.body.error
            ? 'the server refused: '+res.body.error
            : 'the server answered http '+res.http+' with no body');
          e.retry=(res.http>=500);
          throw e;
        });
    }

    function done(res){
      say(nt('good'),true);
      nf.querySelector('.nrow').hidden=true;
      var boxes=nf.querySelectorAll('.ncons');
      for(var i=0;i<boxes.length;i++) boxes[i].hidden=true;
      /* The row exists but the mail telling us about it did not go. The
         visitor is on the list and is told so; this line is for us. */
      if(res.body&&res.body.notified===false)
        console.warn('[reading list] subscribed, but the notification mail failed');
    }

    /* Reported, not shown. The visitor can do nothing with "http 500" and
       should not have to read it; the sentence they get names the one thing
       they can act on. The beacon goes to the same host, so the blocked case
       cannot record itself — every other failure can. */
    function report(reason,blocked){
      console.error('[reading list] '+reason);
      try{
        fetch(ep,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},
          body:JSON.stringify({source:'client-error',where:'reading-list',
            reason:String(reason).slice(0,200),lang:lang,
            page:location.href.split('?')[0]})}).catch(function(){});
      }catch(e){}
      say(nt(blocked?'blocked':'fail'),false);
      nbtn.disabled=false;nbtn.textContent=nt('sub');
    }

    post().then(done,function(err){
      if(!err||!err.retry) return report(err&&err.message?err.message:err,false);
      console.warn('[reading list] '+err.message+' — trying once more');
      return new Promise(function(r){setTimeout(r,1200);})
        .then(post).then(done,function(err2){
          report((err2&&err2.message?err2.message:err2)+' (after one retry)',
                 !!(err2&&err2.blocked));
        });
    });
  });
}
