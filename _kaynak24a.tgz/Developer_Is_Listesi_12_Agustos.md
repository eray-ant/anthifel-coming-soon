# Developer — bütün açık işler · 12 Ağustos 2026

Kaynak: `Developer_Asana.md` (bölüm 2, 4, 5, 6), `Anthifel_Website.md` §10, ve
bugün konuştuklarımız. Kapanmış maddeler listeye alınmadı.

Sınıflandırma benim tahminim, süre değil zorluk:

- **Basit** — yarım saatten az, kararı verilmiş, mekanik.
- **Orta** — birkaç saat, ya da bir cevap bekliyor ama cevap gelince düz iş.
- **Zor** — bir gün ve üzeri, ya da sebebi henüz bilinmeyen bir şey.

Sahibi sütunu: **D** Developer (ben), **E** Eray, **L** Legal, **B** Business,
**M** Marketing, **C** CEO kararı.

---

## Basit

| # | ID | İş | Sahibi | Bekliyor |
|---|---|---|---|---|
| B1 | — | Apps Script'te loglu `Code.gs` için **yeni sürüm** yayınla | E | — |
| B2 | DEV-063 | Bugünün değişikliklerini `Anthifel_Website.md`'ye işle, ID kaydını ve Asana dosyasını güncelle | D | — |
| B3 | item 44 | Ölü bağlantı kontrolü klasör linklerini görmüyor; `#çapa` ve `*.html` dışını da çözsün | D | — |
| B4 | item 43 | Google takviminin `anthifel.com` kaynağından iframe'e girdiğini teyit et | D | Canlı sayfa |
| B5 | item 12 | `FORM_LIVE = true` | D | Z1 + Legal'in üç bilgisi |
| B6 | item 10 | Kayıtlı adresi alt bilgiye ekle | D | Legal |
| B7 | DEV-034 | 0–29 bandının çağrısını görüşme bandına bağla | D | — |
| B8 | item 34 | `privacy@anthifel.com` takma ad değil, gerçek Google Grubu olsun; okuyacak kişi belli olsun | E | — |
| B9 | item 35 | Alan adı kayıt kuruluşunda WHOIS gizliliğini teyit et | E | — |
| B10 | item 32 | Google Workspace sürümü ve veri bölgesi ayarını Admin konsolundan oku | E | — |
| B11 | DEV-016 | Supabase Pro, ayda $25 — onay | C | — |
| B12 | DEV-048 | Toplantı not alma aracını seç (Fireflies mi, Wispr Flow mu) | C | — |

## Orta

| # | ID | İş | Sahibi | Bekliyor |
|---|---|---|---|---|
| O1 | item 37 | **Canlı URL'i okuyan test.** Bütün suite'ler bu konteynerdeki dosyaları okuyor; önemli olan sunucunun ne döndürdüğü. Bugün tam da bu yüzden körlemesine tartıştık | D | Ağ erişimi |
| O2 | item 31 | DigitalOcean bölgesi. **Londra değilse uygulama yeniden kurulup DNS taşınacak — lansmandan sonra değil, önce** | E → D | — |
| O3 | item 9b, 26, 18 | Lansman mekaniği: production build köke, coming-soon kaldır, `/preview/` sil, panel stub'ları değiş, `BLOG_PREFIX` boşalt | D | Lansman günü |
| O4 | item 19 | Okuma listesi rıza akışı gizlilik politikası kapsamına alınsın | D + L | Legal |
| O5 | item 45 | Legal'in üç bilgisi: şirket numarası, kayıtlı adres, ICO numarası | L | — |
| O6 | DEV-007 | Saklama süresi gün olarak → `PURGE_AFTER_DAYS` (şu an 730) | L | — |
| O7 | — | ICO numarası 20 Ağustos'a yetişmezse ilgili cümle silinsin mi | L | — |
| O8 | item 47 | Uzun tire kuralı Legal'in metnini kapsıyor mu | M + L | — |
| O9 | item 42 | Marketing'in üç açık maddesi: §9a Türkçe alt metin, 7c "görüşme ayarla", §8.7c ifadesi | M | — |
| O10 | item 22 | Beşinci alt bilgi blog başlığı — gerçek mi, yer tutucu mu | M | — |
| O11 | item 27, 28 | On iki sorunun metni (M) ve boyut eşlemesi (B); bant metnindeki uzun tire (M) | M + B | — |
| O12 | item 24 | Services §9.2'nin Türkçesi | B | — |
| O13 | DEV-054 | Discovery Sprint, Transformation Retainer, Advisory Board Seat sayfa metinleri | B | — |
| O14 | item 15 | Services §11'deki sapmalardan kaçının açık olduğu | C | — |
| O15 | item 23 | Türkçe künye ifadesi | L | — |

## Zor

| # | ID | İş | Sahibi | Bekliyor |
|---|---|---|---|---|
| Z1 | — | **Kod maili teslim edilmiyor.** `doPost` başarılı, DNS'in dördü de doğru, takma ad geçerli, kota düşüyor — ama mail eline geçmiyor. Sebep henüz bilinmiyor | D + E | `testMailNow` sonucu |
| Z2 | item 48 | **Deploy zinciri.** Hem buradaki konteynerin hem masaüstü köprüsünün git trafiği proxy'den 403 alıyor. Push edebilen tek yer senin Mac'in, ve mobilden çalışmıyor. Çözüm: depoyu bu oturumun kaynaklarına eklemek | E → D | — |
| Z3 | DEV-038…044 | **Blog altyapısı.** GitHub ince ayarlı token, Script Properties, `blogSelfTest` yeşile, günlük `publishDue` tetikleyicisi, `SITE_PREFIX` = `BLOG_PREFIX`, şablonları depoya koy, ilk yazıyı uçtan uca yayınla | E → D | Token |

---

## Sıra önerisi

1. **Z1** — mail çalışmadan test çalışmıyor, test çalışmadan `FORM_LIVE` açılmıyor.
2. **B1** — Z1'i çözmenin aracı; loglar olmadan yine körlemesine bakarız.
3. **O2** — Londra değilse taşıma lansmandan önce, ve bu haftaya sığması lazım.
4. **O5, O6** — Legal'in üçü; hukuki sayfalar yayın sürümüne yazılmıyor.
5. **Z2** — her adımı yavaşlatıyor ama hiçbirini durdurmuyor.
6. **Z3** — blog 12 Ağustos'ta yayına girecekti, tarih zaten kaydı.
