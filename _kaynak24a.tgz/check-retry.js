/*
 * check-retry.js — the reading-list form, driven through its failure paths.
 *
 * On 21 August somebody subscribed, saw "Something did not go through", and no
 * row reached the sheet. The execution log settled it: there is no doPost at
 * that minute at all. The request never arrived — stopped on his side of the
 * wire, by a network or a browser that would not reach script.google.com. We
 * knew about it only because he screenshotted his own screen.
 *
 * So the form was given three things it did not have: one automatic retry for a
 * transport failure, a failure that writes itself down, and a second sentence
 * for the case where the request never left — which is the only one the visitor
 * can act on. This file drives all of them, because a retry loop that fires
 * twice on a refusal, or never fires at all, is worse than no retry — and
 * neither shows up by reading the source.
 *
 * Four runs against an endpoint that misbehaves on purpose:
 *   the request is dropped once   → retried, succeeds, one subscription
 *   the server declines the packet → sent once; retrying a no gets the same no
 *   the request is dropped twice   → stops, and says it survived a retry
 *   …and the sentence it shows names the network, not "something"
 *
 * The address is checked to be absent from the failure report every time. The
 * person did not complete a consented submission, so we have no basis to keep
 * it and no use for it.
 *
 *   node check-retry.js
 */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const ROOT = __dirname;
let pass=0, fail=0;
const ok=(n,c,x)=>{c?(pass++,console.log('  ✓ '+n)):(fail++,console.log('  ✗ '+n+(x?'  → '+x:'')))};

const NEWS = fs.readFileSync(path.join(ROOT,'newsletter.html'),'utf8');
const JS   = fs.readFileSync(path.join(ROOT,'newsletter.js'),'utf8')
               .replace('__PRIVACY_VERSION__','privacy-v3');

const page_ = () => `<!doctype html><html lang="en"><body>${NEWS}
<script>var ENDPOINT='https://ep.invalid/exec';var FORM_LIVE=true;var FORM_TEST=false;<\/script>
<script>${JS}<\/script></body></html>`;

const fill = async p => {
  await p.setContent(page_());
  await p.fill('#nemail','hello@chivit.com.tr');
  await p.check('#ncons'); await p.check('#npriv');
  await p.click('#nbtn');
};

(async () => {
  const b = await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});

  console.log('\n— a dropped request, once —');
  {
    const p = await b.newPage(); const hits = [];
    await p.route('https://ep.invalid/exec', r => {
      const body = JSON.parse(r.request().postData()); hits.push(body);
      if (body.source === 'client-error') return r.fulfill({status:200,body:'{"ok":true}'});
      if (hits.filter(h=>h.source==='reading-list').length === 1) return r.abort('failed');
      r.fulfill({status:200,contentType:'application/json',body:'{"ok":true}'});
    });
    await fill(p); await p.waitForTimeout(3000);
    const msg = (await p.textContent('#nmsg')).trim();
    ok('is retried and succeeds', /on the list/i.test(msg), msg);
    ok('…with exactly two attempts', hits.filter(h=>h.source==='reading-list').length===2,
       String(hits.filter(h=>h.source==='reading-list').length));
    ok('…and the same address both times',
       hits[0].email==='hello@chivit.com.tr' && hits[1].email==='hello@chivit.com.tr');
    ok('…and nothing is reported when it recovers', hits.every(h=>h.source!=='client-error'));
    await p.close();
  }

  console.log('\n— a refusal —');
  {
    const p = await b.newPage(); const hits = [];
    await p.route('https://ep.invalid/exec', r => {
      hits.push(JSON.parse(r.request().postData()));
      r.fulfill({status:200,contentType:'application/json',body:'{"ok":false,"error":"consent"}'});
    });
    await fill(p); await p.waitForTimeout(2500);
    ok('is sent once, not twice', hits.filter(h=>h.source==='reading-list').length===1,
       String(hits.filter(h=>h.source==='reading-list').length));
    const err = hits.find(h=>h.source==='client-error');
    ok('…and is written down', !!err, JSON.stringify(hits.map(h=>h.source)));
    ok('…with the reason the server gave', err && /consent/.test(err.reason), err&&err.reason);
    ok('…and without the address', err && !JSON.stringify(err).includes('chivit'));
    ok('…and the button comes back', !(await p.isDisabled('#nbtn')));
    await p.close();
  }

  console.log('\n— a request that never arrives, the 21 August case —');
  {
    const p = await b.newPage(); const hits = [];
    await p.route('https://ep.invalid/exec', r => {
      const body = JSON.parse(r.request().postData()); hits.push(body);
      if (body.source === 'client-error') return r.fulfill({status:200,body:'{"ok":true}'});
      r.abort('failed');
    });
    await fill(p); await p.waitForTimeout(3500);
    ok('two attempts, then it stops', hits.filter(h=>h.source==='reading-list').length===2,
       String(hits.filter(h=>h.source==='reading-list').length));
    const err = hits.find(h=>h.source==='client-error');
    ok('…and the report says it survived a retry', err && /after one retry/.test(err.reason),
       err && err.reason);
    const msg = (await p.textContent('#nmsg')).trim();
    ok('…and the visitor is told what to try, not just that it broke',
       /could not reach the server/i.test(msg), msg);
    ok('…which is a different sentence from the generic one',
       !/Something did not go through/i.test(msg), msg);
    await p.close();
  }

  await b.close();
  console.log(fail? `\n❌  ${pass} passed, ${fail} failed` : `\n✅  ${pass} passed, 0 failed`);
  process.exit(fail?1:0);
})();
