# Blog adı — Marketing'e öneri

12 Ağustos 2026 · Developer → Marketing, CEO kararıyla

CEO bloğun adının **"The Journal"** olmasını öneriyor. Developer'ın görüşü ve
Türkçe karşılığı için üç seçenek aşağıda. Karar Marketing'in; çıktığında
`Anthifel_Brand_Guidelines.md` §8'e işlenmesi gerekiyor — kaynak güncellenmezse
site ile kılavuz sessizce çelişir, ve bu 9 Ağustos'ta hero cümlesinde bir kez
oldu.

---

## "The Journal" — Developer'ın görüşü: iyi

İki sebeple:

**Sıklık baskısını kaldırıyor.** "Blog" haftalık bir ritim vaat eder ve o ritim
tutmadığında sayfa bakımsız görünür. Bir *journal* ayda bir de çıkabilir; geç
kalmışlık hissi vermez. Bizim yayın planımız da bunu gerektiriyor.

**Yazının cinsini doğru anlatıyor.** Bizim yazdığımız şey haber ya da güncelleme
değil, düşünülmüş metin. Danışmanlıkta yerleşik bir kalıp olması da tesadüf
değil.

---

## Türkçesi — "Yolculuk" olmamalı

Bu bir çeviri tuzağı ve fark edilmesi kolay olduğu için pahalı.

*Journal* Türkçede **yolculuk değil**. İngilizcede *journey* yolculuk, *journal*
günlük kayıt ya da dergi demek. İkisi aynı kökten geliyor — Fransızca *jour*,
gün — ama anlamları ayrılmış. "AI Yolculuğu" dersek İngilizce ad ile Türkçe ad
**iki farklı şeyi** anlatır, ve bunu fark eden ilk okuyucu haklı olarak
dikkatsizlik sayar. Bir marka için en ucuz kaybedilen güven türü budur.

Ayrıca "yolculuk" kelimesi dönüşüm danışmanlığında fazlasıyla yıpranmış: her
sunumda geçiyor ve artık hiçbir şey anlatmıyor.

---

## Üç seçenek, Developer'ın tercih sırasıyla

### 1. İki dilde de "The Journal"

Hizmet adlarında zaten bu kuralı uyguluyoruz: **K34**, AI Readiness Audit
Türkçe sayfada da İngilizce kalıyor. Bir yayın adı da özel isimdir; aynı mantık
geçerli, ve tutarlılık kendi başına bir argüman.

- **Lehte:** çeviri riski sıfır, mevcut kuralla uyumlu, iki dil arasında ad
  farkı yok
- **Aleyhte:** Türkçe okuyucuya bir kelimelik yabancılık

### 2. "Yazılar"

Düz ve dürüst. Marka sesimiz zaten bu: süslemeyen, abartmayan.

- **Lehte:** herkes anlar, hiçbir şey vaat etmez, Türkçe
- **Aleyhte:** ayırt edici değil; her sitede var

### 3. "Defter"

*Journal*'ın birebir karşılığı ve az kullanılmış.

- **Lehte:** sıcak, somut, akılda kalır
- **Aleyhte:** kurumsal bir alıcı için fazla samimi olabilir

**"Günlük" önerilmiyor.** Türkçede kişisel günce çağrışımı çok güçlü ve şirket
bloğu için yanlış yere düşüyor.

---

## Karar çıkınca ne değişiyor

Developer tarafında hepsi mekanik, yarım gün:

- Menüdeki ve alt bilgideki başlık, iki dilde
- Blog dizin sayfasının başlığı ve `<title>`'ı
- `og:title` ve meta açıklamalar
- Blog yazılarının üstündeki dönüş bağlantısı
- `check-blog.js` içindeki başlık kontrolleri

Adres değişmiyor: `/blog/` olarak kalır. Ad değişse de URL'in sabit kalması
doğrusu — yayımlanmış bir bağlantının kırılmaması, sayfanın adından önemli.

---

## Marketing'ten istenen

Tek bir cevap: **üç seçenekten hangisi**, ya da dördüncü bir öneri. Ad §8'e
işlendikten sonra Developer siteye uygular.
