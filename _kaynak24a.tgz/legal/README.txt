Legal's masters, copied here so the site builds without the shared folder mounted.

Legal owns these files. Do not edit them here — edit them in "Anthifel MD's" and
copy them back. build.py reads Part B only; Part A is a handover note and is
never published.
