# Anthifel — Website Terms of Use & Cookie Policy

**Owner:** Legal
**Master file:** `Anthifel MD's/Anthifel_Legal_SiteTerms.md`
**Version:** 1.3 · **Date:** 20 August 2026
**Version identifiers:** `terms-v1` · `cookies-v1` — **unchanged.** Nothing in Part B moved this turn; everything below happened in Part A, which is not published.

### Last change (20 August 2026)

- **`[REGISTERED ADDRESS]` filled, both languages:** `Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom`. From Mükellef's incorporation record, not from the register — verify when the number issues.
- **`[COMPANY NAME]` closed the same day: `Anthifel Ltd`.** The Mükellef screen did not settle it — `Şirket Türü: Private Limited` is the company **type**, not the suffix — but the CEO confirmed he registered it as `Anthifel Ltd`. The text already read that way, so no wording moved. The regulation 25 duty is to publish the **registered** name, so the spelling is still checked against the certificate.
- **`[COMPANY NUMBER]` filled the same day: `17411895`**, from the certificate of incorporation — **ANTHIFEL LTD**, incorporated 20 August 2026 in England and Wales. Both languages updated.
- **The trading-disclosure duty is now live.** Regulation 25 bites from incorporation, not from launch: registered name, number, place of registration and registered office must appear on the website. All four are now in the company block at the head of these Terms and of the Privacy Policy. The one remaining gate on publication is Developer's cookie table, not our text.
- **`terms-v1` and `cookies-v1` do not move.** Placeholders were filled; no published wording changed.
- Urgency: **before launch**
- Affects: Developer
- CEO decision needed: no — the remaining name question is now a reading, not a decision

### Previous change (19 August 2026)

- **Cookie table: received, and rejected in part.** Developer supplied three entries. Two things stop them going into `[COOKIE TABLE]`, both recorded below: no durations, and `anthifel_consent` classified as non-essential when it is the one entry that is plainly strictly necessary. LGL-032 stays open.
- **The company block at the top of Terms is approved as the imprint.** No separate imprint page is needed — the trading-disclosure duty is site-level, not page-level. Two amendments to the Turkish wording are recorded below.
- **`[COMPANY NAME]` added as a placeholder.** "Anthifel Ltd" appears throughout and the suffix is not decided (LGL-001).
- **A dating correction, made visible rather than quietly.** This block was first written as 16 August. It was wrong: the device clock reading I used was taken at the start of the session and was stale, and the file was in fact written and saved on **19 August**. Nothing in the substance changes. It is corrected because in this department a date is part of the record — an opinion is only usable if you can tell how old it is.
- Urgency: **before launch**
- Affects: Developer
- CEO decision needed: yes — LGL-001, the company-name suffix, must be settled before 20 August because Mükellef writes it on the incorporation form.

### Previous change (5 August 2026)

- File created. Website Terms of Use and Cookie Policy, EN and TR. **English governs.** Completes the set of three site legal pages with `Anthifel_Legal_PrivacyPolicy.md`.
- **These are Terms of *Use* — they govern the website. They are not the client contract.** The engagement terms are separate and sit in the contract inventory at `Anthifel_Legal.md` §3. Confusing the two is how a website disclaimer ends up being argued as a limitation on a paid engagement.
- Urgency: **before launch**
- Affects: Developer, Marketing
- CEO decision needed: no

---

# PART A — HANDOVER NOTE · BU BÖLÜM YAYINLANMAZ

## The publication rule, and it is the answer to "can we publish and fix it later"

**Drafting with placeholders: yes. Publishing with placeholders: no.**

Not pedantry. A live page reading `[COMPANY NUMBER]` fails on its face — it is the first thing an enterprise buyer's due diligence looks at, and a regulator after it. Worse for the privacy notice specifically: **before 20 August there is no controller.** Publishing it earlier names a company that does not exist, and every visitor who gives data in that window has been told something untrue about who holds it. That is not a defect you fix by updating the page afterwards; the people affected were already misinformed.

**What does work, and it is what was proposed:** build all three pages now, fill everything except the placeholders, keep them unpublished or `noindex`, and flip them live on 20 August with the placeholders filled. **One rule: nothing goes public with a bracket in it.**

## The site can launch before 20 August — under one condition

The gate is on **collecting personal data**, not on the site existing. A brochure site with **no form, no newsletter signup, no analytics, and no cookies beyond strictly necessary** collects nothing, so it needs no privacy notice and no cookie consent. Terms of Use can be published from day one.

**The moment any of those four is switched on, all three pages must already be live and complete.** Not the same week. The same deployment.

## Placeholders

| Placeholder | Filled by | When |
|---|---|---|
| ~~`[COMPANY NUMBER]`~~ | Legal | **Filled 20 August 2026 — `17411895`**, from the certificate of incorporation |
| ~~`[REGISTERED ADDRESS]`~~ | Legal | **Filled 20 August 2026** — `Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom`. From the incorporation form; verify against the register when the number issues |
| ~~`[COMPANY NAME]`~~ | Legal | **Closed 20 August 2026 — `Anthifel Ltd`**, registered in that form and confirmed by the CEO. The text below already reads `Anthifel Ltd`, so nothing changes. Spelling verified against the certificate when it arrives |
| `[PRIVACY EMAIL]` | Developer | Before go-live. A real monitored mailbox |
| `[COOKIE TABLE]` | **Developer** | Before any non-essential cookie is set. **Still open** — see below |

## The cookie table is Developer's and Legal cannot write it

For every cookie the site sets, Developer supplies: **name, who sets it, what it does, how long it lasts, and whether it is strictly necessary.** The strictly-necessary classification is the one that matters — it decides which cookies need consent and which do not, and it must reflect what the cookie actually does rather than what would be convenient.

**If a cookie's purpose cannot be described in one plain sentence, it does not go on the site.**

## Cookie table — status at 19 August 2026

Three entries supplied. Neither of the two problems below is a matter of opinion, and neither takes long to fix.

| Entry | Set by | What it does | How long | Strictly necessary? |
|---|---|---|---|---|
| `anthifel_consent` | Anthifel | Remembers the cookie choice you made | **Missing** — the answer lapses after six months, but the entry's own lifetime has not been given | **Yes** — Developer classified it "not necessary"; corrected |
| `_ga` | Google Analytics | Distinguishes one visitor from another | **Missing** | No |
| `_ga_W376XEN94E` | Google Analytics | Keeps session state for measurement ID `G-W376XEN94E` | **Missing** | No |

**Problem one: no durations.** The rule above asks for five things and one of them is absent for all three entries. `[COOKIE TABLE]` stays a placeholder until they arrive, and the publication rule at the top of this file does not bend for a table that is three-quarters complete.

**Problem two, and this is the substantive one: `anthifel_consent` is not optional, it is strictly necessary.** Developer classified all three the same way. If the record of a person's cookie choice itself required consent, we could never record a refusal — we would have to ask again on every visit, which is exactly the behaviour the rule exists to prevent. ICO guidance treats the record of a cookie preference as strictly necessary. Our own published Cookie Policy already lists "remembering your cookie choice" among the necessary cookies: publishing the table as supplied would have put the page in contradiction with itself two paragraphs apart.

**A naming point that is not pedantry.** The consent answer is held in `localStorage`, not in a cookie — Developer's own note says so, and the reasoning behind it is sound (asking for cookie permission by setting a cookie would be a poor look). It still belongs in this table. PECR regulation 6 covers storing information on, or gaining access to information stored in, a user's terminal equipment; it is not limited to cookies. So the entry stays, but it is described accurately as a browser storage entry rather than as a cookie.

## The imprint — approved, with two amendments

Developer asked whether a separate imprint page is wanted. **It is not, and it would not add compliance.**

The Company, Limited Liability Partnership and Business (Names and Trading Disclosures) Regulations 2015, regulation 25, requires a company to disclose its registered name, registered number, place of registration and registered office address **on its websites**. The duty attaches to the website, not to each page. The company block at the head of the Privacy Policy and these Terms, plus the footer line, satisfies it. A separate page would need CEO approval, would need maintaining, and would buy nothing.

Two amendments to the Turkish wording, both cheap:

1. **`Anthifel Ltd` must not be hard-coded.** The build already refuses to publish without the company number, registered address and ICO number — good — but it does not guard the name, and the name is the one field that could be wrong on day one. See `[COMPANY NAME]` above.
2. **The footer line `"© 2026 Anthifel Ltd · İngiltere ve Galler'de tescillidir"` becomes `"...İngiltere ve Galler'de kayıtlı şirkettir"`.** In Turkish, "tescilli" standing next to a brand name reads naturally as *trade mark* registration. We hold none: the UKIPO application is not filed before the week of 24 August and registration takes months. Read as a whole the sentence plainly means company registration, and **I am not saying the current wording is an offence.** I am saying the ambiguity costs one word to remove and nothing to leave, and that under section 95 of the Trade Marks Act 1994 falsely representing a mark as registered is a criminal offence in the UK — which is not a sentence anyone wants to have to argue was inapplicable.

## The consent banner — rejected, and why it belongs in this file

The mechanism behind the banner is right and is stronger than the law requires: before an answer, analytics is not loaded at all, so no request reaches Google and nothing is written to the device. That is recorded as approved.

**The layout is rejected.** A framed "Kabul ediyorum" beside a plain-text "Hayır, teşekkürler" is the pattern ICO cookie guidance names when it asks for accept and reject to be equally prominent. Developer measured five properties that answer most of the objection — same size, same colour, same line, one click, both visible without scrolling — and the single remaining difference is the frame. The frame is the objection.

**Not inflating it:** the ICO does not fine for banner design; its practice is warning letters and it has concentrated on the UK's most-visited sites. Anthifel is not one of them. **Not hiding it:** the exposure is not a fine. It is that an enterprise buyer's due diligence looks at exactly this, on a company selling AI transformation; and that once Legal has written down that a design is non-compliant, keeping it stops being an oversight and becomes a decision. Those are not the same thing in front of a regulator.

The fix is one CSS rule: give both controls the same frame. Where visual hierarchy is wanted, build it with order and wording rather than weight. Tracked as **LGL-057**, and it gates the launch of the three pages (LGL-035).

## Timetable for the three pages

| Page | Drafted | Publishable |
|---|---|---|
| Privacy Policy | 5 Aug 2026 | 20 Aug, once the processor list, privacy email and ICO number are in |
| Terms of Use | 5 Aug 2026 | Any time — no placeholders except company details, and it can carry them from 20 Aug |
| Cookie Policy | 5 Aug 2026 | When Developer supplies the cookie table **with durations and the corrected classification** |

**All three complete and live: 20 August 2026.** The critical path as at 19 August is four items, none of them drafting:

1. **LGL-001** — the company-name suffix. Needed by Mükellef *before* 20 August, not on it.
2. **LGL-032** — three cookie durations and one corrected classification.
3. **LGL-028 → LGL-027 → LGL-034** — a five-minute ICO self-assessment that nobody has clicked through, which gates the ICO registration, which gates the registration number on the page.
4. **LGL-057** — the banner layout.

The processor list is no longer on this path; it closed on 19 August with GA4 added.

---
---

# PART B — PUBLISHABLE TEXT

# ENGLISH — GOVERNING VERSION

## Terms of Use

**Version:** terms-v1 · **Last updated:** [GO-LIVE DATE]

### 1. Who we are

This website is operated by Anthifel Ltd, registered in England and Wales, company number 17411895, registered office Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom. Contact: [PRIVACY EMAIL].

### 2. These terms

By using this website you accept these terms. If you do not accept them, please do not use the site.

### 3. What this site is, and what it is not

This site describes our services and publishes material about artificial intelligence and organisational change.

**Nothing on this site is advice, and nothing on it creates a client relationship.** That includes our articles, our published frameworks, and the AI Readiness Assessment and any result it produces. The assessment is an indicative self-check. It does not take account of your circumstances, it is not a professional opinion, and it should not be relied on as a basis for a decision.

**We advise clients under a written engagement contract, and only then.** Reading this site, completing the assessment, or corresponding with us does not create one.

### 4. Our content

The content of this site — text, design, logos, graphics, frameworks and methodology — belongs to us or is used with permission. You may read it, and share or quote it with attribution and a link. You may not republish it as your own, sell it, or use it to build a competing service.

The name **Anthifel**, our logo and our visual identity are our trade marks.

### 5. Using the site properly

Do not attempt to gain unauthorised access to the site or its infrastructure, introduce anything malicious, scrape it at a scale that affects its operation, or use it for anything unlawful.

### 6. Links to other sites

Where we link to another site, we do not control it and we are not responsible for its content.

### 7. Availability

We try to keep the site available, but we do not guarantee it. We may change, suspend or withdraw any part of it without notice.

### 8. Our liability

Nothing in these terms limits our liability for death or personal injury caused by our negligence, for fraud or fraudulent misrepresentation, or for anything else that cannot lawfully be limited.

Subject to that: we provide this site as it is, and we are not liable for any loss arising from your use of it or your reliance on anything published on it. **Liability under an engagement is governed by that engagement's contract, not by these terms.**

### 9. Personal data

How we handle personal data is set out in our Privacy Policy.

### 10. Changes

We may update these terms. The version and date at the top tell you which version applies.

### 11. Governing law

These terms are governed by the law of England and Wales, and the courts of England and Wales have exclusive jurisdiction.

---

## Cookie Policy

**Version:** cookies-v1 · **Last updated:** [GO-LIVE DATE]

### What cookies are

Small files a website stores on your device. Some are needed for a site to work. Others measure how a site is used.

### How we use them

We keep this to a minimum.

**Strictly necessary cookies** make the site work — security, and remembering your cookie choice. These do not need your consent, because without them the site cannot do what you came for.

**All other cookies, including analytics, need your consent, and we ask before we set them.** Not after. If you decline, the site works exactly as it does otherwise — you are simply not measured.

### The cookies we set

[COOKIE TABLE]

### Changing your mind

You can change your cookie choice at any time from the link in our site footer. You can also block or delete cookies in your browser settings, though blocking strictly necessary cookies may stop parts of the site working.

### Questions

Write to [PRIVACY EMAIL].

---
---

# TÜRKÇE — ÇEVİRİ

> **Not:** Bu metin İngilizce aslın çevirisidir. **Uyuşmazlık hâlinde İngilizce metin geçerlidir.**

## Kullanım Şartları

**Sürüm:** terms-v1 · **Son güncelleme:** [YAYIN TARİHİ]

### 1. Biz kimiz

Bu web sitesi, İngiltere ve Galler'de kayıtlı Anthifel Ltd tarafından işletilir. Şirket numarası 17411895, kayıtlı adres Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom. İletişim: [GİZLİLİK E-POSTASI].

### 2. Bu şartlar

Bu siteyi kullanarak bu şartları kabul etmiş olursunuz. Kabul etmiyorsanız lütfen siteyi kullanmayın.

### 3. Bu site nedir, ne değildir

Bu sitede hizmetlerimizi anlatıyor, yapay zekâ ve kurumsal dönüşüm üzerine içerik yayımlıyoruz.

**Bu sitedeki hiçbir şey danışmanlık değildir ve hiçbiri müvekkil ilişkisi kurmaz.** Buna yazılarımız, yayımladığımız çerçeveler ve **AI Readiness Assessment ile ürettiği sonuç da dahildir.** Değerlendirme, yol gösterici bir öz-kontroldür. Sizin koşullarınızı dikkate almaz, profesyonel bir görüş değildir ve bir kararın dayanağı olarak kullanılmamalıdır.

**Müşterilerimize yalnızca yazılı bir hizmet sözleşmesi kapsamında danışmanlık veririz.** Bu siteyi okumak, değerlendirmeyi doldurmak veya bizimle yazışmak böyle bir sözleşme kurmaz.

### 4. İçeriğimiz

Bu sitenin içeriği — metin, tasarım, logolar, görseller, çerçeveler ve metodoloji — bize aittir ya da izinle kullanılmaktadır. Okuyabilir, kaynak göstererek ve bağlantı vererek paylaşabilir veya alıntılayabilirsiniz. Kendinize aitmiş gibi yeniden yayımlayamaz, satamaz ya da rakip bir hizmet kurmak için kullanamazsınız.

**Anthifel** adı, logomuz ve görsel kimliğimiz markalarımızdır.

### 5. Siteyi düzgün kullanmak

Siteye veya altyapısına yetkisiz erişim denemeyin, zararlı yazılım bulaştırmayın, işleyişini etkileyecek ölçekte veri kazımayın ve hukuka aykırı hiçbir amaçla kullanmayın.

### 6. Diğer sitelere bağlantılar

Başka bir siteye bağlantı verdiğimizde o siteyi biz kontrol etmeyiz ve içeriğinden sorumlu değiliz.

### 7. Erişilebilirlik

Sitenin erişilebilir kalması için çalışırız ama bunu garanti etmeyiz. Sitenin herhangi bir bölümünü haber vermeden değiştirebilir, durdurabilir veya kaldırabiliriz.

### 8. Sorumluluğumuz

Bu şartlardaki hiçbir hüküm, ihmalimizden kaynaklanan ölüm veya bedensel zarar, hile veya hileli beyan ya da hukuken sınırlandırılamayacak başka bir husus bakımından sorumluluğumuzu sınırlamaz.

Bunun dışında: bu siteyi olduğu gibi sunarız ve siteyi kullanmanızdan ya da burada yayımlanan bir şeye güvenmenizden doğan zararlardan sorumlu değiliz. **Bir hizmet sözleşmesi kapsamındaki sorumluluk, bu şartlarla değil, o sözleşmeyle belirlenir.**

### 9. Kişisel veri

Kişisel veriyi nasıl işlediğimiz Gizlilik Politikası'nda yazılıdır.

### 10. Değişiklikler

Bu şartları güncelleyebiliriz. Hangi sürümün geçerli olduğunu baştaki sürüm ve tarih gösterir.

### 11. Uygulanacak hukuk

Bu şartlar İngiltere ve Galler hukukuna tabidir; İngiltere ve Galler mahkemeleri münhasır yetkilidir.

---

## Çerez Politikası

**Sürüm:** cookies-v1 · **Son güncelleme:** [YAYIN TARİHİ]

### Çerez nedir

Bir web sitesinin cihazınızda sakladığı küçük dosyalar. Bir kısmı sitenin çalışması için gereklidir. Bir kısmı sitenin nasıl kullanıldığını ölçer.

### Nasıl kullanıyoruz

Asgari düzeyde tutuyoruz.

**Kesinlikle gerekli çerezler** sitenin çalışmasını sağlar — güvenlik ve çerez tercihinizin hatırlanması. Bunlar rızanızı gerektirmez, çünkü onlar olmadan site zaten geldiğiniz işi yapamaz.

**Analitik dahil diğer bütün çerezler rızanızı gerektirir ve biz yerleştirmeden önce sorarız.** Sonra değil. Reddederseniz site tamamen normal çalışır — yalnızca ölçülmezsiniz.

### Kullandığımız çerezler

[ÇEREZ TABLOSU]

### Fikrinizi değiştirirseniz

Çerez tercihinizi site altbilgisindeki bağlantıdan istediğiniz zaman değiştirebilirsiniz. Tarayıcı ayarlarınızdan da çerezleri engelleyebilir veya silebilirsiniz; ancak kesinlikle gerekli çerezleri engellemek sitenin bazı bölümlerinin çalışmamasına yol açabilir.

### Sorular

[GİZLİLİK E-POSTASI] adresine yazın.
