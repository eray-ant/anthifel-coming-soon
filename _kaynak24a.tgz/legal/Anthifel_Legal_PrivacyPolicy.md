# Anthifel — Privacy Policy / Gizlilik Politikası

**Owner:** Legal
**Master file:** `Anthifel MD's/Anthifel_Legal_PrivacyPolicy.md`
**Version:** 1.4 · **Date:** 20 August 2026
**Notice version identifier:** `privacy-v3` — this is the value Developer records in the consent record field required by `Anthifel_Legal_DataProcessing.md` §3. `privacy-v1` and `privacy-v2` were never published and **no real consent record points at either of them**: the only row in the assessment sheet is Developer's own 12 August test, which is deleted before launch. So nothing needs migrating — but the identifier still advances, because the rule is that the identifier follows the wording, and a rule that is bent once for convenience is not a rule.

### Last change (20 August 2026)

- **`[REGISTERED ADDRESS]` filled, both languages:** `Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom`. Source: Mükellef's incorporation record, seen by the CEO on 20 August. **Not yet the register.** Until the certificate issues this is the address we asked for, not the address we have — verify it against the Companies House record the day the number arrives. It is the same discipline as everything else in this file: a value from a form is a value from a form.
- **`[COMPANY NAME]` closed later the same day: `Anthifel Ltd`.** The Mükellef screen did not settle it and this is recorded because the reasoning matters more than the answer. The Mükellef screen shows `Ünvan: Anthifel` and `Şirket Türü: Private Limited`. **"Private Limited" is the company *type*, not the name suffix** — every UK private company limited by shares is one. It did not tell us whether the registered name was `ANTHIFEL LTD` or `ANTHIFEL LIMITED`. The CEO confirmed he registered it as **Anthifel Ltd**, which is what the text already says — so nothing changes. The certificate is still read when it arrives, because a name is reproduced from the register and not from memory.
- **`[COMPANY NUMBER]` filled the same day: `17411895`.** The certificate of incorporation issued from Cardiff on 20 August 2026 for **ANTHIFEL LTD**, a private company limited by shares, situated in England and Wales. Both languages updated.
- **The registered address is now confirmed against a filed document**, not just a form: the electronically filed IN01 records the proposed registered office as `UNIT 501 LEROY HOUSE, 434-436 ESSEX ROAD, LONDON, UNITED KINGDOM N1 3FY`, which is what this file already carried.
- **One bracket left in this file: `[ICO REGISTRATION NUMBER]`.** The publication rule is unchanged — nothing goes public with a bracket in it. The controller now exists, so the go-live gate has moved from "does the company exist" to "is the ICO number in hand", and if it is not, the sentence is deleted rather than published blank.
- **The version identifier does not move.** `privacy-v3` stands — the wording did not change, a placeholder was filled. The identifier tracks what a person read, and nobody has read either version.
- Urgency: **before launch**
- Affects: Developer — the same address goes into the Turkish imprint block
- CEO decision needed: no — the name suffix resolved to `Anthifel Ltd` the same day. Two brackets left, both waiting on paper: the company number and the ICO number

### Previous change (19 August 2026)

- **Google Analytics 4 added to the processor list**, in both languages. The 12 August list did not contain it because GA4 was installed on the evening of 15 August; the three days are the whole of the discrepancy Legal flagged. The list is now eight processors and the open point closes.
- **Transfer section updated** — GA4 is processed in the United States, which makes analytics the most visible of the US transfers rather than a footnote.
- **Cookie section strengthened into a commitment.** The notice now says analytics is *not loaded at all* before consent — no request to Google, nothing written to the device — and that the choice lapses after six months. This is stronger than the law requires and it is true today, verified by 48 automated checks per build. **Publishing it converts an implementation detail into a published statement**: if `check-consent.js` is ever removed, the notice becomes false.
- **Version identifier moved to `privacy-v3`.**
- **A dating correction, made visible rather than quietly.** This block was first written as 16 August. It was wrong: the device clock reading I used was taken at the start of the session and was stale, and the file was in fact written and saved on **19 August**. Nothing in the substance changes. It is corrected because in this department a date is part of the record — an opinion is only usable if you can tell how old it is.
- Urgency: **before launch**
- Affects: Developer
- CEO decision needed: no. Two things must land before publication and neither is a Legal decision: the company-name suffix (LGL-001) and the cookie banner correction (LGL-057).

### Previous change (12 August 2026)

- **Processor list filled from Developer's 12 August delivery.** Seven providers, in both languages. `[PROCESSOR LIST]` / `[HİZMET SAĞLAYICI LİSTESİ]` closed.
- **International transfer section rewritten.** Three US companies; we rely on the UK Extension to the EU-US Data Privacy Framework. The Google data-region point is stated honestly rather than hidden: we cannot promise where the data sits, and what the mechanism protects is the level of protection, not the location.
- **A false sentence corrected.** The notice said the assessment "does not store your result against you". Developer's list shows the email address, the consent record and the result and band **are** stored. Individual answers are not. The text now says what the system does. This is the kind of divergence that turns a privacy notice into a liability rather than a protection.
- **Version identifier moved to `privacy-v2`.** The published wording changed, so the identifier changes with it.
- Urgency: **before launch**
- Affects: Developer
- CEO decision needed: no — but the GA4 open point in Part A must close before publication

### Previous change (5 August 2026)

- File created. English and Turkish text for publication. **English is the governing version**; the Turkish text is a translation and also serves as the KVKK aydınlatma metni for Turkish visitors.
- Bases, purposes and retention periods match `Anthifel_Legal_DataProcessing.md` §1 exactly. If either file changes, both change.
- Urgency: **before launch**
- Affects: Developer, Marketing
- CEO decision needed: no

---

# PART A — HANDOVER NOTE · BU BÖLÜM YAYINLANMAZ

**Do not publish anything in Part A. The publishable text starts at Part B.**

## Five placeholders. None of them may be guessed.

| Placeholder | Filled by | When |
|---|---|---|
| ~~`[COMPANY NUMBER]`~~ | Legal | **Filled 20 August 2026 — `17411895`.** Read off the certificate of incorporation, not off a form. Registered name on the certificate is **ANTHIFEL LTD**, matching the text |
| ~~`[REGISTERED ADDRESS]`~~ | Legal | **Filled 20 August 2026** — `Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom`. Taken from the incorporation form, not yet from the register. **Verify against the Companies House record the day the number issues**, then this row closes for good |
| `[PRIVACY EMAIL]` | Developer — recommend `privacy@anthifel.com` | Before go-live. It must be a real monitored mailbox, not an alias nobody reads |
| `[ICO REGISTRATION NUMBER]` | Legal | After ICO registration. If the number is not yet issued at go-live, **delete the sentence** — do not publish a blank or a placeholder |
| ~~`[COMPANY NAME]`~~ | Legal | **Closed 20 August 2026 — `Anthifel Ltd`.** Registered in that form by the CEO, confirmed by him the same day. The text below already reads `Anthifel Ltd` throughout, so **no wording changes**. One check remains and it rides along with the company number: read the registered name off the certificate of incorporation and confirm the spelling is identical. `LTD` and `LIMITED` are equally valid in law and neither is stronger — what matters is that every document reproduces the one on the register, exactly |
| Processor list | **Developer** | **Supplied 12 Aug 2026, GA4 added 16 Aug** — filled into Part B. Closed |

## Processor list — eight processors, closed 19 August 2026

Supplied by Developer from the code rather than from memory, and filled into Part B. Developer's own note records that a 10 August version was wrong within two days, and that the list now lives inside `legal.py` so the page and the list cannot drift apart. That is the right fix and it is why this list can be trusted in a way the previous one could not.

**The GA4 open point is closed.** The list was written on 12 August; GA4 was installed on the evening of 15 August. The three days are the entire discrepancy. The eighth row is now in the table and in `legal.py`, and `check-legal.js` searches each processor **by name** rather than counting them — which is what stops the next gap from being invisible.

**One item to verify before publication, and it is not Developer's error.** Developer's own note describes GA4 as truncating the IP address before Google stores it. That is an accurate description of the *previous* generation of Google Analytics; GA4's documented behaviour differs, and Legal has not verified Google's current position. **The published text therefore says only that GA4 receives your IP address** — which is true under either description and cannot become false. Do not add a claim about what Google does with it afterwards until someone has read Google's current documentation. Asserting a third party's internal behaviour in our own notice is precisely the error that produced the assessment sentence we had to correct on 12 August.

**Three US companies: Squarespace, Resend and Google** — Google now on two counts, Workspace and Analytics, under the same corporate entity and therefore the same certification. Transfer position in Part B. Resend is certified under the UK Extension to the EU-US Data Privacy Framework (verified); Squarespace and Google are to be confirmed the same way under LGL-056, and any provider that is not certified needs a separate transfer agreement before data reaches it.

## Go-live gate

**Not before 20 August 2026.** The notice names a controller, and Anthifel Ltd does not exist until incorporation. This is the same date that governs the signup form.

## Still owed, separately from this

**Terms of Service** — not covered here. Different document. Website Terms of Use and the Cookie Policy are in `Anthifel_Legal_SiteTerms.md`; the client engagement terms are still to be drafted and sit in the contract inventory at `Anthifel_Legal.md` §3.

**Cookie banner** — built, and the mechanism is right: nothing loads before an answer. **The layout is not right and Legal has rejected it** — a framed "accept" beside a plain-text "reject" is the pattern ICO guidance names. Correction and reasoning: LGL-057. The notice below may publish before the banner is corrected only in the sense that the two are separate files; in practice the site cannot go live with a banner Legal has recorded as non-compliant.

## Version control

If any wording in Part B changes, the identifier changes with it — `privacy-v2`, and so on. Consent records point at the version the person actually saw, so old identifiers must keep resolving to the old text. Keep superseded versions; do not overwrite them.

---
---

# PART B — PUBLISHABLE TEXT

# ENGLISH — GOVERNING VERSION

## Privacy Policy

**Last updated:** [GO-LIVE DATE]
**Version:** privacy-v3

### Who we are

Anthifel Ltd is a company registered in England and Wales, company number 17411895, registered office Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom. We are the controller of the personal data described in this policy.

For anything relating to your personal data, write to **[PRIVACY EMAIL]**.

We are registered with the Information Commissioner's Office under registration number [ICO REGISTRATION NUMBER].

### What this policy covers

This policy covers personal data we collect through our website and in the course of providing our consultancy services. It does not cover other companies' websites we link to.

### What we collect, why, and on what basis

| What we collect | Why | Legal basis | How long we keep it |
|---|---|---|---|
| Name, email address, company, role — when you contact us or request the assessment result | To reply to you and send what you asked for | Our legitimate interest in responding to enquiries; and taking steps at your request before entering a contract | 24 months from our last contact with you |
| Your email address, for our newsletter and updates | To send you content and updates about our work | Your consent, given separately. You can withdraw it at any time | Until you unsubscribe, or after 24 months of no engagement, whichever comes first |
| Information you give us during an engagement — including material about your organisation and its people | To deliver the service you have engaged us for | Performance of our contract with you; and our legitimate interest in delivering the engagement | For the period set out in the engagement contract |
| Technical information about your visit — IP address, browser, pages viewed | To keep the site working and understand how it is used | Your consent for anything beyond what is strictly necessary | Set out in our cookie information below |

**The AI Readiness Assessment.** We do not store your individual answers — ever. If you ask us to send you the result, we store your email address, your consent record, and the overall result and band, so that we can send it and show what you agreed to.

**We do not make automated decisions about you** that produce legal or similarly significant effects, and we do not profile you.

**We do not sell your personal data.** We do not share it with anyone for their own marketing.

### Where we get your data from

From you. You give it to us when you contact us, ask for something, or work with us.

Where we ever hold information about you that did not come from you directly, we will tell you at the first point we contact you — what we hold, where it came from, and how to object.

### Who we share it with

We use service providers who process personal data on our behalf, under contract, and only on our instructions:

| Provider | What it does | Personal data it receives | Where it is processed |
|---|---|---|---|
| DigitalOcean App Platform | Hosts this website | IP address and browser information in server access logs | United Kingdom — London |
| Squarespace Domains | Registers `anthifel.com` | Registrant contact details. WHOIS privacy is on, so these are not public | United States |
| Resend | Sends every email we send you — sign-in codes, assessment results, and our own copy | Your email address; in a result email, also your result, band and five dimension scores | US company; our sending domain is configured in the Ireland region |
| Google — Apps Script and Sheets | Receives the assessment form and holds the record behind it | Your email address, your consent record, and the result and band of a completed assessment. **Never your individual answers** | Google. Our subscription tier does not offer a data region setting |
| Google — Workspace | Our own mailboxes, including `privacy@` | Anything you write to us | As above |
| Google — Calendar appointment scheduling | The booking window behind every meeting button | From the moment you open it: IP address, browser information and Google cookies; then whatever you enter into Google's own form | Google. No region selection offered |
| Google Analytics 4 | Counts visits and tells us which pages are read. **It is loaded only after you agree. If you decline, it is never loaded at all** | Your IP address, browser and device information, the pages you open, and a random identifier stored in a cookie on your device. **Never your name or your email address** | Google. Collected on servers in the region nearest you, **processed in the United States** |
| Supabase | Our internal panel's database. **No visitor data reaches it** | Staff account email addresses only | United Kingdom — London |

We also share personal data where we are required to by law, or with our professional advisers where necessary.

### Sending data outside the UK

Three of the providers above are United States companies: Squarespace, Resend and Google. Google appears twice — our own mailboxes and forms, and analytics — and analytics data is processed in the United States.

For those transfers we rely on the **UK Extension to the EU-US Data Privacy Framework**, under which certified US organisations are treated as providing an adequate level of protection. Where a provider is not certified under it, we put a separate transfer agreement in place before any personal data is sent.

**Analytics is the one transfer you can switch off.** If you decline analytics, no data about your visit is sent to Google at all — the transfer does not happen rather than happening under a mechanism.

**We do not always control which country a provider processes data in.** Our Google Workspace subscription tier does not offer a data region setting, so we cannot promise that data stays in a particular place. What the transfer mechanism protects is the level of protection your data receives, not its location — that protection travels with the data wherever the provider processes it.

You can ask us which mechanism applies to a particular provider and we will tell you.

### Your rights

You have the right to:

- **ask for a copy** of the personal data we hold about you
- **have it corrected** if it is wrong
- **have it deleted** in certain circumstances
- **restrict how we use it** in certain circumstances
- **receive it in a portable format**, where we rely on your consent or on a contract
- **object to our use of it** where we rely on legitimate interests — including, at any time and for any reason, to our use of it for direct marketing
- **withdraw your consent** at any time, where we rely on consent. Withdrawing it does not affect anything we did before you withdrew it

To exercise any of these, write to **[PRIVACY EMAIL]**. We will respond within one month. There is no charge.

**Unsubscribing** is always available from a link in every marketing email, and we do not ask you for a reason.

### Cookies and analytics

We use cookies that are strictly necessary for the site to function, including the record of the cookie choice you make. These do not need your consent — without the record of your answer we would have to ask you again on every visit.

We ask for your consent before setting any other cookie, including analytics. **Until you answer, nothing analytics-related is loaded at all** — no request is sent to Google and nothing is written to your device. If you decline, the site works normally, we remember that you declined, we do not ask again, and any older analytics cookies are removed. You simply are not measured.

Your choice lasts **six months**, after which we ask again. An expired answer is treated as no answer, not as a yes. You can change your mind at any time from the link in our site footer — withdrawing consent is exactly as easy as giving it.

The full list of what we set, and how long each lasts, is in our Cookie Policy.

### Complaints

If you are unhappy with how we have handled your personal data, please tell us first at [PRIVACY EMAIL] — we would rather fix it.

You also have the right to complain to the Information Commissioner's Office, the UK's data protection regulator, at **ico.org.uk**, without contacting us first.

### Changes to this policy

If we change this policy we will publish the new version here with a new version number and date. Where a change materially affects how we use data you have already given us, we will tell you directly.

---
---

# TÜRKÇE — ÇEVİRİ

> **Not:** Bu metin İngilizce aslın çevirisidir ve aynı zamanda KVKK kapsamında aydınlatma metni işlevi görür. **Uyuşmazlık hâlinde İngilizce metin geçerlidir.**

## Gizlilik Politikası

**Son güncelleme:** [YAYIN TARİHİ]
**Sürüm:** privacy-v3

### Biz kimiz

Anthifel Ltd, İngiltere ve Galler'de kayıtlı bir şirkettir. Şirket numarası 17411895, kayıtlı adresi Unit 501 Leroy House, 434-436 Essex Road, London N1 3FY, United Kingdom. Bu politikada anlatılan kişisel verilerin **veri sorumlusu** biziz.

Kişisel verilerinizle ilgili her konu için: **[GİZLİLİK E-POSTASI]**

Bilgi Komiserliği Ofisi'ne (ICO) [ICO KAYIT NUMARASI] numarasıyla kayıtlıyız.

### Bu politika neyi kapsar

Web sitemiz üzerinden ve danışmanlık hizmetlerimizi verirken topladığımız kişisel verileri kapsar. Bağlantı verdiğimiz başka şirketlerin sitelerini kapsamaz.

### Neyi, neden, hangi dayanakla topluyoruz

| Ne topluyoruz | Neden | Hukuki dayanak | Ne kadar saklıyoruz |
|---|---|---|---|
| Ad, e-posta, şirket, unvan — bize yazdığınızda veya değerlendirme sonucunu istediğinizde | Size cevap vermek ve istediğiniz şeyi göndermek | Gelen taleplere cevap vermekteki meşru menfaatimiz; ve sözleşme öncesi sizin talebinizle atılan adım | Son temasımızdan itibaren 24 ay |
| E-posta adresiniz — bülten ve güncellemeler için | Size işimize dair içerik ve güncelleme göndermek | **Ayrıca verdiğiniz açık rızanız.** Dilediğiniz zaman geri alabilirsiniz | Abonelikten çıkana kadar, ya da 24 ay hiç etkileşim olmazsa — hangisi önceyse |
| Bir proje sırasında bize verdiğiniz bilgiler — kurumunuza ve çalışanlarınıza dair malzeme dahil | Bizden aldığınız hizmeti sunmak | Sizinle yaptığımız sözleşmenin ifası; ve projeyi yürütmekteki meşru menfaatimiz | Proje sözleşmesinde belirtilen süre |
| Ziyaretinize dair teknik bilgi — IP adresi, tarayıcı, görüntülenen sayfalar | Sitenin çalışmasını sürdürmek ve nasıl kullanıldığını anlamak | Kesinlikle gerekli olanın ötesindeki her şey için rızanız | Aşağıdaki çerez bölümünde |

**AI Readiness Assessment.** Tek tek cevaplarınızı **hiçbir zaman** saklamıyoruz. Sonucu size göndermemizi isterseniz e-posta adresinizi, rıza kaydınızı ve genel sonuç ile bandı saklarız — sonucu gönderebilmek ve neye onay verdiğinizi gösterebilmek için.

**Hakkınızda otomatik karar almıyoruz** ve profilleme yapmıyoruz.

**Kişisel verinizi satmıyoruz.** Kimseyle kendi pazarlaması için paylaşmıyoruz.

### Verinizi nereden alıyoruz

Sizden. Bize yazdığınızda, bir şey istediğinizde ya da bizimle çalıştığınızda siz veriyorsunuz.

Hakkınızda doğrudan sizden gelmeyen bir bilgiyi elimizde tuttuğumuz durumlarda, sizinle kurduğumuz **ilk temasta** size söyleriz: neyi tuttuğumuzu, nereden geldiğini ve nasıl itiraz edebileceğinizi.

### Kimlerle paylaşıyoruz

Bizim adımıza, sözleşmeye bağlı olarak ve yalnızca talimatlarımızla kişisel veri işleyen hizmet sağlayıcılar kullanıyoruz:

| Sağlayıcı | Ne yapar | Hangi kişisel veri ulaşır | Nerede işlenir |
|---|---|---|---|
| DigitalOcean App Platform | Bu siteyi barındırır | Sunucu erişim kayıtlarında IP adresi ve tarayıcı bilgisi | Birleşik Krallık — Londra |
| Squarespace Domains | `anthifel.com` alan adını tescil eder | Tescil sahibi iletişim bilgileri. WHOIS gizliliği açık, yani herkese açık değil | Amerika Birleşik Devletleri |
| Resend | Size gönderdiğimiz her e-postayı gönderir — giriş kodu, test sonucu ve kendi kopyamız | E-posta adresiniz; sonuç e-postasında ayrıca sonucunuz, bandınız ve beş boyut puanınız | ABD şirketi; gönderim alan adımız İrlanda bölgesinde tanımlı |
| Google — Apps Script ve E-Tablolar | Test formunu alır ve arkasındaki kaydı tutar | E-posta adresiniz, rıza kaydınız, tamamlanmış bir testin sonucu ve bandı. **Tek tek cevaplarınız asla** | Google. Aboneliğimiz veri bölgesi ayarı sunmuyor |
| Google — Workspace | Kendi posta kutularımız, `privacy@` dahil | Bize yazdığınız her şey | Yukarıdaki gibi |
| Google — Takvim randevu takvimi | Her görüşme butonunun arkasındaki randevu penceresi | Pencereyi açtığınız anda IP adresi, tarayıcı bilgisi ve Google çerezleri; sonrasında Google'ın kendi formuna girdikleriniz | Google. Bölge seçimi sunulmuyor |
| Google Analytics 4 | Ziyaret sayısını sayar ve hangi sayfaların okunduğunu söyler. **Yalnızca siz kabul ettikten sonra yüklenir; reddederseniz hiç yüklenmez** | IP adresiniz, tarayıcı ve cihaz bilgisi, açtığınız sayfalar ve cihazınızdaki bir çerezde duran rastgele bir tanımlayıcı. **Adınız ve e-posta adresiniz asla** | Google. Veri size en yakın bölgedeki sunucularda toplanır, **ABD'de işlenir** |
| Supabase | İç panelimizin veritabanı. **Ziyaretçi verisi buraya ulaşmaz** | Yalnızca çalışan hesaplarının e-posta adresleri | Birleşik Krallık — Londra |

Ayrıca hukuken zorunlu olduğumuz hâllerde ve gerektiğinde profesyonel danışmanlarımızla paylaşırız.

### Verinin Birleşik Krallık dışına gönderilmesi

Yukarıdaki sağlayıcılardan üçü Amerika Birleşik Devletleri şirketidir: Squarespace, Resend ve Google. Google listede iki kez geçiyor — kendi posta kutularımız ve formlarımız, bir de analitik — ve **analitik verisi ABD'de işleniyor.**

Bu aktarımlarda **EU-US Data Privacy Framework'ün Birleşik Krallık Uzantısına** dayanıyoruz; bu çerçeve altında sertifikalı ABD kuruluşları yeterli koruma sağlıyor sayılır. Bir sağlayıcı bu çerçeve altında sertifikalı değilse, hiçbir kişisel veri gönderilmeden önce ayrı bir aktarım sözleşmesi yaparız.

**Kapatabileceğiniz tek aktarım analitiktir.** Analitiği reddederseniz ziyaretinize dair Google'a hiçbir veri gitmez — aktarım bir mekanizmaya dayanarak yapılmaz, **hiç yapılmaz.**

**Bir sağlayıcının veriyi hangi ülkede işlediğini her zaman biz belirlemiyoruz.** Google Workspace aboneliğimiz veri bölgesi ayarı sunmuyor; bu yüzden verinin belirli bir yerde kaldığını taahhüt edemeyiz. Aktarım mekanizmasının koruduğu şey verinin **bulunduğu yer değil, gördüğü korumadır** — o koruma, sağlayıcı veriyi nerede işlerse işlesin veriyle birlikte gider.

Belirli bir sağlayıcı için hangi mekanizmanın geçerli olduğunu bize sorabilirsiniz, söyleriz.

### Haklarınız

Şunları yapma hakkınız var:

- Hakkınızda tuttuğumuz kişisel verinin **bir kopyasını istemek**
- Yanlışsa **düzeltilmesini istemek**
- Belirli hâllerde **silinmesini istemek**
- Belirli hâllerde **kullanımını kısıtlatmak**
- Rızaya veya sözleşmeye dayandığımız hâllerde veriyi **taşınabilir bir biçimde almak**
- Meşru menfaate dayandığımız hâllerde **kullanımına itiraz etmek** — doğrudan pazarlama için kullanımımıza **her zaman ve gerekçesiz** itiraz edebilirsiniz
- Rızaya dayandığımız hâllerde **rızanızı geri almak.** Geri almanız, öncesinde yaptıklarımızı etkilemez

Bunlardan birini kullanmak için **[GİZLİLİK E-POSTASI]** adresine yazın. Bir ay içinde cevap veririz. Ücret alınmaz.

**Abonelikten çıkmak** her pazarlama e-postasındaki bağlantıdan her zaman mümkündür ve **sebep sormayız.**

### Çerezler ve analitik

Sitenin çalışması için kesinlikle gerekli çerezleri kullanıyoruz; verdiğiniz çerez kararının kaydı da bunlara dahildir. Bunlar rızanızı gerektirmez — cevabınızın kaydı olmasa her ziyarette size aynı soruyu yeniden sormak zorunda kalırdık.

Analitik dahil diğer her çerez için **önceden rızanızı isteriz.** Siz cevap verene kadar **analitikle ilgili hiçbir şey yüklenmez** — Google'a tek bir istek gitmez, cihazınıza hiçbir şey yazılmaz. Reddederseniz site normal çalışır, reddettiğinizi hatırlarız, size tekrar sormayız ve varsa eski analitik çerezleri silinir. Sadece ölçülmezsiniz.

Tercihiniz **altı ay** geçerlidir, sonra yeniden sorarız. Süresi geçmiş bir cevap "evet" değil, "cevapsız" sayılır. Fikrinizi site altbilgisindeki bağlantıdan istediğiniz zaman değiştirebilirsiniz — **rızayı geri almak, vermek kadar kolaydır.**

Neyi yerleştirdiğimizin ve her birinin ne kadar sürdüğünün tam listesi Çerez Politikamızdadır.

### Şikâyet

Kişisel verinizi ele alışımızdan memnun değilseniz önce bize söyleyin: [GİZLİLİK E-POSTASI]. Düzeltmeyi tercih ederiz.

Bize başvurmadan da, Birleşik Krallık veri koruma düzenleyicisi olan Bilgi Komiserliği Ofisi'ne **ico.org.uk** üzerinden şikâyet etme hakkınız var.

### Bu politikadaki değişiklikler

Politikayı değiştirirsek yeni sürümü burada, yeni bir sürüm numarası ve tarihiyle yayımlarız. Bir değişiklik, bize daha önce verdiğiniz veriyi kullanma şeklimizi esaslı biçimde etkiliyorsa size doğrudan bildiririz.
