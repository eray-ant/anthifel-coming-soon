/**
 * mock-supabase.js — a Supabase project, in memory, for the test suites.
 *
 * The panel's door and its store are now HTTP calls to a real service. Testing
 * them against the real project is the wrong trade twice over: the suites would
 * need a live account and a network, and they would write into the same tables
 * the company actually uses. So the tables live here instead, and every suite
 * that opens the dashboard installs them.
 *
 * What this does test, and it is the part that breaks: the request shapes, the
 * token refresh path, the mapping between the browser's row and the table's
 * row, and every branch that decides whether something reached the server. What
 * it cannot test is whether the real project's row level security is set up
 * correctly — that is a property of the project, not of this code, and it is
 * checked by hand against the live URL.
 */
const EMAIL = 'eray@anthifel.com';
const PASSWORD = 'test-parola';

function install(page, opts = {}) {
  const state = { kv: Object.assign({}, opts.kv), ledger: (opts.ledger || []).slice(), calls: [] };
  let issued = 0;

  const json = (route, status, body) =>
    route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });

  page.route('**/auth/v1/**', async route => {
    const req = route.request();
    const url = req.url();
    const body = JSON.parse(req.postData() || '{}');
    state.calls.push('auth:' + (url.includes('refresh_token') ? 'refresh' : 'password'));

    if (url.includes('grant_type=refresh_token')) {
      if (!body.refresh_token) return json(route, 400, { error_description: 'no refresh token' });
      return json(route, 200, {
        access_token: 'access-' + (++issued), refresh_token: 'refresh-token',
        expires_in: 3600, user: { email: EMAIL },
      });
    }
    if (body.email === EMAIL && body.password === PASSWORD) {
      return json(route, 200, {
        access_token: 'access-' + (++issued), refresh_token: 'refresh-token',
        expires_in: 3600, user: { email: EMAIL },
      });
    }
    // Supabase answers the same way for a wrong password and an account that
    // does not exist. The panel has to cope with that, so the mock keeps it.
    return json(route, 400, { error_description: 'Invalid login credentials' });
  });

  page.route('**/rest/v1/**', async route => {
    const req = route.request();
    const url = new URL(req.url());
    const path = url.pathname.replace('/rest/v1/', '');
    const method = req.method();
    state.calls.push(method + ':' + path);

    // Nothing is served without a bearer token, which is the whole point of
    // the arrangement being tested.
    if (!(req.headers()['authorization'] || '').startsWith('Bearer ')) {
      return json(route, 401, { message: 'no bearer' });
    }

    if (path === 'dash_state') {
      if (method === 'GET') {
        const m = /key=eq\.([^&]+)/.exec(url.search);
        const k = m ? decodeURIComponent(m[1]) : null;
        return json(route, 200, k && k in state.kv ? [{ value: state.kv[k] }] : []);
      }
      if (method === 'POST') {
        const b = JSON.parse(req.postData() || '{}');
        state.kv[b.key] = b.value;
        return route.fulfill({ status: 204, body: '' });
      }
    }
    if (path === 'ledger') {
      if (method === 'GET') {
        return json(route, 200, state.ledger.slice()
          .sort((a, b) => String(b.entry_date).localeCompare(String(a.entry_date))));
      }
      if (method === 'POST') {
        const b = JSON.parse(req.postData() || '{}');
        const row = Object.assign({ id: 'row-' + (state.ledger.length + 1) }, b);
        state.ledger.push(row);
        return json(route, 201, [row]);
      }
      if (method === 'DELETE') {
        const m = /id=eq\.([^&]+)/.exec(url.search);
        const id = m ? decodeURIComponent(m[1]) : null;
        state.ledger = state.ledger.filter(r => r.id !== id);
        return route.fulfill({ status: 204, body: '' });
      }
    }
    return json(route, 404, { message: 'mock: ' + method + ' ' + path });
  });

  return state;
}

/** Open the door the way a person does. */
async function signIn(page, { email = EMAIL, password = PASSWORD } = {}) {
  await page.fill('#em', email);
  await page.fill('#pw2', password);
  await page.click('#gateForm button[type=submit]');
}

module.exports = { install, signIn, EMAIL, PASSWORD };
