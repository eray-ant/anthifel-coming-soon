/* The cookie question, and the only thing on this site that loads Google.
   Markup, stylesheet and behaviour travel together, like the reading list and
   the privacy notice.

   The rule the whole file exists to keep: nothing Google-owned is fetched, and
   no cookie is set, until somebody has said yes. Not "loaded with consent mode
   set to denied" — not loaded. A tag that is on the page in a denied state is
   still a request to Google carrying an IP address, and explaining that to a
   visitor who declined is not a conversation worth having.

   The answer is kept in localStorage rather than a cookie, because asking for
   permission to set a cookie by setting a cookie is the kind of thing that
   makes people distrust the rest of the page. It is stored either way: a no is
   a decision and it deserves to be remembered as much as a yes. */
(function(){
'use strict';
var KEY = 'anthifel_consent';
var MEASUREMENT = '__GA_ID__';          // empty in preview; nothing loads there
var SIX_MONTHS = 1000 * 60 * 60 * 24 * 182;

var bar = document.getElementById('cbar');
if(!bar) return;

function stored(){
  try{
    var raw = localStorage.getItem(KEY);
    if(!raw) return null;
    var v = JSON.parse(raw);
    /* An answer expires. Six months on, the question is asked again, because a
       decision made about a site you visited once in February is not consent in
       August. An expired answer is treated as no answer, not as a no. */
    if(!v || !v.at || (Date.now() - v.at) > SIX_MONTHS) return null;
    return v.ok === true ? 'yes' : 'no';
  }catch(e){ return null; }
}

function remember(ok){
  try{ localStorage.setItem(KEY, JSON.stringify({ ok: !!ok, at: Date.now() })); }catch(e){}
}

var loaded = false;
function loadGA(){
  if(loaded || !MEASUREMENT || MEASUREMENT.charAt(0) === '_') return;
  loaded = true;
  window.dataLayer = window.dataLayer || [];
  window.gtag = function(){ window.dataLayer.push(arguments); };
  gtag('js', new Date());
  /* IP anonymisation is Google's default in GA4 and stating it here changes
     nothing technically. It is written down because the privacy notice says we
     do it, and a claim in a notice should be findable in the code. */
  gtag('config', MEASUREMENT, { anonymize_ip: true });
  var s = document.createElement('script');
  s.async = true;
  s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(MEASUREMENT);
  document.head.appendChild(s);
}

/* Withdrawing has to actually withdraw. GA4's cookies are set on this host, so
   they can be expired from here; what is already at Google is a deletion
   request, and the notice says where to send one. */
function dropCookies(){
  var names = document.cookie.split(';').map(function(c){ return c.split('=')[0].trim(); })
    .filter(function(n){ return n.indexOf('_ga') === 0; });
  var host = location.hostname, bits = host.split('.');
  names.forEach(function(n){
    for(var i = 0; i < bits.length - 1; i++){
      var d = bits.slice(i).join('.');
      document.cookie = n + '=; Max-Age=0; path=/; domain=' + d;
      document.cookie = n + '=; Max-Age=0; path=/; domain=.' + d;
    }
    document.cookie = n + '=; Max-Age=0; path=/';
  });
}

function show(){ bar.hidden = false; }
function hide(){ bar.hidden = true; }

function answer(ok){
  remember(ok);
  hide();
  if(ok) loadGA(); else dropCookies();
}

document.getElementById('cYes').addEventListener('click', function(){ answer(true); });
document.getElementById('cNo').addEventListener('click', function(){ answer(false); });

/* The footer's cookie link reopens the question rather than only explaining it.
   Consent has to be as easy to take back as it was to give, and a policy page
   with no button on it is not that. The link still works as a link: this only
   adds a way back beside it. */
(function(){
  /* A mark, not a second worded link. "Cookies · Cookie choice" side by side
     read as two entries for one subject; this is one entry with a control
     against it. It carries its name in aria-label and in the tooltip, and no
     data-en/data-tr: applyLang() writes textContent into anything carrying
     those, which would replace the drawing with the word. */
  var ICON = '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false" ' +
    'fill="none" stroke="currentColor" stroke-width="1.3">' +
    '<circle cx="8" cy="8" r="6.4"/><circle cx="6" cy="6" r=".9" fill="currentColor" stroke="none"/>' +
    '<circle cx="10.4" cy="7.4" r=".9" fill="currentColor" stroke="none"/>' +
    '<circle cx="7.2" cy="10.6" r=".9" fill="currentColor" stroke="none"/></svg>';
  var made = [];
  var links = document.querySelectorAll('.ftr a[href$="cookies.html"]');
  for(var i = 0; i < links.length; i++){
    var a = links[i];
    var again = document.createElement('button');
    again.type = 'button';
    again.className = 'cbar-again';
    again.innerHTML = ICON;
    again.addEventListener('click', function(){
      try{ localStorage.removeItem(KEY); }catch(e){}
      show();
    });
    a.parentNode.insertBefore(again, a.nextSibling);
    made.push(again);
  }
  if(!made.length) return;
  /* Four shells apply the language four different ways and only two of them
     fire an event, so this watches <html lang> as well — the same reason the
     footer's own link-swapper does. */
  function name(){
    var label = document.documentElement.lang === 'tr' ? 'Çerez tercihi' : 'Cookie choice';
    for(var j = 0; j < made.length; j++){
      made[j].setAttribute('aria-label', label);
      made[j].setAttribute('title', label);
    }
  }
  name();
  document.addEventListener('langchange', name);
  try{
    new MutationObserver(name).observe(document.documentElement,
      {attributes:true, attributeFilter:['lang']});
  }catch(e){}
})();

var was = stored();
if(was === 'yes') loadGA();
else if(was === null) show();
})();
