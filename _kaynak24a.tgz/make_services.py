#!/usr/bin/env python3
"""
make_services.py — writes the three service pages from Business's BUS-033 copy.

Why a generator rather than three hand-written files: the copy is Business's and
arrives as prose in `Anthifel_Website_Service_Pages.md`. Every one of these pages
is the same shape as `svc_audit.html`, and the only way three pages stay the same
shape as each other is if one thing builds all three. Hand-editing three files is
how the fourth section quietly grows a different heading level.

The words are not Developer's. If a line reads wrong it goes back to Business —
`Anthifel_Website_Service_Pages.md` §4. What this file decides is markup only.

One standing exception, CEO 13 August: the founder is never named on a service
page. Business's copy said "Eray" in four places across the Advisory and the
Retainer; all four read Anthifel now. A service belongs to the firm, not to one
person, and the About page is the single place where the name belongs.

Run it, then run build.py. It writes svc_sprint.html, svc_retainer.html and
svc_advisory.html beside the Audit page and nothing else.
"""

import html
import os

ROOT = os.path.dirname(os.path.abspath(__file__))

MEET = ('https://calendar.google.com/appointments/schedules/'
        'AcZssZ0oNnk169UH0Bm1TaPvCd95JJe49zVy9szUUB2pzSe_SRZATmDOkQ4PHkdXMAhMcJokT0Sx-46l')


def attr(s):
    """A fragment of HTML carried inside an attribute, the way svc_audit.html does."""
    return html.escape(s, quote=True)


def line(tag, en, tr, cls=None):
    c = ' class="%s"' % cls if cls else ''
    return '<%s%s data-en="%s" data-tr="%s">%s</%s>' % (
        tag, c, attr(en), attr(tr), html.escape(en), tag)


def prose(en_paras, tr_paras):
    """A body of paragraphs. Bold runs are written as <b> in the source strings."""
    en = ''.join('<p>%s</p>' % p for p in en_paras)
    tr = ''.join('<p>%s</p>' % p for p in tr_paras)
    return '          <div class="svc-bd" data-en="%s" data-tr="%s">%s</div>' % (
        attr(en), attr(tr), en)


def bullets(pairs):
    items = '\n'.join(
        '              <li data-en="%s" data-tr="%s">%s</li>' % (attr(en), attr(tr), html.escape(en))
        for en, tr in pairs)
    return '          <div class="svc-bd">\n            <ul>\n%s\n            </ul>\n          </div>' % items


def days(pairs):
    """The day-by-day list. Same <dl class="svc-days"> the Audit page uses."""
    rows = []
    for (en_t, tr_t), (en_d, tr_d) in pairs:
        rows.append('              <dt data-en="%s" data-tr="%s">%s</dt>' % (attr(en_t), attr(tr_t), html.escape(en_t)))
        rows.append('              <dd data-en="%s" data-tr="%s">%s</dd>' % (attr(en_d), attr(tr_d), html.escape(en_d)))
    return '\n'.join(rows)


def section(en_h, tr_h, body):
    return ('        <section class="svc-sec">\n'
            '          <h2 data-en="%s" data-tr="%s">%s</h2>\n'
            '%s\n'
            '        </section>' % (attr(en_h), attr(tr_h), html.escape(en_h), body))


FORM = '''
      <!-- §C.4. Four fields, no more: a quote is prepared when a company asks
           for one, and this button is the asking. No figure appears here —
           the price is in the quote, which goes by email. -->
      <section class="svc-form" id="teklif">
        <h2 data-en="Request a quote" data-tr="Teklif alın">Request a quote</h2>
        <p class="lede" data-en="We send the proposal in writing, with its scope, by email within one working day." data-tr="Teklifi kapsamıyla birlikte yazılı olarak, bir iş günü içinde e-posta ile gönderiyoruz.">We send the proposal in writing, with its scope, by email within one working day.</p>
        <form id="qf" class="frm" novalidate>
          <div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>

          <div class="fld" id="f-name">
            <label for="qname" data-en="Name" data-tr="Ad soyad">Name</label>
            <input type="text" id="qname" name="name" autocomplete="name" required>
          </div>
          <div class="fld" id="f-email">
            <label for="qemail" data-en="Email address" data-tr="E-posta adresi">Email address</label>
            <input type="email" id="qemail" name="email" autocomplete="email" inputmode="email" placeholder="name@company.com" required>
          </div>
          <div class="fld" id="f-company">
            <label for="qcompany" data-en="Company" data-tr="Şirket">Company</label>
            <input type="text" id="qcompany" name="company" autocomplete="organization" required>
          </div>
          <div class="fld" id="f-size">
            <label for="qsize" data-en="Number of employees" data-tr="Çalışan sayısı">Number of employees</label>
            <select id="qsize" name="size" required>
              <option value="" data-en="Choose" data-tr="Seçin">Choose</option>
              <option value="1-49">1-49</option>
              <option value="50-149">50-149</option>
              <option value="150-499">150-499</option>
              <option value="500+">500+</option>
            </select>
          </div>
          <div class="emsg" id="e-name"></div>
          <div class="emsg" id="e-email"></div>
          <div class="emsg" id="e-company"></div>
          <div class="emsg" id="e-size"></div>

          <div class="actions">
            <button type="submit" class="btn btn-p" id="qsend" data-en="Request a quote →" data-tr="Teklif alın →">Request a quote →</button>
            <a class="btn btn-s" href="__MEET__" target="_blank" rel="noopener" data-meet data-en="Book a 30-minute call" data-tr="30 dakikalık görüşme alın">Book a 30-minute call</a>
          </div>
          <p class="stamp" data-en="We use these four details to prepare the quote and to reply to you. Nothing else. Write to privacy@anthifel.com at any time and we will delete them." data-tr="Bu dört bilgiyi teklifi hazırlamak ve size dönmek için kullanırız. Başka hiçbir şey için değil. Dilediğiniz zaman privacy@anthifel.com adresine yazın, sileriz.">We use these four details to prepare the quote and to reply to you. Nothing else. Write to privacy@anthifel.com at any time and we will delete them.</p>
          <div class="devnote" id="qdev" hidden></div>
        </form>
      </section>

      <!-- One pair of buttons on the page, at the top. The foot used to repeat
           them; a visitor who has read the page scrolls back up or uses the
           form they are standing in front of, and the same two buttons twice
           read as a page that does not know what it wants. -->
      <div class="svc-foot">
        <a class="back" href="index.html" data-en="← Back to the site" data-tr="← Siteye dön">← Back to the site</a>
      </div>
'''.replace('__MEET__', MEET)


def page(head_comment, name, sub_en, sub_tr, lede_en, lede_tr, meta_en, meta_tr, sections):
    parts = [head_comment.rstrip(), '']
    parts.append('      <span class="eyebrow" data-en="Service" data-tr="Hizmet">Service</span>')
    parts.append('      <h1>%s</h1>' % name)
    parts.append('      <p class="svc-sub" data-en="%s" data-tr="%s">%s</p>'
                 % (attr(sub_en), attr(sub_tr), html.escape(sub_en)))
    parts.append('      <p class="lede" data-en="%s" data-tr="%s">%s</p>'
                 % (attr(lede_en), attr(lede_tr), html.escape(lede_en)))
    parts.append('      <p class="svc-meta" data-en="%s" data-tr="%s">%s</p>'
                 % (attr(meta_en), attr(meta_tr), html.escape(meta_en)))
    parts.append('')
    parts.append('      <div class="svc-cta">')
    parts.append('        <a class="btn btn-p" href="#teklif" data-en="Request a quote" data-tr="Teklif alın">Request a quote</a>')
    parts.append('        <a class="btn btn-s" href="%s" target="_blank" rel="noopener" data-meet data-en="Book a 30-minute call" data-tr="30 dakikalık görüşme alın">Book a 30-minute call</a>' % MEET)
    parts.append('      </div>')
    parts.append('')
    parts.append('      <div class="svc-secs">')
    parts.append('')
    for s in sections:
        parts.append(s)
        parts.append('')
    parts.append('      </div>')
    parts.append(FORM)
    return '\n'.join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# 1 · Discovery Sprint
# ─────────────────────────────────────────────────────────────────────────────

SPRINT_HEAD = '''<!-- Discovery Sprint — the page the result screen sends people to.
     Copy is Business's, from Anthifel_Website_Service_Pages.md §1, both blocks
     verbatim. Developer does not touch the words; if one looks wrong it goes
     back to Business. No figure appears anywhere on this page (K50): the
     durations are not prices, and the scope is named only as "scoped project",
     which is what §1 says. The per-tier day counts behind that scope are
     deliberately absent, and are not repeated here either: §4 says a single
     tier's number lives in the proposal and never on the site, and a comment
     that lists the numbers it is banning still puts them in the file.

     The service name carries no data-tr. It is fixed English on both pages
     under Business's K34, and the Turkish reading sits on the line below. -->'''

sprint = page(
    SPRINT_HEAD, 'Discovery Sprint',
    '"Where are we going?"', 'Keşif ve yol haritası programı · "Nereye gidiyoruz?"',
    'Days inside your business, and the rooms that matter. A roadmap with owners, costs and dates.',
    'İşinizin içinde günler ve odalar. Sahipleri, maliyetleri ve tarihleri olan bir yol haritası.',
    '7 to 12 working days · Scoped project', '7 ile 12 iş günü · Kapsama göre fiyatlanan proje',
    [
        section('Who it is for', 'Kimin için', prose(
            ['A company that has decided to take AI seriously, has a budget, and wants a plan it can act on. '
             'The mandate sits at board or CEO level. The question is not whether to start, but where and in what order.'],
            ["AI'ya ciddi girmeye karar vermiş, bütçesi olan, uygulanabilir plan isteyen şirket. "
             'Yönetim kurulu ya da CEO düzeyinde yetkisi ve desteği var. Sorusu "başlayalım mı" değil, "nereden ve hangi sırayla".'])),

        section('What we do', 'Ne yapılır', prose(
            ['<b>A close reading of the business model.</b> Where revenue comes from, which lines are profitable, '
             'and which only keep people busy.',
             '<b>Process mapping.</b> How work actually flows, not how the document says it flows.',
             '<b>Department interviews.</b> Three to eight rooms, depending on scope. This is where the value comes from. '
             'A roadmap cannot be written without entering the room.',
             '<b>Prioritisation.</b> Where AI creates value, and where it does not. The second answer is worth as much as the first.',
             '<b>ROI modelling.</b> What each step returns, over what period, on which assumptions. '
             'The assumptions are written down so you can argue with them.',
             '<b>A phased implementation plan</b> across six to twelve months, with owners and dates.'],
            ['<b>İş modelinin derinlemesine analizi.</b> Geliriniz nereden geliyor, hangi iş kârlı, hangisi yalnızca meşgul ediyor.',
             '<b>Süreç haritalama.</b> İşin gerçekte nasıl aktığı, dokümanda yazdığı gibi değil.',
             '<b>Departman görüşmeleri.</b> Kademenize göre üç ile sekiz oda. '
             "Sprint'in değeri buradan çıkar; bir yol haritası odaya girmeden yazılamaz.",
             '<b>Önceliklendirme.</b> Nerede AI değer yaratır ve nerede yaratmaz. İkincisini söylemek birincisi kadar işinize yarar.',
             '<b>ROI modelleme.</b> Hangi adım ne kazandırır, ne kadar sürede, hangi varsayımla. '
             'Varsayımlar açık yazılır ki tartışabilesiniz.',
             '<b>Fazlı uygulama planı.</b> Altı ile on iki ay, sahipleri ve tarihleriyle.'])),

        section('How it runs', 'Nasıl ilerler',
                '          <div class="svc-bd">\n'
                '            <dl class="svc-days">\n' + days([
                    (('Pre-work', 'Ön çalışma'), ('The pack is completed three working days before kick-off',
                                                  "Paket kick-off'tan üç iş günü önce doldurulur")),
                    (('Day 1', 'Gün 1'), ('Kick-off, scope and stakeholder list are settled',
                                          'Kick-off, kapsam ve paydaş listesi kesinleşir')),
                    (('Day 2-3', 'Gün 2-3'), ('Department deep dives', 'Departman derinlemesine görüşmeleri')),
                    (('Day 4', 'Gün 4'), ('Opportunity mapping', 'AI fırsat haritalama')),
                    (('Day 5', 'Gün 5'), ('Prioritisation and ROI modelling', 'Önceliklendirme ve ROI modelleme')),
                    (('Day 6', 'Gün 6'), ('Roadmap', 'Yol haritası oluşturma')),
                    (('Day 7', 'Gün 7'), ('Report and delivery', 'Rapor yazımı ve teslim')),
                    (('Presentation', 'Sunum'), ('Within two working days of delivery, 90 minutes',
                                                 'Teslimden sonraki iki iş günü içinde, 90 dakika')),
                ]) + '\n            </dl>\n' +
                '            <p class="svc-after" data-en="%s" data-tr="%s">%s</p>\n'
                '          </div>' % (
                    attr('This is the entry scope. In larger scopes the added days go to the rooms, not the report: '
                         'more departments, more interviews.'),
                    attr('Yukarıdaki giriş kademesidir. Daha büyük kapsamda eklenen günler rapora değil odaya gider: '
                         'daha çok departman, daha çok görüşme.'),
                    html.escape('This is the entry scope. In larger scopes the added days go to the rooms, not the report: '
                                'more departments, more interviews.'))),

        section('What you receive', 'Ne teslim edilir', bullets([
            ('A 20 to 30 page Transformation Roadmap', '20 ile 30 sayfalık Transformation Roadmap'),
            ('A prioritised use-case list, mapped by impact and effort',
             'Önceliklendirilmiş use-case listesi, etki ve çaba matrisiyle'),
            ('An ROI model with its assumptions stated', 'ROI modeli, varsayımları açık'),
            ('A phased six to twelve month programme', 'Altı ile on iki aylık fazlı uygulama programı'),
            ('A stakeholder map: who owns each phase', 'Paydaş haritası: her fazın sahibi kim'),
            ('A 90-minute presentation', '90 dakikalık sunum'),
        ])),

        section('What it does not cover', 'Neyi kapsamaz', prose(
            ['<b>It gives no readiness score.</b> The score is the work of the AI Readiness Audit.',
             '<b>It includes no implementation.</b> The plan is delivered; guiding the implementation is the work of '
             'the Transformation Retainer.',
             'No code, models, integrations or tool installation.',
             'No vendor contract negotiation.',
             '<b>Department interviews are not unlimited.</b> The number in your scope is the ceiling.'],
            ['<b>Hazırlık sonucu vermez.</b> Skor AI Readiness Audit\'in işidir.',
             '<b>Uygulama içermez.</b> Plan teslim edilir; uygulama rehberliği Transformation Retainer\'ın konusudur.',
             'Kod, model, entegrasyon, araç kurulumu yoktur.',
             'Tedarikçi sözleşmesi müzakeresi yoktur.',
             '<b>Sınırsız departman görüşmesi yoktur.</b> Kademedeki sayı üst sınırdır.'])),

        section('The pre-work pack', 'Ön çalışma paketi', prose(
            ['This is what makes the short timeline possible. It is completed three working days before kick-off and '
             'asks about your business model, constraints, mandate and systems. No calendar is opened until the pack '
             'is complete, so the data gathering that used to eat the first days is finished before we start.'],
            ["Kısa teslim süresinin şartı budur. Kick-off'tan üç iş günü önce doldurulur; içinde iş modeli, kısıtlar, "
             'mandanız ve sistem zemininiz sorulur. Paket dolmadan takvim açılmaz. Eskiden ilk günlere yayılan veri '
             "toplama işi böylece kick-off'tan önce biter."])),

        section('What comes next', 'Sonrası', prose(
            ['The Transformation Retainer. One rule applies: we do not propose a retainer without a discovery first. '
             'Selling implementation guidance without a roadmap is not honest.'],
            ['Transformation Retainer. Bir kural var: Discovery yapılmadan Retainer teklif edilmez. '
             'Yol haritası olmadan uygulama rehberliği satmak dürüst değildir.'])),
    ])


# ─────────────────────────────────────────────────────────────────────────────
# 2 · Transformation Retainer
# ─────────────────────────────────────────────────────────────────────────────

RETAINER_HEAD = '''<!-- Transformation Retainer — copy is Business's, from
     Anthifel_Website_Service_Pages.md §2, both blocks verbatim. Developer does
     not touch the words; if one looks wrong it goes back to Business.

     No figure appears anywhere on this page (K50), and §4 adds one more: no
     tier and no count. "The number running at once is capped" is the whole
     statement, and it is deliberately not a number.

     The service name carries no data-tr. It is fixed English on both pages
     under Business's K34, and the Turkish reading sits on the line below. -->'''

retainer = page(
    RETAINER_HEAD, 'Transformation Retainer',
    '"How do we get there?"', 'Sürekli dönüşüm rehberliği · "Nasıl gideceğiz?"',
    'The right people, hired and connected. A rhythm that holds.',
    'İşe alımlar yapılmış, roller birbirine bağlanmış. Tutan bir ritim.',
    'Monthly · Minimum 6 months', 'Aylık · Minimum 6 ay',
    [
        section('Who it is for', 'Kimin için', prose(
            ['A company with a roadmap in hand that wants guidance through the implementation. '
             'Either nobody inside owns AI, or someone does and is doing it alone.'],
            ['Yol haritası hazır, uygulamada rehberlik isteyen şirket. '
             "İçeride AI'ı sahiplenecek kimse yok, ya da var ama yalnız."])),

        section('What we do', 'Ne yapılır', prose(
            ['Anthifel does not write code. It organises the transformation.',
             '<b>Building the internal team.</b> Defining the right roles, running the hiring process, '
             'sitting in the interviews.',
             '<b>Connecting the external team.</b> Finding, assessing and engaging the agencies, freelance engineers '
             'and technology providers you need.',
             '<b>The management system.</b> Process ownership, KPI definitions, reporting rhythm.',
             '<b>Coordination.</b> Clearing blockages between departments. Transformation usually stalls between two '
             'departments, not inside the technology.'],
            ['Anthifel kod yazmaz. Dönüşümü organize eder.',
             '<b>İç ekip kurulumu.</b> Doğru rollerin tanımlanması, işe alım sürecinin yönetimi, mülakatlara katılım.',
             '<b>Dış ekip bağlanması.</b> Gereken ajans, freelance mühendis ve teknoloji sağlayıcılarının bulunması, '
             'değerlendirilmesi, işe bağlanması.',
             '<b>Yönetim sistemi.</b> Süreç sahipliği, KPI tanımları, raporlama ritmi.',
             '<b>Koordinasyon.</b> Departmanlar arası engellerin çözülmesi. '
             'Dönüşüm çoğunlukla teknolojide değil, iki departmanın arasında tıkanır.'])),

        section('Rhythm', 'Ritim',
                '          <div class="svc-bd">\n'
                '            <dl class="svc-days">\n' + days([
                    (('Weekly', 'Haftalık'), ('Progress, blockers, a coordination call',
                                              'İlerleme takibi, engel çözme, koordinasyon çağrısı')),
                    (('Monthly', 'Aylık'), ("Management report, KPI review, next month's plan",
                                            'Yönetim raporu, KPI değerlendirme, sonraki ay planı')),
                    (('Quarterly', 'Üç aylık'), ('Strategic review. Mandatory, never skipped',
                                                 'Stratejik gözden geçirme. Zorunlu, atlanmaz')),
                ]) + '\n            </dl>\n          </div>'),

        section('What you receive', 'Ne teslim edilir', bullets([
            ('A monthly progress report', 'Aylık ilerleme raporu'),
            ('The teams and systems that get built', 'Kurulan ekipler ve sistemler'),
            ('A KPI dashboard', 'KPI dashboard'),
            ('A quarterly business review', 'Quarterly business review'),
            ('A readiness re-measurement at month six and month twelve, compared against your entry score',
             'Altıncı ve on ikinci ayda Readiness yeniden ölçümü, giriş skorunuzla karşılaştırmalı'),
            ('Defined access', 'Tanımlı erişim'),
        ])),

        section('Access', 'Erişim', prose(
            ['Email is the primary channel. WhatsApp is for short coordination. Working days, 10:00 to 18:00, '
             'answered the same working day. Four hours a month outside the rhythm.',
             'There is no emergency channel, and that is deliberate. A promise of unlimited access holds for three '
             'months and fails in the fourth, and at that point the client reads it as the relationship breaking down. '
             'We would rather the promise be true from the start.'],
            ['E-posta birincil kanaldır. WhatsApp kısa koordinasyon içindir. İş günü 10:00 ile 18:00 arası, '
             'aynı iş günü içinde yanıt. Ritim dışı erişim ayda dört saat.',
             'Acil kanal yoktur ve bu bilinçlidir. Sınırsız erişim sözü ilk üç ay tutulur, dördüncü ayda tutulamaz '
             've o noktada dördüncü ayda sürdürülemez. Sınırı baştan söylemeyi tercih ediyoruz.'])),

        section('What it does not cover', 'Neyi kapsamaz', prose(
            ['No code, model training or integration work. The team that does it is found and managed.',
             'Salaries and agency fees for the people hired belong to the company, not to the retainer.',
             'Software licences and infrastructure costs belong to the company.',
             'This is not a full-time executive role. Anthifel does not take a CTO or Head of AI post.'],
            ['Kod yazımı, model eğitimi, entegrasyon yoktur. Bunları yapacak ekip bulunur ve yönetilir.',
             "İşe alınan ekiplerin maaşları ve ajans bedelleri şirkete aittir, retainer'a dahil değildir.",
             'Yazılım lisansları ve altyapı maliyeti şirkete aittir.',
             'Tam zamanlı yöneticilik değildir. Anthifel CTO ya da Head of AI görevi almaz.'])),

        section('Commercial terms', 'Ticari koşullar', prose(
            ['Minimum six month commitment.',
             'Three months written notice to cancel.',
             'A mutual review at month six, where the decision to continue is made. Its input is a re-measured score, '
             'not an impression.'],
            ['Minimum altı ay taahhüt.',
             'İptal için üç ay önceden yazılı bildirim.',
             'Altıncı ayda karşılıklı gözden geçirme; devam kararı orada verilir ve girdisi izlenim değil, '
             'yeniden ölçülmüş skordur.'])),

        section('Capacity', 'Kapasite', prose(
            ['The number of retainers running at once is capped. One person delivers them, and we do not hide that. '
             'When the calendar is full we say so: we cannot take this on now, we can from this date.'],
            ['Aynı anda yürütülen retainer sayısı sınırlıdır. Teslimi yapan tek kişidir ve bu saklanmaz. '
             'Takvim doluysa açıkça söylenir: bugün alamıyoruz, şu tarihte alabiliriz.'])),

        section('What comes next', 'Sonrası', prose(
            ['The Advisory Board Seat.'], ['Advisory Board Seat.'])),
    ])


# ─────────────────────────────────────────────────────────────────────────────
# 3 · Advisory Board Seat
# ─────────────────────────────────────────────────────────────────────────────

ADVISORY_HEAD = '''<!-- Advisory Board Seat — copy is Business's, from
     Anthifel_Website_Service_Pages.md §3, both blocks verbatim.

     Two instructions from §4 are carried in the markup rather than trusted to
     memory. No tier and no count: "not sold directly" is the whole statement.
     And the independence block is a plain svc-sec like every other, at the same
     size and weight — §4 says it is not to be made smaller, because it is the
     one sentence nobody else in this market says.

     The service name carries no data-tr. It is fixed English on both pages
     under Business's K34, and the Turkish reading sits on the line below. -->'''

advisory = page(
    ADVISORY_HEAD, 'Advisory Board Seat',
    '"Who is with us?"', 'Danışma kurulu koltuğu · "Yanımızda kim var?"',
    'A seat at your table. A few hours a month, and the phone when it matters.',
    'Masanızda bir sandalye. Ayda birkaç saat ve önemli anlarda telefon.',
    'Monthly · Minimum 12 months', 'Aylık · Minimum 12 ay',
    [
        section('Who it is for', 'Kimin için', prose(
            ['A company with an internal AI team in place, looking for senior strategic judgement. '
             'A scaleup or a corporate business unit.',
             'This seat is not sold directly. It is offered in two cases only: to a company that has completed a '
             'Transformation Retainer, or to one where we have seen a working internal AI team. The reason is simple. '
             'Advising a structure that has not been built is not advice, it is wishful thinking.'],
            ['İç AI ekibi kurulmuş, üst seviye stratejik akıl arayan şirket. Scaleup ya da kurumsal iş birimi.',
             "Bu koltuk doğrudan satılmaz. Yalnız iki durumda verilir: Transformation Retainer'ı tamamlamış şirkete, "
             'ya da içeride kurulmuş ve çalışan bir AI ekibi olduğu görülmüş şirkete. Sebebi basit: '
             'kurulmamış bir yapıya danışmanlık, danışmanlık değil temenni olur.'])),

        section('What we do', 'Ne yapılır', bullets([
            ('Sitting on your advisory board', "Advisory board'da oturmak"),
            ('A low-intensity monthly contribution', 'Aylık düşük yoğunluklu katkı'),
            # CEO, 13 August: the seat is Anthifel's, not one person's, and the
            # two languages did not even agree — English said the name, Turkish
            # said the title. Business's §3 is otherwise verbatim.
            ('Access to us on critical decisions', 'Kritik kararlarda bize erişim'),
            ('A quarterly strategic review', 'Üç aylık stratejik gözden geçirme'),
            ('Introductions across the ecosystem', 'Ekosistem tanıştırmaları'),
        ])),

        section('What you receive', 'Ne teslim edilir', bullets([
            ('A monthly advisory session', 'Aylık danışmanlık seansı'),
            ('Access on critical decisions', 'Kritik kararlarda erişim'),
            ('A quarterly strategic review', 'Üç aylık stratejik gözden geçirme'),
            ('Network access', 'Network erişimi'),
        ])),

        section('What it does not cover', 'Neyi kapsamaz', prose(
            ['No operational execution. Project management, team building and coordination are the work of the '
             'Transformation Retainer.',
             'This is not a statutory board directorship unless separately contracted.',
             'There is no weekly rhythm.',
             'This is not fundraising, round management or investor relations. Introductions are made; '
             'brokerage is not.'],
            ['Operasyonel yürütme yoktur. Proje yönetimi, ekip kurma ve koordinasyon '
             "Transformation Retainer'ın işidir.",
             'Yasal anlamda yönetim kurulu üyeliği değildir, ayrıca sözleşmeye bağlanmadığı sürece.',
             'Haftalık ritim yoktur.',
             'Yatırım bulma, sermaye turu yönetimi ve yatırımcı ilişkileri hizmeti değildir. '
             'Tanıştırma yapılır, aracılık yapılmaz.'])),

        section('Independence', 'Bağımsızlık', prose(
            ['In some arrangements this relationship includes equity. Where it does, Anthifel is not indifferent to '
             'your outcome, and rather than hide that we state it in writing.',
             'An arrangement without equity also exists, and the choice is yours.',
             'If Anthifel proposes another service while the seat is held, the nature of the relationship is stated '
             'on the first page of that proposal. No second seat is taken with a direct competitor of yours in the '
             'same period.'],
            ['Bu ilişki bazı durumlarda hisse içerir. İçerdiğinde Anthifel şirketin sonucuna kayıtsız değildir ve '
             'bunu saklamak yerine yazılı olarak beyan eder.',
             'Hisse içermeyen bir düzen de vardır ve tercih sizindir.',
             'Koltuk sürerken Anthifel size başka bir hizmet teklif ederse, teklifin ilk sayfasında ilişkinin '
             'niteliği açıkça yazılır. Aynı dönemde pazarınızdaki doğrudan rakibinize ikinci bir koltuk verilmez.'])),
    ])


for name, body in (('svc_sprint.html', sprint),
                   ('svc_retainer.html', retainer),
                   ('svc_advisory.html', advisory)):
    with open(os.path.join(ROOT, name), 'w', encoding='utf-8') as fh:
        fh.write(body.rstrip() + '\n')
    print('%-22s %6d bytes' % (name, len(body)))
