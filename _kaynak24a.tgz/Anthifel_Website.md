# Anthifel — Website

**Owner:** Developer
**Master file:** `Anthifel MD's/Anthifel_Website.md`
**Version:** 2.0 · **Date:** 4 August 2026

### Last change (4 August 2026, tenth entry) — K23, Dashboard.md folded in

- **`Anthifel_Dashboard.md` is gone.** What was still true moved here: the
  infrastructure table and the deployment traps into §8, the panel's storage and
  security notes into §21. What was not true was dropped rather than carried:
  the page-per-section structure, the iframe notes and the sidebar rules all
  described the old dashboard, which no longer exists.
- **A file-handling error is recorded here rather than quietly fixed.** The
  ninth entry was written on top of a stale copy of this file and overwrote the
  eighth. Both are restored below from the work itself. Lesson: re-stage before
  editing, every time, and check the version line before writing.
- Live: no change to the site.
- CEO decision needed: no.

### Previous change (4 August 2026, ninth entry) — K50 and the Business brief

- **The live page was carrying a withdrawn sentence.** `anthifel.com` is still
  the coming-soon page and it read "not with technology, but with the people
  behind it" — Brand Guidelines §8 rule 3. Replaced with the §8.3 sub-line,
  verbatim. The first sweep missed it because that page is the one page
  `build.py` does not produce; it now has its own guard, `check-comingsoon.js`.
- **Prices: swept again, none anywhere.** Clean since 3 August, in every
  currency and every format.
- **The assessment is a real test now.** Twelve questions, five dimensions, the
  methodology's weights and both ceilings. §22 has the detail.
- **Two brief items were not applied**, both on the CEO's instruction: the email
  gate stays in front of the test, and the independence statement stays off the
  page. Both go back to Business. §22.
- **The Audit is seven working days**, not two weeks, in Services and Approach.
- Live: **preview yes, root yes** once the commit lands.
- CEO decision needed: no.

### Previous change (4 August 2026, eighth entry) — one dashboard

- **The old panel at `/dashboard/` is gone.** Two panels were live at once, with
  two doors and two to-do lists. Every old page is now a redirect to the matching
  section of `/preview/dashboard/`, so links already given out still work.
- **Content OS moved into İçerik.** It was the last thing that lived only in the
  old panel. Calendar, board, content list, channel views, rules library,
  dependency warnings and the JSON working file all behave as before.
- **The hand-written İçerik reference panels were removed**, because the planner
  already carries the same rules, types and sources.
- **Old browser data is carried across once** on first visit: the to-do list and
  the ledger. The old keys are left untouched in case the conversion is wrong.
- **One build bug fixed**: the CSS scoper treated a comment in front of a rule as
  part of the selector and silently killed the rule. It had eaten the blog
  editor's column layout and the planner's custom properties.
- Live: **preview yes, root redirects.**
- CEO decision needed: no.

### Previous change (4 August 2026, seventh entry) — the dashboard

- **The dashboard is one document at `/preview/dashboard/`.** It used to be a
  set of separate pages, so clicking a section left the panel. The address no
  longer changes; the menu swaps panes and the hash only exists so a section can
  be linked to and reloaded. `/dashboard/crm/` and `/dashboard/blog/` redirect,
  so old links still work.
- **Every section is written.** CRM and Blog are the two applications; Genel
  Bakış, İçerik, Site, SEO, Analitik and Finans are the reference sections,
  built from the content of the old dashboard pages rather than invented. §21
  says what each one holds.
- **Nothing on the public site changed.** This entry touches the panel only.
- **`check-dash.js` replaces `check-crm.js`** and drives the whole panel:
  128 assertions, NO OVERFLOW ANYWHERE.
- Live: **preview yes, root no.**
- CEO decision needed: no. §11 items still stand.

### Previous change (3 August 2026, sixth entry) — K47 item 7

- **Brand Guidelines §8.7 applied to the Turkish page.** All of 7a, 7b, 7c, 7d
  and 7e are in. English copy untouched, as instructed, and a test now asserts
  that it stayed untouched.
- **Live in preview, all of it.** Nothing from item 7 is waiting on a deploy.
  The root is still coming-soon, so `anthifel.com/` is unaffected.
- **Two questions go back**, both listed in §19: the fifth footer blog title has
  no counterpart in the Blog Plan, and the Turkish imprint wording needs Legal.
- **One conflict created**, §19: two Turkish sentences §8.7 rewrites are the same
  sentences `Anthifel_Services.md` §9.2 fixes word for word. Services now
  disagrees with the site; Business has to move.
- Live: **preview yes, root no.**
- CEO decision needed: no. §11 items still stand.

### Previous change (3 August 2026, fifth entry) — K47

- **Brand Guidelines §8 applied.** The withdrawn sentence is off the site, the
  hero and the brand narrative are in, and the four site-wide rules have been
  swept. Source of truth stays in `Anthifel_Brand_Guidelines.md` §8; nothing was
  copied into this file.
- **Live now:** items 1 and 2 (the quote block) and item 5 (the four rules).
  Deployed to `/preview/` and verified.
- **Waiting on deploy:** nothing from K47. Everything below is in `/preview/`.
  The root still shows coming-soon, so **`anthifel.com/` itself is unaffected** —
  the withdrawn sentence was never on the coming-soon page.
- Also in this change: the Also block is no longer bold, and the privacy policy
  opens in place from the consent tick instead of navigating away.
- Live: **preview yes, root no.**
- Aligned with Services: unchanged. Aligned with Brand Guidelines: **yes for §8**,
  with four sentences referred back to Marketing — §16.
- CEO decision needed: no. §11 items still stand.

### Previous change (3 August 2026, fourth entry)

- **Image library.** Typing a path is gone. Images are uploaded from the editor,
  cropped in the browser to the three ratios the blog design uses, and committed
  to `blog/img/`. A focal point picked by clicking the image keeps the subject
  centred in all three crops. Previously uploaded images are reusable from a
  library grid, shared across both languages.
- **Authors are a fixed list** — Eray Dengiz or Anthifel. Was free text.
- **Scheduling.** A future date schedules rather than publishes. A daily
  `publishDue` trigger takes the post live on its day and rebuilds.
- Live: **no.** Nothing deployed; both forms still switched off.
- Aligned with Services: unchanged — §11 deviations still open.
- CEO decision needed: no for this change; §11 items still stand.

### Previous change (3 August 2026, third entry)

- **Blog built, with a publishing system behind it.** Blog index and a new article
  template, both bilingual and responsive. Writing happens in a new dashboard
  module at `/dashboard/blog/`; publishing renders static pages and commits them
  to GitHub, so DigitalOcean deploys them and the site stays fully static.
- **Landing page changed on CEO instruction:** the "Get in touch" section is gone,
  prices are gone, the independence statement is gone, and the assessment now
  opens an email-and-consent gate before the questions. Approach and Services
  headings share one type step. Three of these reverse recorded decisions — §11.3.
- **New personal-data flow:** the reading-list signup on the blog. Same three
  consent conditions as the assessment gate, same switch, same block on Legal.
- Live: **no.** Nothing deployed yet, and both forms stay switched off.
- Aligned with Services: **no.** §11 now carries five open deviations, three of
  them created by today's instructions.
- CEO decision needed: **yes** — §11.3 needs Services §9.1 and §9.4 rewritten by
  Business, or the page put back.

### Previous change (3 August 2026, second entry)

- **Staged release adopted.** The landing page does not replace the coming-soon page yet. It deploys to `anthifel.com/preview/`, behind `noindex,nofollow,noarchive`, while `/` stays on coming-soon. One source now produces two builds — `dist/preview/` and `dist/production/` — differing only in the head block and a preview bar, so what is signed off in preview is byte-identical to what goes live.
- Internal links between the four pages became **relative** (`privacy.html`, not `/privacy`), which is what lets the same files work under `/preview/` and at the root without an edit.
- Setup guide rewritten in Turkish as `KURULUM.md`.
- Live: **no.** Preview not yet deployed either.
- Aligned with Services: unchanged — §11 deviations still open.
- CEO decision needed: no for this change; §11 items still stand.

### Previous change (3 August 2026, first entry)

- **Landing page v2 rebuilt and verified.** Every link now resolves, TR/EN switching works across the whole page, the page is responsive at all seven widths, and a two-step enquiry form with consent capture has been built. Services §9 alignment applied: four service items with §9.2 copy verbatim, price ranges shown, independence statement placed. Holding pages added for privacy, terms and cookies.
- Live: **no** — awaiting deploy. The form additionally stays switched off (`FORM_LIVE = false`) until Legal publishes the privacy policy.
- Aligned with Services: **partly.** Service copy, prices and the independence statement are now verbatim. Two deviations are open and listed in §11.
- CEO decision needed: **yes** — two items in §11: the five-stage Approach, and the four-vs-five assessment dimensions.

### Previous change (2 August 2026)

- File created. Consolidates what was scattered across the dashboard notes, Services §9 and the infrastructure status table.
- Affects: Business (alignment), Marketing (blog structure)
- CEO decision needed: no

---

## 1. Current state

| Component | State |
|---|---|
| `anthifel.com` | Live — DigitalOcean App Platform, static site |
| `www.anthifel.com` | Live — CNAME + SSL |
| DNS | DigitalOcean nameservers (`ns1/2/3.digitalocean.com`) |
| Repo | GitHub `eray-ant/anthifel-coming-soon`, autodeploy on |
| Email | Google Workspace — MX `smtp.google.com` priority 1, SPF `v=spf1 include:_spf.google.com ~all` |
| **DKIM** | **Missing — must be generated in Admin console and added as `google._domainkey` TXT** |
| Dashboard | `anthifel.com/dashboard/` — password gate `anthifel2026` |
| Published page | Coming soon, English only |
| Landing page v2 | **Built, verified, not deployed.** Goes to `anthifel.com/preview/`, not to `/`. 479 KB self-contained. TR/EN, responsive, assessment gate |
| Blog | **Built, verified, not deployed.** `/blog/` and `/en/blog/`, article template, topic filter, reading-list signup |
| Blog publishing | **Built, not connected.** Dashboard editor → Apps Script → GitHub → autodeploy. Needs a GitHub token and Script Properties |
| Dashboard blog editor | **Built, not deployed.** `/dashboard/blog/`, `noindex`. Read-only until the endpoint and token are set |
| Coming-soon page | **Stays at `/`.** Untouched by this work. Removed at launch, open work 9 |
| Privacy / Terms / Cookies | **Built as holding pages, not deployed.** `noindex`. No legal text — waiting on Legal |
| Enquiry form | **Built, switched off.** `FORM_LIVE = false` until the privacy policy is published |
| Form endpoint | Google Apps Script Web App — **not yet created.** Setup in `KURULUM.md` |
| reCAPTCHA | v2 tickbox — **keys not yet issued.** CEO decision 3 Aug, chosen over Turnstile |

**Not Squarespace.** Every plan written before 2 August assumed Squarespace; that assumption is dead. Anything referencing it needs correcting.

---

## 2. Site map — target state at launch

| Page | Path | Source of copy |
|---|---|---|
| Home | `/` | Marketing (hero, positioning) |
| About | `/about` | Marketing — Brand Guidelines §1 |
| Approach | `/approach` | Business — Services §9.3 |
| Services | `/services` | Business — Services §9.2, verbatim |
| Assessment | `/assessment` | Business (methodology) + Developer (mechanics) |
| Blog | `/blog` · `/en/blog` | Marketing — Blog Plan §7 |
| Contact / Meet | `/meet` | Calendly embed |
| Privacy Policy | `/privacy` | Legal |
| Terms | `/terms` | Legal |
| Dashboard | `/dashboard/` | Developer, `noindex` |

---

## 3. Services alignment — Services §9, followed exactly

| Currently on site | Must become | Why |
|---|---|---|
| Six items in Services list | **Four items** | Workshop and Keynote move to a separate small "Also" block |
| Name and duration only | Name + duration + one-line definition | A name alone does not say what is being sold |
| Approach skips from Conversation to Discovery | **Audit made visible** | The cheapest entry product is invisible on the site |
| No prices | **Price ranges shown** | Decision taken: ranges are displayed |
| No independence statement | **Statement placed** below Approach or above footer | "We take no commission from any vendor we recommend." |

Exact bilingual copy for all four services and the "Also" block sits in `Anthifel_Services.md` §9.2. It is copied verbatim, not paraphrased.

**State as of 3 August:** all five rows above are applied on the v2 landing page and
asserted by `check-behaviour.js`, which fails the build if any §9.2 sentence or price
is edited away. Two deviations remain open — §11.

---

## 4. AI Readiness Assessment

Twelve questions, four categories: Strategy, Organisation, Technology, People.

**Waiting on Business:** the five-dimension scoring methodology and its weights. Without it the score cannot be calculated honestly and the automated email has nothing to say.

**Mechanics owned here:**
- Form with conditional logic
- Score 0-100, three bands
- Automated email: score, three to five recommendations, sector benchmark, one CTA
- Chain to CRM: form → Zapier or n8n → Notion Target Client table
- Field mapping: name, email, company, role · Source fixed to "Assessment (site)" · Stage fixed to "Assessment doldurdu" · score into the score field · Next action "personal reply within 24 hours" · Next action date = submission + 1 day

Those last two fields carry the real value: the lead appears in the "This week" view the moment it lands.

**Deadline: 17 August, tested end to end.** Fill the form with a personal address, watch it reach Notion, confirm it surfaces in the view.

---

## 5. Design rules

Everything derives from Brand Guidelines §3-8. What is specific to the build:

- **No dark surfaces in panel interfaces.** Surface `#FFFFFF`, background `#F1F0EC`, text `#1A1815`, accent terracotta `#B84C2E`
- **Wordmark renders at 15 px minimum.** Below that the serif terminals and the thin stroke of the "Λ"-shaped A break up. In a column flex box `align-items:flex-start` is mandatory or the mark stretches
- **The brand appears once per screen.** Embedded apps hide their own wordmark inside the iframe
- Headings Cormorant Garamond, body Inter — the free alternatives named in Brand Guidelines §4
- Every menu item carries a 13-15 px line icon, `stroke-width:1.6`
- Content flows full width; no fixed narrow column

## 6. Mobile rules (≤820 px)

- **No horizontal scrolling anywhere.** Menus wrap downward, they do not scroll sideways
- Main menu becomes a two-column grid; a lone final item spans full width
- Sub-menus become chips; group headings sit on their own line
- Tables become row cards — each cell shows its label via `data-l`, the header row hides with `tr:has(th){display:none}`
- Form fields and buttons go full width
- KPI cards two columns, one below 359 px

**Verification is mandatory.** `check-responsive.js` walks every page and section at 1440 / 1024 / 768 / 430 / 390 / 360 / 320. **Nothing ships without "NO OVERFLOW ANYWHERE" plus a visual pass over the screenshots.**

---

## 7. Technical rules

**Every page is self-contained.** CSS and JS inlined, no external files. Pages carry `<base href="/dashboard/">` so `/dashboard`, `/dashboard/` and `/dashboard?` all behave. The first version used external files and broke on the trailing-slash-free URL — this rule exists because of that.

**Class-name trap.** The top-bar "DASHBOARD" label uses `.sub`; the sidebar uses `.snav`. Give them the same name and sidebar styles land on the label, destroying the layout.

**Data.** Checkboxes, last open section, task list and Finance records live in localStorage — device-specific, never sent to a server. ANC data moves through the app's own Download → Pool file.

**Security.** The dashboard password is a client-side front door. It deters, it does not protect. No sensitive data is stored there. If real authentication becomes necessary, add a layer such as Cloudflare Access.

All dashboard pages are `noindex,nofollow`.

---

## 8. Deployment

GitHub is the only route. `build.py` writes `dist/`, the contents go to the
repository, DigitalOcean App Platform picks the commit up and deploys it.
One to two minutes, then a hard refresh.

**Verification is by commit hash.** DigitalOcean → Activity must show a new line
carrying the hash. "Deployed configuration changes" lines are settings, not
code: a deploy that only produces those has not shipped anything.

### Traps, all of them met at least once

- **DigitalOcean's GitHub access can lapse.** It did once, and autodeploy went
  quiet without an error anywhere. If Activity shows no new line after a push:
  github.com/settings/installations → DigitalOcean → Configure → grant access to
  the repository, then Actions → Force rebuild and deploy.
- **The address may arrive without a trailing slash.** `/dashboard`,
  `/dashboard/` and `/dashboard?` must all work. This is why every page is
  self-contained: an external stylesheet failed to load on the slashless form,
  and the page came up unstyled with its password box dead.
- **Only the root `index.html` is hand-maintained.** Every other page is
  produced by `build.py`, which is exactly how the coming-soon page kept a
  withdrawn sentence for a day after the sweep that was meant to remove it.
  `check-comingsoon.js` exists for that reason.

### Infrastructure

| Component | State |
|---|---|
| `anthifel.com` | Working — DigitalOcean App Platform, static site |
| `www.anthifel.com` | Working — CNAME and SSL |
| DNS | DigitalOcean nameservers, `ns1/2/3.digitalocean.com` |
| Email | Google Workspace. MX `smtp.google.com` priority 1, SPF `v=spf1 include:_spf.google.com ~all` |
| DKIM | **Missing.** To be generated in the Admin console and added as a `google._domainkey` TXT record |
| Dashboard | `anthifel.com/preview/dashboard/`, moving to `/dashboard/` at launch |
| Live page | Coming soon, English only |

Moving the nameservers to DigitalOcean deleted the Workspace records that lived
at the old DNS. MX and SPF were put back; DKIM was not, and is open work item 1.

## 9. SEO

Structure from Blog Plan §7:

- Hand-written meta description per page, 150-160 characters, separate for Turkish and English
- URL pattern: `anthifel.com/blog/ai-donusumu-organizasyon-problemi` · English `anthifel.com/en/blog/ai-transformation-organisational-problem`
- Reciprocal `hreflang` tags on both versions
- Every post links to at least two earlier posts. Posts 2 and 4 are hub pages
- Hand-written image `alt` text in both languages
- UTM on every outbound link: `?utm_source=blog&utm_medium=cta&utm_campaign=yazi-XX&utm_content=tr|en`

Analytics: Google Analytics with defined events for assessment start, assessment complete, and Calendly booking. These three are the only ones that matter.

---

## 10. Open work

| # | Item | Deadline |
|---|---|---|
| 1 | **DKIM record** | Before launch |
| 2 | ~~Assessment scoring methodology received from Business~~ — received 2 Aug, applied 4 Aug (§22) | ~~Before 14 Aug~~ |
| 3 | ~~Assessment form built~~ — built 4 Aug. Still to connect: the score is not sent anywhere by design (§22) | ~~17 Aug~~ |
| 4 | Assessment → CRM automation, tested end to end | 17 Aug |
| 5 | ~~Services §9 alignment applied to the site~~ — applied 3 Aug, two deviations open (§11) | Before 20 Aug |
| 6 | Privacy Policy and Terms published — copy from Legal. **Blocks item 12.** | Before 20 Aug |
| 7 | Calendly `/meet` built and test-booked | 14 Aug |
| 8 | Blog infrastructure — TR/EN, hreflang, UTM | 12 Aug (Blog 1 goes live) |
| 9 | `dist/preview/` deployed to `/preview/`, reviewed on desktop and phone | — |
| 9b | Coming-soon page removed, `dist/production/` deployed to the root, `/preview/` deleted | 20-21 Aug |
| 10 | Registered office address added to footer | After 20 Aug |
| 11 | reCAPTCHA keys issued, Apps Script endpoint deployed, form tested end to end | Before 17 Aug |
| 12 | `FORM_LIVE` flipped to `true` — **only after item 6** | With item 6 |
| 13 | Retention period agreed with Legal, then matched in `PURGE_AFTER_DAYS` | Before 20 Aug |
| 14 | reCAPTCHA disclosed in the privacy and cookie notices — Legal must know it is there | Before 20 Aug |
| 15 | Five deviations in §11 decided by the CEO; Business rewrites Services §9.1 and §9.4 | Before 20 Aug |
| 16 | GitHub fine-grained token issued, blog Script Properties set, `blogSelfTest` green | Before 12 Aug |
| 16b | Daily `publishDue` trigger added — without it scheduled posts never go live | With item 16 |
| 16c | `SITE_PREFIX` in the editor kept equal to `BLOG_PREFIX`, at setup and again at launch | With items 16 and 18 |
| 17 | Blog templates committed to the repo, first post published end to end | 12 Aug (Blog 1 goes live) |
| 18 | **`BLOG_PREFIX` emptied at launch** — left as `preview/` the blog publishes nowhere visible | 20-21 Aug |
| 19 | Reading-list consent flow covered by the privacy policy alongside the assessment gate | Before 20 Aug |
| 20 | Four sentences referred to Marketing rewritten and sent back (§16) | Before 20 Aug |
| 21 | EN tagline full stop settled in Brand Guidelines §8.3 (§16) | Before 20 Aug |
| 22 | Fifth footer blog title — real or placeholder? Marketing (§19) | Before 12 Aug |
| 23 | Turkish imprint wording confirmed by Legal (§19) | Before 20 Aug |
| 24 | Services §9.2 Turkish updated by Business to match Brand Guidelines §8.7 (§19) | Before 20 Aug |
| 25 | Dashboard password replaced by real authentication, if the panel ever holds client data (§21) | Before it does |
| 26 | `/dashboard/` redirect stubs replaced by the production build at launch (§21) | 20-21 Aug |
| 27 | The twelve question texts approved by Marketing and the mapping confirmed by Business (§22) | Before 20 Aug |
| 28 | Em dash in Business's band copy settled by Marketing (§22) | Before 20 Aug |
| 29 | Calendly exists, so the 0–29 call to action can point at a booking rather than the contact card (§22) | 14 Aug |

---

## 11. Open deviations from Services — CEO decision

Both were found while building v2. Neither is a bug; both are places where the
site and `Anthifel_Services.md` now say different things, and Services is the
source. This department cannot edit Services. The CEO decides which side moves.

### 11.1 Approach has five stages, Services §9.3 describes four

§9.3 says keep the four existing steps and add a sub-line under Discovery so the
Audit becomes visible. The page instead promotes Audit to a stage of its own:
**Assessment · Conversation · Audit · Discovery · Transformation.**

This satisfies the stated intent — "Approach'ta Audit hiç geçmiyor" is fixed, and
fixed more plainly than a sub-line would. But it is a different structure from
the one Services specifies, and it changes the service narrative, which is an
escalation under this department's charter.

**Either** Services §9.3 is rewritten to five stages, **or** the page reverts to
four plus a sub-line. Recommendation: rewrite §9.3. The five-stage version makes
the cheapest entry product visible without a reader having to notice a footnote.

### 11.2 The assessment shows four dimensions, Services says five

Services §2 promises "Readiness skoru (0–100), beş boyutta kırılımlı." The site —
both the old page and v2 — names four: **Strategy, Organisation, Technology,
People.** §4 of this file repeats the same four.

The fifth dimension has never been named anywhere. Services §10 still lists
"Readiness skoru metodolojisi — beş boyut ve ağırlıkları" as an open item owned by
Business, so this is not a copy error — the methodology does not exist yet.

**Nothing was invented to close the gap.** The page ships with the four names that
were already agreed. When Business delivers the methodology, whichever number is
real goes into Services, this file and the page together.

### 11.3 Three recorded decisions reversed, 3 August

Instructed by the CEO in session. Applied. Recorded here because each one
contradicts a line that is currently written down somewhere else, and the site
and Services must not silently disagree.

| Removed | What still says otherwise |
|---|---|
| **Prices** — all four ranges | Services §9.1: "Fiyat yok → Fiyat aralıkları eklenecek · Karar: aralıklar gösterilir". §9.2 carries the figures. §3 of this file repeats it |
| **The independence statement** | Services §9.4 requires it "website'ta görünür bir yere". Services §3 calls the no-commission promise a sales argument, not an aside |
| **The "Get in touch" form** | Nothing mandates it — this one is clean. The consequence is that the only way to reach us from the page is `hello@anthifel.com` in the footer, plus `/meet` once Calendly exists |

Durations stayed. Service names and the §9.2 one-liners stayed, verbatim.

**What has to happen:** Business rewrites Services §9.1 and §9.4 to match, or the
page goes back. This department cannot edit Services. Until one or the other, the
site is knowingly out of alignment and `check-behaviour.js` asserts the removals
so they are not undone by accident.

One note, offered once and not repeated. The commission sentence was the only
place on the page where the business model was stated rather than described, and
Services §3 frames it as the argument that makes the Retainer credible. Removing
it costs something a price list does not. If the concern was that it read as
defensive, it could return in the footer at 13 px instead of as a display quote.

### 11.4 Approach and Services headings

They were 22 px and 29 px. Now both take `--h-card`, a single custom property
(24 px, 22 px below 640 px). `check-behaviour.js` compares the computed size,
family and weight of the two and fails if they ever drift apart again.

### 11.5 The assessment gate changed what the assessment promises

"Start the assessment" no longer starts the assessment. It opens a gate: email
address, unticked consent box, captcha. The twelve questions come after.

This was the CEO's decision and it is a reasonable one — the email is the lead,
and capturing it at the gate means an abandoned assessment still produces one.
But it makes Services §1 wrong: "AI Readiness Assessment — Üç dakika, dürüst bir
skor. **Hiçbir şey kaydedilmez.**" Something is now recorded, before the first
question. The page says so plainly; Services still says the opposite.

---

## 12. Form and consent — how it actually works

Built 3 August. Decisions taken by the CEO the same day.

**Two steps, in this order.** Email address plus consent first; name, company,
role, size, subject and message second. Nothing is transmitted until the second
step is submitted — step one is a gate, not a save.

**Consent meets the three conditions Legal set out:**

1. The tickbox ships **unticked**. There is no pre-selected state anywhere.
2. The policy link sits **inside the label**, next to the words being agreed to.
3. The **moment of consent is recorded** — an ISO timestamp taken in the browser
   when the box is ticked, plus the visitor's timezone, plus the server's own
   receipt time, plus **the exact wording** shown at the time. Storing the
   wording matters: consent to a sentence we later edited is not evidence.

**Endpoint:** Google Apps Script Web App, chosen over Formspree so that no new
data processor is introduced and nothing is added to the monthly cost. Writes to
a Google Sheet, emails Eray, emails the enquirer a copy in their own language.

**Anti-abuse:** three layers. An off-screen honeypot field, a five-minute
per-address flood guard in the script, and Google reCAPTCHA v2 tickbox. The
captcha is verified **server-side** — a client-side pass alone is decorative.

**reCAPTCHA is the one external dependency on the page.** It breaks the
"self-contained, no external files" rule in §7, knowingly: a captcha that runs
entirely locally is not a captcha. It also sets Google cookies and must be
disclosed in the privacy and cookie notices — §10 items 14. Turnstile was offered
as the privacy-preserving alternative and not taken.

**Failure behaviour:** if Google is unreachable the captcha degrades **open**, and
the honeypot and flood guard still run. Blocking every visitor because a third
party is down costs more than the spam does.

**The form is switched off.** `FORM_LIVE = false` in `index.html`. It renders,
validates and refuses to send, telling people to email `hello@anthifel.com`
instead. This is deliberate and it is the one thing in this build that must not
be quietly flipped: the consent tickbox links to `/privacy`, and consent that
points at a page with no policy on it is not informed consent. Legal's item 5
unblocks it.

---

## 13. Staged release

The landing page does not take the root until launch. Until then it lives at
`anthifel.com/preview/` and the coming-soon page keeps `/`.

`build.py` emits two directories from one source:

| Build | Destination | Difference |
|---|---|---|
| `dist/preview/` | `/preview/` | `noindex,nofollow,noarchive`, no canonical, black preview bar across the top |
| `dist/production/` | repo root, **at launch** | canonical + hreflang, indexable, no bar |

**Nothing else differs.** Same markup, same CSS, same form, same copy — so the
thing signed off in preview is the thing that goes live. This is the point of
building it this way rather than keeping a hand-edited copy.

The preview path is one line in `build.py` (`PREVIEW_DIR`). A less guessable
slug is available if the page should be harder to stumble on.

**Links between the four pages are relative** — `privacy.html`, not `/privacy`.
That is what lets the identical files work under `/preview/` and at the root
without an edit, and it sidesteps the trailing-slash failure recorded in §7.

**Blog links are the exception and stay absolute** (`/blog/…`). They 404 today
because the blog does not exist yet — open work 8. They were left pointing at the
real future URLs rather than being stubbed to `#`, because a dead `#` link is
the defect this rebuild existed to remove.

**Editing rule:** changes go into `body.html` and `stub_template.html`. `dist/`
is generated output and is wiped on every build.

---

## 14. Blog

Design received 3 August; rebuilt the same way the landing page was. The article
page did not exist in the design and was built here.

### Pages

| Page | Path | Built from |
|---|---|---|
| Journal, Turkish | `/blog/` | `blog_index.html` |
| Journal, English | `/en/blog/` | same source |
| Article | `/blog/<slug>/` · `/en/blog/<slug>/` | `blog_post.html` |
| Editor | `/dashboard/blog/` | `dashboard_blog.html`, `noindex` |

URL shape follows Blog Plan §7. Turkish at the root, English under `/en/`,
reciprocal `hreflang` on both, `BlogPosting` JSON-LD per article.

### How publishing works

Writing happens in the dashboard. Saving writes to a `posts` sheet. Publishing
renders the index and every article from templates held **in the repo**, then
commits the result through the GitHub Contents API, which triggers the normal
autodeploy.

**The result is a static file.** A visitor opening an article makes no request to
Apps Script, to the sheet, or to Google. If this whole backend disappeared
tomorrow, every published article would keep working. That is the reason for
building it this way rather than fetching JSON at runtime — the alternative also
hands the article body to a crawler as an empty div, which for a blog whose whole
purpose is SEO would be self-defeating.

A republish that produces byte-identical output is skipped, so the repo does not
fill with empty commits.

**`BLOG_PREFIX` is the trap.** It is the repo path articles are written under —
`preview/` today. Left as `preview/` at launch, articles publish into the preview
folder and never appear on the site. It is the single most likely thing to be
forgotten on 20 August.

### Images

No path field. Upload from the editor or reuse from the library.

The browser crops and compresses before anything is sent — **1600×900** for the
article lead, **1200×900** for the featured slot, **1200×800** for a card, plus a
320×213 thumbnail for the library. JPEG at 0.82. All four are committed to
`blog/img/` and shared by both languages, so a translated pair carries one file
set, not two.

**The focal point is the part that earns its place.** A card is 3:2 and an
article lead is 16:9; centre-cropping one source into both regularly puts a face
half out of frame. Clicking the image sets a point that all three crops keep
centred, within what the edges allow. The three previews update live, so what is
approved is what ships.

Cropping client-side also means the original never reaches us — a 6 MB phone
photo becomes four files totalling a few hundred KB before it leaves the browser.

Deleting an image is refused while a post still points at it, and the refusal
names the post.

`SITE_PREFIX` in the editor exists only so the image previews load from the right
place. It must carry the same value as `BLOG_PREFIX`, and both change at launch.

### Scheduling

The date field is both the published date and the timer. A future date makes the
publish button read `Zamanla`, stores the post as `scheduled`, and keeps it off
the site. A daily `publishDue` trigger flips anything whose day has arrived and
rebuilds; a day with nothing due produces no commit.

The decision is taken from the date rather than a separate switch, so the two can
never disagree — there is no way to have a post marked published with a date next
week, or scheduled with a date last month.

### Authors

A fixed list: **Eray Dengiz** or **Anthifel**. It was free text, which over a
year of writing reliably produces two spellings of the same name in the byline.

### What is stored where

The sheet is the source; the repo is output. Editing a published HTML file by
hand works until the next publish overwrites it. Corrections go through the
editor.

### The dashboard token

The editor authenticates to Apps Script with a shared secret held in the page
source. The dashboard is `noindex` and behind a client-side password, so this
token is **publishing authority, not a vault** — §7 already records that the
dashboard password deters rather than protects. Anyone with the dashboard URL and
its source can publish to the blog. Acceptable while one person writes; if that
changes, Cloudflare Access is the answer, as §7 says.

### Reading list

The newsletter box on the blog is a second personal-data flow and carries the
same three consent conditions as the assessment gate: unticked box, policy link
inside the label, timestamp and exact wording recorded. It ships switched off
with the same flag and unblocks with the same Legal item.

The design shipped this box with no consent tick at all. That would not have
satisfied Legal §2 item 2, which requires explicit consent for any list receiving
marketing email, so the tickbox was added rather than the promise weakened.

---

## 15. Verification

Four scripts, all must pass before anything deploys.

`check-responsive.js` — walks every page at 1440 / 1024 / 768 / 430 / 390 / 360 /
320, ignores elements a parent clips or that are parked off-screen on purpose,
and writes full-page screenshots. Must print **NO OVERFLOW ANYWHERE**.

`check-behaviour.js` — 118 assertions on the landing page: every anchor resolves,
no `href="#"` survives, every relative page link exists as a file beside
`index.html`, every `data-en` node has a `data-tr` twin, each §9.2 sentence
appears verbatim, the form gates hold, the consent box starts unticked with its
policy link in place, the burger menu opens and closes, the four Brand Guidelines
§8 sweeps still hold, and every wordmark renders at 15 px or above.

The §9.2 assertions are the useful part: they fail the build if someone
paraphrases a service line, which is exactly how the site drifted from Services
the first time.

`check-blog.js` — 82 assertions across the blog index, the article template and
the editor: relative links resolve at their own depth, the publish markers are
intact, the topic filter works, the reading-list consent rules hold, every
template placeholder is present, a filled article renders, the editor
transliterates Turkish into slugs correctly, its markdown preview matches the
renderer in `BlogCode.gs`, and injected markup is escaped rather than executed.
The three crops come out at exactly the design's dimensions, clicking moves the
focal point, a future date flips the button to `Zamanla` and a past one flips it
back, and the author field is a two-item list rather than free text.

`check-dash.js` — 128 assertions on the dashboard: the door refuses a wrong
password and nothing is drawn behind it, the menu opens all eight sections
without leaving the document, the hash survives a reload, an unknown hash falls
back to Genel Bakış, the to-do list and the two checklist sets remember
themselves, the Measurement ID validator refuses a bad ID and the generator
writes a correct snippet, the ledger totals and its category breakdown are
right, the CRM loads sample data and every flow draws, search and bulk actions
and undo behave, keyboard triage advances, the DM queue fills from templates,
the CRM's shortcuts stay silent while another section is open, the blog editor
derives a slug and previews, and the old per-section links redirect. Overflow is
checked at every stop and at five widths.

Both builds are checked, not just one. State at 4 August: **NO OVERFLOW
ANYWHERE** across every page in preview and production, **118 passed** on the
landing page in each build, **82 passed** on the blog, **128 passed** on the
dashboard, visual pass done on every dashboard section at 1440 and at 560.

---

## 16. K47 — Brand Guidelines §8, what shipped and what did not

**Site copy lives in `Anthifel_Brand_Guidelines.md` §8, not here.** That block is
Marketing's handover and the single source. It is deliberately not reproduced in
this file: two copies of the same paragraph stop agreeing within days and nobody
can then say which one the site was built from. When §8 changes, Marketing sends
it again and this department reapplies.

### Shipped, in the order §8.6 sets

| §8 item | State |
|---|---|
| 1 · withdrawn sentence removed | **Live in preview** |
| 2 · replacement in the same slot, EN and TR | **Live in preview** |
| 3 · hero block, tagline and hero altı | **Live in preview** |
| 4 · brand narrative | **Not applied.** Added 3 Aug, removed the same day on CEO instruction |
| 5 · four site-wide rules | **Swept**, see below |
| 6 · order | Followed |

**Item 4 is the one gap.** It had no home to begin with: there is no about page
and no narrative block existed, so a quiet section was added between Services and
the assessment. The CEO removed it the same day. The section is gone and the
copy was not moved anywhere else, so **§8.4 is currently unapplied** and the site
carries no brand narrative in either language. Recorded here rather than quietly
dropped, because §8 lists it as handed over.

If it is wanted later it needs a decision this department cannot take alone:
an about page (which needs a nav entry) or a home-page block (which was just
rejected). Marketing and the CEO, not Developer.

### The four rules, as swept

**Rule 2, em dash.** Zero remain in any customer-facing text: landing, blog index
and article template, the three holding pages, and the confirmation email in
`Code.gs`. Replaced by a middle dot in titles, a full stop or comma in prose. The
preview banner was cleaned too. Code comments still contain them; they are not
customer text.

**Rule 1, "wrong" and "yanlış".** Zero remain. One non-obvious hit: the form's
failure message read "Something went wrong", now "Something did not go through",
which is also more accurate about whose failure it was.

**Rule 3, technology opposition.** The hero sub-line and the meta description
both carried "not with the technology, but with the people behind it". Both
replaced with §8 text. One case referred to Marketing, below.

**Rule 4, Turkish written separately.** Applied where §8 supplies both languages.
Elsewhere the existing Turkish was left alone rather than machine-adjusted; where
it reads as a translation it is listed below.

**These four are now assertions in `check-behaviour.js`.** The sweep is not a
one-off tidy: the build fails if an em dash, a "wrong", a "yanlış" or the
withdrawn sentence reappears in any page copy, in either language. Attribute
copy for the language that is not currently showing is swept too, which is where
half of it was hiding.

### Referred to Marketing, not changed here

Site copy is Marketing's content. §8 gives replacement text for the home page
only, so the following were left standing and are Marketing's to rewrite. They
are recorded here so the gap is visible, not to propose wording.

| Where | Sentence | Which rule |
|---|---|---|
| Blog masthead, EN | "…written for the people who have to decide, not for the people who build the models." | 3 — sets us against model builders using the X-not-Y shape |
| Blog masthead, TR | "Modelleri kuranlar için değil, karar vermek zorunda olanlar için yazıldı." | 3, and 4 — reads as a translation of the English |
| Blog meta description | Same sentence, both languages | 3 |
| Reading list, TR | "Şirketlerin içinde gördüklerimizi, karar vermek zorunda olan insanlar için ayda bir yazıyoruz." | 4 — English clause order |

The em dashes in those sentences were removed, because punctuation is mechanical.
The constructions were not, because rewriting them is writing copy.

### One question back to Marketing

§8.3 gives the EN tagline without a full stop ("AI needs a guide, not just
tools") while §1 Marka Vaadi gives it with one. The site keeps the full stop, as
it had. Turkish has one in both places. Worth settling in §8 so the next person
does not have to choose.

---

## 17. Every internal link is relative

The nav pointed at `/blog`. Under `/preview/` that resolves to
`anthifel.com/blog`, which does not exist, so the Blog menu item was a 404 for
every visitor of the preview build. The footer post links and `/meet` had the
same shape.

All of them are now relative: `blog/`, `blog/<slug>/`, `meet/`. The same file
then works under `/preview/` and at the root without an edit, which is the rule
§13 already sets for the legal pages, applied consistently.

One related bug went with it. `footerPosts_()` in `BlogCode.gs` generated links
relative to the blog index and the same string was reused on article pages, one
level deeper, where they resolved to `blog/<slug>/<slug>/`. It now takes a base.
Nothing had shipped yet, so nothing broke in public.

`check-behaviour.js` now fails on any `href` beginning with `/`.

---

## 18. K47 item 7 — Turkish page

Same rule as §16: the copy lives in `Anthifel_Brand_Guidelines.md` §8.7, not
here. Below is only what shipped and what did not.

| §8.7 | State |
|---|---|
| 7a · spelling and the half sentence | **Live in preview**, all three |
| 7b · three sentences against the brand voice | **Live in preview**, all three |
| 7c · translation smell | **Live in preview**, all six |
| 7d · blog titles in Turkish | **Live in preview**, four of five — see §19 |
| 7e · naming and imprint | **Live in preview**, all four |
| 7f · AI suffixes, two addresses | No action needed, site was already consistent |
| 7g · Advisory Board Seat vs five stages | Marketing's, not waited on |

**English was not touched.** A test asserts three English sentences item 7
rewrites in Turkish are still present in English, so a future sweep cannot
quietly "fix" them.

### One name for the assessment

The page carried three: "AI Hazirlik Testi", "Hazirlik testi", "Test". Now:

| Where | Name |
|---|---|
| Eyebrow, gate | **AI Hazırlık Testi** |
| Hero button | **AI Hazırlık Testi →** |
| Nav, footer menu, Approach stage I | **Hazırlık Testi** |

The short form is the one §8.7e sanctions for narrow space. A bare "Test"
appears nowhere, and the test fails if it comes back.

### Two "skor" outside the scan

The scan read the public page, so it never reached the two strings behind the
assessment gate, which also said "skor". The word and the reason are exactly the
ones §8.7c rules on, so the same substitution was applied rather than leaving
two sentences contradicting the rule that had just been set. **Flagged as applied
by extension, not from the §8.7 list** — Marketing can reverse it in a line.

---

## 19. Back to Marketing, Business and Legal

**To Marketing — the fifth blog title.** §8.7d gives Turkish for four of the five
footer titles and records that "The first ninety days of an AI roadmap" is not in
the Blog Plan. The four Turkish titles are in; **the fifth row was removed.**

That needs saying plainly, because removing it also shortened the English footer
from five links to four, and item 7 was supposed to leave English alone. The
alternative was one English title sitting among four Turkish ones on the Turkish
page, which is the exact defect 7d exists to fix. All five links are placeholders
pointing at articles that do not exist, and `footerPosts_()` overwrites the whole
list at the first publish on 12 August, so this self-heals. **One line restores
it** if Marketing says the title is real.

**To Legal — the imprint.** §8.7e asks whether translating the registration
statement is acceptable and gives the Turkish. It is **applied**: the Turkish
page now reads "© 2026 Anthifel Ltd · İngiltere ve Galler'de tescillidir".
Applied rather than held because it is preview only and reverting is one line.
If Legal wants the statutory English form kept in both languages, say so and it
goes back.

**To Business — Services §9.2 now disagrees with the site.** Two Turkish
sentences §8.7 rewrites are sentences §9.2 fixes word for word:

| Service | §9.2 says | §8.7 says, and the site now shows |
|---|---|---|
| Transformation Retainer | "Doğru insanlar, işe alınmış ve birbirine bağlanmış. Tutan bir ritim." | "İşe alımlar yapılmış, roller birbirine bağlanmış. Tutan bir ritim." |
| Executive Workshop | "Yönetiminizle bir gün. Genel bir eğitim değil, sizin senaryolarınız." | "Yönetim ekibinizle, genel bir eğitim değil, sizin senaryolarınız üzerine." |

This department's charter says the site follows Services exactly. It now does
not, because a newer instruction from Marketing, routed through the CEO, says
otherwise. **Brand Guidelines §8.7 was followed**, on the grounds that it is
newer, it is explicitly a handover to this department, and it is specifically
about these strings. Services §9.2 needs updating by Business so the two agree
again. Until then the English half of §9.2 is still asserted verbatim by the
tests; only the Turkish diverges.

---

## 20. Privacy in place

The consent tick links to the privacy policy. Following that link used to leave
the page, which lost the tick and, in practice, the visitor. It now opens in a
dialog over the form: Escape closes it, the tick survives, and a link to the full
page is still there for anyone who wants it. The same applies to the reading-list
box on the blog.

The dialog copy is generated by `build.py` from the same `STUBS` entry
`privacy.html` is generated from. One source, two surfaces, so Legal's text
cannot land in one and not the other.

---

## 21. The dashboard

`/preview/dashboard/` is one document. The section menu at the top swaps panes
inside it; the hash exists so a section can be linked to and reloaded, not so
the browser can navigate. `/dashboard/crm/` and `/dashboard/blog/` are redirect
stubs, because those links were given out before.

Heavy sections build themselves the first time they are opened. Until you go to
CRM it draws nothing, and until you go to Blog it does not call the Apps Script.
A section that is never opened costs nothing but its bytes.

### What each section holds

| Section | What it is | State |
|---|---|---|
| Genel Bakış | What is live, what is missing, a to-do list with dates and a card per module | this browser |
| CRM | The ANC engine: pool, triage, four working lists, DM rounds, advice engine | CSV, on disk |
| Blog | The editor: markdown, image library, crop with a focal point, scheduling | Sheet + GitHub |
| İçerik | Pillars and target mix, channels, ten content types and their rules, blog and social pre-publish checklists, banned words, sources | this browser |
| Site | Launch checklist, content map with the search string for each piece of copy, page inventory, how publishing works | this browser |
| SEO | Page and post rules, key phrases, the one-off site-wide list | this browser |
| Analitik | GA4 setup, Measurement ID validator and snippet generator, panel links, the events worth counting | nothing stored |
| Finans | Income and expense ledger, category breakdown, CSV out, monthly fixed costs | this browser |

"this browser" means `localStorage` on the machine you are sitting at. It is a
working aid, not a record: nothing survives a cleared browser and nothing is
visible from a second device. Every section that stores something says so on the
page. Anything that must survive belongs in the MD files.

### What is deliberately not there

No prices, anywhere. The CEO sets those; the panel records what happened, not
what something should cost. No live analytics: the site is static, so numbers
are read in Google's own panel and only the setup lives here. No client
personal data: the door is a password written into the page, which is a
deterrent and not a lock, and it stays that way only as long as nothing behind
it is worth stealing.

### Storage and the door

Ticked boxes, the to-do list and the ledger live in `localStorage`: device-bound,
never sent anywhere. The CRM's own data moves through the file you download and
load again; the planner's through the JSON working file you choose.

The password is a client-side front door on a static site. It deters, it does
not secure. **No sensitive data is kept in the panel**, and that is the condition
that makes the arrangement acceptable rather than the password. Real
authentication, if the panel ever holds client data, means a layer in front of
it — Cloudflare Access or equivalent. Open work item 25.

Two traps worth remembering, both met while building the old panel: a class name
shared between the top bar and the side menu applied the wrong rules to both, and
a brand mark in a column flex box stretches to the box width unless
`align-items:flex-start` is set.

### Source layout

`dash_parts.html` holds the shell — head, gate, section menu, toast, router and
the shared checklist helper. Each section is a fragment, `dash_sec_*.html`, with
its own stylesheet, its markup and a builder registered on `window.dashInit`.
`build.py` stamps them into `dash_app.html`. The blog editor was written as a
page of its own and uses class names the shell also uses, so its stylesheet is
confined to its own section at build time rather than renamed by hand.

`mk_crm.py` is the one-off that lifted the CRM engine out of the old dashboard.
It is kept for the record: it says exactly what was changed in the port and what
was left alone.

### The old dashboard

`/dashboard/` used to be a panel of its own. Both were live for a day, which is
one day too many: two doors, two to-do lists, two answers to the same question.
Its pages are now redirect stubs pointing at the matching section here, and the
two things it kept in the browser, the to-do list and the ledger, are carried
across on first visit. Nothing was deleted from the old keys; if the conversion
is wrong in some way, the originals are still there.

At launch the production build writes the dashboard to `/dashboard/` itself and
the stubs are replaced.

`mk_icerik.py` is the one-off that lifted the planner across, kept for the same
reason `mk_crm.py` is.

---

## 22. The readiness test

Built 4 August from `Anthifel_Readiness_Metodolojisi.md` and the Business
brief. Before this the assessment was an email gate followed by a placeholder.

### What it does

Twelve questions, five dimensions, weights 30 / 25 / 20 / 15 / 10. Three
options per question worth 0, 50 or 100. Dimension score is the plain mean of
its questions; the raw score is the weighted sum. Then the two ceilings from
methodology §4, in order: any dimension below 40 caps the total at 59, and
Strategy & Ownership below 40 caps it at 49.

**When a ceiling bites, the result screen says so** — raw score, ceiling, and
which dimension caused it. That is the most useful thing on the screen and the
reason the test cannot be hidden behind a single number.

The result is one screen in three parts, in this order: score and band; five
dimension bars with the weakest picked out and named in a sentence; one call to
action. One, not two, by instruction.

### Nothing about it is recorded

No answer and no score is written to storage, posted to the endpoint or passed
to analytics. `check-behaviour.js` proves it rather than trusting it: it reads
every POST body the page attempts and inspects both storages after a completed
run.

### What Business did not supply

The methodology defines **seventeen** criteria and the test has **twelve**
slots. The twelve questions are drafted here from those criteria, one question
per criterion. Five criteria are therefore **not asked**:

| Dimension | Criterion not asked |
|---|---|
| Strategy & Ownership | 1.3 Link to a business goal |
| People & Capacity | 2.4 HR alignment |
| Data & Process Foundation | 3.3 Data reliability |
| Economics & Measurement | 4.2 Baseline measurement |
| Technology & Infrastructure | 5.2 Integration |

The wording is Developer's draft, not approved copy. **Marketing owns the
words and Business owns the mapping**; both are open work, items 27 and 28.

### Three answers back to Business

**The email gate stays.** Brief red line 3 says the score must not sit behind an
email wall. The gate was built at the CEO's instruction and the CEO confirmed on
4 August that it stays. The brief's other two red lines around it hold in full:
the test records nothing, and the score is shown on screen the moment the last
question is answered. What the gate collects is the email address, before the
questions, exactly as before.

**The independence statement stays off the page.** Brief §B.3 asks for it in a
visible place. It was removed on 3 August by CEO instruction, and the brief is
dated 2 August, so the instruction is the newer of the two. Confirmed again on
4 August. Services §9.4 still requires it, so Services and the site disagree
until Business moves. This is §11.3, unchanged.

**§B.2 is already done, in a better shape.** The brief says Approach jumps from
the conversation straight to Discovery and asks for a sub-line under stage III.
Approach has had Audit as its own stage since 3 August, so the sub-line would be
a footnote under a stage that already exists. Left as is. Note that this is the
five-stage Approach of §11.1, which Services §9.3 still describes as four.

### One conflict for Marketing

Brief §A.4 says the band copy goes in verbatim and Developer does not change it.
Brand Guidelines §8 says no em dash appears anywhere on the site. **Three of the
five band paragraphs contain one.** The copy went in verbatim, as instructed,
and the exception is pinned in the test: nothing else on the result screen may
carry an em dash. Marketing settles which rule wins.

---

## Change protocol

```
### Last change (date)

- [what changed — page, module, infrastructure]
- Live: [yes / no — awaiting deploy]
- Aligned with Services: [yes / no — if no, why]
- CEO decision needed: [yes — why / no]
```

Save to `Anthifel MD's/`. Mirrors are read-only.
