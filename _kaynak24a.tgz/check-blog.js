/**
 * check-blog.js — Anthifel
 * The blog index, the article template and the dashboard editor.
 */
const { chromium } = require('playwright');
const mock = require('./mock-supabase');
const path = require('path');
const fs = require('fs');

let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${x ? '  → ' + x : ''}`)); };
const DIST = process.argv[2] || 'dist/preview';

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  /* ---------------- blog index ---------------- */
  console.log('\n=== blog index ===');
  let page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  page.on('pageerror', e => { if (!/recaptcha|gstatic|google/i.test(String(e))) errs.push(String(e)); });
  await page.goto('file://' + path.resolve(DIST, 'blog/index.html'), { waitUntil: 'load' });
  await page.waitForTimeout(400);

  const hrefs = await page.$$eval('a[href]', as => as.map(a => a.getAttribute('href')));
  ok('no href="#" left', !hrefs.includes('#'));
  ok('links back to the landing page', hrefs.some(h => /^\.\.\/#approach$/.test(h)));
  ok('legal links are relative and one level up', hrefs.includes('../privacy.html'));
  ok('Blog is marked as the current page', await page.$('.nav a[aria-current="page"]') !== null);

  ok('publish markers present for the index', (await page.content()).includes('FEATURED:START'));
  ok('publish markers present for the grid', (await page.content()).includes('GRID:START'));

  console.log('\n— topic filter —');
  ok('six topic chips', (await page.$$('.chip')).length === 6);
  ok('All is pressed by default', (await page.getAttribute('.chip[data-cat=""]', 'aria-pressed')) === 'true');
  await page.click('.chip[data-cat="People"]');
  await page.waitForTimeout(150);
  ok('clicking a chip moves the pressed state', (await page.getAttribute('.chip[data-cat="People"]', 'aria-pressed')) === 'true');
  ok('empty state shown while there are no posts', await page.isVisible('#empty'));
  ok('count reads zero', /0/.test(await page.textContent('#count')));

  console.log('\n— reading list consent —');
  ok('consent box starts unticked', !(await page.isChecked('#ncons')));
  ok('policy link sits inside the label', await page.$('.ncons label a[href="../privacy.html"]') !== null);
  await page.fill('#nemail', 'bad');
  await page.click('#nbtn'); await page.waitForTimeout(150);
  ok('rejects a malformed address', /valid|geçerli/i.test(await page.textContent('#nmsg')));
  await page.fill('#nemail', 'test@example.com');
  await page.click('#nbtn'); await page.waitForTimeout(150);
  ok('blocks without consent', /tick|işaretle/i.test(await page.textContent('#nmsg')));
  /* Two questions since 19 August: the permission to write, and the
     acknowledgement that the notice was read. Ticking one is not an answer to
     the other, and the form says which one is still missing. */
  await page.check('#ncons');
  await page.click('#nbtn'); await page.waitForTimeout(200);
  ok('…and blocks again on the privacy box alone',
     /Privacy Policy|Gizlilik/i.test(await page.textContent('#nmsg')),
     await page.textContent('#nmsg'));
  await page.check('#npriv');
  /* 20 August, launch. This used to assert "records nothing while FORM_LIVE is
     false" — a description of the switch, not of the form. With the switch on,
     a form that records nothing is the failure. So the endpoint is answered
     locally and what is asserted is the packet: the five fields
     Anthifel_Legal_DataProcessing.md §3 requires, and the moment of the tick
     rather than the moment of the send. Nothing reaches Google — the route
     intercepts before the request leaves. */
  const sent = [];
  await page.route('**script.google.com/**', async r => {
    sent.push(JSON.parse(r.request().postData() || '{}'));
    await r.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' });
  });
  await page.click('#nbtn'); await page.waitForTimeout(600);
  /* The four shells space this differently — `FORM_LIVE  =` in body.html,
     `FORM_LIVE =` here — which is exactly the kind of detail a test should not
     depend on. Read the value, not the whitespace. */
  const live = /var FORM_LIVE\s*=\s*true;/.test(await page.content());
  if (live) {
    ok('a complete answer is recorded', sent.length === 1, JSON.stringify(sent));
    const d = sent[0] || {};
    ok('…as a reading-list signup', d.action === 'reading-list', d.action);
    for (const f of ['consentAt', 'consentText', 'consentVersion', 'channel', 'affirmative'])
      ok(`…carrying §3's ${f}`, !!d[f], JSON.stringify(d[f]));
    ok('…and the privacy notice version it was given under',
       /^privacy-v\d+$/.test(d.privacyVersion || ''), d.privacyVersion);
    ok('…and the visitor is told it worked',
       /Thank you|Teşekkürler/i.test(await page.textContent('#nmsg')),
       await page.textContent('#nmsg'));
  } else {
    ok('records nothing while FORM_LIVE is false',
       /shortly|yakında/i.test(await page.textContent('#nmsg')));
    ok('…and really sent nothing', sent.length === 0, JSON.stringify(sent));
  }

  console.log('\n— language —');
  await page.click('.lang button[data-lang="tr"]');
  await page.waitForTimeout(250);
  ok('switches to Turkish', (await page.getAttribute('html', 'lang')) === 'tr');
  ok('chips translate', /Hepsi/.test(await page.textContent('#chips')));
  const untranslated = await page.$$eval('[data-en]', els =>
    els.filter(e => !e.hasAttribute('data-tr')).map(e => e.tagName));
  ok('every data-en node has data-tr', untranslated.length === 0, untranslated.join(','));
  ok('no page errors', errs.length === 0, errs.join(' | '));
  await page.close();

  /* ---------------- article template ---------------- */
  console.log('\n=== article template ===');
  const tplPath = path.resolve(DIST, 'blog/_tpl-post.html');
  ok('_tpl-post.html emitted', fs.existsSync(tplPath));
  const tpl = fs.readFileSync(tplPath, 'utf8');
  for (const k of ['{{TITLE}}', '{{BODY}}', '{{CATEGORY}}', '{{CATEGORY_TR}}', '{{DATE}}',
                   '{{CANONICAL}}', '{{HREFLANG}}', '{{JSONLD}}', '{{RELATED}}',
                   '{{TRANSLATION_URL}}', '{{LANG}}']) {
    ok(`placeholder ${k}`, tpl.includes(k));
  }
  ok('article links two levels up to the root', tpl.includes('href="../../"'));
  /* Both Journals, from every article. The way back used to be the Turkish
     index whatever language the reader was in — on an English article it was
     the one link on the page that changed language under them. */
  ok('article links to the English Journal by default', tpl.includes('href="../../en/blog/"'));
  ok('…and carries the Turkish address beside it',
     tpl.includes('data-href-tr="../../blog/?lang=tr"'));
  // Two tokens survive the build on purpose, and only in the templates: the
  // endpoint is pasted in at deploy, and __FOOTER_POSTS__ is what the publisher
  // fills with the real Journal list every time it writes a page. A page the
  // build itself writes must carry neither, which is asserted further down.
  ok('no build tokens left unfilled',
    !/__[A-Z_]+__/.test(tpl.replace(/__APPS_SCRIPT_URL__|__FOOTER_POSTS__/g, '')),
    (tpl.match(/__[A-Z_]+__/g) || []).join(','));
  ok('the template keeps the slot the publisher fills', tpl.includes('__FOOTER_POSTS__'));

  // Render it with sample values to prove the shell survives substitution.
  const filled = tpl
    .replace(/\{\{LANG\}\}/g, 'tr').replace(/\{\{TITLE\}\}/g, 'Örnek başlık')
    .replace(/\{\{SEO_DESC\}\}/g, 'Açıklama').replace(/\{\{CANONICAL\}\}/g, 'https://anthifel.com/blog/x/')
    .replace(/\{\{HREFLANG\}\}/g, '').replace(/\{\{ISO_DATE\}\}/g, '2026-08-03')
    .replace(/\{\{JSONLD\}\}/g, '{}').replace(/\{\{CATEGORY_TR\}\}/g, 'Strateji')
    .replace(/\{\{CATEGORY\}\}/g, 'Strategy')
    .replace(/\{\{EXCERPT\}\}/g, 'Spot cümlesi.').replace(/\{\{AUTHOR\}\}/g, 'Eray Dengiz')
    .replace(/\{\{DATE\}\}/g, '3 Ağustos 2026').replace(/\{\{READ\}\}/g, '6 dk okuma')
    .replace(/\{\{LEAD_IMAGE\}\}/g, '').replace(/\{\{URLENC\}\}/g, 'x')
    .replace(/\{\{TRANSLATION_URL\}\}/g, '').replace(/\{\{RELATED\}\}/g, '')
    .replace(/\{\{BODY\}\}/g, '<h2>Ara başlık</h2><p>Gövde metni.</p><blockquote>Alıntı.</blockquote>');
  const tmp = path.resolve(DIST, 'blog/_rendercheck.html');
  fs.writeFileSync(tmp, filled);
  page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const aerr = [];
  page.on('pageerror', e => { if (!/recaptcha|gstatic|google/i.test(String(e))) aerr.push(String(e)); });
  await page.goto('file://' + tmp, { waitUntil: 'load' });
  await page.waitForTimeout(400);
  ok('renders a headline', (await page.textContent('.art h1')).includes('Örnek'));
  ok('renders prose', await page.$('.prose h2') !== null);
  ok('language buttons disabled with no translation', await page.isDisabled('.lang button[data-lang="en"]'));
  /* The topic is one stored value and two printed words. A Turkish article had
     "ORGANISATION" over it — the wrong language, and in the wrong letters too:
     CSS uppercasing follows the page's language, so the i became a dotted İ. */
  ok('the topic carries both languages', await page.$('.art .cat[data-tr]') !== null);
  ok('…and reads Turkish on a Turkish article',
     (await page.textContent('.art .cat')).trim() === 'Strateji',
     await page.textContent('.art .cat'));
  ok('no page errors', aerr.length === 0, aerr.join(' | '));
  await page.close();
  // kept until the header comparison below has measured it

  console.log('\n— the header matches the landing page —');
  // The nav sat 2px higher on blog pages and its links did not respond to the
  // pointer: the current-page marker changed the line height, and the hover
  // rule was never carried over from the landing page's stylesheet.
  const hdr = async f => {
    const p2 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await p2.goto('file://' + path.resolve(f), { waitUntil: 'load' });
    const box = await p2.evaluate(() => {
      const n = document.querySelector('.nav'), a = document.querySelector('.nav a');
      return { navH: Math.round(n.getBoundingClientRect().height),
               aTop: Math.round(a.getBoundingClientRect().top) };
    });
    await p2.hover('.nav a');
    await p2.waitForTimeout(260);
    const colour = await p2.evaluate(() => getComputedStyle(document.querySelector('.nav a')).color);
    await p2.close();
    return { ...box, colour };
  };
  const landing = await hdr(path.resolve(DIST, 'index.html'));
  // The article is measured on a rendered page, not on the template: the
  // template's meta tags sit outside a head until substitution puts them there,
  // and an unrendered template measures 20px short.
  for (const [name, file] of [['blog index', 'blog/index.html'], ['article', 'blog/_rendercheck.html']]) {
    const h = await hdr(path.resolve(DIST, file));
    ok(`${name}: nav sits where the landing page's does`,
       h.navH === landing.navH && h.aTop === landing.aTop,
       JSON.stringify(h) + ' vs ' + JSON.stringify(landing));
    ok(`${name}: nav links answer the pointer`, h.colour === 'rgb(184, 76, 46)', h.colour);
  }
  // Kept for the campaign check below, which needs an article at the address a
  // real one gets: blog/<slug>/index.html, not a loose file in blog/.
  const artDir = path.resolve(DIST, 'blog/ornek-yazi');
  fs.mkdirSync(artDir, { recursive: true });
  fs.copyFileSync(path.resolve(DIST, 'blog/_rendercheck.html'), path.join(artDir, 'index.html'));
  fs.unlinkSync(path.resolve(DIST, 'blog/_rendercheck.html'));

  console.log('\n— one footer, not two —');
  // The Journal carried its own near-copy of the site footer until 13 August,
  // and the two had drifted where nobody was looking: the blog's had no About
  // link and an empty Journal list. There is one file now, aimed at each depth.
  {
    const p5 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await p5.goto('file://' + path.resolve(DIST, 'blog/index.html'), { waitUntil: 'load' });
    const links = await p5.$$eval('.ftr a[href]', as => as.map(a => a.getAttribute('href')));
    /* Either address. The Turkish index takes Turkish as the page's language on
       arrival, so its footer link is aimed at hakkimizda.html — which is the
       point of that link, not a fault in it. What is being asserted is that the
       Journal's footer reaches the About page at all; it once did not. */
    ok('the Journal footer reaches About',
       links.some(h => /(about|hakkimizda)\.html$/.test(h)), links.join(' '));
    ok('…and the four legal and menu links with it',
       ['privacy.html', 'terms.html', 'cookies.html'].every(f => links.some(h => h.endsWith(f))));
    /* The footer lists what the Journal has, not a fixed four. It was four
       while the four planned titles stood in; it is one on the day the first
       piece goes out, and five once there are five. What has to hold is that it
       lists something and that every line carries both languages. */
    const fp = await p5.$$eval('#ftrPosts li a', as =>
      as.map(a => ({ en: a.getAttribute('data-en'), tr: a.getAttribute('data-tr') })));
    ok('…and lists the Journal itself', fp.length >= 1 && fp.length <= 5, String(fp.length));
    ok('…with both languages on every line', fp.every(t => t.en && t.tr), JSON.stringify(fp));
    ok('every one of its links climbs out of blog/',
       links.filter(h => /\.html$/.test(h)).every(h => h.startsWith('../')),
       links.filter(h => /\.html$/.test(h)).join(' '));
    ok('the reading list is on the page', await p5.isVisible('.news'));
    // The modal travels with the band. Inside blog/ every root-level link needs
    // a prefix, and the one the modal carries is its own — the link to the full
    // page. A modal that opens fine but whose only way out is a 404 is a modal
    // that was tested on the front page and nowhere else.
    ok('the privacy notice is here too', await p5.$('#povl') !== null);
    ok('hidden until asked', await p5.isHidden('#povl'));
    ok('its link to the full page climbs out of blog/',
       (await p5.getAttribute('#povl .pmft a', 'href')) === '../privacy.html',
       await p5.getAttribute('#povl .pmft a', 'href'));
    await p5.$eval('.ncons label a[href$="privacy.html"]', a => a.click());
    await p5.waitForTimeout(150);
    ok('the consent link opens it rather than leaving the Journal',
       await p5.isVisible('#povl') && p5.url().includes('/blog/'));
    await p5.keyboard.press('Escape');
    await p5.waitForTimeout(120);
    ok('Escape closes it', await p5.isHidden('#povl'));
    await p5.close();
  }

  console.log('\n— UTM on the way out (Blog Plan §7) —');
  {
    const p3 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await p3.goto('file://' + path.resolve(DIST, 'blog/index.html'), { waitUntil: 'load' });
    // The tag is written on click, so read it the same way: swallow the
    // navigation and look at the href the handler left behind.
    const tag = sel => p3.evaluate(s => {
      const a = document.querySelector(s);
      if (!a) return null;
      const stop = e => e.preventDefault();
      document.addEventListener('click', stop);
      a.click();
      document.removeEventListener('click', stop);
      return a.getAttribute('href');
    }, sel);

    const clean = await p3.$eval('.nav a[href*="#services"]', a => a.getAttribute('href'));
    ok('the shipped href carries no campaign', !/utm_/.test(clean), clean);

    const site = await tag('.nav a[href*="#services"]');
    ok('a link into the site is tagged on click',
       /[?&]utm_source=blog/.test(site) && /[?&]utm_medium=cta/.test(site) &&
       /[?&]utm_campaign=journal/.test(site), site);
    ok('…and the hash survives the tagging', /#services$/.test(site), site);
    ok('…and it carries the reader’s language', /[?&]utm_content=(tr|en)/.test(site), site);

    const legal = await tag('a[href$="privacy.html"]');
    ok('the Privacy Policy is not a campaign', legal !== null && !/utm_/.test(legal), String(legal));

    const inside = await tag('.nav a[href*="blog/"]');
    ok('a link that stays in the Journal is not tagged',
       inside !== null && !/utm_/.test(inside), String(inside));

    const twice = await tag('.nav a[href*="#services"]');
    ok('clicking twice does not stack the tags',
       (twice.match(/utm_source=/g) || []).length === 1, twice);

    await p3.close();

    // An article names itself in the campaign, so a click can be traced to the
    // piece that earned it — not merely to "the blog".
    const p4 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await p4.goto('file://' + path.join(artDir, 'index.html'), { waitUntil: 'load' });
    const fromArticle = await p4.evaluate(() => {
      const a = document.querySelector('.nav a[href*="#services"]');
      const stop = e => e.preventDefault();
      document.addEventListener('click', stop);
      a.click();
      document.removeEventListener('click', stop);
      return a.getAttribute('href');
    });
    ok('an article names itself in the campaign',
       /utm_campaign=yazi-ornek-yazi(&|$)/.test(fromArticle), fromArticle);
    ok('…and the campaign is not the file name',
       !/yazi-index/.test(fromArticle), fromArticle);
    await p4.close();
  }
  fs.rmSync(artDir, { recursive: true, force: true });

  /* ---------------- dashboard editor ---------------- */
  console.log('\n=== dashboard editor ===');
  page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const derr = [];
  page.on('pageerror', e => derr.push(String(e)));
  mock.install(page);
  // The editor is a section of the one dashboard document now, not a page.
  const DASH_URL = 'file://' + path.resolve(DIST, 'dashboard/index.html');
  const openBlog = async () => {
    // pointing at the department opens its list, the list has the section
    await page.hover('.dept[data-dept="marketing"] button');
    await page.waitForTimeout(220);
    await page.click('.dept[data-dept="marketing"] .dmenu a[href="#blog"]');
    await page.waitForTimeout(300);
  };
  await page.goto(DASH_URL, { waitUntil: 'load' });
  await page.waitForTimeout(400);

  ok('noindex', (await page.getAttribute('meta[name=robots]', 'content')).includes('noindex'));

  console.log('\n— door —');
  ok('gate shown before anything else', await page.isVisible('#gateScr'));
  await mock.signIn(page, { password: 'nope' });
  await page.waitForTimeout(300);
  ok('wrong password refused', /hatal/i.test(await page.textContent('#gateErr')));
  ok('still closed', await page.isVisible('#gateScr'));
  await mock.signIn(page);
  await page.waitForTimeout(400);
  ok('correct account opens it', await page.isHidden('#gateScr'));
  ok('same session as the rest of the dashboard',
    await page.evaluate(() => !!JSON.parse(localStorage.getItem('anth_sb_session') || 'null')));
  await page.reload(); await page.waitForTimeout(400);
  ok('stays open on reload', await page.isHidden('#gateScr'));
  await openBlog();

  ok('no dark surface in the panel', await page.evaluate(() => {
    const rgb = getComputedStyle(document.body).backgroundColor.match(/\d+/g).map(Number);
    return (rgb[0] + rgb[1] + rgb[2]) / 3 > 200;
  }));
  ok('offline notice shown before setup', await page.isVisible('#offNote'));

  console.log('\n— a post starts from the plan —');
  // Content decides what gets written and when. The editor reads that calendar
  // rather than keeping a second copy of it, so these assertions are as much
  // about the build lifting the rows as about the button.
  ok('the plan reached the editor', await page.evaluate(() =>
    /var PLAN = \[\s*\{/.test(document.documentElement.innerHTML)));
  ok('Blog Ekle sits in the page header', await page.isVisible('#addBtn'));
  ok('the chooser is closed until asked', await page.isHidden('#planPick'));
  await page.click('#addBtn');
  await page.waitForTimeout(250);
  ok('it opens on a list of planned pieces', await page.isVisible('#planPick'));
  const planned = await page.$$eval('#planList button', bs => bs.length);
  ok('the list is capped at twelve', planned > 0 && planned <= 12, String(planned));
  const firstPlan = await page.$eval('#planList button .pt', e => e.textContent.trim());
  await page.click('#planList button');
  await page.waitForTimeout(250);
  ok('picking one fills the title', (await page.inputValue('#title')) === firstPlan,
     await page.inputValue('#title'));
  ok('…and the URL, from the title', /^[a-z0-9-]+$/.test(await page.inputValue('#slug')),
     await page.inputValue('#slug'));
  ok('…and the date, from the plan', /^\d{4}-\d{2}-\d{2}$/.test(await page.inputValue('#date')),
     await page.inputValue('#date'));
  ok('…and a category, chosen rather than left at the default',
     ['Strategy', 'Organisation', 'Technology', 'People', 'Field notes']
       .includes(await page.inputValue('#category')), await page.inputValue('#category'));
  ok('…and it says where the category came from',
     /plandaki/.test(await page.textContent('#msg')), await page.textContent('#msg'));
  ok('the chooser closes once a piece is picked', await page.isHidden('#planPick'));
  // The escape hatch: not everything written is on the calendar.
  await page.click('#addBtn');
  await page.waitForTimeout(200);
  await page.click('#planSkip');
  await page.waitForTimeout(200);
  ok('a blank post is still one click away', (await page.inputValue('#title')) === '');

  console.log('\n— the drafting tools stay dark without a key —');
  // The editor never holds the Gemini key; it only learns whether the server
  // has one. With no key the two buttons are disabled and say why, because a
  // button that fails when pressed teaches nothing.
  for (const [id, label] of [['#aiAllBtn', 'Oluştur'], ['#aiTrBtn', 'Çevir'],
                            ['#aiImgBtn', 'Görsel üret'], ['#pubPairBtn', 'EN + TR yayımla']]) {
    ok(`${label} exists`, await page.$(id) !== null);
    ok(`  …disabled with no key`, await page.isDisabled(id));
    ok(`  …and names the property to set`,
       /GEMINI_KEY/.test(await page.getAttribute(id, 'title') || ''),
       await page.getAttribute(id, 'title'));
  }
  // DEV-041. The editor's image prefix and the backend's BLOG_PREFIX have to be
  // the same string or a published post shows broken pictures. This half is
  // stamped from PREVIEW_DIR now rather than typed; the assertion is that it
  // was stamped at all, because an unfilled token would be silent.
  ok('the image prefix is stamped, not hand-typed', await page.evaluate(() =>
    /var SITE_PREFIX = '\/[a-z0-9-]*\/?'/.test(document.documentElement.innerHTML) &&
    !/__SITE_PREFIX__/.test(document.documentElement.innerHTML)));
  // …and the other half is now checked against the server's answer rather than
  // trusted. A mismatch is silent by nature: the upload succeeds and the
  // picture is simply never found.
  ok('the editor compares the two prefixes when it opens',
     await page.evaluate(() => /function prefixCheck\(/.test(document.documentElement.innerHTML)));
  ok('…and says which value to change, not just that something is wrong',
     await page.evaluate(() => {
       const src = document.documentElement.innerHTML;
       const fn = src.slice(src.indexOf('function prefixCheck('), src.indexOf('/* ---------- hero'));
       return /BLOG_PREFIX/.test(fn) && /SITE_PREFIX/.test(fn);
     }));

  console.log('\n— the plan reaches the editor from the other side —');
  // Content hands a row over rather than making anyone retype a title. The
  // section may never have been opened, so both directions have to exist.
  ok('the editor accepts a row from the Content section',
     await page.evaluate(() => typeof window.blogFromPlan === 'function'));
  ok('…and picks one up that was left before it was built',
     await page.evaluate(() => /__blogSeed/.test(document.documentElement.innerHTML)));

  console.log('\n— covers are WebP —');
  ok('the editor encodes WebP, with a fallback that is checked not assumed',
     await page.evaluate(() => {
       const src = document.documentElement.innerHTML;
       const fn = src.slice(src.indexOf('function encode('), src.indexOf('function canWebp('));
       return /image\/webp/.test(fn) && /indexOf\('data:image\/webp'\)/.test(fn);
     }));
  ok('nothing in the editor still writes a .jpg name',
     await page.evaluate(() => !/toDataURL\('image\/jpeg'\)/.test(document.documentElement.innerHTML)));

  ok('no Gemini key reached the browser',
     !/GEMINI_KEY\s*[:=]\s*['"][^'"]+['"]/.test(await page.content()));
  ok('neither tool publishes — both write into the form',
     await page.evaluate(() => {
       const src = document.documentElement.innerHTML;
       // aiWrite, aiAll, aiTranslate and illustrate — everything between the
       // first drafting function and the pair publisher, which is the one place
       // that is allowed to publish and does it with a person's finger on it.
       const fn = src.slice(src.indexOf('function aiWrite('), src.indexOf('function publishPair('));
       return !/save\('published'\)|api\('publish'/.test(fn);
     }));

  console.log('\n— slug —');
  await page.fill('#title', 'Yapay zekâ dönüşümü neden bir İNSAN problemi?');
  await page.waitForTimeout(150);
  const slug = await page.inputValue('#slug');
  ok('Turkish characters transliterate', slug === 'yapay-zeka-donusumu-neden-bir-insan-problemi', slug);
  await page.selectOption('#lang', 'en');
  await page.waitForTimeout(120);
  ok('English posts get the /en/blog/ prefix', (await page.textContent('#slugPre')) === '/en/blog/');
  await page.selectOption('#lang', 'tr');

  console.log('\n— validation —');
  await page.click('#pubBtn'); await page.waitForTimeout(200);
  ok('refuses to publish without body and excerpt', (await page.$$('.f.err')).length >= 2);

  console.log('\n— markdown preview —');
  await page.fill('#excerpt', 'Spot cümlesi.');
  await page.fill('#body', '## Başlık\n\nParagraf **kalın** ve *italik*.\n\n- bir\n- iki\n\n> Alıntı\n\n1. adım\n2. adım');
  await page.click('#tabPrev'); await page.waitForTimeout(250);
  const prev = await page.innerHTML('#panedPrev');
  ok('heading', prev.includes('<h2>Başlık</h2>'));
  ok('bold', prev.includes('<strong>kalın</strong>'));
  ok('italic', prev.includes('<em>italik</em>'));
  ok('bullets', /<ul><li>bir<\/li><li>iki<\/li><\/ul>/.test(prev));
  ok('numbered list', /<ol><li>adım<\/li>/.test(prev));
  ok('quote', prev.includes('<blockquote>Alıntı</blockquote>'));
  ok('escapes injected markup', await page.evaluate(() => {
    document.getElementById('body').value = '<script>alert(1)<\/script> & <b>x</b>';
    document.getElementById('tabPrev').click();
    return !document.getElementById('panedPrev').querySelector('script')
        && document.getElementById('panedPrev').innerHTML.includes('&lt;');
  }));
  console.log('\n— authors —');
  const authors = await page.$$eval('#author option', o => o.map(x => x.value));
  ok('exactly two authors', authors.length === 2, authors.join(','));
  ok('Eray Dengiz and Anthifel', authors.includes('Eray Dengiz') && authors.includes('Anthifel'));
  ok('author is a fixed list, not free text', (await page.$eval('#author', e => e.tagName)) === 'SELECT');

  console.log('\n— schedule —');
  ok('no strip for today', await page.isHidden('#sched'));
  await page.fill('#date', '2027-01-15');
  await page.waitForTimeout(200);
  ok('future date shows the strip', await page.isVisible('#sched'));
  ok('strip names the date in Turkish', /15 Ocak 2027/.test(await page.textContent('#schedTxt')));
  ok('button becomes "Zamanla"', (await page.textContent('#pubBtn')).trim() === 'Zamanla');
  await page.fill('#date', '2020-01-15');
  await page.waitForTimeout(200);
  ok('past date hides the strip', await page.isHidden('#sched'));
  ok('button reverts to "Yayımla"', /Yayımla/.test(await page.textContent('#pubBtn')));

  console.log('\n— image library —');
  ok('path field replaced by a picker', await page.$('#hero[type=hidden]') !== null);
  ok('placeholder shown when empty', /Görsel yok/.test(await page.textContent('#heroThumb')));
  await page.click('#libBtn'); await page.waitForTimeout(250);
  ok('library opens', await page.isVisible('#libOvl'));
  ok('empty library says so', await page.isVisible('#libEmpty'));
  ok('"use" disabled with nothing picked', await page.isDisabled('#libUse'));
  await page.click('#libClose'); await page.waitForTimeout(150);
  ok('library closes', await page.isHidden('#libOvl'));

  console.log('\n— upload and crop —');
  await page.click('#upBtn'); await page.waitForTimeout(200);
  ok('upload dialog opens on the file step', await page.isVisible('#pickWrap'));
  ok('upload button disabled before a file', await page.isDisabled('#upDo'));
  await page.setInputFiles('#file', path.resolve('assets/b3d4e4a2-dabe-414b-a6e1-475f65f4e1a9.png'));
  await page.waitForTimeout(900);
  ok('crop step appears', await page.isVisible('#cropWrap'));
  ok('upload button enabled', !(await page.isDisabled('#upDo')));

  const dims = await page.evaluate(() =>
    ['16x9', '4x3', '3x2', 'thumb'].map(k => {
      const c = document.getElementById('c' + k); return k + ':' + c.width + 'x' + c.height;
    }));
  ok('three design ratios plus a thumbnail',
    dims.join(' ') === '16x9:1600x900 4x3:1200x900 3x2:1200x800 thumb:320x213', dims.join(' '));

  const moved = await page.evaluate(async () => {
    const before = document.getElementById('cropDot').style.left;
    const box = document.getElementById('cropBox').getBoundingClientRect();
    document.getElementById('cropBox').dispatchEvent(new MouseEvent('click',
      { clientX: box.left + box.width * 0.2, clientY: box.top + box.height * 0.3, bubbles: true }));
    return { before, after: document.getElementById('cropDot').style.left };
  });
  ok('clicking sets the focal point', moved.before !== moved.after, moved.before + ' → ' + moved.after);

  ok('crops actually render pixels', await page.evaluate(() => {
    const c = document.getElementById('c3x2');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const seen = new Set();
    for (let i = 0; i < d.length; i += 4000) seen.add(d[i]);
    return seen.size > 1;   // more than a flat fill
  }));
  ok('produces a JPEG data URL', await page.evaluate(() =>
    document.getElementById('c3x2').toDataURL('image/jpeg', 0.82).indexOf('data:image/jpeg') === 0));

  ok('publish disabled before setup', /ÖNİZLEME/.test(await page.textContent('#offNote')));

  console.log('\n— the panel key is not in the page —');
  // The dashboard is served from a public address. A secret written into it is
  // published, whatever stands in front of it. These four assertions are the
  // whole guarantee, so they are worth more than the comment above them.
  const dashSrc = fs.readFileSync(path.resolve(DIST, 'dashboard/index.html'), 'utf8');

  /* Two files have to agree on one letter. The publisher writes the covers and
     the editor previews them, and on 15 August the publisher moved to WebP
     while the editor kept asking for .jpg — so every cover came back 404 and
     the editor showed a broken picture beside a post whose picture was fine on
     the site. Nothing failed; the editor simply lied about what it had. */
  {
    const gs = fs.readFileSync(path.resolve(__dirname, 'BlogCode.gs'), 'utf8');
    const pub = (gs.match(/var IMG_EXT\s*=\s*'([a-z0-9]+)'/) || [])[1];
    const ed = (dashSrc.match(/var IMG_EXT\s*=\s*'([a-z0-9]+)'/) || [])[1];
    ok('the publisher names the picture format it writes', !!pub, String(pub));
    ok('the editor reads the same format back', ed === pub, `publisher ${pub} vs editor ${ed}`);
    ok('…and no stray extension is left in the editor',
       !/heroUrl[\s\S]{0,160}\.(jpg|jpeg|png)'/.test(dashSrc),
       (dashSrc.match(/heroUrl[\s\S]{0,160}/) || [''])[0].slice(0, 120));

    /* The same trap, one level up: the list of derivatives lives in both files
       too. On 20 August a fifth was added — the JPEG share card — because
       LinkedIn does not read WebP for link previews and the first post shared
       as an empty box. If one file grows a variant and the other does not, the
       publisher writes a name nobody asks for or asks for a name nobody wrote,
       and the only symptom is a blank share card weeks later. */
    const keys = src => (src.match(/key:\s*'([a-z0-9]+)'/g) || [])
      .map(m => m.replace(/.*'([a-z0-9]+)'.*/, '$1')).sort().join(',');
    const pubKeys = keys((gs.match(/IMG_VARIANTS = \[[\s\S]*?\];/) || [''])[0]);
    const edKeys  = keys((dashSrc.match(/VARIANTS = \[[\s\S]*?\];/) || [''])[0]);
    ok('the two variant lists are the same list',
       pubKeys === edKeys && pubKeys.length > 0, `publisher ${pubKeys} vs editor ${edKeys}`);
    ok('…and one of them is the share card',
       /(^|,)og(,|$)/.test(pubKeys), pubKeys);
    /* The share card must not be WebP, whatever the site's format is. This is
       the assertion that would have caught it on 19 August. */
    ok('the share card is a format the crawlers read',
       /key:\s*'og'[^}]*ext:\s*'jpe?g'/.test(gs) &&
       /key:\s*'og'[^}]*jpeg:\s*true/.test(dashSrc),
       'og variant ext');
  }
  ok('no __DASH_TOKEN__ placeholder left to paste into', !dashSrc.includes('__DASH_TOKEN__'));
  ok('no key literal assigned anywhere',
     !/\bTOKEN\s*=\s*['"][^'"]{8,}['"]/.test(dashSrc),
     (dashSrc.match(/\bTOKEN\s*=\s*['"][^'"]{8,}['"]/g) || []).join(' '));
  ok('the key is read from this browser instead',
     /localStorage\.getItem\(\s*TOKEN_KEY\s*\)/.test(dashSrc));
  ok('and the editor asks for it when it is missing', await page.isVisible('#keyRow'));
  ok('…in a field that does not show what is typed',
     await page.getAttribute('#keyIn', 'type') === 'password');

  ok('no page errors', derr.length === 0, derr.join(' | '));
  await page.close();

  /* ---------------- two authors, one file ----------------
     build.py writes the Journal index's shell; the publisher, inside Google,
     writes the cards on it. Both write blog/index.html. On 15 August a deploy
     wrote the shell over a published page and the Journal went empty in both
     languages — and nothing said so, because a build writes files rather than
     visiting them.
     live/ holds a copy of what is actually deployed. The rule these checks
     hold: a build may never come out with fewer articles than the deployed
     page carries. Being behind is survivable; losing is not. */
  console.log('\n=== the Journal index the deploy would replace ===');
  {
    const cards = html => (html.match(/class="card"/g) || []).length +
                          (html.match(/class="feat"/g) || []).length;
    for (const rel of ['blog/index.html', 'en/blog/index.html']) {
      const livePath = path.resolve('live', path.basename(path.resolve(DIST)), rel);
      const builtPath = path.resolve(DIST, rel);
      if (!fs.existsSync(livePath)) {
        console.log(`  – ${rel}: no deployed copy in live/, nothing to compare`);
        continue;
      }
      const live = cards(fs.readFileSync(livePath, 'utf8'));
      const built = fs.existsSync(builtPath) ? cards(fs.readFileSync(builtPath, 'utf8')) : null;
      if (built === null) {
        // The build refused to write it. That is the safe answer, and it counts.
        ok(`${rel}: left alone rather than overwritten`, true);
        continue;
      }
      ok(`${rel}: the build loses no articles (${live} deployed, ${built} built)`,
         built >= live, `deployed ${live} → built ${built}`);
    }
  }

  /* The footer's Journal rows point at one piece that exists at two addresses.
     They used to point at the Turkish one whatever language the reader was in:
     the title swapped, the destination did not, and an English reader clicking
     an English headline landed on a Turkish page. */
  /* The Journal has two front pages, one per language, and the menu pointed at
     the Turkish one from every shell. An English reader clicked "The Journal"
     under an English menu and got Turkish headlines — the chrome was in their
     language and the writing was not.
     Six shells carry that link at four different depths, which is why this
     walks them all rather than checking the markup once. */
  console.log('\n=== the menu knows which Journal ===');
  {
    const SHELLS = ['index.html', 'about.html', 'ai-readiness-audit.html',
                    'cookies.html', 'blog/index.html', 'en/blog/index.html'];
    for (const f of SHELLS) {
      const p3 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
      await p3.goto('file://' + path.resolve(DIST, f), { waitUntil: 'load' });
      await p3.waitForTimeout(250);
      /* Both languages are set explicitly rather than read as they land. The
         two Journal indexes now take their own language on arrival, so reading
         the "English" href off the Turkish index without asking for English
         first measures the page's language, not the link's. */
      const read = async lang => {
        await p3.evaluate(l => { document.documentElement.lang = l; }, lang);
        await p3.waitForTimeout(150);
        return p3.evaluate(() => {
          const a = [...document.querySelectorAll('.nav a, header a')]
            .find(x => /The Journal/i.test(x.textContent));
          return a ? a.getAttribute('href') : null;
        });
      };
      const en = await read('en');
      const tr = await read('tr');
      /* Depth-agnostic on purpose: what matters is that English lands in
         /en/blog/ and Turkish does not, from wherever the page sits. */
      /* Two addresses, and the Turkish one says so: /blog/?lang=tr is what a
         reader is handed, because a bare /blog/ answers to whatever they last
         chose and that is not something you can put in an email. */
      ok(`${f}: English goes to the English Journal`,
         /(^|\/)en\/blog\/$/.test(en || ''), en);
      ok(`${f}: …and Turkish to the Turkish one, with its language on it`,
         /(^|\/)blog\/\?lang=tr$/.test(tr || '') && !/\/en\/blog\//.test(tr || ''), tr);
      await p3.close();
    }
  }

  console.log('\n=== the footer follows the reader ===');
  {
    const p2 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await p2.goto('file://' + path.resolve(DIST, 'index.html'), { waitUntil: 'load' });
    await p2.waitForTimeout(300);
    const rows = await p2.$$eval('#ftrPosts a', as => as.map(a => ({
      href: a.getAttribute('href'), tr: a.getAttribute('data-href-tr'),
      en: a.getAttribute('data-en'), trT: a.getAttribute('data-tr') })));
    ok('the reading list has rows', rows.length > 0, String(rows.length));
    ok('every row carries both titles', rows.every(r => r.en && r.trT));
    const paired = rows.filter(r => r.tr);
    if (paired.length) {
      ok('a published pair carries both addresses',
         paired.every(r => r.href !== r.tr), JSON.stringify(paired[0]));
      ok('the default address is the English one',
         paired.every(r => /(^|\/)en\/blog\//.test(r.href)), JSON.stringify(paired[0]));
      /* The swap itself, not the attribute: the footer's own script watches
         <html lang>, because only two of the four shells fire langchange. */
      const after = await p2.evaluate(() => {
        document.documentElement.lang = 'tr';
        return new Promise(r => setTimeout(() =>
          r([...document.querySelectorAll('#ftrPosts a[data-href-tr]')]
            .map(a => a.getAttribute('href'))), 150));
      });
      ok('…and switching to Turkish moves it to the Turkish page',
         after.every(h => /(^|\/)blog\//.test(h) && !/\/en\/blog\//.test(h)), after.join(' '));
    } else {
      console.log('  – nothing published as a pair yet; the planned rows have one address');
    }
    await p2.close();
  }

  await browser.close();
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
