# Anthifel — sitede tıklanabilir bağlantılar

12 Ağustos 2026 · yalnızca ziyaretçinin görüp tıklayabildiği bağlantılar.
Blog şablonları ve panel dışarıda: ikisi de yayında sunulmuyor.

## AI Readiness Audit

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | index.html#approach |
| Hizmetler | Services | index.html#services |
| Hazırlık Testi | Assessment | index.html#assessment |
| Blog | Blog | blog/ |
| İletişim | Contact | index.html#contact |
| Teklif alın | Request a quote | Aynı sayfada: #teklif |
| 30 dakikalık görüşme alın | Book a 30-minute call | Google Takvim — görüşme · yeni sekme |
| ← Siteye dön | ← Back to the site | index.html |
| Takvim açılmadıysa yeni sekmede açın | Calendar not loading? Open it in a new tab | Google Takvim — görüşme · yeni sekme |
| Gizlilik | Privacy | privacy.html |
| Kullanım Şartları | Terms | terms.html |
| Çerezler | Cookies | cookies.html |

## Blog (TR)

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | ../#approach |
| Hizmetler | Services | ../#services |
| Hazırlık Testi | Assessment | ../#assessment |
| Blog | Blog | ../blog/ |
| İletişim | Contact | ../#contact |
| — | Privacy Policy | ../privacy.html |
| — | Gizlilik Politikası | ../privacy.html |
| — | hello@anthifel.com | E-posta açar · hello@anthifel.com |
| Görüşme planla | Book a call | ../#meet |
| Gizlilik | Privacy | ../privacy.html |
| Kullanım Şartları | Terms | ../terms.html |
| Çerezler | Cookies | ../cookies.html |

## Çerezler

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | index.html#approach |
| Hizmetler | Services | index.html#services |
| Hazırlık Testi | Assessment | index.html#assessment |
| Blog | Blog | blog/ |
| İletişim | Contact | index.html#contact |
| Gizlilik Politikası | Privacy Policy | privacy.html |
| Kullanım Şartları | Terms of Use | terms.html |
| Çerez Politikası | Cookie Policy | cookies.html |
| — | privacy@anthifel.com | E-posta açar · privacy@anthifel.com |
| ← Siteye dön | ← Back to the site | index.html |
| Gizlilik | Privacy | privacy.html |
| Kullanım Şartları | Terms | terms.html |
| Çerezler | Cookies | cookies.html |

## Blog (EN)

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | ../../#approach |
| Hizmetler | Services | ../../#services |
| Hazırlık Testi | Assessment | ../../#assessment |
| Blog | Blog | ../../blog/ |
| İletişim | Contact | ../../#contact |
| — | Privacy Policy | ../../privacy.html |
| — | Gizlilik Politikası | ../../privacy.html |
| — | hello@anthifel.com | E-posta açar · hello@anthifel.com |
| Görüşme planla | Book a call | ../../#meet |
| Gizlilik | Privacy | ../../privacy.html |
| Kullanım Şartları | Terms | ../../terms.html |
| Çerezler | Cookies | ../../cookies.html |

## Ana sayfa

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | Aynı sayfada: #approach |
| Hizmetler | Services | Aynı sayfada: #services |
| Hazırlık Testi | Assessment | Aynı sayfada: #assessment |
| Blog | Blog | blog/ |
| İletişim | Contact | Aynı sayfada: #contact |
| AI Hazırlık Testi → | Readiness assessment → | Aynı sayfada: #assessment |
| Görüşme Ayarla | Book a 30-minute call | Google Takvim — görüşme · yeni sekme |
| — | Privacy Policy | privacy.html |
| — | Gizlilik Politikası | privacy.html |
| Takvim açılmadıysa yeni sekmede açın | Calendar not loading? Open it in a new tab | Google Takvim — görüşme · yeni sekme |
| — | hello@anthifel.com | E-posta açar · hello@anthifel.com |
| Görüşme planla | Book a call | Google Takvim — görüşme · yeni sekme |
| AI Dönüşümü Neden Teknoloji Değil, Organizasyon Problemidir? | Why AI transformation is a people problem | blog/ai-transformation-people-problem/ |
| Bir Şirketin AI’a Hazır Olduğunu Nasıl Anlarsın? 12 Sinyal | Twelve signals your company is ready for AI | blog/twelve-signals-ready-for-ai/ |
| “AI’dan Kim Sorumlu?” Sorusunun Cevabı Yoksa Dönüşüm Başlamamıştır | Who should own AI in your organisation? | blog/who-should-own-ai/ |
| Pilot Mezarlığı: Şirketler AI Projelerini Neden Gömüyor? | What a pilot project really tells you | blog/what-a-pilot-really-tells-you/ |
| Gizlilik | Privacy | privacy.html |
| Kullanım Şartları | Terms | terms.html |
| Çerezler | Cookies | cookies.html |
| — | privacy@anthifel.com | E-posta açar · privacy@anthifel.com |
| — | ico.org.uk | ico.org.uk · yeni sekme |
| Sayfanın tamamını aç | Open the full page | privacy.html |

## Gizlilik

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | index.html#approach |
| Hizmetler | Services | index.html#services |
| Hazırlık Testi | Assessment | index.html#assessment |
| Blog | Blog | blog/ |
| İletişim | Contact | index.html#contact |
| Gizlilik Politikası | Privacy Policy | privacy.html |
| Kullanım Şartları | Terms of Use | terms.html |
| Çerez Politikası | Cookie Policy | cookies.html |
| — | privacy@anthifel.com | E-posta açar · privacy@anthifel.com |
| — | ico.org.uk | ico.org.uk · yeni sekme |
| ← Siteye dön | ← Back to the site | index.html |
| Gizlilik | Privacy | privacy.html |
| Kullanım Şartları | Terms | terms.html |
| Çerezler | Cookies | cookies.html |

## Kullanım Şartları

| Türkçe | İngilizce | Nereye gider |
|---|---|---|
| Yaklaşım | Approach | index.html#approach |
| Hizmetler | Services | index.html#services |
| Hazırlık Testi | Assessment | index.html#assessment |
| Blog | Blog | blog/ |
| İletişim | Contact | index.html#contact |
| Gizlilik Politikası | Privacy Policy | privacy.html |
| Kullanım Şartları | Terms of Use | terms.html |
| Çerez Politikası | Cookie Policy | cookies.html |
| — | privacy@anthifel.com | E-posta açar · privacy@anthifel.com |
| ← Siteye dön | ← Back to the site | index.html |
| Gizlilik | Privacy | privacy.html |
| Kullanım Şartları | Terms | terms.html |
| Çerezler | Cookies | cookies.html |

---

**Toplam 98 tıklanabilir bağlantı**, 7 tanesi siteden çıkıyor.
