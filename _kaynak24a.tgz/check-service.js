/**
 * check-service.js — Anthifel
 *
 * The service pages. There are four, and they exist because the result screen
 * used to send its warmest visitors to a catalogue row (Developer brief §C.1).
 * What is checked here is the part that can rot without anyone noticing: that
 * each page still speaks both languages, that no figure ever appears on it,
 * that the quote form records nothing while it is switched off, and that the
 * booking window behaves the same here as it does on the landing page.
 *
 * Every page runs the same checks. Three of them are generated from Business's
 * copy by make_services.py, so a page that drifts from the others is a bug in
 * the generator rather than in one file, and that is exactly the bug a suite
 * running over all four will catch and a suite running over one will not.
 */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const DIR = path.resolve(process.argv[2] || 'dist/preview');

/* One entry per page. Everything outside this table is checked identically on
   all four, which is the point: the three new pages are generated from one
   template, so a difference between them is a bug in the generator. What lives
   here is only what genuinely differs — the name, a phrase from each language
   that proves the right copy landed, and the shape Business gave that page. */
const SPECS = {
  'ai-readiness-audit.html': {
    name: 'AI Readiness Audit',
    en: /honest picture of where you stand/i,
    tr: /dürüst bir fotoğrafı/,
    trSub: /AI hazırlık denetimi/,
    sections: 6, dayRows: 6, bullets: 5,
    meta: { en: /4 working days/, tr: /4 iş günü/ },
  },
  'discovery-sprint.html': {
    name: 'Discovery Sprint',
    en: /the rooms that matter/i,
    tr: /günler ve odalar/,
    trSub: /Keşif ve yol haritası programı/,
    sections: 7, dayRows: 8, bullets: 6,
    meta: { en: /7 to 12 working days/, tr: /7 ile 12 iş günü/ },
  },
  'transformation-retainer.html': {
    name: 'Transformation Retainer',
    en: /a rhythm that holds/i,
    tr: /Tutan bir ritim/,
    trSub: /Sürekli dönüşüm rehberliği/,
    sections: 9, dayRows: 3, bullets: 6,
    meta: { en: /Minimum 6 months/, tr: /Minimum 6 ay/ },
  },
  'advisory-board-seat.html': {
    name: 'Advisory Board Seat',
    en: /A seat at your table/i,
    tr: /Masanızda bir sandalye/,
    trSub: /Danışma kurulu koltuğu/,
    sections: 5, dayRows: 0, bullets: 9,
    meta: { en: /Minimum 12 months/, tr: /Minimum 12 ay/ },
  },
};
const PAGES = Object.keys(SPECS);
let pass = 0, fail = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  for (const name of PAGES) {
    const spec = SPECS[name];
    console.log(`\n=== ${name} ===`);
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const errs = [];
    page.on('pageerror', e => errs.push(String(e)));
    const posted = [];
    page.on('request', r => { if (r.method() === 'POST') posted.push(r.postData() || ''); });
    const offsite = [];
    page.on('request', r => {
      const u = r.url();
      if (!/^(file|data|blob|about):/.test(u)) offsite.push(u.split('?')[0]);
    });
    /* The quote form posts for real now. Answered here so the suite exercises
       the whole path without a single request leaving the machine — and so a
       page that quietly stopped posting fails rather than passing quietly. */
    const slug = name.replace(/\.html$/, '');
    await page.route('**script.google.com/**', r =>
      r.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' }));
    await page.route('**calendar.google.com/**', r =>
      r.fulfill({ status: 200, contentType: 'text/html', body: '<p>schedule</p>' }));

    const FILE = 'file://' + path.join(DIR, name);
    await page.goto(FILE, { waitUntil: 'load' });
    await page.waitForTimeout(400);

    console.log('\n— nothing leaves the page on a plain visit —');
    ok('no third-party request on load', offsite.length === 0, offsite.join(' '));

    console.log('\n— no prices, ever (K50) —');
    // Both languages at once: the copy for the language that is not showing
    // lives in data-tr, and a price could hide there just as easily.
    const all = await page.evaluate(() => {
      const c = document.body.cloneNode(true);
      c.querySelectorAll('style,script').forEach(e => e.remove());
      // The privacy modal is on every page now. What it holds is Legal's
      // notice, word for word, and it is checked on its own page by
      // check-legal — under Legal's rules, which permit an em dash and would
      // never carry a price. Reading it here would make every page fail a
      // marketing rule for a document marketing does not write.
      c.querySelectorAll('.povl').forEach(e => e.remove());
      let extra = '';
      c.querySelectorAll('[data-en]').forEach(e => {
        extra += ' ' + (e.getAttribute('data-en') || '') + ' ' + (e.getAttribute('data-tr') || '');
      });
      return c.textContent + extra;
    });
    ok('no currency figure anywhere', !/[£$€₺]\s?\d|\d\s?(GBP|USD|EUR|TL)\b/i.test(all),
      (all.match(/[£$€₺]\s?[\d,.]+/g) || []).join(' '));
    ok('no "starting from" construction', !/\bfrom £|başlangıç fiyat|itibaren fiyat/i.test(all));
    ok('rule 2 — no em dash in customer-facing copy', !all.includes('—'),
      (all.match(/.{30}—.{30}/) || [''])[0]);

    console.log('\n— the name is fixed English (Business K34) —');
    ok('h1 is the service name', (await page.textContent('h1')).trim() === spec.name,
       await page.textContent('h1'));
    ok('h1 carries no translation', await page.getAttribute('h1', 'data-tr') === null);

    console.log('\n— both languages —');
    ok('starts in English', (await page.getAttribute('html', 'lang')) === 'en');
    ok('English body copy is there', spec.en.test(await page.textContent('body')));
    ok('the English duration line is Business\'s', spec.meta.en.test(await page.textContent('.svc-meta')),
       await page.textContent('.svc-meta'));
    await page.click('.lang button[data-lang="tr"]');
    await page.waitForTimeout(250);
    ok('switches to Turkish', (await page.getAttribute('html', 'lang')) === 'tr');
    const tr = await page.textContent('body');
    ok('Turkish body copy is there', spec.tr.test(tr));
    ok('the Turkish reading sits under the name', spec.trSub.test(tr));
    ok('the name did not translate', tr.includes(spec.name));
    ok('the Turkish duration line is Business\'s', spec.meta.tr.test(await page.textContent('.svc-meta')),
       await page.textContent('.svc-meta'));
    // ?lang=tr is how a quote or an email will link to this page.
    const p2 = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await p2.goto(FILE + '?lang=tr', { waitUntil: 'load' });
    await p2.waitForTimeout(300);
    ok('?lang=tr opens in Turkish', (await p2.getAttribute('html', 'lang')) === 'tr');
    await p2.close();
    await page.click('.lang button[data-lang="en"]');
    await page.waitForTimeout(250);

    console.log('\n— the sections Business wrote —');
    ok(`${spec.sections} sections`, (await page.$$('.svc-sec')).length === spec.sections,
       String((await page.$$('.svc-sec')).length));
    ok(`${spec.dayRows} rows in the schedule`, (await page.$$('.svc-days dt')).length === spec.dayRows,
       String((await page.$$('.svc-days dt')).length));
    ok(`${spec.bullets} bullets`, (await page.$$('.svc-bd ul li')).length === spec.bullets,
       String((await page.$$('.svc-bd ul li')).length));

    console.log('\n— the two buttons, ranked (§C.3) —');
    const top = await page.$$eval('main .wrap > .svc-cta .btn', bs =>
      bs.map(b => ({ cls: b.className, href: b.getAttribute('href') })));
    ok('two buttons at the top', top.length === 2, JSON.stringify(top));
    ok('primary is filled and asks for a quote',
      /btn-p/.test(top[0].cls) && top[0].href === '#teklif', JSON.stringify(top[0]));
    ok('secondary is outlined and books the call',
      /btn-s/.test(top[1].cls) && /calendar\.google\.com/.test(top[1].href), JSON.stringify(top[1]));
    // 10 August, CEO: one pair of buttons on the page. The foot repeated them,
    // which read as a page that does not know what it wants.
    ok('the pair is not repeated at the foot', (await page.$$('.svc-foot .btn')).length === 0);
    ok('#teklif resolves', await page.$('#teklif') !== null);

    console.log('\n— the quote form —');
    ok('four fields, no more', (await page.$$('#qf .fld')).length === 4);
    for (const id of ['qname', 'qemail', 'qcompany', 'qsize']) {
      ok(`field ${id} exists`, await page.$('#' + id) !== null);
    }
    ok('honeypot exists and is parked off-screen', await page.evaluate(() => {
      const el = document.querySelector('[name=website]');
      return !!el && el.getBoundingClientRect().left < -1000;
    }));
    ok('the one-working-day promise is on screen',
      /one working day/i.test(await page.textContent('.svc-form')));
    // Empty submit: four complaints, nothing sent.
    await page.click('#qsend');
    await page.waitForTimeout(200);
    ok('an empty form is refused, field by field', await page.evaluate(() =>
      ['e-name', 'e-email', 'e-company', 'e-size'].every(i => document.getElementById(i).textContent.trim())));
    ok('nothing was sent', posted.length === 0);
    const formLive = /var FORM_LIVE\s*=\s*true;/.test(await page.content());
    await page.fill('#qname', 'Test Person');
    await page.fill('#qemail', 'test@example.com');
    await page.fill('#qcompany', 'Test Ltd');
    await page.selectOption('#qsize', '50-149');
    await page.click('#qsend');
    await page.waitForTimeout(300);
    /* 20 August, launch. This used to assert the opposite — that the form said
       it was switched off and sent nothing — which was a description of
       FORM_LIVE, not of the form. With the switch on, a quote form that sends
       nothing is the failure. So the endpoint is answered locally (nothing
       reaches Google; the route intercepts before the request leaves) and what
       is asserted is the packet and the receipt: the four fields the visitor
       filled, the service they were looking at, and a confirmation in place of
       the form so nobody submits twice. */
    if (formLive) {
      ok('the quote is sent', posted.length === 1, posted.join(' | '));
      const d = JSON.parse(posted[0] || '{}');
      ok('…as a quote request', d.source === 'quote-request', d.source);
      ok('…naming the service the visitor was reading', d.service === slug, d.service);
      ok('…with the four fields they filled',
         d.name === 'Test Person' && d.email === 'test@example.com' &&
         d.company === 'Test Ltd' && d.size === '50-149', JSON.stringify(d));
      ok('…and the form is replaced by a confirmation',
         await page.$('.svc-form .stamp') !== null,
         (await page.textContent('.svc-form')).slice(0, 80));
      ok('…so it cannot be submitted twice', await page.$('#qsend') === null);
    } else {
      ok('switched off, and it says so', await page.isVisible('#qdev'));
      ok('still nothing sent', posted.length === 0, posted.join(' | '));
    }

    console.log('\n— the booking band, same as the landing page —');
    ok('no calendar request before the click',
      !offsite.some(u => u.includes('calendar.google.com')), offsite.join(' '));
    ok('the band is closed until asked', await page.isHidden('#meet'));
    await page.click('main .wrap > .svc-cta a[data-meet]');
    await page.waitForTimeout(600);
    ok('clicking opens the band', await page.isVisible('#meet'));
    ok('the page did not navigate away', page.url().includes(name));
    ok('the schedule is embedded', /gv=true/.test(await page.getAttribute('#meet iframe', 'src') || ''));
    ok('the briefing came with it', /keşif görüşmesi|discovery call/i.test(
      await page.getAttribute('#meet .mmintro', 'data-en') || ''));
    await page.keyboard.press('Escape');
    await page.waitForTimeout(300);
    ok('Escape closes it', await page.isHidden('#meet'));

    console.log('\n— the site menu —');
    // A visitor arriving on this page from a quote or an email has to be able
    // to get anywhere else without going home first.
    const nav = await page.$$eval('.nav a', as => as.map(a => a.getAttribute('href')));
    ok('the menu is on the page', nav.length === 5, nav.join(' '));
    ok('its anchors resolve against the home page',
      nav.filter(h => h.startsWith('index.html#')).length === 4, nav.join(' '));
    /* Relative, and aimed by language. The default is the English Journal and
       the Turkish address rides along in data-href-tr; both are relative, which
       is what makes the same file work at /preview/ and at the root. */
    ok('the blog link is relative', nav.includes('en/blog/'), nav.join(' '));
    ok('…and carries the Turkish Journal beside it',
       (await page.$$eval('.nav a', as => as.map(a => a.getAttribute('data-href-tr'))))
         .includes('blog/?lang=tr'));
    ok('it folds into a burger on a narrow screen', await page.evaluate(() => {
      const b = document.getElementById('burger');
      return !!b && getComputedStyle(b).display === 'none';
    }));

    console.log('\n— the site\'s gutter, not this page\'s own —');
    // This page sat in a 1280px box with grey either side while the rest of the
    // site ran edge to edge. Same rule now, and it is measured rather than
    // assumed: header full width, wordmark on the 1136px column.
    const g = await page.evaluate(() => {
      const h = document.querySelector('.hdr').getBoundingClientRect();
      const img = document.querySelector('.hdr img').getBoundingClientRect();
      return { left: Math.round(h.left), right: Math.round(innerWidth - h.right),
               mark: Math.round(img.left), bg: getComputedStyle(document.body).backgroundColor };
    });
    ok('the header runs edge to edge', g.left === 0 && g.right === 0, JSON.stringify(g));
    ok('the gutter is the site\'s 72px floor at 1280px', g.mark === 72, JSON.stringify(g));
    ok('no second background behind the page', g.bg === 'rgb(245, 241, 234)', g.bg);

    console.log('\n— links and chrome —');
    const hrefs = await page.$$eval('a[href]', as => as.map(a => a.getAttribute('href')));
    ok('no href="#" placeholders', !hrefs.includes('#'));
    ok('no absolute internal links', !hrefs.some(h => h.startsWith('/')), hrefs.filter(h => h.startsWith('/')).join(' '));
    ok('back to the site, relatively', hrefs.includes('index.html'));
    ok('the three legal links are in the footer',
      ['privacy.html', 'terms.html', 'cookies.html'].every(h => hrefs.includes(h)));
    ok('wordmark ≥ 15 px', await page.$eval('img[alt="Anthifel"]',
      i => i.getBoundingClientRect().height >= 15));

    // Business, 12 August: the Audit came down from seven working days to four,
    // and the report from 15-25 pages to 12-18. The old numbers are the kind of
    // thing that survives in one corner of a page for months.
    console.log('\n— the numbers Business changed on 12 August —');
    if (name === 'ai-readiness-audit.html') {
      // innerText, not textContent: the page carries its fonts inlined inside a
      // <style> in the body, and base64 contains every character there is. A
      // price check that reads style rules finds a currency symbol every time.
      const text = await page.evaluate(() => document.body.innerText);
      const html = await page.content();
      ok('four working days, not seven',
         /4 working days|4 iş günü/.test(html) && !/7 working days|7 iş günü/.test(html));
      ok('the process block is four days',
         /Four days|Dört gün/.test(html) && !/Seven days|Yedi gün/.test(html));
      ok('the pre-work pack is named', /Pre-work|Ön çalışma/.test(html));
      ok('the presentation is within two working days of delivery',
         /two working days of delivery|iki iş günü içinde/.test(html));
      ok('the report is 12 to 18 pages',
         /12 to 18|12 ile 18/.test(html) && !/15 to 25|15 ile 25/.test(html));
      ok('the page says why the time came down, not just that it did',
         /the scope did not|kapsam küçülmedi/.test(html));
      // The price rule, 12 August: never spoken, always written.
      ok('the quote is promised in writing, with its scope',
         /in writing, with its scope|kapsamıyla birlikte yazılı/.test(html));
      ok('and still no price anywhere', !/£|\$|€|TL\b/.test(text));
    } else {
      // The other three carry no report length and no day count of their own to
      // go stale, but the price rule and the writing promise apply everywhere.
      const text = await page.evaluate(() => document.body.innerText);
      const html = await page.content();
      ok('the quote is promised in writing, with its scope',
         /in writing, with its scope|kapsamıyla birlikte yazılı/.test(html));
      ok('no price anywhere', !/£|\$|€|TL\b/.test(text));
      // §4: a single tier's number belongs in the proposal, never on the site.
      // Read from innerText, not the source: the first version of this check
      // read the HTML and caught the build comment that says these numbers must
      // not appear. What matters is what a visitor sees.
      ok('no tier and no headcount cap leaked from the proposal',
         !/7, 10|10 gün|500\+ çalışan|150–500 çalışan/.test(text));
    }

    // The privacy modal reached these pages on 13 August. Until then the consent
    // box in the reading list linked away, and a visitor who clicked it lost the
    // tick and usually the page. The band is on every page, so the modal has to
    // be too — and it has to arrive whole, which is what these four lines check:
    // hidden at rest, opened by the link, readable, and closable.
    console.log('\n— the privacy notice opens in place —');
    ok('the modal is on the page', await page.$('#povl') !== null);
    ok('hidden until asked', await page.isHidden('#povl'));
    await page.click('.ncons label a[href$="privacy.html"]');
    await page.waitForTimeout(150);
    ok('the reading list\'s consent link opens it', await page.isVisible('#povl'));
    ok('the page did not navigate away', page.url().includes(name));
    ok('it carries Legal\'s notice, not a summary',
       /privacy@anthifel.com/.test(await page.textContent('#povl')));
    // The close button is the control that dismisses a dialog covering the page.
    // On these pages `.btn` is 21px tall, which is why the part brings its own.
    const pmH = await page.$eval('#pmDone', b => Math.round(b.getBoundingClientRect().height));
    ok('the close button clears the 44px touch floor', pmH >= 44, String(pmH));
    // The language switch on this shell does not dispatch an event and does not
    // touch [data-pane] — it only writes lang onto <html>. The part watches that
    // attribute for exactly this reason, and this is the assertion that fails if
    // someone removes the observer as redundant.
    // Clicked through the DOM, not the mouse: the modal is open and covering the
    // switch, which is the whole point of testing it in this state.
    await page.$eval('.lang button[data-lang="tr"]', b => b.click());
    await page.waitForTimeout(200);
    const pane = await page.evaluate(() => {
      const en = document.querySelector('#povl .pmpane[data-pane="en"]');
      const tr = document.querySelector('#povl .pmpane[data-pane="tr"]');
      return { en: en && en.hidden, tr: tr && tr.hidden };
    });
    ok('the notice follows the language switch', pane.en === true && pane.tr === false,
       JSON.stringify(pane));
    await page.$eval('.lang button[data-lang="en"]', b => b.click());
    await page.waitForTimeout(150);
    await page.keyboard.press('Escape');
    await page.waitForTimeout(150);
    ok('Escape closes it', await page.isHidden('#povl'));

    console.log('\n— js —');
    ok('no page errors', errs.length === 0, errs.join(' | '));
    await page.close();
  }

  /* ---------------- About ---------------- */
  // Same shell as the service pages, different rules. It is checked here rather
  // than in a suite of its own because what it shares with them — the chrome,
  // the language switch, the gutter — is exactly what would drift.
  {
    console.log('\n=== about.html ===');
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const errs = [];
    page.on('pageerror', e => errs.push(String(e)));
    const posted = [];
    page.on('request', r => { if (r.method() === 'POST') posted.push(r.postData() || ''); });
    await page.route('**calendar.google.com/**', r =>
      r.fulfill({ status: 200, contentType: 'text/html', body: '<p>schedule</p>' }));
    const FILE = 'file://' + path.join(DIR, 'about.html');
    await page.goto(FILE, { waitUntil: 'load' });
    await page.waitForTimeout(400);

    console.log('\n— four sections, two languages —');
    /* Three, then four, and three again.
       "The company" was added on 13 August at the CEO's instruction. On
       20 August Marketing read the live page against Brand Guidelines §13b/§13c
       and asked for their text back word for word — their argument being that a
       page half in one hand and half in another is worse than either. The CEO
       ruled for Marketing, so the fourth section came out with the four service
       links that lived in it. §13a's point is unchanged and is what these
       assertions exist for: this page does not grow. */
    ok('three sections, no more (§13a)', (await page.$$('.ab-sec')).length === 3);
    // The same rule the service pages are held to. The new section was written
    // here rather than lifted from a document that permits them.
    const abAll = await page.evaluate(() => {
      const c = document.body.cloneNode(true);
      c.querySelectorAll('style,script,.povl').forEach(e => e.remove());
      let extra = '';
      c.querySelectorAll('[data-en]').forEach(e => {
        extra += ' ' + (e.getAttribute('data-en') || '') + ' ' + (e.getAttribute('data-tr') || '');
      });
      return c.textContent + extra;
    });
    ok('rule 2 — no em dash in customer-facing copy', !abAll.includes('—'),
       (abAll.match(/.{30}—.{30}/) || [''])[0]);
    const heads = await page.$$eval('.ab-sec h2', hs => hs.map(h => h.textContent.trim()));
    ok('and they are the three §13b names',
       JSON.stringify(heads) === JSON.stringify(['The name','What we do','Who runs it']),
       JSON.stringify(heads));
    ok('the English copy is Marketing\'s',
       /the Greek/i.test(await page.textContent('body')) &&
       /no account layer/i.test(await page.textContent('body')));
    await page.click('.lang button[data-lang="tr"]');
    await page.waitForTimeout(250);
    const tr = await page.textContent('body');
    // §13c: written separately, not translated. Two phrases that only exist in
    // the Turkish text, so a machine translation of the English would fail here.
    ok('the Turkish copy is its own text, not a translation',
       /kökünden gelir/.test(tr) && /ara katman yok/.test(tr));
    ok('the title changes language too',
       (await page.title()).startsWith('Hakkımızda'), await page.title());
    ok('the portrait\'s alt text changes with it',
       (await page.getAttribute('.ab-portrait', 'alt')) === "Eray Dengiz, Anthifel'in kurucusu",
       await page.getAttribute('.ab-portrait', 'alt'));
    ok('…and so does the steps picture\'s',
       /basamak/i.test(await page.getAttribute('.ab-steps img', 'alt') || ''),
       await page.getAttribute('.ab-steps img', 'alt'));
    await page.click('.lang button[data-lang="en"]');
    await page.waitForTimeout(250);
    ok('…and back', (await page.getAttribute('.ab-portrait', 'alt')) === 'Eray Dengiz, founder of Anthifel');

    console.log('\n— the portrait (§13a-2) —');
    const pt = await page.evaluate(() => {
      const i = document.querySelector('.ab-portrait');
      const s = getComputedStyle(i);
      const r = i.getBoundingClientRect();
      return { round: s.borderRadius, border: s.borderStyle, shadow: s.boxShadow,
               ratio: +(r.width / r.height).toFixed(2), w: Math.round(r.width) };
    });
    ok('square', pt.ratio === 1, String(pt.ratio));
    ok('no rounding, no border, no shadow',
       parseFloat(pt.round) === 0 && pt.border === 'none' && pt.shadow === 'none',
       JSON.stringify(pt));
    ok('drawn between 420 and 480 px on a desktop', pt.w >= 420 && pt.w <= 480, String(pt.w));

    console.log('\n— one call to action, under the bio, and it is the call (§13e) —');
    const cta = await page.$$eval('.ab-acts a', as =>
      as.map(a => ({ href: a.getAttribute('href'), text: a.textContent.trim() })));
    // §13e is about invitations to buy, not about the number of anchors: the
    // LinkedIn button goes to a person and asks for nothing, so it is allowed
    // beside the call. What is not allowed is a second thing to book.
    const books = cta.filter(a => /calendar\.google\.com/.test(a.href || ''));
    ok('exactly one booking link', books.length === 1, JSON.stringify(cta));
    ok('it says the call is free', /free|Ücretsiz/i.test(books[0].text), books[0].text);
    ok('any second button is LinkedIn and nothing else',
       cta.every(a => /calendar\.google\.com/.test(a.href || '') || /linkedin\.com/i.test(a.href || '')),
       JSON.stringify(cta));
    // It sits in the same column as the bio — under the sentence that makes the
    // offer, not in a band under the page. Measured, because 'under the bio' is
    // a position, and a class name can be right while the position is wrong.
    const under = await page.evaluate(() => {
      const acts = document.querySelector('.ab-acts');
      const bio  = document.querySelector('.ab-who .ab-col > div');
      if(!acts || !bio) return null;
      const a = acts.getBoundingClientRect(), b = bio.getBoundingClientRect();
      return { below: a.top >= b.bottom - 1, aligned: Math.abs(a.left - b.left) < 2,
               gap: Math.round(a.top - b.bottom) };
    });
    ok('it sits directly under the bio, in the same column',
       !!under && under.below && under.aligned, JSON.stringify(under));
    // The site menu and the footer carry an assessment link on every page and
    // must keep it. §13e is about this page's own body: the visitor came to
    // read, and a test that read the chrome would ban the wrong thing.
    const bodyHrefs = await page.$$eval('main a[href]', as => as.map(a => a.getAttribute('href')));
    ok('the page body offers no assessment link',
       !bodyHrefs.some(h => /#assessment/.test(h || '')), bodyHrefs.join(' '));
    ok('…while the shared menu still carries one',
       (await page.$$eval('a[href]', as => as.map(a => a.getAttribute('href'))))
         .some(h => /#assessment/.test(h || '')));

    // The steps photograph, in "What we do". It is drawn only when the file is in
    // assets/, which means "it is not there" and "it was never wired up" look the
    // same on the page — so the test asserts the picture, not the plumbing.
    console.log('\n— the picture in "What we do" —');
    const st = await page.evaluate(() => {
      const f = document.querySelector('.ab-steps img');
      if (!f) return null;
      const r = f.getBoundingClientRect(), s = getComputedStyle(f);
      // It sits between the pair and What we do now, on the page's own measure.
      const sec = document.querySelector('.ab-do').getBoundingClientRect();
      return { w: Math.round(r.width), sec: Math.round(sec.width), src: f.getAttribute('src').slice(0, 20),
               round: parseFloat(s.borderRadius), border: s.borderStyle, shadow: s.boxShadow,
               alt: f.getAttribute('alt') };
    });
    ok('it is on the page', st !== null);
    ok('inlined like every other image here', st && st.src.startsWith('data:image/webp'), st && st.src);
    ok('it lines up with the sections above and below it',
       st && Math.abs(st.w - st.sec) < 2, JSON.stringify(st));
    ok('no frame, no rounding, no shadow',
       st && st.round === 0 && st.border === 'none' && st.shadow === 'none', JSON.stringify(st));
    ok('it carries alt text', st && st.alt && st.alt.length > 12, st && st.alt);

    // The profile URL arrived on 15 August. Until then the button was not drawn
    // at all, which is the state this assertion protects against returning to.
    const li = await page.$$eval('.ab-acts a[href*="linkedin.com"]', as =>
      as.map(a => ({ href: a.getAttribute('href'), t: a.target, rel: a.getAttribute('rel') })));
    ok('the LinkedIn button is drawn, once', li.length === 1, JSON.stringify(li));
    ok('it points at the founder\'s own profile',
       li[0] && /^https:\/\/www\.linkedin\.com\/in\/[^/]+\/?$/.test(li[0].href), JSON.stringify(li));
    ok('it opens in a new tab and cannot reach back',
       li[0] && li[0].t === '_blank' && /noopener/.test(li[0].rel || ''), JSON.stringify(li));

    ok('the privacy notice is on this page too', await page.$('#povl') !== null);

    console.log('\n— 13a: the Turkish address —');
  // The page has two addresses and is not two pages. /hakkimizda has to open in
  // Turkish for someone arriving from a search result with nothing stored and an
  // English browser: a URL that says Turkish and renders English is a broken
  // promise, not a default.
  {
    const tp = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await tp.addInitScript(() => { try { localStorage.clear(); } catch (e) {} });
    await tp.goto('file://' + path.join(DIR, 'hakkimizda.html'), { waitUntil: 'load' });
    await tp.waitForTimeout(350);
    ok('the Turkish address exists', true);
    ok('it opens in Turkish', await tp.evaluate(() => document.documentElement.lang) === 'tr');
    ok('…and says so before any script runs',
       /<html lang="tr"/.test(fs.readFileSync(path.join(DIR, 'hakkimizda.html'), 'utf-8')));
    ok('its title is the Turkish one', (await tp.title()).startsWith('Hakkımızda'), await tp.title());
    ok('it is the same page, not a second one',
       (await tp.$$eval('.ab-sec h2', h => h.length)) === 3);
    // The footer link follows the language, so the Turkish reader lands on the
    // Turkish address and can send it on as it stands.
    ok('the footer points at the Turkish address in Turkish',
       (await tp.getAttribute('.ftr a[data-href-tr]', 'href')) === 'hakkimizda.html',
       await tp.getAttribute('.ftr a[data-href-tr]', 'href'));
    await tp.click('.lang button[data-lang="en"]');
    await tp.waitForTimeout(250);
    ok('…and at the English one in English',
       (await tp.getAttribute('.ftr a[data-href-tr]', 'href')) === 'about.html',
       await tp.getAttribute('.ftr a[data-href-tr]', 'href'));
    await tp.close();
  }

  console.log('\n— §13d: the founder, and where the line now is —');
    const text = await page.evaluate(() => document.body.innerText);
    /* This block was written against §13d as it stood: no figure, no scale, no
       exit. On 16 August the CEO replaced the founder's paragraph with a
       Marketing-approved text that carries all three — around three hundred
       companies, close to a thousand people, a company's sale and investment
       process. The old assertions would not have caught any of it, because the
       new text spells its numbers out in words, and a rule that passes by
       accident of wording is not a rule.
       So the line is redrawn where the decision actually put it, and the
       Brand Guidelines §13d text needs the same edit — otherwise the next
       person to read them will "fix" this page back. */

    /* Written out, not printed. "three hundred companies" is a working life;
       "300+ clients" is a claim on a billboard, and the difference is the whole
       of this page's voice. */
    const dated = text.replace(/\b20 (August|Ağustos) 2026\b/g, 'FOUNDED');
    /* 20 August: the trading disclosure joins the founding date as an exemption,
       and for the same reason. The rule is about voice — "three hundred
       companies" rather than "300+ clients" — and a company number and a
       registered office are neither voice nor a claim. They are facts a
       regulation requires to be reproduced exactly, and spelling them out in
       words would be a breach of it. The exemption is the disclosure line
       itself, not "any number in the footer": everything else in that footer is
       still held to the rule. */
    /* Read from the DOM, not by regexing innerText. The first version of this
       matched "the line with the company number in it", which was true while
       the disclosure was one line in the bottom bar; on 20 August it became a
       four-line block in the brand column and the assertion started reading a
       third of it. What identifies the disclosure is its markup, so ask the
       markup. */
    const disclosed = await page.evaluate(() =>
      [...document.querySelectorAll('.ftr-brand .imp-name, .ftr-brand .imprint')]
        .map(e => e.innerText).join(' | '));
    ok('§13d: the disclosure names the registered company',
       /Anthifel Ltd/.test(disclosed), disclosed.slice(0, 200));
    ok('§13d: …with its number', /17411895/.test(disclosed), disclosed.slice(0, 200));
    ok('§13d: …where it is registered',
       /England and Wales|İngiltere ve Galler/.test(disclosed), disclosed.slice(0, 200));
    ok('§13d: …and its registered office',
       /Leroy House[\s\S]{0,60}London N1 3FY/.test(disclosed), disclosed.slice(0, 200));
    /* The disclosure is exempt from the numbers-in-words rule: a company number
       and a street number are facts a regulation requires reproduced exactly,
       not the page's voice. Removed by content rather than by line, because the
       block's shape is what just changed under this test. */
    const withoutImprint = disclosed
      .split(' | ')
      .reduce((acc, part) => acc.split(part).join(' '), dated);
    const figures = (withoutImprint.match(/\b\d[\d.,]*\b/g) || []).filter(n => !/^(2026|30)$/.test(n));
    ok('every number but the founding date and the length of the call is in words',
       figures.length === 0, figures.join(' '));
    /* A sum of money, a valuation or a named former employer are still out.
       The track record says what the work was, never what it was worth. */
    ok('no sum, no valuation, no named employer',
       !/\b(million|milyon|billion|milyar)\b|[$£€]\s?\d|\bIPO\b|\b(CEO|CTO|COO) of\b/i.test(text),
       (text.match(/\b(million|milyon|billion|milyar)\b|[$£€]\s?\d|\bIPO\b|\b(CEO|CTO|COO) of\b/i) || [''])[0]);
    /* K50 reaches this page too: the services are named here and linked, and a
       page that names a price beside them prices them. */
    ok('no price anywhere on it', !/\b(price|pricing|fee|ücret|fiyat)\b/i.test(text),
       (text.match(/\b(price|pricing|fee|ücret|fiyat)\b/i) || [''])[0]);
    /* Nobody else's name. A client list is somebody else's decision to make
       public, and a logo wall is the version of this page we are not building. */
    ok('no client is named', !/\b(client[s]? include|müşterilerimiz aras|worked for)\b/i.test(text));
    ok('nothing was sent by this page', posted.length === 0);
    ok('no page errors', errs.length === 0, errs.join(' | '));
    await page.close();
  }

  await browser.close();
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
