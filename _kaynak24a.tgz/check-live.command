#!/usr/bin/env bash
# check-live.command — Anthifel
#
# Çift tıkla. Yayındaki sitenin, deploy edilmiş dosyalarla birebir aynı olup
# olmadığını kontrol eder.
#
# Neden gerekli: bütün diğer testler dosyaları okuyor, sunucuyu değil. Bir
# sayfanın doğru derlendiğini bilmek, sunucunun onu servis ettiğini bilmek
# değildir. 12 Ağustos'ta yayında olan ve doğru çalışan bir animasyonu yarım
# gün tartıştık, çünkü sunucunun ne döndürdüğünü kimse okuyamıyordu.
#
# Bu buradan çalışmak zorunda: hem buluttaki konteynerin hem de masaüstü
# köprüsünün ağ trafiği proxy'den geçiyor ve anthifel.com'a 403 veriyor.
# Senin makinen erişebilen tek yer.

cd "$(dirname "$0")"

echo "Anthifel — yayındaki site kontrolü"
echo "─────────────────────────────────────────"
echo

for f in check-live.js check-live.command deploy.sh deploy.command DEPLOY_MSG.txt; do
  grep -qxF "$f" .git/info/exclude 2>/dev/null || echo "$f" >> .git/info/exclude
done

if ! command -v node >/dev/null 2>&1; then
  echo "✗ node bulunamadı. nodejs.org adresinden kurup tekrar dene."
  echo
  echo "Bu pencereyi kapatabilirsin."
  exit 1
fi

# 20 Ağustos, lansman: site kökte. Varsayılan adres kök oldu ve karşılaştırma
# dist/production ile yapılıyor. Preview'i okumak isteyen adresi elle verir —
# ama artık öyle bir kopya yok.
node check-live.js "${1:-https://anthifel.com/}"
status=$?

echo
if [ $status -eq 0 ]; then
  echo "Sunucudaki her sayfa, deploy ettiğin dosyalarla birebir aynı."
else
  echo "Yukarıda ✗ olan satırları Developer'a olduğu gibi yolla."
fi

echo
echo "Bu pencereyi kapatabilirsin."
