# -*- coding: utf-8 -*-
"""
legal.py — Legal's three pages, built from Legal's two files.

The copy on privacy.html, terms.html and cookies.html is not this department's.
It is written in `Anthifel_Legal_PrivacyPolicy.md` and `Anthifel_Legal_SiteTerms.md`
and it is read from there at build time rather than copied into the site, so the
page and the master file cannot drift apart. Part A of each file is a handover
note and is never published; only Part B is read.

Legal left placeholders and said which department fills which. Three are
Developer's and they are filled here. Three are Legal's and they are not
guessed — the page shows them as an unfilled marker in preview, and
`unfilled()` reports them so the production build can refuse to write a page
with a bracket in it. That refusal is the point: Legal's rule is that nothing
goes public with a placeholder, and a rule that depends on someone remembering
is not a rule.
"""
import io
import os
import re

ROOT = os.path.dirname(os.path.abspath(__file__))

# Where Legal's masters live once the folder is beside the site source. The
# build falls back to the copy under `legal/` so a checkout without the shared
# folder still builds.
SEARCH = [
    os.path.join(ROOT, 'legal'),
    os.path.join(ROOT, '..', "Anthifel MD's"),
    "/mnt/user-data/uploads/Anthifel MD's",
]

PRIVACY_EMAIL = 'privacy@anthifel.com'
GO_LIVE = '20 August 2026'
GO_LIVE_TR = '20 Ağustos 2026'

# Developer's, from Anthifel_Website.md §23 — read off the built files, not off
# memory. Everything that is not live today is marked as such: a notice that
# describes a processor the site does not use yet is as wrong as one that omits
# a processor it does.
#
# Rewritten 12 August, and the reason is worth keeping. This list was written on
# 10 August and reported to Legal as delivered. By the evening of the 12th four
# of its rows were false: Resend was missing entirely though it now sends every
# mail we send; the registrar was "to be confirmed" when it is Squarespace with
# WHOIS privacy on; Apps Script was described as sending the result mail, which
# it no longer does; and the cookie table described a bot check that runs
# "entirely in your browser", which was true of the proof of work and is not
# true of an emailed code.
#
# None of that was carelessness at the time. It is what a list of processors
# does when the thing it describes is still being built — which is why this
# block sits next to the code that generates the notice rather than in a
# document somewhere, and why nothing here may be edited without re-reading the
# built files.
# ---- the processor table moved to Legal, 20 August ----
#
# Until today this file carried the eight processors and stamped them into
# `[PROCESSOR LIST]`. Legal's 20 August file writes the table into Part B
# itself, and the token is gone from their text — so the rows below were being
# maintained here and published nowhere. Two writers and one table is the same
# hazard as two writers and one file: the copy nobody is looking at is the copy
# that drifts, and it drifts silently because it still looks maintained.
#
# So they are deleted rather than kept "just in case". What replaces them is
# not trust: check-legal reads the *published* page and looks for every live
# processor by name, which works whoever wrote the table. And if Legal ever
# puts the token back, `unfilled()` sees an unfilled bracket and production
# refuses the page — loud, which is the right failure.
#
# The cookie table below is still ours. It is the one Legal asked for and the
# token for it is still in their Part B.
COOKIE_ROWS_EN = [
    ('anthifel_lang', 'Anthifel', 'Remembers whether you are reading in English or Turkish. Browser storage, not a cookie',
     'Until you clear your browser storage', 'Strictly necessary'),
    ('None for the bot check', 'Anthifel', 'The check in front of the assessment is a code we email you. It sets no cookie and stores nothing on your device; the code itself is held on our side for fifteen minutes and then deleted',
     'Nothing is stored on your device', 'Not applicable'),
    ('Google Calendar cookies', 'Google', 'Shows the booking calendar inside our page. Set only when you open the booking window',
     'Set by Google; see Google’s cookie information', 'Not strictly necessary. Nothing is set unless you open the window'),
    ('anth_sb_session', 'Anthifel', 'Keeps a member of staff signed in to our internal dashboard. Browser storage, not a cookie. Not set for visitors',
     'Until sign-out', 'Strictly necessary'),
    ('anthifel_consent', 'Anthifel',
     'Remembers your answer to the cookie question, so we do not ask again. Browser '
     'storage, not a cookie. It is set whichever way you answer, including when you decline',
     'Six months, then we ask again', 'Strictly necessary'),
    ('_ga', 'Google',
     'Tells Google Analytics one visit from another. Set only after you accept, and '
     'removed when you change your answer to no',
     'Two years', 'Not strictly necessary. Nothing is set unless you accept'),
    ('_ga_W376XEN94E', 'Google', 'The same, for this site specifically. Set only after you accept',
     'Two years', 'Not strictly necessary. Nothing is set unless you accept'),
]
COOKIE_ROWS_TR = [
    ('anthifel_lang', 'Anthifel', 'İngilizce mi Türkçe mi okuduğunuzu hatırlar. Tarayıcı depolaması, çerez değil',
     'Tarayıcı depolamasını temizleyene kadar', 'Zorunlu'),
    ('Bot kontrolü için hiçbiri', 'Anthifel', 'Testin önündeki kontrol, size e-posta ile gönderdiğimiz bir koddur. Çerez yerleştirmez ve cihazınızda hiçbir şey saklamaz; kodun kendisi bizde on beş dakika durur ve silinir',
     'Cihazınızda hiçbir şey saklanmaz', 'Uygulanmaz'),
    ('Google Takvim çerezleri', 'Google', 'Randevu takvimini sayfamızın içinde gösterir. Yalnızca randevu penceresini açtığınızda yerleşir',
     'Google tarafından belirlenir; Google’ın çerez bilgilerine bakın', 'Zorunlu değil. Pencereyi açmazsanız hiçbir şey yerleşmez'),
    ('anth_sb_session', 'Anthifel', 'Bir çalışanın iç panelde oturumunu açık tutar. Tarayıcı depolaması, çerez değil. Ziyaretçilerde yerleşmez',
     'Çıkış yapılana kadar', 'Zorunlu'),
    ('anthifel_consent', 'Anthifel',
     'Çerez sorusuna verdiğiniz cevabı hatırlar, tekrar sormayalım diye. Tarayıcı '
     'depolaması, çerez değil. Hangi cevabı verirseniz verin yerleşir, reddettiğinizde de',
     'Altı ay, sonra yeniden sorulur', 'Zorunlu'),
    ('_ga', 'Google',
     'Google Analytics’in bir ziyareti diğerinden ayırmasını sağlar. Yalnızca kabul '
     'ettikten sonra yerleşir, cevabınızı hayıra çevirdiğinizde silinir',
     'İki yıl', 'Zorunlu değil. Kabul etmezseniz hiçbir şey yerleşmez'),
    ('_ga_W376XEN94E', 'Google', 'Aynısı, bu siteye özel. Yalnızca kabul ettikten sonra yerleşir',
     'İki yıl', 'Zorunlu değil. Kabul etmezseniz hiçbir şey yerleşmez'),
]

COOKIE_HEAD_EN = ('Name', 'Set by', 'What it does', 'How long it lasts', 'Strictly necessary?')
COOKIE_HEAD_TR = ('Ad', 'Kim yerleştirir', 'Ne yapar', 'Ne kadar kalır', 'Zorunlu mu?')

# Legal's. Never guessed. Each one is shown as a marker in preview and stops a
# production build.
LEGAL_OWNED = ['[COMPANY NUMBER]', '[REGISTERED ADDRESS]', '[ICO REGISTRATION NUMBER]',
               '[ŞİRKET NUMARASI]', '[KAYITLI ADRES]', '[ICO KAYIT NUMARASI]']

# Legal wrote the Turkish translation with Turkish placeholder names. They mean
# the same thing and are filled from the same place.
ALIASES = {
    '[PRIVACY EMAIL]':   '[GİZLİLİK E-POSTASI]',
    '[GO-LIVE DATE]':    '[YAYIN TARİHİ]',
    '[PROCESSOR LIST]':  '[HİZMET SAĞLAYICI LİSTESİ]',
    '[COOKIE TABLE]':    '[ÇEREZ TABLOSU]',
}


def _find(name):
    for d in SEARCH:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return io.open(p, encoding='utf-8').read()
    raise SystemExit('legal: cannot find %s in %s' % (name, ' / '.join(SEARCH)))


def _part_b(text):
    """Part A is a handover note and is never published."""
    i = text.index('# PART B')
    return text[i:]


def _split_languages(part_b):
    en = part_b[part_b.index('# ENGLISH'):part_b.index('# TÜRKÇE')]
    tr = part_b[part_b.index('# TÜRKÇE'):]
    return en, tr


def _section(text, heading):
    """One '## heading' block, up to the next '## ' or '# ' at the same level."""
    m = re.search(r'^## %s\s*$' % re.escape(heading), text, re.M)
    if not m:
        raise SystemExit('legal: no section "%s"' % heading)
    rest = text[m.end():]
    n = re.search(r'^#{1,2} ', rest, re.M)
    return (rest[:n.start()] if n else rest).strip('\n')


_INLINE = [
    (re.compile(r'\*\*(.+?)\*\*'), r'<strong>\1</strong>'),
    (re.compile(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)'), r'<em>\1</em>'),
    (re.compile(r'`(.+?)`'), r'<code>\1</code>'),
]


def _inline(s):
    s = (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))
    for rx, rep in _INLINE:
        s = rx.sub(rep, s)
    # Bare addresses become links; a policy that tells you where to write and
    # then makes you retype it is doing half the job.
    s = re.sub(r'\b([\w.+-]+@[\w-]+\.[\w.]+)\b', r'<a href="mailto:\1">\1</a>', s)
    s = re.sub(r'(?<![\w/@.])(ico\.org\.uk)\b', r'<a href="https://\1" target="_blank" rel="noopener">\1</a>', s)
    return s


def _table(rows):
    head, body = rows[0], rows[2:]          # rows[1] is the ---|--- rule
    out = ['<table><thead><tr>']
    out += ['<th>%s</th>' % _inline(c) for c in head]
    out.append('</tr></thead><tbody>')
    for r in body:
        out.append('<tr>' + ''.join('<td>%s</td>' % _inline(c) for c in r) + '</tr>')
    out.append('</tbody></table>')
    return ''.join(out)


def _md(block):
    """The subset Legal actually writes: h3, paragraphs, tables, bullets, quote."""
    html, lines, i = [], block.split('\n'), 0
    while i < len(lines):
        ln = lines[i]
        if not ln.strip():
            i += 1
            continue
        if ln.startswith('### '):
            html.append('<h3>%s</h3>' % _inline(ln[4:].strip()))
            i += 1
        elif ln.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].startswith('|'):
                rows.append([c.strip() for c in lines[i].strip().strip('|').split('|')])
                i += 1
            html.append(_table(rows))
        elif ln.startswith('- '):
            items = []
            while i < len(lines) and lines[i].startswith('- '):
                items.append('<li>%s</li>' % _inline(lines[i][2:].strip()))
                i += 1
            html.append('<ul>' + ''.join(items) + '</ul>')
        elif ln.startswith('> '):
            para = []
            while i < len(lines) and lines[i].startswith('> '):
                para.append(lines[i][2:].strip())
                i += 1
            html.append('<blockquote>%s</blockquote>' % _inline(' '.join(para)))
        elif ln.strip() == '---':
            i += 1
        else:
            para = []
            while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||- |> |---$)', lines[i]):
                para.append(lines[i].strip())
                i += 1
            html.append('<p>%s</p>' % _inline(' '.join(para)))
    return '\n'.join(html)


def _rows_table(head, rows):
    out = ['<table><thead><tr>'] + ['<th>%s</th>' % h for h in head] + ['</tr></thead><tbody>']
    for r in rows:
        out.append('<tr>' + ''.join('<td>%s</td>' % c for c in r) + '</tr>')
    out.append('</tbody></table>')
    return ''.join(out)


# ---- the one placeholder that is deleted rather than published ----
#
# Legal's rule, 20 August: "If the number is not yet issued at go-live, delete
# the sentence — do not publish a blank or a placeholder."
#
# It is the only placeholder in the set that behaves this way, and the reason is
# worth stating. The other brackets are facts we will have; a page missing them
# is unfinished. The ICO registration is a fact we may never have on the day, and
# a privacy notice that says "registered under number ____" is worse than one
# that does not raise the subject: it reads as a registration we are hiding.
#
# The rule is deliberately narrow. The sentence is dropped only when the
# placeholder is *alone in its own paragraph*, which is how Legal writes it in
# both languages. If it ever appears mid-sentence, nothing is dropped, the
# bracket survives, and `unfilled()` stops the production build — which is the
# right outcome, because at that point a human has to read the paragraph.
#
# And it disables itself: the day Legal fills the number, there is no
# placeholder, so there is nothing to drop.
DROP_WHOLE_PARAGRAPH = ['[ICO REGISTRATION NUMBER]', '[ICO KAYIT NUMARASI]']


def _drop_paragraphs(html):
    """Remove each <p> whose entire content is one droppable placeholder sentence."""
    out = html
    for ph in DROP_WHOLE_PARAGRAPH:
        # One paragraph, one placeholder, nothing else bracketed inside it.
        pat = re.compile(r'<p>(?:(?!</p>).)*' + re.escape(ph) + r'(?:(?!</p>).)*</p>\s*',
                         re.S)
        def keep_or_drop(m):
            body = m.group(0)
            # A paragraph carrying a second placeholder is not a sentence about
            # the ICO alone. Leave it; the build will refuse the page and say so.
            if len(re.findall(r'\[[A-Z][A-Z ÇĞİÖŞÜ \-]+\]', body)) != 1:
                return body
            return ''
        out = pat.sub(keep_or_drop, out)
    return out


def _fill(html, lang):
    """Developer's placeholders. Legal's are left standing, on purpose."""
    tr = (lang == 'tr')
    def both(key):
        return (key, ALIASES[key])
    for k in both('[PRIVACY EMAIL]'):
        html = html.replace(k, '<a href="mailto:%s">%s</a>' % (PRIVACY_EMAIL, PRIVACY_EMAIL))
    for k in both('[GO-LIVE DATE]'):
        html = html.replace(k, GO_LIVE_TR if tr else GO_LIVE)
    for k in both('[COOKIE TABLE]'):
        html = html.replace('<p>%s</p>' % k,
                            _rows_table(COOKIE_HEAD_TR if tr else COOKIE_HEAD_EN,
                                        COOKIE_ROWS_TR if tr else COOKIE_ROWS_EN))
    # The ICO sentence goes before the marking step, so preview and production
    # agree: a sentence that will not be published is not shown as a gap either.
    html = _drop_paragraphs(html)
    # What is left belongs to Legal. It is marked rather than hidden, so nobody
    # reads the preview and concludes the page is finished.
    for ph in LEGAL_OWNED:
        html = html.replace(ph, '<span class="lgap" title="Legal">%s</span>' % ph)
    return html


def documents():
    """
    { slug: {'en': html, 'tr': html, 'title_en':…, 'title_tr':…} }
    """
    priv = _part_b(_find('Anthifel_Legal_PrivacyPolicy.md'))
    site = _part_b(_find('Anthifel_Legal_SiteTerms.md'))
    pen, ptr = _split_languages(priv)
    sen, str_ = _split_languages(site)

    def doc(text, heading, lang):
        return _fill(_md(_section(text, heading)), lang)

    return {
        'privacy': {
            'title_en': 'Privacy Policy', 'title_tr': 'Gizlilik Politikası',
            'en': doc(pen, 'Privacy Policy', 'en'),
            'tr': doc(ptr, 'Gizlilik Politikası', 'tr'),
            'desc': 'How Anthifel Ltd collects, uses and protects personal data, and the rights you have over it.',
        },
        'terms': {
            'title_en': 'Terms of Use', 'title_tr': 'Kullanım Şartları',
            'en': doc(sen, 'Terms of Use', 'en'),
            'tr': doc(str_, 'Kullanım Şartları', 'tr'),
            'desc': 'The terms on which you may use the Anthifel website.',
        },
        'cookies': {
            'title_en': 'Cookie Policy', 'title_tr': 'Çerez Politikası',
            'en': doc(sen, 'Cookie Policy', 'en'),
            'tr': doc(str_, 'Çerez Politikası', 'tr'),
            'desc': 'Every cookie and every piece of browser storage this site uses, what it does and how long it lasts.',
        },
    }


def unfilled(html):
    """Placeholders still standing. Production must not ship a page with any."""
    return sorted(set(re.findall(r'\[[A-Z][A-Z ÇĞİÖŞÜ \-]+\]', html)))


def privacy_version(default='privacy-v1'):
    """
    The notice's own version identifier, read out of Legal's file.

    Legal writes it as "**Notice version identifier:** `privacy-v1`" and changes
    it whenever Part B changes. Consent records point at it, so it has to come
    from the notice rather than from a constant somebody remembers to update.
    """
    import os as _os, re as _re
    path = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)),
                         'legal', 'Anthifel_Legal_PrivacyPolicy.md')
    try:
        text = open(path, encoding='utf-8').read()
    except Exception:
        return default
    m = _re.search(r'Notice version identifier:?\*{0,2}\s*`([a-z0-9.\-]+)`', text, _re.I)
    return m.group(1) if m else default
