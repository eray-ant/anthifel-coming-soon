#!/usr/bin/env python3
"""
mk_icerik.py — one-off: lift the Content OS planner out of the old dashboard and
re-house it as the İçerik section of the single-page dashboard.

Same shape as the CRM port. The planner itself is untouched: the calendar, the
board, the content list, the channel views, the rules library, the dependency
warnings and the JSON working file all behave exactly as before. What changes is
the housing — the left sidebar becomes a horizontal flow strip, the shell chrome
comes from the dashboard, and the whole thing stops owning the viewport.

Three things had to be handled because the dashboard is one document:

  ids       "main", "nav", "toast" were already taken. Everything is prefixed.
  scope     the app stays in global scope, as written. Its screens are drawn
            with innerHTML and their inline handlers run in global scope
            whatever this script does, so a closure would cut the app off from
            its own state. The one name that clashed, toast, now delegates to
            the dashboard's.
  timing    the planner draws nothing until the section is opened.

Run once. After that dash_sec_icerik.html is the source and this script is
history: it records what the port changed and what it left alone.

  python3 mk_icerik.py
"""

import os, re

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(ROOT, 'legacy', 'content-os.html')   # the old dashboard's copy, kept for the record

raw = open(SRC, encoding='utf-8').read()

css = re.search(r'<style>\n(.*?)\n</style>', raw, re.S).group(1)
app = re.search(r'<script>\n(/\* ═+ SABİTLER.*)\n</script>', raw, re.S).group(1)

# ── 1. drop the rules that belong to a page, not to a section ────────────────
# The dashboard already sets the type, the background and the box model; the
# planner's own shell (sidebar, top bar, scroll frame) is replaced outright.
DEAD = [
    r'\*\{box-sizing:border-box;margin:0;padding:0\}\n',
    r'html,body\{height:100%\}\n',
    r'body\{background:var\(--lime\).*?\}\n',
    r'/\* ── shell ── \*/\n',
    r'\.app\{[^}]*\}\n', r'\.side\{[^}]*\}\n', r'\.bd\{[^}]*\}\n',
    r'\.bd \.wm\{[^}]*\}\n', r'\.bd \.sb\{[^}]*\}\n',
    r'nav\{[^}]*\}\n', r'nav a\{[^}]*\}\n', r'nav a:hover\{[^}]*\}\n',
    r'nav a\.on\{[^}]*\}\n', r'nav a \.ic\{[^}]*\}\n', r'nav a \.ct\{[^}]*\}\n',
    r'nav \.gp\{[^}]*\}\n', r'\.sfoot\{[^}]*\}\n',
    r'\.wrap\{[^}]*\}\n', r'\.top\{[^}]*\}\n', r'\.top h1\{[^}]*\}\n',
    r'\.body\{[^}]*\}\n', r'\.inner\{[^}]*\}\n',
]
for pat in DEAD:
    css, n = re.subn(pat, '', css, flags=re.S)
    if not n:
        raise SystemExit('CSS rule not found, refusing to guess: ' + pat)

# The planner's palette is already the brand's; only the page tone differs.
css = css.replace('--lime:#F5F1EA;', '--lime:#F1F0EC;')
css = ':root' + css.split(':root', 1)[1] if css.strip().startswith(':root') else css
css = css.replace(':root{', '#cos{', 1)

# ── 2. ids. Two applications in one document cannot both own "main". ─────────
IDS = {
    'main': 'cosMain', 'nav': 'cosNav', 'ttl': 'cosTtl', 'sdot': 'cosDot',
    'stxt': 'cosTxt', 'sbtn': 'cosSave', 'dlg': 'cosDlg', 'scrim': 'cosScrim',
    'c-cal': 'cosCal', 'c-brd': 'cosBrd', 'c-all': 'cosAll',
    'c-blog': 'cosBlog', 'c-soc': 'cosSoc',
}
for a, b in IDS.items():
    app = app.replace("getElementById('%s')" % a, "getElementById('%s')" % b)
    app = app.replace("querySelector('#%s" % a, "querySelector('#%s" % b)
    app = app.replace('querySelectorAll(\'#%s a\')' % a, 'querySelectorAll(\'#%s a\')' % b)

# The planner reaches for elements by document-wide selector. Inside one
# document those must be confined to its own subtree or they would pick up
# the CRM's cards and the blog editor's columns.
app = re.sub(r"document\.querySelectorAll\('(\.[^']+)'\)",
             r"document.querySelectorAll('#cos \1')", app)

# ── 3. one toast for the whole dashboard ─────────────────────────────────────
# One line, and it must stay one line: a greedy match here would swallow the
# helpers that follow it.
old_toast = re.search(r'^function toast\(m\)\{.*\}$', app, re.M)
if not old_toast:
    raise SystemExit('could not find the planner toast')
app = app.replace(old_toast.group(0), 'function toast(m){ window.toast(m); }')

# ── 3b. the status line lives in the dashboard's page head, outside the
#       planner's stylesheet, so it carries its own colours and must not
#       overwrite the dashboard's button classes.
old_upstat = """function upStat(){
  document.getElementById('cosDot').className='dot '+(dirty?'un':'sv');
  document.getElementById('cosTxt').textContent=dirty?(fh?'Kaydedilmemi\u015f de\u011fi\u015fiklik':'Kaydedilmedi'):(fh?fh.name:'Kaydedildi');
  document.getElementById('cosSave').className=dirty?'p':'';
}"""
new_upstat = """function upStat(){
  document.getElementById('cosDot').style.background = dirty ? '#B84C2E' : '#2F6B3F';
  document.getElementById('cosTxt').textContent=dirty?(fh?'Kaydedilmemi\u015f de\u011fi\u015fiklik':'Kaydedilmedi'):(fh?fh.name:'Kaydedildi');
  document.getElementById('cosSave').className = 'btn ' + (dirty ? 'btn-p' : 'btn-s');
}"""
if old_upstat not in app:
    raise SystemExit('upStat is not where it was')
app = app.replace(old_upstat, new_upstat)

# ── 4. global listeners must not fire while another section is open ──────────
app = app.replace(
    "document.addEventListener('keydown',e=>{\n  if(e.key==='Escape'&&editId)closeC();\n"
    "  if((e.metaKey||e.ctrlKey)&&e.key==='s'){e.preventDefault();saveNow()}\n});",
    "document.addEventListener('keydown',e=>{\n"
    "  if(document.getElementById('sec-icerik').hidden)return;   /* another section is open */\n"
    "  if(e.key==='Escape'&&editId)closeC();\n"
    "  if((e.metaKey||e.ctrlKey)&&e.key==='s'){e.preventDefault();saveNow()}\n});")

# ── 5. the planner is built when the section is first opened ─────────────────
tail = re.search(r'\nboot\(\);\nconst _t=tod\(\);\n.*?\ndirty=false;render\(\);\s*$', app, re.S)
if not tail:
    raise SystemExit('could not find the boot tail')
app = app[:tail.start()] + '''

/* Built the first time the section is opened, not on page load. */
window.dashInit.icerik = function(){
  boot();
  const _t = tod();
  calM = _t < pd('2026-08-01') ? new Date(2026, 7, 1) : new Date(_t.getFullYear(), _t.getMonth(), 1);
  dirty = false;
  render();
};
'''

NAV = [
    ('Yönetim',   [('dash', 'Panel', None), ('cal', 'Takvim', 'cosCal'),
                   ('board', 'Akış', 'cosBrd'), ('list', 'Tüm içerik', 'cosAll')]),
    ('Kanallar',  [('blog', 'Blog', 'cosBlog'), ('social', 'Sosyal', 'cosSoc'),
                   ('accounts', 'Hesaplar', None)]),
    ('Plan',      [('plans', 'Aylık ve yıllık', None), ('analytics', 'Hedefler', None)]),
    ('Kütüphane', [('rules', 'Kurallar ve ses', None), ('types', 'İçerik tipleri', None),
                   ('src', 'Kaynaklar', None), ('data', 'Veri', None)]),
]
nav_html = []
for i, (grup, items) in enumerate(NAV):
    if i:
        nav_html.append('      <span class="navsep"></span>')
    nav_html.append('      <span class="navcap">%s</span>' % grup)
    for v, lbl, cid in items:
        cnt = '<span class="cnt" id="%s"></span>' % cid if cid else ''
        nav_html.append('      <a data-v="%s"><span class="lbl">%s</span>%s</a>' % (v, lbl, cnt))
nav_html = '\n'.join(nav_html)

OUT = '''<style>
/* ============================================================
   İçerik — Content OS

   The planner that ran at /dashboard/ before, unchanged in behaviour and
   re-housed here. Its own class names are common ones — .bar, .card, .col,
   .top — so every rule below is confined to #cos at build time. The palette
   was already the brand's; only the page tone was adjusted.

   Working file: the planner keeps its content in a JSON file you choose, not
   in the browser. Nothing is stored on a server.
   ============================================================ */
%s

/* ---------- housing ---------- */
#cos{font-size:14px;line-height:1.55;color:var(--basalt)}
#cos button,#cos input,#cos select,#cos textarea{font-family:inherit}
#cos .pnav{display:flex;align-items:center;gap:3px;flex-wrap:wrap;background:#FFFFFF;
  border:1px solid rgba(26,24,21,.10);border-radius:3px;padding:7px 9px;margin-bottom:14px}
#cos .pnav a{display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border-radius:2px;
  font-size:12.5px;font-weight:500;color:#57534C;white-space:nowrap;cursor:pointer;
  border:1px solid transparent;transition:background .14s,color .14s}
#cos .pnav a:hover{background:#FAF9F6;color:#1A1815}
#cos .pnav a.on{background:#FAF7F4;color:#1A1815;font-weight:600;box-shadow:inset 0 -2px 0 #B84C2E}
#cos .pnav .cnt{font-size:11px;color:#7A756C;font-variant-numeric:tabular-nums}
#cos .pnav .navcap{font-size:9.5px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
  color:#7A756C;padding:0 7px 0 3px}
#cos .pnav .navsep{width:1px;height:20px;background:rgba(26,24,21,.12);margin:0 7px}
#cos .cost{display:flex;align-items:center;gap:12px;padding:15px 18px;flex-wrap:wrap;background:#FFFFFF;
  border:1px solid rgba(26,24,21,.10);border-bottom:0;border-radius:3px 3px 0 0}
#cos .cost h1{font-family:'Cormorant Garamond',Georgia,serif;font-weight:400;font-size:24px;
  line-height:1.15;margin-right:auto}
#cos .page{background:#F1F0EC;border:1px solid rgba(26,24,21,.10);border-radius:0 0 3px 3px;
  padding:18px;min-height:320px}
#cos .inner{max-width:none}
@media (max-width:760px){#cos .page{padding:14px}#cos .cost{padding:13px 14px}}
</style>

<div class="phead">
  <div>
    <h1>İçerik</h1>
    <p>Content OS: takvim, akış tahtası, kanallar, kurallar ve yıllık plan.<br>
       Çalışma dosyası senin diskinde durur; hiçbir şey sunucuya gitmez.</p>
    <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#7A756C;margin-top:7px">
      <span id="cosDot" style="width:7px;height:7px;border-radius:50%%;background:#7A756C;flex:none"></span>
      <span id="cosTxt">Kaydedilmedi</span>
    </div>
  </div>
  <div class="acts">
    <button class="btn btn-p" type="button" onclick="openC()">+ Yeni içerik</button>
    <button class="btn btn-s" type="button" id="cosSave" onclick="saveNow()">Kaydet</button>
    <button class="btn btn-s" type="button" onclick="loadFile()">Aç</button>
  </div>
</div>

<div id="cos">
  <nav class="pnav" id="cosNav">
%s
  </nav>
  <div class="cost"><h1 id="cosTtl">Panel</h1></div>
  <div class="page"><div class="inner" id="cosMain"></div></div>

  <div class="scrim" id="cosScrim" onclick="closeC()"></div>
  <aside class="dlg" id="cosDlg"></aside>
</div>

<script>
/* Content OS. Global scope, as it was written: the app draws its screens with
   innerHTML and those screens call back through inline handlers, which run in
   global scope whatever this script does. Its only name that clashed with the
   dashboard was toast, and that one now delegates. */
%s
</script>
''' % (css.strip(), nav_html, app.strip())

open(os.path.join(ROOT, 'dash_sec_icerik.html'), 'w', encoding='utf-8').write(OUT)
print('dash_sec_icerik.html  %d KB' % (len(OUT) // 1024))
