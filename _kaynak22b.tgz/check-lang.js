/*
 * check-lang.js — the Turkish page really is in Turkish, before any script runs.
 *
 * Every translatable node carries English as its content and Turkish in
 * `data-tr`, and `applyLang` swaps them in the browser. That works for a person
 * and not at all for a crawler: `hakkimizda.html` said `<html lang="tr">` and
 * its visible words were English. Marketing's §12 rests on assistants
 * preferring content in the language of the question, so the one page with a
 * Turkish address was answering in the wrong one.
 *
 * `trlang.py` now does the same swap at build time. That makes two
 * implementations of one rule, which is the shape every fork on this site has
 * started as — so this file renders both and compares them:
 *
 *   built page          the file we ship, read with JavaScript switched off
 *   applyLang('tr')     the English page, switched by the site's own function
 *
 * If the two ever disagree, one of them is wrong and it does not matter which.
 *
 *   node check-lang.js [dist/production]
 */
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const DIR = path.resolve(process.argv[2] || 'dist/production');
let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.log('  ✗ ' + n + (x ? '  → ' + x : ''))); };

const PAIRS = [['about.html', 'hakkimizda.html']];

(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  const visible = async (file, switchTo) => {
    const ctx = await b.newContext({ javaScriptEnabled: switchTo !== null });
    const p = await ctx.newPage();
    await p.route('**calendar.google.com/**', r => r.fulfill({ status: 200, contentType: 'text/html', body: '<p>x</p>' }));
    await p.goto('file://' + path.join(DIR, file), { waitUntil: switchTo === null ? 'domcontentloaded' : 'load' });
    /* Switched by pressing the button, not by calling the function: applyLang
       lives inside a closure, and the visitor's path is the one worth
       comparing against anyway. */
    if (switchTo) { await p.click(`.lang button[data-lang="${switchTo}"]`); await p.waitForTimeout(250); }
    const t = await p.evaluate(() => {
      const walk = document.body.cloneNode(true);
      walk.querySelectorAll('script,style,template,[hidden]').forEach(e => e.remove());
      return walk.textContent.replace(/\s+/g, ' ').trim();
    });
    await ctx.close();
    return t;
  };

  for (const [en, tr] of PAIRS) {
    console.log(`\n— ${tr} —`);
    const raw = await visible(tr, null);              // scripts off: what a crawler reads
    ok('reads Turkish with JavaScript switched off',
       /Ne yapıyoruz|Hakkımızda/.test(raw) && !/^.{0,400}What we do/.test(raw), raw.slice(0, 120));
    ok('…and says so in <html lang>',
       /<html lang="tr"/.test(fs.readFileSync(path.join(DIR, tr), 'utf-8')));

    const built = raw.replace(/\s+/g, ' ');
    const switched = (await visible(en, 'tr')).replace(/\s+/g, ' ');
    /* Not byte-equal: the English page keeps a few nodes the Turkish build
       drops, and the assessment is drawn in JS. What has to match is the prose. */
    const grab = s => (s.match(/Ne yapıyoruz.{0,600}/) || [''])[0];
    ok('the build-time swap agrees with applyLang, word for word',
       grab(built) === grab(switched),
       'built: ' + grab(built).slice(0, 90) + '\n      switched: ' + grab(switched).slice(0, 90));

    /* The switch still works: the page is Turkish, and a visitor can get back. */
    const ctx = await b.newContext(); const p = await ctx.newPage();
    await p.route('**calendar.google.com/**', r => r.fulfill({ status: 200, contentType: 'text/html', body: '<p>x</p>' }));
    await p.goto('file://' + path.join(DIR, tr), { waitUntil: 'load' });
    await p.waitForTimeout(250);
    ok('the language switch marks Turkish as current',
       (await p.getAttribute('.lang button[data-lang="tr"]', 'aria-current')) === 'true');
    await p.click('.lang button[data-lang="en"]');
    await p.waitForTimeout(250);
    ok('…and English still brings the English back',
       /What we do/.test(await p.textContent('body')));
    await ctx.close();
  }

  await b.close();
  console.log(fail ? `\n❌  ${pass} passed, ${fail} failed` : `\n✅  ${pass} passed, 0 failed`);
  process.exit(fail ? 1 : 0);
})();
