/**
 * mobile-pass.js — one screenshot of every page at phone width, plus the
 * measurements a screenshot cannot show: overflow, tap-target size, text that
 * is too small to read, and anything that pushes the document wider than the
 * viewport. check-responsive says whether the page overflows; this says whether
 * it is usable.
 */
const { chromium } = require('playwright');
const path = require('path');
const P = require('./pages');
const fs = require('fs');

const DIR = path.resolve('dist/preview');
const OUT = path.resolve('shots/mobile');
/* The Turkish pages, because Turkish is the longer language and a narrow
   screen is where length shows. They used to be reached with ?lang=tr on the
   English file; they are their own documents now. */
const HAS_MEET = new Set(['home', 'about', 'ai-readiness-audit', 'discovery-sprint',
                          'transformation-retainer', 'advisory-board-seat']);
const PAGES = P.TR.map(pg => [pg.key + '-tr', pg.file, HAS_MEET.has(pg.key)]);
const WIDTHS = [390, 360, 320];
let pass = 0, fail = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  for (const [name, file, hasMeet] of PAGES) {
    for (const w of WIDTHS) {
      const p = await b.newPage({ viewport: { width: w, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
      const errs = [];
      p.on('pageerror', e => errs.push(String(e)));
      await p.route('**calendar.google.com/**', r =>
        r.fulfill({ status: 200, contentType: 'text/html', body: '<p>schedule</p>' }));
      await p.goto('file://' + path.join(DIR, file), { waitUntil: 'load' });
      await p.waitForTimeout(500);

      const m = await p.evaluate((vw) => {
        const doc = document.documentElement.scrollWidth;
        // Anything a finger has to hit: 44px is the floor both platforms use.
        // A link inside a sentence is as tall as the line it sits in, and
        // making it taller would break the paragraph. What has to be big enough
        // is a control standing on its own: a menu item, a tab, a button, a box
        // to tick.
        const inProse = el => !!el.closest('label,p,li,td,dd,blockquote,.doc,.mmintro,.stamp,.mmnote,.lgnote,.devnote');
        const small = [];
        document.querySelectorAll('a,button,input,select').forEach(el => {
          const r = el.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) return;
          if (r.left < -1000) return;
          if (getComputedStyle(el).display === 'none') return;
          if (inProse(el)) return;
          // A tick box is the size a tick box is; what has to be big is the
          // label beside it, and that is clickable and full width.
          if (el.type === 'checkbox' && r.height >= 22) return;
          if (r.height < 40) small.push((el.tagName + (el.id ? '#' + el.id : '') + ':' + (el.textContent || '').trim().slice(0, 18)) + '=' + Math.round(r.height));
        });
        // Body copy under 13px is a strain on a phone.
        const tiny = [];
        document.querySelectorAll('p,li,td,dd').forEach(el => {
          const t = (el.textContent || '').trim();
          if (t.length < 40) return;
          const fs = parseFloat(getComputedStyle(el).fontSize);
          if (fs < 12.5) tiny.push(Math.round(fs) + 'px:' + t.slice(0, 24));
        });
        return { doc, small: small.slice(0, 6), tiny: tiny.slice(0, 4) };
      }, w);

      ok(`${name} ${w}px — no horizontal scroll`, m.doc <= w, 'doc=' + m.doc);
      ok(`${name} ${w}px — every control is tappable`, m.small.length === 0, m.small.join(' | '));
      ok(`${name} ${w}px — no body copy under 13px`, m.tiny.length === 0, m.tiny.join(' | '));
      ok(`${name} ${w}px — no page errors`, errs.length === 0, errs.join(' | '));

      if (w === 390) {
        await p.screenshot({ path: path.join(OUT, name + '-full.png'), fullPage: true });
        // The menu is the one thing that is invisible until pressed.
        const burger = await p.$('#burger');
        if (burger) {
          await burger.click();
          await p.waitForTimeout(300);
          const navOpen = await p.isVisible('#nav');
          ok(`${name} — the burger opens the menu`, navOpen);
          await p.screenshot({ path: path.join(OUT, name + '-menu.png') });
          await burger.click();
          await p.waitForTimeout(200);
        }
        if (hasMeet) {
          await p.click('[data-meet]').catch(() => {});
          await p.waitForTimeout(700);
          ok(`${name} — the booking band opens`, await p.isVisible('#meet'));
          const over = await p.evaluate(() => document.documentElement.scrollWidth);
          ok(`${name} — and does not widen the page`, over <= 390, 'doc=' + over);
          await p.screenshot({ path: path.join(OUT, name + '-meet.png') });
        }
      }
      await p.close();
    }
  }

  await b.close();
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
