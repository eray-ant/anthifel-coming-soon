# [DEVELOPER] — Task ID Kaydı · 2026-08-08

Son kullanılan numara: 068

Bu 49 task Asana'ya yazıldı. Bundan sonraki her `Developer_Asana_Tasks.md`
ve `Developer_Update_*.md` dosyasında bu ID'leri kullan. Yeni işleri 050'den
devam ettir, atlama yapma, kullanılmış bir numarayı yeniden kullanma.

ID'siz gelen güncelleme satırı işlenemez.

## Bu partiye özel not

Bu partide bir çıkarma var. Kaynak dosyadaki "Assessment → CRM otomasyonunu kur ve uçtan uca test et" maddesi Sales ile birebir aynıydı; CEO işi Sales'e devretti (SLS-019). Developer listesine yazılmadı ve numaralar boşluk kalmayacak şekilde kaydırıldı.

| Task ID | Task |
|---|---|
| DEV-001 | İşleyen listesini Legal'e [PROCESSOR LIST] biçiminde teslim et |
| DEV-002 | Sitenin kurduğu çerezlerin tablosunu çıkar |
| DEV-003 | privacy@anthifel.com adresini Google Grup olarak aç |
| DEV-004 | Rıza kaydının beş alanını form akışına ekle |
| DEV-005 | Bot rotasını rıza yakalanamazsa kapanacak şekilde kur |
| DEV-006 | reCAPTCHA'yı gizlilik ve çerez metinlerinde açıkla |
| DEV-007 | Saklama süresini Legal ile netleştirip PURGE_AFTER_DAYS değerine yaz |
| DEV-008 | Okuma listesi rıza akışını gizlilik politikası kapsamına aldır |
| DEV-009 | Alan adı WHOIS gizliliğinin açık olduğunu doğrula |
| DEV-010 | Her alan adının WHOIS dökümünü dosya olarak delil arşivine ver |
| DEV-011 | Her sosyal hesabın açılış tarihini dosya olarak delil arşivine ver |
| DEV-012 | DigitalOcean uygulamasının bölgesini konsoldan doğrula |
| DEV-013 | Google Workspace sürümü ve veri bölgesi ayarını Admin konsolundan oku |
| DEV-014 | DKIM'i doğru yöntemle yeniden test et |
| DEV-015 | Canlı adresi okuyan bir kontrol yaz |
| DEV-016 | Supabase projesini Pro plana geçir |
| DEV-017 | Buffer'ın gerekliliğini LinkedIn API kısıtı üzerinden teyit et |
| DEV-018 | Squarespace Core satırının gerekliliğini teyit et |
| DEV-019 | Legal'in gizlilik politikası metnini privacy.html'e işle |
| DEV-020 | Legal'in Kullanım Şartları metnini terms.html'e işle |
| DEV-021 | Legal'in Çerez Politikası metnini cookies.html'e işle |
| DEV-022 | Legal'in onayladığı Türkçe künye metnini siteye işle |
| DEV-023 | Kayıtlı şirket adresini alt bilgiye ekle |
| DEV-024 | Marketing'in yeniden yazdığı dört cümleyi siteye işle |
| DEV-025 | Services §9 sapmalarını CEO kararına göre uygula |
| DEV-026 | Coming-soon sayfasını kaldırıp production yapısını köke deploy et |
| DEV-027 | /preview/ klasörünü lansmanda sil |
| DEV-028 | reCAPTCHA anahtarlarını üret ve forma bağla |
| DEV-029 | Apps Script uç noktasını yayınla |
| DEV-030 | Formu uçtan uca test et |
| DEV-031 | reCAPTCHA kararını ver: kalsın, değişsin ya da honeypot olsun |
| DEV-032 | FORM_LIVE değerini true yap |
| DEV-033 | Calendly /meet sayfasını kur ve test rezervasyonu yap |
| DEV-034 | 0–29 bandının çağrısını Calendly rezervasyonuna bağla |
| DEV-035 | On iki soru metnini Marketing onayına sun |
| DEV-036 | Soru-boyut eşlemesini Business'a teyit ettir |
| DEV-037 | Bant metnindeki uzun tire için Marketing kararını uygula |
| DEV-038 | GitHub ince ayarlı token üret ve blog Script Properties'i doldur |
| DEV-039 | blogSelfTest kontrolünü yeşile getir |
| DEV-040 | Günlük publishDue tetikleyicisini ekle |
| DEV-041 | SITE_PREFIX ile BLOG_PREFIX değerlerini eşitle |
| DEV-042 | BLOG_PREFIX değerini lansmanda boşalt |
| DEV-043 | Blog altyapısını TR/EN, hreflang ve UTM ile tamamla |
| DEV-044 | Blog şablonlarını depoya işle ve ilk yazıyı uçtan uca yayınla |
| DEV-045 | Beşinci alt bilgi blog başlığını Marketing'e sor |
| DEV-046 | ANC uygulamasından "Assessment daveti" sekmesini kaldır |
| DEV-047 | Lansmanda paneli /dashboard/ altına yaz |
| DEV-048 | Toplantı not alma aracını seç ve iç toplantıda pilotla |
| DEV-049 | Toplantı kaydı için Legal'den rıza metni ve işleyen sözleşmesi iste |
| DEV-050 | Marketing sekizinci tur: "boutique/butik" temizliği ve Türkçe H1 |
| DEV-051 | Hero cümlesini CEO metniyle güncelle ve Yaklaşım III-IV başlıklarını Türkçeleştir |
| DEV-052 | Marketing dokuzuncu/onuncu/on birinci tur ve hero butonlarının yer değiştirmesi |
| DEV-053 | Ücretsiz görüşme butonunu Google takvim popup'ına bağla, ölü meet/ bağlantısını kaldır |
| DEV-054 | AI Readiness Audit sayfasını kur, sonuç ekranını ve teklif formunu bağla |
| DEV-055 | Görüşme penceresini ortak parçaya çıkar, iki sayfa aynı pencereyi kullansın |
| DEV-056 | Üç hukuki sayfayı Legal metniyle doldur, işlemci ve çerez tablolarını yaz |
| DEV-057 | reCAPTCHA yerine tarayıcıda çalışan proof-of-work bot kontrolü kur |
| DEV-058 | Görüşme penceresini sayfa içi banda çevir ve menüyü tüm sayfalara koy |
| DEV-059 | Mobil kontrol suite'i yaz ve dokunma hedeflerini düzelt |
| DEV-060 | Web sitesi yapılacaklar iş listesi |
| DEV-061 | Bot kontrolünü e-posta koduyla değiştir, üç maili ve doğrulama akışını kur |
| DEV-062 | Hero satırını harf harf yazılan animasyona çevir |
| DEV-063 | Apps Script endpoint'ini bağla, teslimat sorunlarını görünür kıl |
| DEV-064 | DigitalOcean uygulamasını Londra'ya taşı |
| DEV-065 | Hizmet sayfalarını zenginleştir, tasarım ve SEO ile yeniden kur |
| DEV-066 | Site footer'ını ortak parçaya çıkar, her sayfaya koy |
| DEV-067 | Yayın öncesi son kontrol ve FORM_LIVE'ı aç |
| DEV-068 | Bloğun adını belirle ve siteye uygula |
