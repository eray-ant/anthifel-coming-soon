# Anthifel — Website

**Owner:** Developer
**Master file:** `Anthifel MD's/Anthifel_Website.md`
**Version:** 7.0 · **Date:** 12 August 2026

### Last change (12 August 2026, thirty-third entry) — the mail arrives, and every page gets a way out

- **The code mail arrives, and the whole flow is proved end to end.** `DEV-063`.
  Address, code to the inbox, code verified, twelve questions, result mail to
  the visitor, lead mail to us, a row in the sheet with score, band and finish
  time. And the thing that had to be checked by eye: the lead mail carries the
  score, the band, the weakest dimension and the five dimension averages, and
  **not one of the twelve answers.** The red line holds where it matters, which
  is in a real mail rather than in a test.
- **Sending moved to Resend, and that is the whole fix.** Eight code mails left
  Google on 12 August and not one was seen — not in spam, nowhere. Nothing was
  misconfigured: SPF, DKIM, DMARC and MX were all correct and the send-as alias
  was verified. A two-week-old domain has no sending reputation, and reputation
  is not something you configure. Resend sends from IPs that already have one,
  signed with our DKIM. The switch is a single Script Property: set `RESEND_KEY`
  and every mail goes that way, unset it and everything falls back to `MailApp`
  exactly as before, in both directions, with nothing else changing.
- **Resend is a processor and belongs in the notice.** It sees the recipient's
  address and the body of the mail, which for the result mail includes a score
  and a band. §23 carries it; Legal has to approve the line before `FORM_LIVE`.
  Free tier is 3,000 a month and 100 a day, which is far more than we need.
- **The code is in the subject line now.** *214507 — AI Hazırlık Testi giriş
  kodunuz*. A subject is what a phone shows in a notification and what a mail
  client shows in a list — and it is the only part of a message that can be read
  without opening one that has landed in spam.

**Every page now has a way out.**

- **The footer was on one page.** `DEV-066`. The service page and the three
  legal pages carried a copyright line and three links: no address, no menu, no
  blog, nothing but the header to get back into the site. Someone landing on the
  privacy page from a search result was at a dead end. It is now one part —
  markup and stylesheet together — injected into all five, with `__HOME__`
  making the same copy work on the home page and away from it.
- **Two things came out of moving it, and both are the same lesson.** The part
  had to bring its own list reset, because the first thing it did on the legal
  pages was sprout bullet points: a part that depends on the page it lands in is
  not a part. And the address in the brand block was a 21px tap target — the one
  control in the footer a thumb could miss. It had been there all along and only
  showed up when `mobile-pass` was given four more pages to walk.
- **`check-links.js` is new** and it found what it was built for. The old check
  understood two shapes — a `#anchor` and a bare `foo.html` beside index.html —
  and silently skipped directory links, links with a fragment, and links one
  level up. That is how `meet/` stayed broken for days behind a green suite. On
  its first run it found `meet/` **still** linked from the blog footer, in both
  languages and both templates, to a page that never existed. It also asserts
  that every public page carries the full footer, and it prints the three things
  it knows are pending rather than broken instead of hiding them.

**Three decisions taken, and one that was wrong.**

- The app moves to **London (LON1)**, done the same day. `DEV-064`.
- **Supabase stays free** — the panel is not in daily use, a paused project
  comes back in one click, and $25 a month buys nothing today. `DEV-016` closed.
- **Wispr Flow, free plan**, for meeting notes. `DEV-048` closed. It records
  from system audio rather than joining the call, which is why `DEV-049` — the
  consent wording — matters more, not less: there is no bot for anyone to see.
  Google's own Gemini notes were considered and ruled out: **no Turkish**, notes
  rather than transcripts, and not on Business Starter.
- **The wrong one:** most of a day went into hypotheses — a refused alias, a
  suspended subscription, a missing SPF record — every one of them wrong,
  because the failure was invisible from the outside. That is recorded in the
  thirty-second entry and the fixes are in place. What this entry adds is the
  cost: the fix took twenty minutes once the state was visible.

- check-behaviour 207, check-code 59, check-links 6 (new), check-legal 95,
  check-service 52, check-dash 229, check-blog 86, check-comingsoon 16,
  mobile-pass 82, NO OVERFLOW ANYWHERE.
- Live: **yes**, commit `16194da`, verified against the remote rather than
  assumed — `git diff` between the served tree and this build is empty.
- Aligned with Services: yes.
- Aligned with Brand Guidelines: the blog's name is open (`DEV-068`). The CEO
  proposes *The Journal*; the Turkish is Marketing's and *Yolculuk* would be a
  mistranslation — *journal* is a record, not a journey.
- CEO decision needed: no. Four were taken today and are recorded above.

### Previous change (12 August 2026, thirty-second entry) — the day the endpoint was wired, and what it cost to find out why nothing arrived

- **The Apps Script endpoint is live and stamped in at build time.** `DEV-063`.
  Four files carried `__APPS_SCRIPT_URL__` and four code paths wrote them, so
  the address now lives in `build.py` and is stamped over the whole tree after
  the build. Four copies of one address is three chances to update three of
  them. The production build is stamped `FORM_TEST = false`, so `?form=live`
  cannot be reached there by any URL; the preview is stamped `true` and runs
  the real chain, which is how the endpoint can be proved before the Privacy
  Policy is published.
- **Both gate buttons now say what the visitor is doing.** *Start the
  assessment →* and *Verify and start →*. The first said *Send the code*,
  which described our plumbing. And the second button is mostly decoration
  now: six digits is the whole code, so it sends itself as the last digit
  lands, typed or pasted. The button stays for the second attempt.
- **The code screen opens before the endpoint answers.** Apps Script takes two
  to twenty seconds — a cold start, then a mail — and the gate held the visitor
  on a greyed-out button for all of it. There is nothing to decide while it
  runs and the mail they are waiting for takes longer than the request, so the
  screen moves and the request finishes behind it.
- **A refused sender no longer takes the request down.** `MailApp` only accepts
  a `from` that is a verified send-as alias; when it is not, it throws, and that
  exception was taking the whole call with it. It now falls back to the
  account's own address and writes the refusal to the log.

**And then the part that took the day.**

- **Nothing arrived, four times, in both directions.** A code mail to the CEO,
  a code from the site, an external mail to `privacy@`, and the group's own
  archive: all empty. Every hypothesis in turn — a refused alias, a suspended
  subscription, a missing SPF record — was wrong. DNS was correct on all four
  records, the alias was verified, the subscription was active and paid.
- **The answer was Gmail's spam folder.** The domain is two weeks old and has no
  sending reputation; a new sender, a short message and a six-digit number is
  the textbook profile. Nothing was broken and nothing had to be fixed. Google
  Postmaster Tools was added and verified, and will stay empty at our volume —
  it needs real traffic before it says anything.
- **What actually cost the time was not the bug. It was that nothing said
  anything.** Four things were silent by construction, and each one is now
  fixed:
  1. `doPost` caught every failure and returned it as JSON, so a run that did
     nothing still showed as *Completed*. It now logs the action, a masked
     address, whether a mail went, the sender used and the quota left — and
     the full stack of anything it catches.
  2. The hourly limit answered `ok: true` and sent nothing, deliberately, so a
     stranger is never told we have seen their address. In testing that reads
     exactly like a delivery failure. The endpoint now returns `why`, `from`
     and `quota` — what it did, never who asked — and **the preview prints it
     on screen**. The live site shows nothing, because `?form=live` cannot be
     reached there. The limit went from five an hour to eight: one mistyped
     address plus one resend and a real person is already at four.
  3. `r.json()` turned a login page, an uncompilable script and a blocked
     redirect into the same six words. A non-JSON reply now carries the status,
     the host the request actually ended at, and the first line of the body.
  4. **`checkMailSetup()` and `testMailNow()`** were added to `Code.gs`: one
     prints which aliases are usable, what `SEND_AS` is set to, the remaining
     quota and whether the properties are set, without sending anything; the
     other sends one real code mail from the editor, skipping the web app
     entirely, which splits "the site is broken" from "Apps Script cannot reach
     that inbox" in a single click.
- **The rule this leaves behind:** a state that cannot be seen from the outside
  will cost a day the first time it matters. Silence that is correct for a
  stranger is not correct for us, and the answer is not to remove the silence
  but to give ourselves a window into it.

**Two things the CEO asked for.**

- **The hero line loops for everyone**, including under reduced motion. `DEV-062`
  went through three positions in a day: hidden entirely for that preference
  (correct by the letter of the rule, and invisible in the worst way — a line
  that does not move looks exactly like a script that never ran); then typed
  once and stopped; now looping, by instruction, because it is the one moving
  thing on the site and its job is to be noticed. Reduced motion keeps the
  caret held still. The protections that matter were never preferences: nothing
  moves while it types, and it stops off screen and in the background. The
  element carries `data-tw` so this is never again guessed at from a screenshot.
- **The monogram is bigger** — 400 to 540 px, further into the right gutter,
  380 on mobile. The headline's glyphs end about 90 px before it starts at
  1440, 1280 and 1024.

- check-behaviour 207, check-code 58, check-legal 95, check-service 52,
  check-dash 229, check-blog 86, check-comingsoon 16, mobile-pass 82, NO
  OVERFLOW ANYWHERE.
- Live: **preview yes**, commits `7d8fb86`, `ea10716`, `2a18e00` and the ones
  that followed. Deploys are still a double-click on the CEO's desktop; see
  §10 item 48.
- Aligned with Services: yes.
- Aligned with Brand Guidelines: the three mail templates were **approved by
  the CEO on 12 August** rather than by Marketing, who did not need to see
  them. §10 item 51 closed. The two gate button labels are new and are named
  in the Asana file as request 23.
- CEO decision needed: no. Two were taken today and are recorded in §10:
  the app moves to London, and the mail copy is approved.

### Previous change (11 August 2026, thirty-first entry) — the bot check becomes a code, and the hero line writes itself

- **The bot check is now the email itself.** A six-digit code goes to the
  address the visitor typed; the assessment does not open until that code comes
  back. `DEV-061`. This replaces the proof of work of 10 August, which replaced
  reCAPTCHA on 9 August, and it is worth saying why the third answer is
  different in kind from the first two: neither of them checked the one thing
  this form actually needs, which is that the address is real and reachable. The
  result has to arrive somewhere. A made-up address defeats the whole exchange
  whether a robot typed it or a person did.
- **Nothing is stored until the code comes back.** `send-code` holds the address,
  the consent flag, the consent timestamp and the exact consent wording in
  Script Properties for fifteen minutes and writes nothing. `verify-code` is
  what appends the sheet row. An address that never confirms leaves no trace at
  all — which is a better privacy position than the one it replaces, where the
  row was written the moment the button was pressed.
- **Three calls, three mails.** `send-code` → the code mail. `verify-code` → the
  row, and the quiz opens. `result` → the visitor's result mail and our lead
  mail, and the row is completed with score, band and finish time. `Code.gs` was
  rewritten around those three; the quote form is untouched and still dispatches
  on `source`.
- **The red line holds and is now tested twice.** The lead mail carries the
  score, the band, the weakest dimension and the five dimension averages — the
  same five bars the visitor is looking at. The twelve answers are not in any
  request body, and `check-code.js` asserts it two ways: no field named for
  them, and nothing twelve items long anywhere in any payload.
- **A new suite, because the preview cannot exercise the live shape.** The
  preview carries `FORM_LIVE = false` and an unwired endpoint, so it skips the
  code step — correct behaviour, and it hides the part that matters.
  `check-code.js` makes its own copy of the built page with the switch flipped
  and a fake endpoint substituted, then answers that endpoint locally. 46
  assertions, and not one of them touches Google, Apps Script or a mailbox.
- **What a failing code says.** Wrong, expired, unknown and too-many are four
  different replies from the endpoint and three different sentences on screen:
  *unknown* deliberately reads the same as *expired*, because telling them apart
  tells an attacker which addresses we hold. A wrong code also says how many
  tries are left.
- **The hero line writes itself out, a letter at a time, clears, and starts
  again.** `DEV-062`, at the CEO's instruction. Two layers do it: the finished
  sentence, present but invisible, holding the width and the height open, and
  the letters drawn on top of it. That is the whole reason the headline
  underneath never moves — a line that shoves the page around every six seconds
  is not attention, it is a fault, and the suite samples the headline's position
  fourteen times across a full cycle to prove it does not.
- **It behaves when nobody is watching.** It stops when it scrolls out of sight
  and when the tab goes to the background, it does not run at all for a visitor
  who has asked for reduced motion, and a screen reader is given the finished
  sentence once as a label rather than hearing it typed. The language switch
  rewrites the element, so `applyLang` remounts it; eight switches in a row
  leave exactly one caret and one pair of layers.
- **Copy that Marketing has not seen yet.** The three mails are Developer's
  draft and say so in the file. The gate's own button changed from *Readiness
  assessment →* to *Send the code →* because it now sends a code, and the code
  screen's button reads *Start the assessment →*. Functional labels, not brand
  copy, but they are on screen and Marketing should see them.
- check-behaviour 198, check-code 46 (new), check-legal 95, check-service 52,
  check-dash 229, check-blog 86, check-comingsoon 16, mobile-pass 82, NO
  OVERFLOW ANYWHERE across six pages.
- Live: **preview no, not deployed yet.** The desktop bridge was down for most
  of the day; the build is in `dist/preview/` and was delivered to the CEO as an
  archive.
- Aligned with Services: yes — nothing in this entry touches a service name, a
  service description or the order of the five stages.
- Aligned with Brand Guidelines: the mail copy is unreviewed and the two gate
  button labels are new. The three conflicts from the twenty-fifth and
  twenty-seventh entries are still Marketing's and Legal's.
- CEO decision needed: no for the work itself; yes for the Apps Script URL and
  the `hello@` send-as, without which none of it can be switched on.

### Previous change (10 August 2026, thirtieth entry) — the phone gets targets it can hit

- **A real mobile pass, and it found things the overflow suite could not.**
  `mobile-pass.js` walks six pages at 390, 360 and 320 and measures what a
  screenshot does not show: the height of every control, the smallest body copy,
  whether the burger opens, whether the booking band widens the page. `DEV-059`.
- **Twenty-four failures on the first run, all real.** The language switch was
  14px tall. The footer menu links were 17. The legal tabs were 20, the
  newsletter tick 17, the blog filter chips 34, the wordmark's own link 16. A
  14px target is a target you miss, and none of it shows in a screenshot or in
  an overflow check. Every one now has a thumb-sized hit area and **nothing
  changed above 820px.**
- **Two needed a second pass for the same reason:** a later rule of equal
  specificity was winning. The chips needed `.chips .chip`; the last footer link
  had lost its padding along with its border. Worth remembering — a rule that
  looks applied and is not is the quietest kind of wrong.
- **The suite exempts what should be exempt and says why in the code.** A link
  inside a sentence is as tall as its line and making it taller breaks the
  paragraph; a tick box is the size a tick box is, and what has to be big is the
  label beside it.
- **The calendar's top margin.** The crop landed on the top edge of Google's
  rounded card, which put it hard against our square border while the bottom had
  room. `--gtop` is that room given back, 16px of our own background above the
  frame. Three numbers now, together, each labelled.
- **The service page and the three legal pages joined the site's grid.** They
  were in a 1280px box with grey either side while the rest of the site ran edge
  to edge — a fixed 72px gutter instead of the site's 1136px column with the
  remainder as gutter. Same rule now, same background, same sticky header, and
  three assertions in each suite hold it, measured off the rendered page.
- check-behaviour 178, check-legal 95, check-service 52, check-dash 229,
  check-blog 86, check-comingsoon 16, mobile-pass 82 (new), NO OVERFLOW
  ANYWHERE across six pages.
- Live: **preview no, not deployed yet**, commits `54517bb` and `9c0dcd1`.
- Aligned with Brand Guidelines: unchanged; the three conflicts from the
  twenty-fifth and twenty-seventh entries are still Marketing's and Legal's.
- CEO decision needed: no.

### Previous change (10 August 2026, twenty-ninth entry) — the booking window leaves its overlay

- **A modal was the wrong shape.** It is right for something you must answer
  before you can carry on; booking a call is the opposite, and a visitor who is
  only looking should be able to keep looking. The calendar is now a band in the
  page between the assessment and the footer. The button scrolls to it, the same
  button closes it, and so do the close control and Escape. `#meet` is a real
  address a quote or an email can link to. `DEV-058`.
- **It cannot close itself when a booking is made, and it does not pretend to.**
  The booking happens inside Google's page on Google's origin and nothing about
  it is readable from here. Anything that looked like "it closed, so it worked"
  would be a guess dressed as a confirmation.
- **The crop is gone.** It hid the organiser block and the Google footer, and it
  worked until Google laid the page out at a different height — then it cut the
  calendar instead, which is the failure that matters. The frame shows Google's
  page whole; everything worth saying first is said above it in our own words.
  The frame's height is generous rather than exact for the same reason: if
  Google's page is shorter there is space under it, if taller the frame scrolls.
  **Nothing in the site now depends on Google's layout staying still.** Open
  work 46 closes with it.
- **The site menu is on every page.** The service page and the three legal pages
  had a wordmark, a language switch and no way to get anywhere; someone landing
  from a quote, an email or a search result had to go home first. Anchors
  resolve against `index.html`, and it folds into the same burger below 960px.
- **check-responsive was passing on a page nobody sees.** A hidden element
  cannot overflow, so the booking band was never measured. The suite opens it
  before it measures now, across five pages plus the blog and the dashboard at
  seven widths. Mobile also checked by eye.
- check-behaviour 178, check-legal 86, check-service 49, check-dash 229,
  check-blog 86, check-comingsoon 16, NO OVERFLOW ANYWHERE.
- Live: **preview no, not deployed yet**, commits `68c2ffd` and `d37c63a`.
- Aligned with Brand Guidelines: unchanged from the entry below.
- CEO decision needed: no.

### Previous change (10 August 2026, twenty-eighth entry) — the bot check stops being Google's

- **reCAPTCHA is out.** It cost a request to Google carrying the visitor's IP
  address, user agent and cookies; it needed two keys we do not have; and it put
  a processor on the privacy notice for a form that asks for one email address.
  The trade stopped making sense the moment the notice had to list it. `DEV-057`.
- **What replaces it is a proof of work.** The browser is handed a challenge and
  has to find a number that makes SHA-256 of the pair start with eighteen zero
  bits. A visitor waits a fraction of a second; a script wanting ten thousand
  submissions pays that ten thousand times on its own hardware. It is not a
  Turing test and does not pretend to be — with the honeypot it prices out
  volume, which is what this form is exposed to. It reaches nobody, so it is on
  screen from the moment the gate opens rather than a gap that fills in later.
- **Two open items closed with it:** `DEV-028` (reCAPTCHA keys) is void, and
  Google leaves the processor list and the cookie table. **One opened:** the
  token is carried and recorded but not yet verified on receipt — Apps Script
  repeats the hash once, which costs it nothing, and that is part of `DEV-029`.
- **The consent modal was showing a holding paragraph** while `privacy.html`
  carried Legal's real notice. It shows the notice now, the same bytes from the
  same source. A consent box that links to a summary is a consent box that was
  not read.
- **Legal's notice inside index.html brought its em dashes into a suite that
  checks Marketing's rules.** The modal is excluded from that sweep, with the
  reason written into the test: rule 2 versus Legal's verbatim text is open work
  47 and this suite has no say in it.
- **The service page stopped repeating its two buttons at the foot** (CEO).
- check-behaviour 175, check-legal 80, check-service 44.
- Live: **preview no**, commit `8818b36`.
- Aligned with Brand Guidelines: unchanged.
- **CEO decision needed: yes** — whether the bot check stays ours or goes back
  to Google's. Ours is live in the build; going back needs two keys from Google
  Cloud and puts the processor back on the notice.

### Previous change (10 August 2026, twenty-seventh entry) — the three legal pages are written

- **They were one-paragraph holding pages.** They now carry Legal's full text,
  both languages, with the three tabbed together at the top of each: a reader
  treats privacy, terms and cookies as one document even though they are three
  files. `DEV-056`.
- **The copy is read from Legal's masters at build time, not copied into the
  site.** `legal.py` opens `Anthifel_Legal_PrivacyPolicy.md` and
  `Anthifel_Legal_SiteTerms.md`, takes **Part B only**, and converts it. Legal
  edits their file and the site follows. There is no second copy to forget, and
  no round of "which version is live".
- **Part A never reaches a page.** It is a handover note naming placeholders,
  dates and internal arguments. Six of its phrases are asserted absent from
  every built page, because the failure mode here is silent: a converter that
  takes one heading too many publishes Legal's working notes.
- **Developer's three placeholders are filled.** `[PRIVACY EMAIL]` is
  `privacy@anthifel.com` and it is a link. **`[PROCESSOR LIST]`** names six
  providers with what personal data reaches each and where it is hosted
  (`DEV-001`, closed). **`[COOKIE TABLE]`** names four entries and classifies
  every one, including the honest part: this site sets no cookie of its own,
  and the two things it remembers are browser storage (`DEV-002`, closed).
- **Legal's three are not filled and are not guessed.** Company number,
  registered address and ICO number stand as visible markers; the preview
  carries a note saying the page is unfinished; and **the production build
  refuses to write a page that still contains one.** It writes everything else,
  reports what it skipped, and exits non-zero. Legal's rule is that nothing
  goes public with a bracket in it, and a rule nobody enforces is a hope.
- **One conflict, recorded not resolved:** Legal's tables use the em dash, which
  Brand Guidelines rule 2 forbids on the site. Legal's copy goes in verbatim,
  same as Business's band copy. Marketing and Legal decide whether rule 2
  reaches legal text.
- **Three CEO items in the same pass.** Google's booking page opens with its own
  header — organiser, meeting title, duration and the description we already
  print beside it. No parameter turns it off and no stylesheet reaches across an
  origin, so it is cropped: `--gcrop` in `meet_modal.html` is the one number
  that moves it, and it is set by eye rather than measured, because this
  container cannot reach Google. The small button pair inside Approach I and II
  comes out. The Audit button now has a page to open, which was the previous
  entry.
- **`STUBS` is gone from build.py.** The three pages it produced are real pages
  now. `check-legal.js` is new: 79 assertions.
- check-legal 79, check-behaviour 171, check-service 44, check-dash 229,
  check-blog 86, check-comingsoon 16, NO OVERFLOW ANYWHERE on five pages.
- Live: **preview no, not deployed yet**, commit `6b17957`.
- Aligned with Brand Guidelines: **no** — the em dash conflict above, plus the
  three from the twenty-fifth entry, all still open with Marketing.
- CEO decision needed: no. **Legal decision needed: yes** — the three details,
  and whether the ICO sentence is deleted if the number is not issued by
  20 August (Legal's own Part A says delete rather than publish a blank).

### Previous change (9 August 2026, twenty-sixth entry) — the AI Readiness Audit gets a page

- **The result screen's warmest moment pointed at a catalogue row.** Developer
  brief §C.1 is right that this is not a button-target problem: there was no
  page to point at. Business wrote the copy in §C.2 and it goes in verbatim,
  both languages, no figure anywhere on it (K50). `DEV-054`.
- **Three files, not one.** `service_template.html` is the shell,
  `svc_audit.html` is this service's content, `SERVICES` in build.py is the
  list. The other three services will be a row and a content file each, not
  three copies of a page.
- **The booking window moved into `meet_modal.html`.** Two pages offer the call
  and the briefing copy and the schedule URL must not exist twice. Any page that
  includes the fragment gets the markup, the styles and the behaviour, and binds
  itself to every `[data-meet]` link it finds. `DEV-055`.
- **The quote request is on the page, four fields, switched off** (§C.4). Same
  arrangement as the assessment gate and for the same reason: no privacy policy,
  no recording. The suite fills it in and checks nothing was sent.
- **Two bands changed** (§C.3). 30-49 leads to the Audit page with the quote
  request beside it, ranked filled-then-outlined. 0-29 opened the footer, which
  is as much a dead end as the catalogue row; it opens the booking window now
  and keeps its single button, because that screen says we may not be for you
  and a quote button under that sentence contradicts it.
- **Three bands still point at the catalogue row.** Business has written one
  service page, not four. Three more buttons pointing at a list item would be
  three more of the bug this round exists to fix. The count is asserted so it
  has to come down deliberately.
- **§C.5, both items.** The result screen states the 79 ceiling as well as the
  ±15 range. The tie rule is written down rather than left to array order.
- **A gap in the dead-link check, found the hard way:** it resolves `#anchors`
  and `*.html` and nothing else, which is why `meet/` was broken for days.
  Open work 44.
- check-behaviour 171, check-service 44 (new), check-dash 229, check-blog 86,
  check-comingsoon 16, NO OVERFLOW ANYWHERE.
- Live: **preview no**, commit `b00a1ff`.
- Aligned with Brand Guidelines: yes. Aligned with Services: yes, §C.2 verbatim.
- CEO decision needed: no. **Business decision needed: yes** — the other three
  service pages' copy.

### Previous change (9 August 2026, twenty-fifth entry) — the call is booked in place

- **The booking button was a dead link and had been since it was written.**
  `meet/` was never built. Three links pointed at it: the hero, the second
  Approach stage, and the footer. Every visitor who asked for a call got a 404.
  This was not caught by the suite because the dead-link check only resolves
  `#anchors` and `*.html` files, and `meet/` is neither. `DEV-053`.
- **The call is now chosen inside our own frame.** Clicking any of the three
  opens a modal built from the privacy modal's frame and the assessment gate's
  type; Google's appointment schedule is embedded inside it with `gv=true`. The
  visitor does not leave the page. The times are Google's because that is where
  they live; nothing else in the window is.
- **The request to Google is made on the click, never on load.** Same decision
  as the reCAPTCHA one (§12) and the same reason: a page view is not consent to
  be seen by a third party. Two assertions hold both halves — no calendar
  request before the click, one after it.
- **There is a way out if the frame is refused.** A browser or an extension can
  decline to frame another origin, and when it does the box is empty with
  nothing to say so. A line under it opens the schedule in a tab. This is the
  only silent-failure path the feature had.
- **The alt metin band is gone; its sentence opens the hero sentence instead**
  (CEO). In English the hero is now §8's full form verbatim. **In Turkish the
  sentence is translated, and §9a says it is not translated.** The band no
  longer exists for that rule to attach to, but *AI dönüşümünün insan tarafını
  biz düzenliyoruz.* is a new Turkish brand string and it is Marketing's to
  approve or replace. Flagged, not assumed.
- **The four orange buttons said four different things.** "Readiness assessment
  →", "Start the test", "Start the assessment →", "Begin the assessment →".
  They now all read **Readiness assessment → / AI Hazırlık Testi →**, which is
  also the name Marketing's 7e requires, and the one that was black is orange.
- **One guard is parked rather than deleted.** Marketing's 7c forbids the phrase
  "görüşme ayarla" by name and gives its reason; the CEO named the buttons
  **Görüşme Ayarla**. The instruction wins for now, the assertion is commented
  out with the date and the reason, and a second assertion holds the promise
  that §8.7c actually protects — the call is still said to be free, in the
  modal. **Marketing rules on 7c**; the guard goes back or comes out.
- **The five dimension names come off the assessment card** (CEO).
- check-behaviour 165, check-dash 229, check-blog 86, check-comingsoon 16, NO
  OVERFLOW ANYWHERE.
- Live: **preview no, not deployed yet**, commit `3ed530b`.
- Aligned with Brand Guidelines: **no, and knowingly** — three open conflicts,
  all named above (§9a translation, 7c phrase, §8.7c wording). Marketing has
  been told in the same message this entry was written from.
- CEO decision needed: no. Marketing decision needed: yes, three.

### Previous change (9 August 2026, twenty-fourth entry) — Marketing's ninth, tenth and eleventh rounds

- **The Turkish tagline came back** (§11, CEO, 9 August). The Turkish page's H1
  and `<title>` carry *AI araçla başlar, rehberle ilerler.* again. This reverses
  the eighth round's decision three days after it shipped.
- **`og:title` cannot follow.** Open Graph is read before any script runs, so a
  single-valued meta tag cannot switch language. The Turkish page's `og:title`
  is the English tagline and stays that way unless the Turkish page becomes its
  own URL. Answered to Marketing.
- **The alt metin went on the site for the first time** (§9a) as a band between
  the hero and the scope quote. It lived there for one afternoon; the CEO moved
  it into the hero sentence the same day — see the entry above.
- **§9c reversed the twenty-third entry's hero change.** With the band carrying
  that sentence, leaving it in the hero as well printed it twice on one page,
  so the hero went back to §8 verbatim. The CEO then reversed §9c in turn.
- **A Turkish line under each service name** (§10a), on the Turkish page only.
  The names stay English; that rule now lives in §8 item 10 with its reason.
- **The hero buttons swapped roles** (CEO): the assessment leads and is orange,
  the call follows in white. The same pair, small, inside the first two Approach
  stages, so the page teaches once what the two colours mean.
- **The tagline assertion has now been written three ways in two days.** It
  carries a comment naming the round it enforces and the date, because the next
  person to read it will otherwise assume it is wrong.
- check-behaviour 150, check-dash 229, check-blog 86, check-comingsoon 16, NO
  OVERFLOW ANYWHERE.
- Live: **preview yes**, commit `ba6542d`.
- Aligned with Brand Guidelines: yes at the time of writing; superseded the same
  day by the entry above.
- CEO decision needed: no.

### Previous change (9 August 2026, twenty-third entry) — the hero names the work

- **The hero sentence gained a first clause, on the CEO's instruction:** "We
  organise the human side of AI transformation. It is new for everyone. We
  stand with you while every part of your company adapts to AI." The Turkish
  was written rather than translated, per rule 4.
- **This is the first place the site knowingly differs from §8.** Until now the
  hero sentence was Marketing's block verbatim. The difference is a decision,
  not drift, and the verbatim assertion carries a comment saying so — otherwise
  the next person to compare the two will "fix" the site back.
- **Approach stages III and IV were English on the Turkish page** while their
  three siblings were Turkish. No rule made that so — Transformation maps to a
  paid service too and reads "Dönüşüm" — so it was an inconsistency rather than
  a convention. They are **Denetim** and **Keşif**.
- **The Services headings were not touched, and now cannot be by accident.**
  AI Readiness Audit, Discovery Sprint, Transformation Retainer, Advisory Board
  Seat and Executive Workshop are fixed English on both pages under Business's
  K34 instruction. Five assertions hold them there, so a later Turkish sweep
  cannot finish a job it was never asked to start. Changing them is Business's
  call, not this department's.
- **One request refused and explained rather than done:** the Turkish headline
  reading in English is the eighth round's decision (K52), applied and deployed
  the same day. Reversing it means reversing K52, which is Marketing's and the
  CEO's.
- check-behaviour 148, check-dash 229, check-blog 86, check-comingsoon 16, NO
  OVERFLOW ANYWHERE.
- Live: **preview yes**, commit `bf99a52`.
- Aligned with Brand Guidelines: **no, and deliberately** — the hero sentence
  now differs from §8 by CEO instruction. Marketing should be told so §8 and the
  site do not disagree silently.
- CEO decision needed: no.

### Previous change (8 August 2026, twenty-second entry) — Marketing's eighth round

- **"Boutique" and "butik" are off every page.** The eyebrow in both languages,
  and the meta and og descriptions that also carried it. Marketing's table
  listed only the eyebrow; the rule is that the word appears in no text of the
  brand's, and a description is text. `DEV-050`.
- **The Turkish page carries the English tagline.** The Turkish tagline was
  withdrawn on 5 August, so the H1 is now "AI needs a guide, not just tools."
  in both languages. Not an inconsistency: a tagline is a brand element and is
  not translated, like the service names. The sentence beneath it stays Turkish.
- **The four sentences Marketing rewrote are in** — blog masthead EN and TR,
  blog meta description EN and TR, reading list TR. `DEV-024`, closed.
- **Three assertions had to move with the copy, and two of them inverted.** They
  were written against the retired Turkish tagline; the headline must now *not*
  change with the language, and a new one checks that the hero sentence still
  does. A suite that only ever asserts the current copy blocks the next change
  instead of guarding it — worth remembering the next time a rule is written as
  a test.
- **Two guards added:** neither withdrawn word appears in any page text, and
  "AI araçla başlar" cannot come back. Both were live copy, and a retired word
  returns the moment an old block is reused.
- **Reported back, not fixed here:** the launch DM templates in the CRM section
  still say "butik" in four places. The tool is this department's, the text is
  Sales's.
- **The masthead reading was approved by the CEO** on the same day, on
  Marketing's behalf: the target sentence replaces the second half of the
  existing one rather than the whole paragraph. The line reads "What we learn
  inside companies that are trying to change. Written for the people who have
  to decide."
- **§8.4, the brand narrative, is still nowhere on the site** and Marketing
  confirms that is not this department's gap — there is no about page and the
  CEO removed the home block. Waiting on a CEO decision, not on work here.
- check-behaviour 143, check-dash 229, check-blog 86, check-comingsoon 16, NO
  OVERFLOW ANYWHERE.
- Live: **preview yes**, commit `1db0abc`.
- Aligned with Brand Guidelines: **yes, §8 item 8 verbatim.**
- CEO decision needed: no.

### Previous change (8 August 2026, twenty-first entry) — task IDs, and one item that left

- **Open work now carries Asana IDs.** `DEV-001` to `DEV-049`, issued by the
  CEO in `Developer_ID_Kayit.md`. The numbering in §10 is unchanged and stays
  unchanged: it is older, it is referenced throughout this file, and
  renumbering it would break every cross-reference in the document that
  specifies the site. The two are mapped in the register.
- **Item 4 is no longer this department's.** "Assessment → CRM automation,
  tested end to end" was identical to a Sales task and the CEO moved it there
  as `SLS-019`. It stays listed here because the site's form is one end of it,
  but the work and the deadline belong to Sales.
- **Nothing about the site changed.**
- Live: no change.
- CEO decision needed: no.

### Previous change (6 August 2026, twentieth entry) — handing the model to Finance

- **Finance cannot see the panel and cannot reach the database.** It reads the
  shared folder. Neither its sandbox nor this one has a network route to
  Supabase — checked from here; Finance should check its own before anything is
  built on the assumption. So the file is the channel.
- **It is a handover, not a sync.** `Anthifel_Finansal_Model.xlsx` is the source
  of truth; what leaves the panel is a dated proposal. A continuous sync would
  mean Finance reading the CEO mid-change, which is worse than reading nothing.
- **The export carries its date and a summary.** The filename is
  `anthifel-finance-secim-YYYY-MM-DD.json` — a fixed name made a three-week-old
  handover look like today's. Inside, next to the raw state, a Turkish summary:
  scenario, mode, the lines switched off **by name**, the edits, the added
  lines, the three-year expense totals and the cash trough with its month.
  Finance no longer derives any of that from line numbers.
- **"Finance'a devret" writes straight into the folder.** The browser's own
  folder picker, once; the handle is kept in memory for the session and in
  IndexedDB across reloads. Carrying the file from Downloads was the step that
  got forgotten, and a forgotten handover is worse than none.
- **Three failure paths, all landing somewhere sensible:** no API in the
  browser → download, and say so; picker cancelled → silence, because that is
  an answer; anything else → download and say why.
- **What the suite can and cannot check.** The picker cannot be driven from a
  test, so the folder is stubbed and what is checked is this code: the handle
  asked for once and reused, the dated name, contents matching the download,
  and the fallback. Whether the real picker behaves is verified by hand.
- **Import is unchanged.** The keys the panel reads back are exactly the ones it
  always had; everything added is ignored, so old files still load.
- check-dash 229, check-behaviour 140, check-blog 86, check-comingsoon 16, NO
  OVERFLOW ANYWHERE.
- Live: **preview once the push lands.**
- CEO decision needed: no.

### Previous change (5 August 2026, nineteenth entry) — the round trip is proved, and three more from one screenshot

- **The write path is confirmed against the live table.** One row in `ledger`:
  2026-08-05, gelir, "test", Danışmanlık, 30.00. So the panel does reach the
  database; what was missing was only the read, and the fix for it needed a
  deploy that had not finished when the incognito test ran.
- **Subtotals were not misaligned; the numbers inside them were.** The cells
  were in the right columns and the figures sat left in them, because `.am` is
  written as `.li .am` and a subtotal row is not a row. A right-aligned column
  of left-aligned numbers is indistinguishable from a shifted column, which is
  exactly how it was reported.
- **The list adds itself up now.** A column of subtotals with no total at the
  foot is a sum the reader is asked to do. The total row follows the same rules
  as the subtotals above it — only switched-on lines, only what the month filter
  leaves on screen — so it adds up by eye.
- **A record the server has not acknowledged says so on its row.** Not in a
  toast, which is gone in three seconds. The whole reason for having a server is
  that this browser is not the record; a panel that cannot show the difference
  is back where it started. This is what makes the next occurrence
  self-diagnosing instead of a conversation.
- **Version fingerprint, for checking a deploy landed:** the lines list ends in
  a "Toplam · N kalem" row. It exists only from this build.
- check-dash 220, check-behaviour 140, check-blog 86, check-comingsoon 16, NO
  OVERFLOW ANYWHERE.
- **Verified end to end on the live panel**, in a browser that had never seen
  it: signed in with an account, the ledger record written on another machine
  was there, the totals line up. That is the whole point of the store, checked
  the only way that counts — against the served page, not the build.
- Live: **preview yes**, commit `a18205b`.
- CEO decision needed: no.

**Standing risk, now that a real record lives there:** the Supabase project is
on the free plan and **pauses after a week without use**. Nothing is lost, but
it has to be resumed by hand and the panel will fail to read until it is. Pro
is $25 a month and removes it. Worth doing before anyone depends on the ledger
rather than after the first time it bites.

### Previous change (5 August 2026, eighteenth entry) — the live test found two the suites did not

- **Row level security verified against the live project.** Signed out, with
  only the publishable key, `ledger` returns `[]`. That is the check this
  department cannot run — the container has no network route to Supabase — and
  the CEO ran it. Recorded here because it is the assumption everything else
  rests on.
- **The ledger was never asking the server.** It binds itself when the page is
  parsed, which is before anyone signs in, so its one read always found no
  session and did nothing. On the machine that wrote a record it looked
  correct, because the browser copy was there — which is exactly why the live
  test passed and why it was still wrong. On a second machine it would have
  shown an empty ledger with nothing to say anything was missing. The suite now
  seeds a row on the server, so reading and not reading are different results.
- **The form asked for the category after the button that submits it.** It had
  also lost its layout in the restructure: `.frow` was the panel's rule and the
  ledger had moved out from under `#fin`, so every field went full width. Both
  are consequences of the same confinement fix, and neither was caught because
  that flow was not looked at again after it.
- **The lesson, again.** Two of the three came from a screenshot of the live
  panel, not from 215 assertions. Tests are for the paths already understood;
  they do not notice a field in the wrong order or a read that never happens
  because the state that made it necessary was never set up.
- Live: **preview once the push lands.**
- CEO decision needed: no.

### Previous change (5 August 2026, seventeenth entry) — the store is in, and the password is gone

- **The project exists and the schema is live.** London region, free plan,
  sign-up disabled, anonymous sign-ins off. The CEO created it and ran the SQL.
- **The panel talks to it directly over HTTP**, not through Supabase's client
  library. Two reasons and both bind: the page is self-contained, and §23 now
  has a test that fails if a third-party request goes out. The only host the
  panel reaches is our own project.
- **The password written into the page is gone.** The door is an account. §21
  called that password a deterrent and not a lock, acceptable only while
  nothing behind it was worth stealing — a shared database ends that argument.
  Open work 25 and 39 are done. The password path stays as the fallback when no
  project is configured, so the file still works on its own.
- **Local first, server wins.** Every read answers from the browser and
  corrects itself when the server replies. Model writes are debounced — one
  burst of changes is one write, and there is a test that measures it.
- **The status line says where the state is**, not just that it is saved. A
  panel reading "kayıtlı" while the server never heard is the failure this
  whole thing replaces, so it now reads "sunucuda", "bu tarayıcıda" or
  "sunucuya yazılamadı".
- **The suites run against an in-memory Supabase** (`mock-supabase.js`), so
  they need no account and write into no real table. What they cannot check is
  whether the live project's policies are right — that is a property of the
  project and is verified by hand. check-dash 213, check-behaviour 140,
  check-blog 86, check-comingsoon 16, NO OVERFLOW ANYWHERE.
- Live: **preview once the push lands**, root unchanged.
- CEO decision needed: no. **One action: create the user account** — sign-up is
  off, so the first user is added from Authentication → Users.

### Previous change (5 August 2026, sixteenth entry) — the database is approved, and what that changes

- **CEO approved Supabase, London region.** Open work 30 is decided. §24 is the
  design: two tables, row level security, and Supabase's own authentication
  replacing the password written into the page — which closes open work 25 in
  the same move rather than leaving it for later.
- **The schema is written and waiting**, `anthifel_schema.sql`. It runs once,
  in the project's SQL editor, after the project exists. This department cannot
  create the project: it needs an account and a card.
- **One setting decides whether any of this is safe.** The anon key ships
  inside the page — that is what it is for — so the only thing between the cash
  model and the internet is who is allowed to sign in. Public sign-up must be
  off. §24 says it twice for that reason.
- **The exchange rate assumption is closed.** The CEO's answer: leave it. The
  model keeps Finance's ~18% a year and the panel keeps reporting it.
- **Three console readings remain the CEO's**, and this department cannot do
  them: the DigitalOcean region, the Google Workspace data region, and the
  domain's WHOIS privacy. All three sit behind logins in his browser. The
  hosting IP was checked from here and settles nothing — `anthifel.com`
  resolves to Cloudflare, which is App Platform's edge, not the app's region.
- Live: no change to the site.
- CEO decision needed: no — items 31 to 35 are readings and actions, not
  decisions.

### Previous change (5 August 2026, fifteenth entry) — the withdrawn sentence was never actually off the site

- **`anthifel.com` still carried it.** "not with technology, but with the people
  behind it" — Brand Guidelines §8 rule 3, retired. The ninth entry reported it
  fixed on 4 August. **It was not, and this department said it was.**
- **Why.** The fix was committed in a clone that cannot push, and the deploy
  that day was a hand upload of a different copy of the file. The test that
  guards this sentence — `check-comingsoon.js` — passes against the file in the
  clone, and nothing was checking the file actually being served. A green test
  on the wrong artefact is worth nothing.
- **The §8.3 replacement is written into the new clone** and goes out with the
  next push. Everything under `preview/` was already current, byte for byte,
  all twelve files.
- **Deploys are no longer drag-and-drop.** A real clone of the repository sits
  on the CEO's desktop, connected to this session. Files are written straight
  into it and `deploy.sh` commits and pushes them. The bridge cannot delete
  files, which is why a script exists at all: git has to remove its own
  `.git/index.lock` after every operation.
- **`deploy.sh` and `DEPLOY_MSG.txt` are kept out of the repository**, in
  `.git/info/exclude`. The repo root is also the web root — anything committed
  there is downloadable from the live site.
- **Verified live.** Commit `7d2a797` is on `main` and `anthifel.com` now reads
  "Transformation is new for everyone. We stand with you while every part of
  your company adapts to AI." The retired sentence returns nothing on the
  served page. Checked against the URL, not the build — which is the whole
  point of open work 37.
- **Push works.** `gh auth login` as `eray-ant`; the Mac had a stored
  credential for a different account, `edeployforever`, which is why every
  attempt returned 403 rather than asking for anything. Deploys are now: files
  written into the clone from here, `bash deploy.sh` there.
- Live: **root fixed, verified.**
- CEO decision needed: no.

### Previous change (5 August 2026, fourteenth entry) — two dashboards again, and why

- **The panel went live at a second address.** `anthifel.com/dashboard/` was
  serving the full application instead of the redirect stub. The eighth entry
  killed exactly this on 4 August; it came back the same day.
- **The cause is the upload route, not the build.** The push proxy will not
  inject a credential for this repository, so every deploy is a hand upload,
  and a hand upload puts a folder wherever it lands. `dashboard/index.html` at
  the root was overwritten with the built panel.
- **Contained, not harmless.** `robots.txt` disallows both paths and the file
  carries `noindex`, so nothing was indexed. The damage is drift: two copies of
  the same panel, one of which nobody is maintaining, and two places to look
  when a number is wrong.
- **Fixed by restoring the 521-byte stub** at `dashboard/index.html`, delivered
  in `_github-yukle4/`. The other nine stubs were untouched.
- **A rule, because this will recur while uploads are by hand:** only the
  `preview` folder is ever uploaded. The root `index.html` and `dashboard/` do
  not change by hand before 20–21 August. §21.
- Live: root back to coming-soon plus stubs once the upload lands.
- CEO decision needed: no — but open work 36 makes the underlying problem go
  away, and it is worth more than the twenty minutes it costs.

### Previous change (5 August 2026, thirteenth entry) — the menu, and what Finans was actually showing

- **The section menu is a hover menu.** One row of departments, each opening
  its own list when pointed at. Only where a pointer exists: a touch screen
  reports a hover it never had, and the list would open under the finger on the
  way past. On a phone the burger opens the whole tree at once.
- **A number was right and unlabelled, which is worse than wrong.** Finans had
  one amount column and it read as monthly. It was the 36-month total: $100 a
  month is ₺4.630 today and ₺221.736 over three years, because the model's rate
  moves from 46,3 to 76,5. The CEO checked it by hand and the column could not
  answer him. It is four columns now — today's charge with its unit spelled
  out, then each of the three years.
- **The years are twelve months each, not calendar years.** The horizon starts
  in August, so calendar years would give four uneven buckets and a five-month
  first year. Year 1 is Ağu 2026 – Tem 2027 and every heading says so. A
  year-level flow — revenue, spend, closing cash — sits beside the chart.
- **Finans leads with the lines, not the months.** 106 lines grouped by
  category, each carrying its own frequency. A month is a filter on that list,
  not a different screen. The month timeline is one click away.
- **Two repairs recorded in §21**, both silent failures: an icon glyph that no
  amount of centring could align, and a stylesheet confined to `#fin` that was
  reaching the shell's own buttons because `#fin` wrapped more than the panel.
- **The FX path is Finance's, and it is worth a second look.** 46,3 → 76,5 over
  36 months is about 18% a year against the dollar. If the working assumption
  is higher, the payload changes, not the panel. To Finance.
- **`check-dash.js` is 202 assertions**, including the arithmetic the CEO
  checked: the three year columns must add up to the total.
- Live: **preview yes once the commit lands, root no.**
- CEO decision needed: no new ones. Items 30–35 still open.

### Previous change (5 August 2026, twelfth entry) — the service provider list, and one leak closed

- **§23 is the list Legal asked for.** Every tool, what personal data reaches
  it, and where it is hosted — taken from the built files, not from memory.
  Live today versus planned at launch are separated, because they are different
  questions.
- **Everything on it is outside the UK.** Google, GitHub, Calendly and
  DigitalOcean are all US companies. Three of the six can be moved or swapped
  and three cannot; §23 says which is which and what each one costs. Five new
  open work items, 31 to 35, one per thing that has to be read off a console or
  decided.
- **A leak was found and closed.** The reCAPTCHA script tag ran on every page
  view — the widget waited for the gate, the network request did not. Google
  was receiving the visitor's IP address and reCAPTCHA cookies on every visit,
  before consent and before a privacy policy exists. It is now fetched only
  when the gate opens and only with a live form behind it, so today nothing is
  requested at all.
- **The rule is a test now, not a habit.** `check-behaviour.js` fails if any
  request leaves the page on a plain visit. 140 assertions, on both builds.
- **`privacy@anthifel.com` is the right address**, as a Google Group rather than
  an alias — §23 says why. No cost either way.
- Live: **preview yes once the commit lands, root yes** — the reCAPTCHA fix is
  in the production build too, though the root is still coming-soon.
- CEO decision needed: **yes — items 31 to 35, and item 30 still open.**

### Previous change (5 August 2026, eleventh entry) — Finance's panel, and the menu by department

- **Finance's cash panel is in the Finans section**, as the first of three
  flows: the model, the ledger, the fixed costs. The engine, the payload and
  the three formulas are Finance's and are untouched — `Anthifel_Finansal_Model.xlsx`
  stays the source and the payload is regenerated there, not here.
- **The panel now remembers.** Its handover asked the dashboard to provide the
  persistence it deliberately left out. Mode, scenario, the lines switched off,
  the edits and the added lines are written on every render, in exactly the
  shape the panel's own JSON export already speaks. It is this browser, so it
  is one machine and one browser — §21 says what that costs and what replacing
  it takes.
- **The menu is two rows.** Genel Bakış, Sales, Marketing, Finance, Developer,
  and under the open one the sections that department owns. Eight sections,
  same eight, reachable in two clicks instead of read off one long strip.
- **Four collisions came with the port and are recorded in §21**, because each
  one failed silently rather than with an error, and the same class of failure
  will happen again the next time a page becomes a section.
- **`check-dash.js` is 168 assertions**, up from 137: the department row, the
  three Finance flows and the model's own numbers. check-behaviour 139,
  check-blog 86, check-comingsoon 16, check-responsive NO OVERFLOW ANYWHERE.
- Live: **preview yes once the commit lands, root no.** The push is still
  blocked — the repository is not in this session's authorised set — so the
  built file is in `_github-yukle3/preview/dashboard/index.html`.
- Aligned with Services: unchanged, the panel is not public.
- CEO decision needed: **yes — open work item 30, where the panel's data lives.**

### Previous change (4 August 2026, tenth entry) — K23, Dashboard.md folded in

- **`Anthifel_Dashboard.md` is gone.** What was still true moved here: the
  infrastructure table and the deployment traps into §8, the panel's storage and
  security notes into §21. What was not true was dropped rather than carried:
  the page-per-section structure, the iframe notes and the sidebar rules all
  described the old dashboard, which no longer exists.
- **A file-handling error is recorded here rather than quietly fixed.** The
  ninth entry was written on top of a stale copy of this file and overwrote the
  eighth. Both are restored below from the work itself. Lesson: re-stage before
  editing, every time, and check the version line before writing.
- Live: no change to the site.
- CEO decision needed: no.

### Previous change (4 August 2026, ninth entry) — K50 and the Business brief

- **The live page was carrying a withdrawn sentence.** `anthifel.com` is still
  the coming-soon page and it read "not with technology, but with the people
  behind it" — Brand Guidelines §8 rule 3. Replaced with the §8.3 sub-line,
  verbatim. The first sweep missed it because that page is the one page
  `build.py` does not produce; it now has its own guard, `check-comingsoon.js`.
- **Prices: swept again, none anywhere.** Clean since 3 August, in every
  currency and every format.
- **The assessment is a real test now.** Twelve questions, five dimensions, the
  methodology's weights and both ceilings. §22 has the detail.
- **Two brief items were not applied**, both on the CEO's instruction: the email
  gate stays in front of the test, and the independence statement stays off the
  page. Both go back to Business. §22.
- **The Audit is seven working days**, not two weeks, in Services and Approach.
- Live: **preview yes, root yes** once the commit lands.
- CEO decision needed: no.

### Previous change (4 August 2026, eighth entry) — one dashboard

- **The old panel at `/dashboard/` is gone.** Two panels were live at once, with
  two doors and two to-do lists. Every old page is now a redirect to the matching
  section of `/preview/dashboard/`, so links already given out still work.
- **Content OS moved into İçerik.** It was the last thing that lived only in the
  old panel. Calendar, board, content list, channel views, rules library,
  dependency warnings and the JSON working file all behave as before.
- **The hand-written İçerik reference panels were removed**, because the planner
  already carries the same rules, types and sources.
- **Old browser data is carried across once** on first visit: the to-do list and
  the ledger. The old keys are left untouched in case the conversion is wrong.
- **One build bug fixed**: the CSS scoper treated a comment in front of a rule as
  part of the selector and silently killed the rule. It had eaten the blog
  editor's column layout and the planner's custom properties.
- Live: **preview yes, root redirects.**
- CEO decision needed: no.

### Previous change (4 August 2026, seventh entry) — the dashboard

- **The dashboard is one document at `/preview/dashboard/`.** It used to be a
  set of separate pages, so clicking a section left the panel. The address no
  longer changes; the menu swaps panes and the hash only exists so a section can
  be linked to and reloaded. `/dashboard/crm/` and `/dashboard/blog/` redirect,
  so old links still work.
- **Every section is written.** CRM and Blog are the two applications; Genel
  Bakış, İçerik, Site, SEO, Analitik and Finans are the reference sections,
  built from the content of the old dashboard pages rather than invented. §21
  says what each one holds.
- **Nothing on the public site changed.** This entry touches the panel only.
- **`check-dash.js` replaces `check-crm.js`** and drives the whole panel:
  128 assertions, NO OVERFLOW ANYWHERE.
- Live: **preview yes, root no.**
- CEO decision needed: no. §11 items still stand.

### Previous change (3 August 2026, sixth entry) — K47 item 7

- **Brand Guidelines §8.7 applied to the Turkish page.** All of 7a, 7b, 7c, 7d
  and 7e are in. English copy untouched, as instructed, and a test now asserts
  that it stayed untouched.
- **Live in preview, all of it.** Nothing from item 7 is waiting on a deploy.
  The root is still coming-soon, so `anthifel.com/` is unaffected.
- **Two questions go back**, both listed in §19: the fifth footer blog title has
  no counterpart in the Blog Plan, and the Turkish imprint wording needs Legal.
- **One conflict created**, §19: two Turkish sentences §8.7 rewrites are the same
  sentences `Anthifel_Services.md` §9.2 fixes word for word. Services now
  disagrees with the site; Business has to move.
- Live: **preview yes, root no.**
- CEO decision needed: no. §11 items still stand.

### Previous change (3 August 2026, fifth entry) — K47

- **Brand Guidelines §8 applied.** The withdrawn sentence is off the site, the
  hero and the brand narrative are in, and the four site-wide rules have been
  swept. Source of truth stays in `Anthifel_Brand_Guidelines.md` §8; nothing was
  copied into this file.
- **Live now:** items 1 and 2 (the quote block) and item 5 (the four rules).
  Deployed to `/preview/` and verified.
- **Waiting on deploy:** nothing from K47. Everything below is in `/preview/`.
  The root still shows coming-soon, so **`anthifel.com/` itself is unaffected** —
  the withdrawn sentence was never on the coming-soon page.
- Also in this change: the Also block is no longer bold, and the privacy policy
  opens in place from the consent tick instead of navigating away.
- Live: **preview yes, root no.**
- Aligned with Services: unchanged. Aligned with Brand Guidelines: **yes for §8**,
  with four sentences referred back to Marketing — §16.
- CEO decision needed: no. §11 items still stand.

### Previous change (3 August 2026, fourth entry)

- **Image library.** Typing a path is gone. Images are uploaded from the editor,
  cropped in the browser to the three ratios the blog design uses, and committed
  to `blog/img/`. A focal point picked by clicking the image keeps the subject
  centred in all three crops. Previously uploaded images are reusable from a
  library grid, shared across both languages.
- **Authors are a fixed list** — Eray Dengiz or Anthifel. Was free text.
- **Scheduling.** A future date schedules rather than publishes. A daily
  `publishDue` trigger takes the post live on its day and rebuilds.
- Live: **no.** Nothing deployed; both forms still switched off.
- Aligned with Services: unchanged — §11 deviations still open.
- CEO decision needed: no for this change; §11 items still stand.

### Previous change (3 August 2026, third entry)

- **Blog built, with a publishing system behind it.** Blog index and a new article
  template, both bilingual and responsive. Writing happens in a new dashboard
  module at `/dashboard/blog/`; publishing renders static pages and commits them
  to GitHub, so DigitalOcean deploys them and the site stays fully static.
- **Landing page changed on CEO instruction:** the "Get in touch" section is gone,
  prices are gone, the independence statement is gone, and the assessment now
  opens an email-and-consent gate before the questions. Approach and Services
  headings share one type step. Three of these reverse recorded decisions — §11.3.
- **New personal-data flow:** the reading-list signup on the blog. Same three
  consent conditions as the assessment gate, same switch, same block on Legal.
- Live: **no.** Nothing deployed yet, and both forms stay switched off.
- Aligned with Services: **no.** §11 now carries five open deviations, three of
  them created by today's instructions.
- CEO decision needed: **yes** — §11.3 needs Services §9.1 and §9.4 rewritten by
  Business, or the page put back.

### Previous change (3 August 2026, second entry)

- **Staged release adopted.** The landing page does not replace the coming-soon page yet. It deploys to `anthifel.com/preview/`, behind `noindex,nofollow,noarchive`, while `/` stays on coming-soon. One source now produces two builds — `dist/preview/` and `dist/production/` — differing only in the head block and a preview bar, so what is signed off in preview is byte-identical to what goes live.
- Internal links between the four pages became **relative** (`privacy.html`, not `/privacy`), which is what lets the same files work under `/preview/` and at the root without an edit.
- Setup guide rewritten in Turkish as `KURULUM.md`.
- Live: **no.** Preview not yet deployed either.
- Aligned with Services: unchanged — §11 deviations still open.
- CEO decision needed: no for this change; §11 items still stand.

### Previous change (3 August 2026, first entry)

- **Landing page v2 rebuilt and verified.** Every link now resolves, TR/EN switching works across the whole page, the page is responsive at all seven widths, and a two-step enquiry form with consent capture has been built. Services §9 alignment applied: four service items with §9.2 copy verbatim, price ranges shown, independence statement placed. Holding pages added for privacy, terms and cookies.
- Live: **no** — awaiting deploy. The form additionally stays switched off (`FORM_LIVE = false`) until Legal publishes the privacy policy.
- Aligned with Services: **partly.** Service copy, prices and the independence statement are now verbatim. Two deviations are open and listed in §11.
- CEO decision needed: **yes** — two items in §11: the five-stage Approach, and the four-vs-five assessment dimensions.

### Previous change (2 August 2026)

- File created. Consolidates what was scattered across the dashboard notes, Services §9 and the infrastructure status table.
- Affects: Business (alignment), Marketing (blog structure)
- CEO decision needed: no

---

## 1. Current state

| Component | State |
|---|---|
| `anthifel.com` | Live — DigitalOcean App Platform, static site |
| `www.anthifel.com` | Live — CNAME + SSL |
| DNS | DigitalOcean nameservers (`ns1/2/3.digitalocean.com`) |
| Repo | GitHub `eray-ant/anthifel-coming-soon`, autodeploy on |
| Email | Google Workspace — MX `smtp.google.com` priority 1, SPF `v=spf1 include:_spf.google.com ~all` |
| **DKIM** | **Missing — must be generated in Admin console and added as `google._domainkey` TXT** |
| Dashboard | `anthifel.com/dashboard/` — password gate `anthifel2026` |
| Published page | Coming soon, English only |
| Landing page v2 | **Built, verified, not deployed.** Goes to `anthifel.com/preview/`, not to `/`. 479 KB self-contained. TR/EN, responsive, assessment gate |
| Blog | **Built, verified, not deployed.** `/blog/` and `/en/blog/`, article template, topic filter, reading-list signup |
| Blog publishing | **Built, not connected.** Dashboard editor → Apps Script → GitHub → autodeploy. Needs a GitHub token and Script Properties |
| Dashboard blog editor | **Built, not deployed.** `/dashboard/blog/`, `noindex`. Read-only until the endpoint and token are set |
| Coming-soon page | **Stays at `/`.** Untouched by this work. Removed at launch, open work 9 |
| Privacy / Terms / Cookies | **Built as holding pages, not deployed.** `noindex`. No legal text — waiting on Legal |
| Enquiry form | **Built, switched off.** `FORM_LIVE = false` until the privacy policy is published |
| Form endpoint | Google Apps Script Web App — **not yet created.** Setup in `KURULUM.md` |
| Bot check | **A six-digit code, mailed to the address.** No captcha, no keys, no third party, no cookie. Replaced the proof of work 11 Aug, which replaced reCAPTCHA 10 Aug (§12) |

**Not Squarespace.** Every plan written before 2 August assumed Squarespace; that assumption is dead. Anything referencing it needs correcting.

---

## 2. Site map — target state at launch

| Page | Path | Source of copy |
|---|---|---|
| Home | `/` | Marketing (hero, positioning) |
| About | `/about` | Marketing — Brand Guidelines §1 |
| Approach | `/approach` | Business — Services §9.3 |
| Services | `/services` | Business — Services §9.2, verbatim |
| Assessment | `/assessment` | Business (methodology) + Developer (mechanics) |
| Blog | `/blog` · `/en/blog` | Marketing — Blog Plan §7 |
| Contact / Meet | `/meet` | Calendly embed |
| Privacy Policy | `/privacy` | Legal |
| Terms | `/terms` | Legal |
| Dashboard | `/dashboard/` | Developer, `noindex` |

---

## 3. Services alignment — Services §9, followed exactly

| Currently on site | Must become | Why |
|---|---|---|
| Six items in Services list | **Four items** | Workshop and Keynote move to a separate small "Also" block |
| Name and duration only | Name + duration + one-line definition | A name alone does not say what is being sold |
| Approach skips from Conversation to Discovery | **Audit made visible** | The cheapest entry product is invisible on the site |
| No prices | **Price ranges shown** | Decision taken: ranges are displayed |
| No independence statement | **Statement placed** below Approach or above footer | "We take no commission from any vendor we recommend." |

Exact bilingual copy for all four services and the "Also" block sits in `Anthifel_Services.md` §9.2. It is copied verbatim, not paraphrased.

**State as of 3 August:** all five rows above are applied on the v2 landing page and
asserted by `check-behaviour.js`, which fails the build if any §9.2 sentence or price
is edited away. Two deviations remain open — §11.

---

## 4. AI Readiness Assessment

**This section is a pointer, not a spec.** It described the assessment as it was
planned on 2 August — four categories, an automated email of recommendations, a
chain into Notion — and every one of those has since been decided differently.
Leaving the old shape here would mean the file contradicts itself, which is the
one thing a specification cannot do. What is true now:

- **What it asks and how it scores:** §22. Twelve questions, five dimensions,
  weights 30 / 25 / 20 / 15 / 10, two ceilings.
- **How someone gets into it, and what is stored:** §12. Email plus consent, a
  six-digit code to that address, and a row written only once the code comes
  back.
- **What is emailed afterwards:** §12. The visitor gets their score, their band
  and the five dimension averages. We get the same, as a lead. Neither carries
  the twelve answers.
- **The chain into the CRM** is `SLS-019` and belongs to Sales, not here — moved
  on 8 August (§10 item 4). The form is this department's end of it.

---

## 5. Design rules

Everything derives from Brand Guidelines §3-8. What is specific to the build:

- **No dark surfaces in panel interfaces.** Surface `#FFFFFF`, background `#F1F0EC`, text `#1A1815`, accent terracotta `#B84C2E`
- **Wordmark renders at 15 px minimum.** Below that the serif terminals and the thin stroke of the "Λ"-shaped A break up. In a column flex box `align-items:flex-start` is mandatory or the mark stretches
- **The brand appears once per screen.** Embedded apps hide their own wordmark inside the iframe
- Headings Cormorant Garamond, body Inter — the free alternatives named in Brand Guidelines §4
- Every menu item carries a 13-15 px line icon, `stroke-width:1.6`
- Content flows full width; no fixed narrow column
- **One thing on the site moves, and it is the hero line.** *AI transformation
  advisory · London* writes itself out a letter at a time, holds, clears and
  starts again, with a terracotta caret. Added 11 August at the CEO's
  instruction (`DEV-062`). The rule it must never break is that **nothing else
  moves with it**: the finished sentence sits in the page invisibly, holding the
  width and the height, and the letters are drawn on top of it. It stops when it
  scrolls out of sight and when the tab is in the background, it does not run at
  all under `prefers-reduced-motion`, and a screen reader is given the sentence
  once as a label rather than hearing it typed. Twelve assertions in
  `check-behaviour.js` hold all of that, including fourteen samples of the
  headline's position across a full cycle

## 6. Mobile rules (≤820 px)

- **No horizontal scrolling anywhere.** Menus wrap downward, they do not scroll sideways
- Main menu becomes a two-column grid; a lone final item spans full width
- Sub-menus become chips; group headings sit on their own line
- Tables become row cards — each cell shows its label via `data-l`, the header row hides with `tr:has(th){display:none}`
- Form fields and buttons go full width
- KPI cards two columns, one below 359 px

**Verification is mandatory.** `check-responsive.js` walks every page and section at 1440 / 1024 / 768 / 430 / 390 / 360 / 320. **Nothing ships without "NO OVERFLOW ANYWHERE" plus a visual pass over the screenshots.**

---

## 7. Technical rules

**Every page is self-contained.** CSS and JS inlined, no external files. Pages carry `<base href="/dashboard/">` so `/dashboard`, `/dashboard/` and `/dashboard?` all behave. The first version used external files and broke on the trailing-slash-free URL — this rule exists because of that.

**Class-name trap.** The top-bar "DASHBOARD" label uses `.sub`; the sidebar uses `.snav`. Give them the same name and sidebar styles land on the label, destroying the layout.

**Data.** Checkboxes, last open section, task list and Finance records live in localStorage — device-specific, never sent to a server. ANC data moves through the app's own Download → Pool file.

**Security.** The dashboard password is a client-side front door. It deters, it does not protect. No sensitive data is stored there. If real authentication becomes necessary, add a layer such as Cloudflare Access.

All dashboard pages are `noindex,nofollow`.

---

## 8. Deployment

GitHub is the only route. `build.py` writes `dist/`, the contents go to the
repository, DigitalOcean App Platform picks the commit up and deploys it.
One to two minutes, then a hard refresh.

**Verification is by commit hash.** DigitalOcean → Activity must show a new line
carrying the hash. "Deployed configuration changes" lines are settings, not
code: a deploy that only produces those has not shipped anything.

### Traps, all of them met at least once

- **DigitalOcean's GitHub access can lapse.** It did once, and autodeploy went
  quiet without an error anywhere. If Activity shows no new line after a push:
  github.com/settings/installations → DigitalOcean → Configure → grant access to
  the repository, then Actions → Force rebuild and deploy.
- **The address may arrive without a trailing slash.** `/dashboard`,
  `/dashboard/` and `/dashboard?` must all work. This is why every page is
  self-contained: an external stylesheet failed to load on the slashless form,
  and the page came up unstyled with its password box dead.
- **Only the root `index.html` is hand-maintained.** Every other page is
  produced by `build.py`, which is exactly how the coming-soon page kept a
  withdrawn sentence for a day after the sweep that was meant to remove it.
  `check-comingsoon.js` exists for that reason.

### Infrastructure

| Component | State |
|---|---|
| `anthifel.com` | Working — DigitalOcean App Platform, static site |
| `www.anthifel.com` | Working — CNAME and SSL |
| DNS | DigitalOcean nameservers, `ns1/2/3.digitalocean.com` |
| Email | Google Workspace. MX `smtp.google.com` priority 1, SPF `v=spf1 include:_spf.google.com ~all` |
| DKIM | **Missing.** To be generated in the Admin console and added as a `google._domainkey` TXT record |
| Dashboard | `anthifel.com/preview/dashboard/`, moving to `/dashboard/` at launch |
| Live page | Coming soon, English only |

Moving the nameservers to DigitalOcean deleted the Workspace records that lived
at the old DNS. MX and SPF were put back; DKIM was not, and is open work item 1.

## 9. SEO

Structure from Blog Plan §7:

- Hand-written meta description per page, 150-160 characters, separate for Turkish and English
- URL pattern: `anthifel.com/blog/ai-donusumu-organizasyon-problemi` · English `anthifel.com/en/blog/ai-transformation-organisational-problem`
- Reciprocal `hreflang` tags on both versions
- Every post links to at least two earlier posts. Posts 2 and 4 are hub pages
- Hand-written image `alt` text in both languages
- UTM on every outbound link: `?utm_source=blog&utm_medium=cta&utm_campaign=yazi-XX&utm_content=tr|en`

Analytics: Google Analytics with defined events for assessment start, assessment complete, and Calendly booking. These three are the only ones that matter.

---

## 10. Open work

Asana IDs (`DEV-###`) live in `Developer_ID_Kayit.md` and are mapped to these
rows there. The numbering below is **not** renumbered to match: it is older and
referenced throughout this file, and a specification whose cross-references
have quietly shifted is worse than one with two numbering schemes.

| # | Item | Deadline |
|---|---|---|
| 1 | ~~DKIM record~~ — done 12 Aug, and confirmed live in DNS alongside SPF (`v=spf1 include:_spf.google.com ~all`) and DMARC (`p=none`) | ~~Before launch~~ |
| 51 | ~~The three mail templates are Developer's draft~~ — **approved by the CEO on 12 Aug**, who read all five and did not refer them to Marketing | ~~Before `FORM_LIVE`~~ |
| 53 | **Resend is a processor and is not in the privacy notice yet.** It sees the recipient's address and the body of every mail we send, which for the result mail includes a score and a band. §23 carries it; Legal has to approve the line. **Blocks `FORM_LIVE`** | Before `FORM_LIVE` |
| 52 | ~~The code mail lands in Gmail's spam folder~~ — closed 12 Aug by moving transactional mail to **Resend**, which sends from IPs that already have a reputation, signed with our DKIM. Proved end to end: inbox, not spam. The code is in the subject line as well, so it can be read without opening the mail (§12) | ~~Before launch~~ |
| 50 | ~~`hello@` has to be a send-as Workspace will honour~~ — done 12 Aug. Verified alias, DKIM live, and `checkMailSetup()` in `Code.gs` prints the state of all of it without sending anything | ~~Before `FORM_LIVE`~~ |
| 49 | ~~The proof-of-work token is not verified on receipt~~ — closed 11 Aug by removing the proof of work. The check is now a code mailed to the address and verified by the endpoint, which is a server-side check by construction (`DEV-061`, §12) | ~~Before `FORM_LIVE`~~ |
| 48 | **Deploys depend on the desktop bridge being up.** It dropped four times on 10 Aug and three builds sat undeployed because the files never reached the clone — `deploy.sh` reported a clean tree and was right to. Interim practice from 10 Aug: **every write is verified on the device before it is reported**, by comparing byte counts against the build. The permanent fix is still a decision: push from here, or `deploy.sh` fetches the build itself | Before 20 Aug |
| 47 | **Rule 2 versus Legal's text.** Legal's tables use the em dash; Brand Guidelines rule 2 forbids it on the site. Legal's copy went in verbatim. Marketing and Legal decide | Before 20 Aug |
| 46 | ~~`--gcrop` set by eye, not measured~~ — closed 10 Aug by removing the crop. Google's page is framed whole and our own words go above it; nothing depends on Google's layout staying still | ~~Before 20 Aug~~ |
| 45 | **Legal's three details** — company number, registered address, ICO number. The production build refuses to write privacy.html and terms.html until they are in (§25) | 20 Aug |
| 44 | ~~The dead-link check does not see directory links~~ — closed 12 Aug. `check-links.js` walks both builds and resolves every internal href against the tree: directories, fragments, one level up. On its first run it found `meet/` still linked from the blog footer in both languages, to a page that never existed (`DEV-066`) | ~~Before 20 Aug~~ |
| 43 | **Google appointment schedule: confirm it frames on the live origin.** It is embedded with `gv=true` and works locally; whether Google allows framing from `anthifel.com` can only be read off the served page (§23) | Before 20 Aug |
| 42 | **Three Marketing conflicts opened by the CEO on 9 Aug** — §9a Turkish alt metin, 7c "görüşme ayarla", §8.7c wording. All three are live in the build and named in the twenty-fifth entry | Before 20 Aug |
| 2 | ~~Assessment scoring methodology received from Business~~ — received 2 Aug, applied 4 Aug (§22) | ~~Before 14 Aug~~ |
| 3 | ~~Assessment form built~~ — built 4 Aug. Still to connect: the score is not sent anywhere by design (§22) | ~~17 Aug~~ |
| 4 | Assessment → CRM automation, tested end to end — **moved to Sales as `SLS-019`** on 8 Aug. The form is this department's end of it; the automation is not | 17 Aug |
| 5 | ~~Services §9 alignment applied to the site~~ — applied 3 Aug, two deviations open (§11) | Before 20 Aug |
| 6 | Privacy Policy and Terms published — copy from Legal. **Blocks item 12.** | Before 20 Aug |
| 7 | Calendly `/meet` built and test-booked | 14 Aug |
| 8 | Blog infrastructure — TR/EN, hreflang, UTM | 12 Aug (Blog 1 goes live) |
| 9 | `dist/preview/` deployed to `/preview/`, reviewed on desktop and phone | — |
| 9b | Coming-soon page removed, `dist/production/` deployed to the root, `/preview/` deleted | 20-21 Aug |
| 10 | Registered office address added to footer | After 20 Aug |
| 11 | **Apps Script endpoint deployed; the flow is not yet proved end to end.** Deployed 12 Aug with all three properties set and the retention trigger added. `doGet` answers correctly, so the script compiles and is public. A POST from the page was still returning HTML at the end of the day — the reply now reports its status, final host and first line, which is the next thing to read | Before 17 Aug |
| 12 | `FORM_LIVE` flipped to `true` — **only after item 6** | With item 6 |
| 13 | Retention period agreed with Legal, then matched in `PURGE_AFTER_DAYS` | Before 20 Aug |
| 14 | ~~reCAPTCHA disclosed in the privacy and cookie notices~~ — closed 11 Aug; there is no captcha to disclose and no cookie set by one. What Legal does need to know is that the code mail is sent through Google Workspace, which is already on the list in §23 | ~~Before 20 Aug~~ |
| 15 | Five deviations in §11 decided by the CEO; Business rewrites Services §9.1 and §9.4 | Before 20 Aug |
| 16 | GitHub fine-grained token issued, blog Script Properties set, `blogSelfTest` green | Before 12 Aug |
| 16b | Daily `publishDue` trigger added — without it scheduled posts never go live | With item 16 |
| 16c | `SITE_PREFIX` in the editor kept equal to `BLOG_PREFIX`, at setup and again at launch | With items 16 and 18 |
| 17 | Blog templates committed to the repo, first post published end to end | 12 Aug (Blog 1 goes live) |
| 18 | **`BLOG_PREFIX` emptied at launch** — left as `preview/` the blog publishes nowhere visible | 20-21 Aug |
| 19 | Reading-list consent flow covered by the privacy policy alongside the assessment gate | Before 20 Aug |
| 20 | ~~Four sentences referred to Marketing rewritten and sent back~~ — returned in Brand Guidelines §8 item 8c and applied 8 Aug (`DEV-024`) | ~~Before 20 Aug~~ |
| 21 | EN tagline full stop settled in Brand Guidelines §8.3 (§16) | Before 20 Aug |
| 22 | Fifth footer blog title — real or placeholder? Marketing (§19) | Before 12 Aug |
| 23 | Turkish imprint wording confirmed by Legal (§19) | Before 20 Aug |
| 24 | Services §9.2 Turkish updated by Business to match Brand Guidelines §8.7 (§19) | Before 20 Aug |
| 25 | ~~Dashboard password replaced by real authentication~~ — done 5 Aug with item 39 (§24) | ~~With item 39~~ |
| 26 | `/dashboard/` redirect stubs replaced by the production build at launch (§21) | 20-21 Aug |
| 27 | The twelve question texts approved by Marketing and the mapping confirmed by Business (§22) | Before 20 Aug |
| 28 | Em dash in Business's band copy settled by Marketing (§22) | Before 20 Aug |
| 29 | Calendly exists, so the 0–29 call to action can point at a booking rather than the contact card (§22) | 14 Aug |
| 31 | **The app is in Frankfurt (FRA1), and moves to London.** Read off the console 12 Aug. Not a compliance problem — Germany is covered by the UK's adequacy finding — but §23 and the notices say London, and a specification that disagrees with the console is worse than either. **CEO decided 12 Aug: move.** New app in LON1 from the same repo, verify on its temporary address, move the domain, then destroy the old one. `DEV-064` | Before 20 Aug |
| 32 | ~~Google Workspace edition and data-region setting~~ — read 12 Aug: **Business Starter**, and data regions are **not offered on that edition**. So there is no region control over Workspace data and there will not be without an upgrade. Legal needs to know this; §23 says so | ~~Before 20 Aug~~ |
| 33 | ~~reCAPTCHA decision~~ — closed 11 Aug. Neither reCAPTCHA nor the proof of work that replaced it; the bot check is the code mailed to the address, which needs no keys, no third party and no cookie (§12) | ~~With item 11~~ |
| 34 | ~~`privacy@anthifel.com` created as a Google Group~~ — done 12 Aug. A real group, not an alias, with **external senders allowed to post** — without that a data subject cannot reach the address the privacy notice gives them — and the archive closed to outsiders. The CEO is the named owner | ~~Before 20 Aug~~ |
| 41 | ~~Legal's privacy policy text worked into `privacy.html`~~ — done 10 Aug, read from Legal's master at build time. `FORM_LIVE` still waits on Legal's three details (item 45) | ~~Before 20 Aug~~ |
| 37 | **A check that reads the live URL, not the build.** Every suite runs against files in this container; the one thing that matters is what the server returns. `check-comingsoon.js` was green while the served page carried the retired sentence (§8) | Before 20 Aug |
| 36 | ~~Push access restored, so deploys stop being hand uploads~~ — done 5 Aug. A clone on the CEO's desktop, written to from here, pushed with `deploy.sh` (§21) | ~~Before 20 Aug~~ |
| 35 | ~~Registrar WHOIS privacy checked~~ — done 12 Aug. Registrar is **Squarespace**; WHOIS Privacy **on**, domain lock on, auto-renew on to 26 July 2027. The registrant details are not public | ~~Before 20 Aug~~ |
| 30 | ~~Where the panel's data lives — CEO decision~~ — decided 5 Aug: Supabase, London. Build tracked at 38 (§24) | ~~Before 20 Aug~~ |
| 38 | ~~Supabase project created in London, schema run, sign-up disabled~~ — done 5 Aug (§24) | ~~Before 20 Aug~~ |
| 40 | ~~First user account created~~ — done 5 Aug; signed in on the live panel and a ledger record round-tripped (§24) | ~~Before using the panel~~ |
| 39 | ~~Dashboard door replaced by Supabase authentication, store swapped from `localStorage`~~ — done 5 Aug (§24) | ~~With item 38~~ |

---

## 11. Open deviations from Services — CEO decision

Both were found while building v2. Neither is a bug; both are places where the
site and `Anthifel_Services.md` now say different things, and Services is the
source. This department cannot edit Services. The CEO decides which side moves.

### 11.1 Approach has five stages, Services §9.3 describes four

§9.3 says keep the four existing steps and add a sub-line under Discovery so the
Audit becomes visible. The page instead promotes Audit to a stage of its own:
**Assessment · Conversation · Audit · Discovery · Transformation.**

This satisfies the stated intent — "Approach'ta Audit hiç geçmiyor" is fixed, and
fixed more plainly than a sub-line would. But it is a different structure from
the one Services specifies, and it changes the service narrative, which is an
escalation under this department's charter.

**Either** Services §9.3 is rewritten to five stages, **or** the page reverts to
four plus a sub-line. Recommendation: rewrite §9.3. The five-stage version makes
the cheapest entry product visible without a reader having to notice a footnote.

### 11.2 The assessment shows four dimensions, Services says five

Services §2 promises "Readiness skoru (0–100), beş boyutta kırılımlı." The site —
both the old page and v2 — names four: **Strategy, Organisation, Technology,
People.** §4 of this file repeats the same four.

The fifth dimension has never been named anywhere. Services §10 still lists
"Readiness skoru metodolojisi — beş boyut ve ağırlıkları" as an open item owned by
Business, so this is not a copy error — the methodology does not exist yet.

**Nothing was invented to close the gap.** The page ships with the four names that
were already agreed. When Business delivers the methodology, whichever number is
real goes into Services, this file and the page together.

### 11.3 Three recorded decisions reversed, 3 August

Instructed by the CEO in session. Applied. Recorded here because each one
contradicts a line that is currently written down somewhere else, and the site
and Services must not silently disagree.

| Removed | What still says otherwise |
|---|---|
| **Prices** — all four ranges | Services §9.1: "Fiyat yok → Fiyat aralıkları eklenecek · Karar: aralıklar gösterilir". §9.2 carries the figures. §3 of this file repeats it |
| **The independence statement** | Services §9.4 requires it "website'ta görünür bir yere". Services §3 calls the no-commission promise a sales argument, not an aside |
| **The "Get in touch" form** | Nothing mandates it — this one is clean. The consequence is that the only way to reach us from the page is `hello@anthifel.com` in the footer, plus `/meet` once Calendly exists |

Durations stayed. Service names and the §9.2 one-liners stayed, verbatim.

**What has to happen:** Business rewrites Services §9.1 and §9.4 to match, or the
page goes back. This department cannot edit Services. Until one or the other, the
site is knowingly out of alignment and `check-behaviour.js` asserts the removals
so they are not undone by accident.

One note, offered once and not repeated. The commission sentence was the only
place on the page where the business model was stated rather than described, and
Services §3 frames it as the argument that makes the Retainer credible. Removing
it costs something a price list does not. If the concern was that it read as
defensive, it could return in the footer at 13 px instead of as a display quote.

### 11.4 Approach and Services headings

They were 22 px and 29 px. Now both take `--h-card`, a single custom property
(24 px, 22 px below 640 px). `check-behaviour.js` compares the computed size,
family and weight of the two and fails if they ever drift apart again.

### 11.5 The assessment gate changed what the assessment promises

"Start the assessment" no longer starts the assessment. It opens a gate: email
address, unticked consent box, captcha. The twelve questions come after.

This was the CEO's decision and it is a reasonable one — the email is the lead,
and capturing it at the gate means an abandoned assessment still produces one.
But it makes Services §1 wrong: "AI Readiness Assessment — Üç dakika, dürüst bir
skor. **Hiçbir şey kaydedilmez.**" Something is now recorded, before the first
question. The page says so plainly; Services still says the opposite.

---

## 12. Form and consent — how it actually works

Built 3 August. Decisions taken by the CEO the same day.

**Two steps, in this order.** Email address plus consent first; name, company,
role, size, subject and message second. Nothing is transmitted until the second
step is submitted — step one is a gate, not a save.

**Consent meets the three conditions Legal set out:**

1. The tickbox ships **unticked**. There is no pre-selected state anywhere.
2. The policy link sits **inside the label**, next to the words being agreed to.
3. The **moment of consent is recorded** — an ISO timestamp taken in the browser
   when the box is ticked, plus the visitor's timezone, plus the server's own
   receipt time, plus **the exact wording** shown at the time. Storing the
   wording matters: consent to a sentence we later edited is not evidence.

**Endpoint:** Google Apps Script Web App, chosen over Formspree so that no new
data processor is introduced and nothing is added to the monthly cost. Writes to
a Google Sheet, emails Eray, emails the enquirer a copy in their own language.

**Anti-abuse — rewritten 11 August, and this is the third answer.** The page
has now carried reCAPTCHA, then a proof of work, and now a code mailed to the
address. The first two are worth recording because the reasoning is what
matters, not the outcome:

| | What it did | Why it went |
|---|---|---|
| reCAPTCHA v2 | Google decided whether the visitor was a robot | Two keys we did not have, a request to Google carrying the visitor's IP and cookies, and a processor on the privacy notice — for a form that asks for one email address |
| Proof of work | The browser hashed until it found enough leading zero bits | Cheaper and private, and it did price out volume. But it answered "is this automated", which was never the question |
| **Email code** | A six-digit code is sent to the address; the assessment opens when it comes back | The address has to exist, has to be reachable, and whoever typed it has to be holding it |

The question this form is actually exposed to is not whether a robot filled it
in. It is whether the address is real — because the result has to arrive
somewhere, and a made-up address defeats the exchange whether a robot typed it
or a person did. The code answers that and the bot problem at the same time,
and a real visitor pays one mail they were getting anyway.

Two layers remain underneath it: the off-screen honeypot, and per-address and
site-wide hourly rate limits in the script. The per-address limit answers
identically whether or not it fired, so it cannot be used to find out which
addresses we hold.

**Three calls, in order.**

| Call | Carries | Does |
|---|---|---|
| `send-code` | email, consent, consent moment, consent wording, language, page, referrer, timezone | Mails a six-digit code. **Writes nothing.** The record is held in Script Properties for fifteen minutes |
| `verify-code` | email, code | Appends the sheet row — this is the first moment anything is stored — and opens the assessment |
| `result` | email, score, band, weakest dimension, five dimension averages | Completes the row and sends both mails |

**Nothing is stored until the code comes back.** An address that never confirms
leaves no trace, which is a better position than the arrangement it replaces,
where the row was written the moment the button was pressed.

**What a failing code says.** The endpoint distinguishes wrong, expired, unknown
and too-many; the screen shows three sentences, because *unknown* deliberately
reads the same as *expired*. Telling them apart tells whoever is asking which
addresses we hold. A wrong code also says how many attempts are left.

**Failure behaviour:** if the endpoint is unreachable the visitor is told
plainly and pointed at `hello@anthifel.com`. Nothing degrades open here — there
is nothing to degrade open into, because the code is not a check that can be
skipped, it is how the result gets delivered.

**The three mails are approved.** Code, result-to-visitor, and lead-to-us, in
Turkish and English. The CEO read all five renderings on 12 August and approved
them without referring them to Marketing.

**They are sent through Resend, and that is why they arrive.**

Half a day on 12 August went into looking for a misconfiguration that did not
exist. SPF, DKIM, DMARC and MX were all correct and the send-as alias was
verified. Eight code mails left Google and not one was seen — not in spam,
nowhere. The domain is two weeks old and has no sending reputation, and a new
sender with a short message and a six-digit number is exactly the shape a filter
is built to catch. **Reputation is not something you configure**, which is why
every hypothesis that assumed a configuration fault was wrong.

Resend sends from IPs that already have a reputation, signed with our DKIM —
the part that cannot be bought with more DNS records. The switch is one Script
Property: set `RESEND_KEY` and every mail goes that way; unset it and everything
falls back to `MailApp` exactly as before. Deliberately reversible in both
directions, and nothing else in the flow changes with it. If Resend refuses — a
wrong key, an unverified domain, a rate limit — the mail is not lost: it falls
back to Gmail and the refusal is written to the log.

Resend is a **processor**. It sees the recipient's address and the body of the
mail, which for the result mail includes a score and a band. §23 carries it and
Legal has to approve the line before `FORM_LIVE` — §10 item 53.

**The code is in the subject line**: *214507 — AI Hazırlık Testi giriş kodunuz*.
A subject is what a phone shows in a notification and what a mail client shows
in a list, and it is the only part of a message that can be read without opening
one that has landed somewhere unexpected.

**The form is switched off.** `FORM_LIVE = false` in `index.html`. It renders,
validates and refuses to send, telling people to email `hello@anthifel.com`
instead. This is deliberate and it is the one thing in this build that must not
be quietly flipped: the consent tickbox links to `/privacy`, and consent that
points at a page with no policy on it is not informed consent. Legal's item 5
unblocks it.

---

## 13. Staged release

The landing page does not take the root until launch. Until then it lives at
`anthifel.com/preview/` and the coming-soon page keeps `/`.

`build.py` emits two directories from one source:

| Build | Destination | Difference |
|---|---|---|
| `dist/preview/` | `/preview/` | `noindex,nofollow,noarchive`, no canonical, black preview bar across the top |
| `dist/production/` | repo root, **at launch** | canonical + hreflang, indexable, no bar |

**Nothing else differs.** Same markup, same CSS, same form, same copy — so the
thing signed off in preview is the thing that goes live. This is the point of
building it this way rather than keeping a hand-edited copy.

The preview path is one line in `build.py` (`PREVIEW_DIR`). A less guessable
slug is available if the page should be harder to stumble on.

**Links between the four pages are relative** — `privacy.html`, not `/privacy`.
That is what lets the identical files work under `/preview/` and at the root
without an edit, and it sidesteps the trailing-slash failure recorded in §7.

**Blog links are the exception and stay absolute** (`/blog/…`). They 404 today
because the blog does not exist yet — open work 8. They were left pointing at the
real future URLs rather than being stubbed to `#`, because a dead `#` link is
the defect this rebuild existed to remove.

**Editing rule:** changes go into `body.html` and `stub_template.html`. `dist/`
is generated output and is wiped on every build.

---

## 14. Blog

Design received 3 August; rebuilt the same way the landing page was. The article
page did not exist in the design and was built here.

### Pages

| Page | Path | Built from |
|---|---|---|
| Journal, Turkish | `/blog/` | `blog_index.html` |
| Journal, English | `/en/blog/` | same source |
| Article | `/blog/<slug>/` · `/en/blog/<slug>/` | `blog_post.html` |
| Editor | `/dashboard/blog/` | `dashboard_blog.html`, `noindex` |

URL shape follows Blog Plan §7. Turkish at the root, English under `/en/`,
reciprocal `hreflang` on both, `BlogPosting` JSON-LD per article.

### How publishing works

Writing happens in the dashboard. Saving writes to a `posts` sheet. Publishing
renders the index and every article from templates held **in the repo**, then
commits the result through the GitHub Contents API, which triggers the normal
autodeploy.

**The result is a static file.** A visitor opening an article makes no request to
Apps Script, to the sheet, or to Google. If this whole backend disappeared
tomorrow, every published article would keep working. That is the reason for
building it this way rather than fetching JSON at runtime — the alternative also
hands the article body to a crawler as an empty div, which for a blog whose whole
purpose is SEO would be self-defeating.

A republish that produces byte-identical output is skipped, so the repo does not
fill with empty commits.

**`BLOG_PREFIX` is the trap.** It is the repo path articles are written under —
`preview/` today. Left as `preview/` at launch, articles publish into the preview
folder and never appear on the site. It is the single most likely thing to be
forgotten on 20 August.

### Images

No path field. Upload from the editor or reuse from the library.

The browser crops and compresses before anything is sent — **1600×900** for the
article lead, **1200×900** for the featured slot, **1200×800** for a card, plus a
320×213 thumbnail for the library. JPEG at 0.82. All four are committed to
`blog/img/` and shared by both languages, so a translated pair carries one file
set, not two.

**The focal point is the part that earns its place.** A card is 3:2 and an
article lead is 16:9; centre-cropping one source into both regularly puts a face
half out of frame. Clicking the image sets a point that all three crops keep
centred, within what the edges allow. The three previews update live, so what is
approved is what ships.

Cropping client-side also means the original never reaches us — a 6 MB phone
photo becomes four files totalling a few hundred KB before it leaves the browser.

Deleting an image is refused while a post still points at it, and the refusal
names the post.

`SITE_PREFIX` in the editor exists only so the image previews load from the right
place. It must carry the same value as `BLOG_PREFIX`, and both change at launch.

### Scheduling

The date field is both the published date and the timer. A future date makes the
publish button read `Zamanla`, stores the post as `scheduled`, and keeps it off
the site. A daily `publishDue` trigger flips anything whose day has arrived and
rebuilds; a day with nothing due produces no commit.

The decision is taken from the date rather than a separate switch, so the two can
never disagree — there is no way to have a post marked published with a date next
week, or scheduled with a date last month.

### Authors

A fixed list: **Eray Dengiz** or **Anthifel**. It was free text, which over a
year of writing reliably produces two spellings of the same name in the byline.

### What is stored where

The sheet is the source; the repo is output. Editing a published HTML file by
hand works until the next publish overwrites it. Corrections go through the
editor.

### The dashboard token

The editor authenticates to Apps Script with a shared secret held in the page
source. The dashboard is `noindex` and behind a client-side password, so this
token is **publishing authority, not a vault** — §7 already records that the
dashboard password deters rather than protects. Anyone with the dashboard URL and
its source can publish to the blog. Acceptable while one person writes; if that
changes, Cloudflare Access is the answer, as §7 says.

### Reading list

The newsletter box on the blog is a second personal-data flow and carries the
same three consent conditions as the assessment gate: unticked box, policy link
inside the label, timestamp and exact wording recorded. It ships switched off
with the same flag and unblocks with the same Legal item.

The design shipped this box with no consent tick at all. That would not have
satisfied Legal §2 item 2, which requires explicit consent for any list receiving
marketing email, so the tickbox was added rather than the promise weakened.

---

## 15. Verification

Nine suites. All must pass before anything deploys, and a visual pass over the
screenshots after that — a green suite and a broken-looking page are not
mutually exclusive.

| Suite | Assertions | What it is for |
|---|---|---|
| `check-responsive.js` | prints a verdict | Every page at 1440 / 1024 / 768 / 430 / 390 / 360 / 320. Ignores what a parent clips or what is parked off-screen on purpose. Must print **NO OVERFLOW ANYWHERE** |
| `check-behaviour.js` | 207 | The landing page |
| `check-code.js` | 59 | The email-code gate, in its live shape |
| `check-links.js` | 6 | Every internal link in both builds, and the footer on every public page |
| `check-legal.js` | 95 | The three legal pages |
| `check-service.js` | 52 | The AI Readiness Audit page |
| `check-blog.js` | 86 | The blog index, the article template and the editor |
| `check-dash.js` | 229 | The dashboard |
| `check-comingsoon.js` | 16 | The page that is actually served today |
| `mobile-pass.js` | 82 | Six pages at 390 / 360 / 320: tap-target height, body-copy size, the burger, the booking band |

**`check-behaviour.js`** — every anchor resolves, no `href="#"` survives, every
relative page link exists as a file beside `index.html`, every `data-en` node has
a `data-tr` twin, each §9.2 sentence appears verbatim, the gate holds, the
consent box starts unticked with its policy link inside the label, the twelve
questions and both ceilings score correctly, nothing about the test reaches
storage or the network, the burger opens and closes, the four Brand Guidelines
§8 sweeps hold, every wordmark renders at 15 px or above, and the hero line
types without moving the headline.

The §9.2 assertions are the useful part: they fail the build if someone
paraphrases a service line, which is exactly how the site drifted from Services
the first time.

**`check-code.js`** exists because the preview cannot exercise what matters. The
built preview carries `FORM_LIVE = false` and an unwired endpoint, so it skips
the code step entirely — correct behaviour, and it would leave the whole flow
untested. The suite takes the built page, flips the switch and substitutes a
fake endpoint into its own copy, then answers that endpoint locally. It never
reaches Google, Apps Script or a mailbox. Beyond the happy path it drives every
failure the endpoint can return, and asserts the red line two ways: no field
named for the answers, and nothing twelve items long in any payload.

**`check-links.js`** exists because of `meet/`. It was linked from three places,
it never existed, and it stayed broken for days behind a green suite — because
the old check understood exactly two shapes: a `#anchor`, and a bare `foo.html`
sitting beside index.html. Directory links, links with a fragment on the end,
links one level up: none were resolved, and none were reported as unchecked
either. A test that silently skips what it cannot parse is worse than no test,
because it counts as a pass. This one resolves everything, asserts that every
public page carries the full site footer, and prints the three things it knows
are pending rather than broken — templates resolved from where they will be
written, blog posts not yet published, and the legal pages production refuses to
write — so each disappears on its own when the thing it waits for happens.

**`mobile-pass.js`** measures what a screenshot cannot: the height of every
control, the smallest body copy, whether the burger opens, whether the booking
band widens the page. It exempts a link inside a sentence, which is as tall as
its line, and a tick box, which is the size a tick box is — and says so in the
code, because an unexplained exemption is how a suite quietly stops testing.

Both builds are checked, not just one. State at 12 August: **NO OVERFLOW
ANYWHERE** across six pages in preview and production, and every count in the
table above passing with none failing.

---

## 16. K47 — Brand Guidelines §8, what shipped and what did not

**Site copy lives in `Anthifel_Brand_Guidelines.md` §8, not here.** That block is
Marketing's handover and the single source. It is deliberately not reproduced in
this file: two copies of the same paragraph stop agreeing within days and nobody
can then say which one the site was built from. When §8 changes, Marketing sends
it again and this department reapplies.

**Re-verified 8 August against the built file**, not against this table: every
item below was checked by reading `dist/preview/index.html` — the withdrawn
quote absent in both languages, the replacement sentence present in both, the
hero block present, zero em dashes, zero "wrong", zero "yanlış". Item 4 is still
the only gap. The table was already right; it is the checking that was worth
doing, because a state table is a claim and the build is the fact.

### Shipped, in the order §8.6 sets

| §8 item | State |
|---|---|
| 1 · withdrawn sentence removed | **Live in preview** |
| 2 · replacement in the same slot, EN and TR | **Live in preview** |
| 3 · hero block, tagline and hero altı | **Live in preview** |
| 4 · brand narrative | **Not applied.** Added 3 Aug, removed the same day on CEO instruction |
| 5 · four site-wide rules | **Swept**, see below |
| 6 · order | Followed |

**Item 4 is the one gap.** It had no home to begin with: there is no about page
and no narrative block existed, so a quiet section was added between Services and
the assessment. The CEO removed it the same day. The section is gone and the
copy was not moved anywhere else, so **§8.4 is currently unapplied** and the site
carries no brand narrative in either language. Recorded here rather than quietly
dropped, because §8 lists it as handed over.

If it is wanted later it needs a decision this department cannot take alone:
an about page (which needs a nav entry) or a home-page block (which was just
rejected). Marketing and the CEO, not Developer.

### The four rules, as swept

**Rule 2, em dash.** Zero remain in any customer-facing text: landing, blog index
and article template, the three holding pages, and the confirmation email in
`Code.gs`. Replaced by a middle dot in titles, a full stop or comma in prose. The
preview banner was cleaned too. Code comments still contain them; they are not
customer text.

**Rule 1, "wrong" and "yanlış".** Zero remain. One non-obvious hit: the form's
failure message read "Something went wrong", now "Something did not go through",
which is also more accurate about whose failure it was.

**Rule 3, technology opposition.** The hero sub-line and the meta description
both carried "not with the technology, but with the people behind it". Both
replaced with §8 text. One case referred to Marketing, below.

**Rule 4, Turkish written separately.** Applied where §8 supplies both languages.
Elsewhere the existing Turkish was left alone rather than machine-adjusted; where
it reads as a translation it is listed below.

**These four are now assertions in `check-behaviour.js`.** The sweep is not a
one-off tidy: the build fails if an em dash, a "wrong", a "yanlış" or the
withdrawn sentence reappears in any page copy, in either language. Attribute
copy for the language that is not currently showing is swept too, which is where
half of it was hiding.

### Referred to Marketing, not changed here

Site copy is Marketing's content. §8 gives replacement text for the home page
only, so the following were left standing and are Marketing's to rewrite. They
are recorded here so the gap is visible, not to propose wording.

| Where | Sentence | Which rule |
|---|---|---|
| Blog masthead, EN | "…written for the people who have to decide, not for the people who build the models." | 3 — sets us against model builders using the X-not-Y shape |
| Blog masthead, TR | "Modelleri kuranlar için değil, karar vermek zorunda olanlar için yazıldı." | 3, and 4 — reads as a translation of the English |
| Blog meta description | Same sentence, both languages | 3 |
| Reading list, TR | "Şirketlerin içinde gördüklerimizi, karar vermek zorunda olan insanlar için ayda bir yazıyoruz." | 4 — English clause order |

The em dashes in those sentences were removed, because punctuation is mechanical.
The constructions were not, because rewriting them is writing copy.

### One question back to Marketing

§8.3 gives the EN tagline without a full stop ("AI needs a guide, not just
tools") while §1 Marka Vaadi gives it with one. The site keeps the full stop, as
it had. Turkish has one in both places. Worth settling in §8 so the next person
does not have to choose.

---

## 17. Every internal link is relative

The nav pointed at `/blog`. Under `/preview/` that resolves to
`anthifel.com/blog`, which does not exist, so the Blog menu item was a 404 for
every visitor of the preview build. The footer post links and `/meet` had the
same shape.

All of them are now relative: `blog/`, `blog/<slug>/`, `meet/`. The same file
then works under `/preview/` and at the root without an edit, which is the rule
§13 already sets for the legal pages, applied consistently.

One related bug went with it. `footerPosts_()` in `BlogCode.gs` generated links
relative to the blog index and the same string was reused on article pages, one
level deeper, where they resolved to `blog/<slug>/<slug>/`. It now takes a base.
Nothing had shipped yet, so nothing broke in public.

`check-behaviour.js` now fails on any `href` beginning with `/`.

---

## 18. K47 item 7 — Turkish page

Same rule as §16: the copy lives in `Anthifel_Brand_Guidelines.md` §8.7, not
here. Below is only what shipped and what did not.

| §8.7 | State |
|---|---|
| 7a · spelling and the half sentence | **Live in preview**, all three |
| 7b · three sentences against the brand voice | **Live in preview**, all three |
| 7c · translation smell | **Live in preview**, all six |
| 7d · blog titles in Turkish | **Live in preview**, four of five — see §19 |
| 7e · naming and imprint | **Live in preview**, all four |
| 7f · AI suffixes, two addresses | No action needed, site was already consistent |
| 7g · Advisory Board Seat vs five stages | Marketing's, not waited on |

**Re-verified 8 August against the built file.** 7a, 7b, 7c and 7e all read as
this table says. 7d is now four blog titles, not five — the fifth was never
added and the behaviour suite asserts four. 7f needs a decision that is not
this department's, below.

**7f, and a change made and reverted.** The Turkish copy carries two different
apostrophes: `AI'a` in one place, `AI’a` in two others, and the same split runs
through the consent line and the imprint. This department normalised them to the
typographic form, then put all of it back. Marketing writes the rule itself as
`AI'a` with a straight apostrophe, and §8.7e's imprint is straight — so choosing
the other one was inventing a rule Marketing had not set, in copy that is
Marketing's. The inconsistency is real and is now a question to Marketing rather
than a fix from here.

**English was not touched.** A test asserts three English sentences item 7
rewrites in Turkish are still present in English, so a future sweep cannot
quietly "fix" them.

### One name for the assessment

The page carried three: "AI Hazirlik Testi", "Hazirlik testi", "Test". Now:

| Where | Name |
|---|---|
| Eyebrow, gate | **AI Hazırlık Testi** |
| Hero button | **AI Hazırlık Testi →** |
| Nav, footer menu, Approach stage I | **Hazırlık Testi** |

The short form is the one §8.7e sanctions for narrow space. A bare "Test"
appears nowhere, and the test fails if it comes back.

### Two "skor" outside the scan

The scan read the public page, so it never reached the two strings behind the
assessment gate, which also said "skor". The word and the reason are exactly the
ones §8.7c rules on, so the same substitution was applied rather than leaving
two sentences contradicting the rule that had just been set. **Flagged as applied
by extension, not from the §8.7 list** — Marketing can reverse it in a line.

---

## 19. Back to Marketing, Business and Legal

**To Marketing — the fifth blog title.** §8.7d gives Turkish for four of the five
footer titles and records that "The first ninety days of an AI roadmap" is not in
the Blog Plan. The four Turkish titles are in; **the fifth row was removed.**

That needs saying plainly, because removing it also shortened the English footer
from five links to four, and item 7 was supposed to leave English alone. The
alternative was one English title sitting among four Turkish ones on the Turkish
page, which is the exact defect 7d exists to fix. All five links are placeholders
pointing at articles that do not exist, and `footerPosts_()` overwrites the whole
list at the first publish on 12 August, so this self-heals. **One line restores
it** if Marketing says the title is real.

**To Legal — the imprint.** §8.7e asks whether translating the registration
statement is acceptable and gives the Turkish. It is **applied**: the Turkish
page now reads "© 2026 Anthifel Ltd · İngiltere ve Galler'de tescillidir".
Applied rather than held because it is preview only and reverting is one line.
If Legal wants the statutory English form kept in both languages, say so and it
goes back.

**To Business — Services §9.2 now disagrees with the site.** Two Turkish
sentences §8.7 rewrites are sentences §9.2 fixes word for word:

| Service | §9.2 says | §8.7 says, and the site now shows |
|---|---|---|
| Transformation Retainer | "Doğru insanlar, işe alınmış ve birbirine bağlanmış. Tutan bir ritim." | "İşe alımlar yapılmış, roller birbirine bağlanmış. Tutan bir ritim." |
| Executive Workshop | "Yönetiminizle bir gün. Genel bir eğitim değil, sizin senaryolarınız." | "Yönetim ekibinizle, genel bir eğitim değil, sizin senaryolarınız üzerine." |

This department's charter says the site follows Services exactly. It now does
not, because a newer instruction from Marketing, routed through the CEO, says
otherwise. **Brand Guidelines §8.7 was followed**, on the grounds that it is
newer, it is explicitly a handover to this department, and it is specifically
about these strings. Services §9.2 needs updating by Business so the two agree
again. Until then the English half of §9.2 is still asserted verbatim by the
tests; only the Turkish diverges.

---

## 20. Privacy in place

The consent tick links to the privacy policy. Following that link used to leave
the page, which lost the tick and, in practice, the visitor. It now opens in a
dialog over the form: Escape closes it, the tick survives, and a link to the full
page is still there for anyone who wants it. The same applies to the reading-list
box on the blog.

The dialog copy is generated by `build.py` from the same `STUBS` entry
`privacy.html` is generated from. One source, two surfaces, so Legal's text
cannot land in one and not the other.

---

## 21. The dashboard

`/preview/dashboard/` is one document. The section menu at the top swaps panes
inside it; the hash exists so a section can be linked to and reloaded, not so
the browser can navigate. `/dashboard/crm/` and `/dashboard/blog/` are redirect
stubs, because those links were given out before.

The menu is one row of departments — Genel Bakış, Sales, Marketing, Finance,
Developer — each opening its own list when pointed at. The panel always answers
"whose screen am I on" before it answers "which screen". Nothing was renamed to
do this: the lists are read at load off the markup, so adding a section is one
line in one place.

Hover opens it only where a pointer exists. A touch screen reports a hover it
never had, and the list would open under the finger on the way somewhere else,
so below 900px the burger opens the whole tree at once and the dropdown logic
stays out of the way. Where hovering does work the list is already open by the
time you press, so the department header is simply a link to its first section.
Keyboard focus opens it too.

Heavy sections build themselves the first time they are opened. Until you go to
CRM it draws nothing, and until you go to Blog it does not call the Apps Script.
A section that is never opened costs nothing but its bytes.

### What each section holds

| Section | What it is | State |
|---|---|---|
| Genel Bakış | What is live, what is missing, a to-do list with dates and a card per module | this browser |
| CRM | The ANC engine: pool, triage, four working lists, DM rounds, advice engine | CSV, on disk |
| Blog | The editor: markdown, image library, crop with a focal point, scheduling | Sheet + GitHub |
| İçerik | Pillars and target mix, channels, ten content types and their rules, blog and social pre-publish checklists, banned words, sources | this browser |
| Site | Launch checklist, content map with the search string for each piece of copy, page inventory, how publishing works | this browser |
| SEO | Page and post rules, key phrases, the one-off site-wide list | this browser |
| Analitik | GA4 setup, Measurement ID validator and snippet generator, panel links, the events worth counting | nothing stored |
| Finans | Three flows: Finance's 36-month cash model read line by line and year by year, an income and expense ledger with CSV out, and the fixed costs | this browser |

"this browser" means `localStorage` on the machine you are sitting at. It is a
working aid, not a record: nothing survives a cleared browser and nothing is
visible from a second device. Every section that stores something says so on the
page. Anything that must survive belongs in the MD files.

### What is deliberately not there

No prices, anywhere. The CEO sets those; the panel records what happened, not
what something should cost. No live analytics: the site is static, so numbers
are read in Google's own panel and only the setup lives here. No client
personal data: the door is a password written into the page, which is a
deterrent and not a lock, and it stays that way only as long as nothing behind
it is worth stealing.

### Storage and the door

Ticked boxes, the to-do list and the ledger live in `localStorage`: device-bound,
never sent anywhere. The CRM's own data moves through the file you download and
load again; the planner's through the JSON working file you choose.

**There is no database.** That is the honest answer and it is a decision that
has not been taken rather than a gap that was overlooked. Three routes, in
order of what they cost:

| Route | What it buys | What it costs |
|---|---|---|
| **Google Sheet + Apps Script** | One record for every device and browser, readable by anyone with the Sheet, no new bill and no new account — the blog editor already runs on this exact plumbing | Slow at a few thousand rows, no real query, and every write goes through a script that has to stay deployed |
| **A hosted Postgres (Supabase, Neon)** | A real store with real queries, and a foundation the CRM could sit on later | A monthly bill and an account to keep — CEO decision under the charter — plus authentication in front of it, which the panel does not have (item 25) |
| **Stay in the browser** | Nothing to build, nothing to pay, nothing to secure | One machine, one browser, and gone if it is cleared |

The recommendation is the Sheet, and only for the Finance model and the ledger
— the two things that are records rather than working aids. The panel's state
is already written in the shape Finance's own export speaks, so the move is
`finSave()` and `finLoad()` and nothing else. The checklists can stay where
they are; losing a ticked box costs a minute. Open work item 30.

The password is a client-side front door on a static site. It deters, it does
not secure. **No sensitive data is kept in the panel**, and that is the condition
that makes the arrangement acceptable rather than the password. Real
authentication, if the panel ever holds client data, means a layer in front of
it — Cloudflare Access or equivalent. Open work item 25.

Two traps worth remembering, both met while building the old panel: a class name
shared between the top bar and the side menu applied the wrong rules to both, and
a brand mark in a column flex box stretches to the box width unless
`align-items:flex-start` is set.

### Finance's cash panel

Finance handed over a standalone page: 36 months, two scenarios, 106 expense
lines, and a cash line that recomputes as a line is switched off or edited. It
is the browser copy of `Anthifel_Finansal_Model.xlsx`. The engine is theirs and
was not touched.

Its handover said two things that shaped the port. *"Panel salt istemci.
Dashboard'a gömerken off/on/edits/custom durumunu kendi kalıcı katmanınızda
tutun."* And: *"localStorage kullanılmadı — bilinçli. Kalıcılık dashboard'un
işi."* So persistence was added here and nowhere else, in the shape the panel's
own export already speaks — `{ mode, real, scen, off, on, edits, custom }`. The
file it exports and the record it stores are interchangeable, which is what
makes moving to a real store later a change of two functions rather than a
migration.

**The panel was month-first; it is line-first now.** It opened on a
month-by-month breakdown, which answers "when" — and the question actually
being asked of it is "what are we paying for, and how often". The 106 lines are
listed by category, each carrying its own frequency, and a month is a filter on
that list rather than a different screen.

**One column was right and unlabelled, which is worse than being wrong.** The
amount column held the 36-month total and read as a monthly figure. $100 a
month is ₺4.630 today and ₺221.736 over three years, because the model's rate
moves from 46,3 to 76,5 — the difference is the rate path, not an error. It is
four columns now: today's charge with its unit spelled out, then each of the
three years, which add up to the total and can be checked by eye. A test
asserts that they add up.

The years are twelve months each. The horizon starts in August, so calendar
years would give four uneven buckets and a five-month first year; every heading
names its range instead of its number alone.

Worth passing back: 46,3 → 76,5 over 36 months is about 18% a year against the
dollar. That is Finance's assumption and it lives in the payload, not here.

**Four things collided in the port, and every one of them failed silently.** They are worth
writing down because the next page that becomes a section will hit the same
four.

| What | What it looked like |
|---|---|
| Top-level names | The panel was a page, so `render`, `D`, `mode`, `off` were globals. İçerik is also top-level — it draws with `innerHTML` and calls back through inline handlers, so it has to be — and has a `render()` of its own. Load order decided which survived. **İçerik came up blank, no error anywhere.** The panel is wrapped in a closure now |
| `:root` | The panel declared its custom properties on `:root`. Confined to `#fin` that selector matches nothing, so every border, muted label and chart colour resolved to nothing. The panel came up flat and readable enough to miss. They are declared on `#fin` |
| Bare `button` | `#fin button` outranks the shell's `.btn` on specificity, so it repainted the flow strip and every dashboard button in the section. Guarding the rule with `:not(.btn)` only moved the damage — it raised the rule above `.ib`, a 23px icon box, and the 12px padding pushed the glyph out of it. The fix was structural: `#fin` now wraps the panel and nothing else, and the flow strip is shell markup. **Confinement only works if the thing being confined is the only thing inside** |
| `.sec` | The panel's category heading class. The shell calls a section pane `.sec` and counts them to prove one is open. Renamed to `.fsec` |

The row icons were the panel's own `✎` and `−` glyphs in a 23px box. Two fonts,
two sets of metrics, and no centring rule fixes both at once — one sat high and
the other low. They are inline SVG now, and a test measures the distance
between each icon's centre and its box's.

An unclosed `<div>` came with it too: the extraction stopped at the page's own
closing `</div>`, leaving its opening tag in place. One unclosed div is
invisible until something is placed after it — the Defter and Sabit flows
became children of the model flow and vanished with it. `mk_finans.py` now
counts the tags and refuses to write an unbalanced fragment.

### Source layout

`dash_parts.html` holds the shell — head, gate, section menu, toast, router and
the shared checklist helper. Each section is a fragment, `dash_sec_*.html`, with
its own stylesheet, its markup and a builder registered on `window.dashInit`.
`build.py` stamps them into `dash_app.html`. The blog editor was written as a
page of its own and uses class names the shell also uses, so its stylesheet is
confined to its own section at build time rather than renamed by hand.

`mk_crm.py` is the one-off that lifted the CRM engine out of the old dashboard.
It is kept for the record: it says exactly what was changed in the port and what
was left alone.

### The old dashboard

`/dashboard/` used to be a panel of its own. Both were live for a day, which is
one day too many: two doors, two to-do lists, two answers to the same question.
Its pages are now redirect stubs pointing at the matching section here, and the
two things it kept in the browser, the to-do list and the ledger, are carried
across on first visit. Nothing was deleted from the old keys; if the conversion
is wrong in some way, the originals are still there.

At launch the production build writes the dashboard to `/dashboard/` itself and
the stubs are replaced.

**Until then, only `preview` is ever uploaded.** The root `index.html` is the
coming-soon page and the root `dashboard/` is ten redirect stubs; neither
changes by hand. On 5 August the built panel was uploaded over
`dashboard/index.html` and the application was live at two addresses again,
one day after that was fixed the first time. It is a consequence of deploying
by hand — the push proxy will not carry a credential for this repository — and
it will keep happening until that is resolved. Open work 36.

`mk_icerik.py` and `mk_finans.py` are the one-offs that lifted the planner and
Finance's cash panel across, kept for the same reason `mk_crm.py` is: they say
exactly what was changed in each port and what was left alone.

---

## 22. The readiness test

Built 4 August from `Anthifel_Readiness_Metodolojisi.md` and the Business
brief. Before this the assessment was an email gate followed by a placeholder.

### What it does

Twelve questions, five dimensions, weights 30 / 25 / 20 / 15 / 10. Three
options per question worth 0, 50 or 100. Dimension score is the plain mean of
its questions; the raw score is the weighted sum. Then the two ceilings from
methodology §4, in order: any dimension below 40 caps the total at 59, and
Strategy & Ownership below 40 caps it at 49.

**When a ceiling bites, the result screen says so** — raw score, ceiling, and
which dimension caused it. That is the most useful thing on the screen and the
reason the test cannot be hidden behind a single number.

The result is one screen in three parts, in this order: score and band; five
dimension bars with the weakest picked out and named in a sentence; one call to
action. One, not two, by instruction.

### What is recorded, and what never is

**The twelve answers are never recorded, anywhere.** Not in storage, not in a
request body, not passed to analytics. They live in one array in memory and go
nowhere. This is the Developer brief's second red line and it is proved rather
than trusted, in two suites: `check-behaviour.js` reads every POST body the page
attempts and inspects both storages after a completed run, and `check-code.js`
does the same against a live-shaped endpoint that records everything it is sent.

**The score, the band and the five dimension averages are recorded** — from
11 August, when the result mails were added (§12). The dimension averages are
the five bars already on the visitor's screen, and they are what makes the lead
mail worth reading; a bare number says a company scored 62 and nothing about
where it is thin. The distinction that matters is the one the red line draws:
what a company answered to a given question stays with the company, and the
shape of the result comes to us.

Before 11 August nothing at all was recorded, because there was nowhere to send
it. That was a consequence of the endpoint not existing, not a policy, and it
should not be read as one.

### What Business did not supply

The methodology defines **seventeen** criteria and the test has **twelve**
slots. The twelve questions are drafted here from those criteria, one question
per criterion. Five criteria are therefore **not asked**:

| Dimension | Criterion not asked |
|---|---|
| Strategy & Ownership | 1.3 Link to a business goal |
| People & Capacity | 2.4 HR alignment |
| Data & Process Foundation | 3.3 Data reliability |
| Economics & Measurement | 4.2 Baseline measurement |
| Technology & Infrastructure | 5.2 Integration |

The wording is Developer's draft, not approved copy. **Marketing owns the
words and Business owns the mapping**; both are open work, items 27 and 28.

### Three answers back to Business

**The email gate stays.** Brief red line 3 says the score must not sit behind an
email wall. The gate was built at the CEO's instruction and the CEO confirmed on
4 August that it stays. The brief's other two red lines around it hold in full:
the test records nothing, and the score is shown on screen the moment the last
question is answered. What the gate collects is the email address, before the
questions, exactly as before.

**The independence statement stays off the page.** Brief §B.3 asks for it in a
visible place. It was removed on 3 August by CEO instruction, and the brief is
dated 2 August, so the instruction is the newer of the two. Confirmed again on
4 August. Services §9.4 still requires it, so Services and the site disagree
until Business moves. This is §11.3, unchanged.

**§B.2 is already done, in a better shape.** The brief says Approach jumps from
the conversation straight to Discovery and asks for a sub-line under stage III.
Approach has had Audit as its own stage since 3 August, so the sub-line would be
a footnote under a stage that already exists. Left as is. Note that this is the
five-stage Approach of §11.1, which Services §9.3 still describes as four.

### One conflict for Marketing

Brief §A.4 says the band copy goes in verbatim and Developer does not change it.
Brand Guidelines §8 says no em dash appears anywhere on the site. **Three of the
five band paragraphs contain one.** The copy went in verbatim, as instructed,
and the exception is pinned in the test: nothing else on the result screen may
carry an em dash. Marketing settles which rule wins.

---

## 23. Service providers — what reaches whom, and where

Legal asked for one thing per tool: what it is, which personal data reaches it,
and which country it is hosted in. This is that list, taken from the code
rather than from memory — every entry below is something the built files
actually do, or explicitly do not do.

Two words are used carefully. **Live** means it is in the file being served
today. **Planned** means it is written into the launch plan and is not in the
file yet, so nothing reaches it now.

### What reaches a third party today

| Service | What it is | Personal data reaching it | Hosted | State |
|---|---|---|---|---|
| **DigitalOcean App Platform** | The hosting. Serves every page | Visitor IP address and user agent, in access logs | **To confirm — read the region off the console.** DigitalOcean is a US company; the app's region was chosen at creation | Live |
| **Domain registrar** | The `anthifel.com` registration | Registrant name, address, email in WHOIS unless privacy is on | To confirm with the registrar | Live |

That is the whole list. A visit to `anthifel.com` reaches the host and nothing
else — see "What deliberately does not leave the browser" below.

### What will reach a third party at launch

| Service | What it is | Personal data reaching it | Hosted | State |
|---|---|---|---|---|
| **Google Calendar appointment schedule** | The booking window behind every "Görüşme Ayarla" button. Embedded in a modal, not navigated to | IP address, user agent and Google cookies **only once the visitor clicks**; then whatever they type into Google's own booking form — name and email at minimum. That form is Google's, not ours, and we do not see it before Google does | Google. No region control is offered | **Live on the preview, on click only.** Nothing reaches Google on a page view |
| **Google Apps Script + Sheets** | The form endpoint and the store behind it | Name, email, company, role, the consent record, and the score and band of a completed assessment. Never the twelve answers | Google. Which region depends on the Workspace edition and the Admin console setting — **to confirm** | Planned — item 11 |
| **Resend** | **How every mail we send actually leaves.** The code mail, the visitor's result mail and our own lead mail | The recipient's address, the subject and the body — which for the result mail carries a score, a band and five dimension averages | Resend, Inc. — US company; our sending domain is configured in their **Ireland (eu-west-1)** region | **Live from 12 Aug.** Not yet in the privacy notice — §10 item 53 |
| **Google Workspace — outbound mail** | The fallback, if `RESEND_KEY` is unset or Resend refuses | As above | As below | Live as a fallback only |
| **Google Workspace** | Mail, including the privacy inbox | Whatever anyone writes to us | As above | Live for mail |
| **GitHub** | Where a published blog post is committed, by Apps Script, not by the browser | Author name on the post. No visitor data | GitHub, Inc. — US | Live for the editor, item 16 |
| **Google Analytics 4** | Visitor measurement | IP address, device, pages viewed | Google | Planned — the panel holds the setup only, no tag is on the site |
| **Calendly** | `/meet` booking | Name, email, meeting time, anything typed into the booking form | Calendly LLC — US | Planned — item 7 |

### Outside the UK

**All six of them.** Google, GitHub, Calendly and DigitalOcean are all US
companies, and none of the data above is guaranteed to sit in the UK as things
stand. Three are worth separating, because what can be done about them differs:

- **DigitalOcean** is in **Frankfurt (FRA1)**, read off the console on 12
  August, and is moving to **London (LON1)** — the CEO's decision the same day.
  Not a compliance problem: Germany sits inside the UK's adequacy finding, and
  the site is static, so there is no visitor data there to move. It is a
  consistency problem, and the cheaper thing to fix is the console rather than
  every sentence that says London. The region cannot be changed on an existing
  app, so it means a new app from the same repo and moving the domain. `DEV-064`.
- **Google Workspace** has a data-region setting, but not on every edition.
  Read on 12 August: ours is **Business Starter**, and the setting **does not
  exist on it**. So there is no region control over Workspace data — mail, the
  sheet behind the form, the code store — and there will not be without an
  upgrade. This is a fact for Legal to work with rather than a gap to close.
- **Calendly** offers no region choice at all, and the question is whether the
  booking is worth the transfer; it is a name, an email and a time. The line
  that used to sit beside it — reCAPTCHA, also with no region choice — is gone:
  the bot check is now a mail we send ourselves, so there is no captcha vendor
  to place anywhere (§12).

This is an inventory, not an opinion on what is lawful. What is adequate,
what needs a transfer mechanism and what should simply not be used is Legal's
call, and every row above is written so it can be answered without reading the
code.

### What deliberately does not leave the browser

These are the strongest facts in this file and they are all testable, so they
are tested rather than asserted.

- **The fonts are inlined.** Cormorant Garamond and Inter ship as base64 inside
  the page. There is no font CDN, so no font request and no IP address going to
  one. `check-behaviour.js` fails if any request leaves the page on a plain
  visit.
- **The assessment is scored in the browser.** The twelve answers and the score
  are computed on the device. Nothing about the answers is transmitted, at any
  point, to anyone.
- **The CRM never uploads anything.** The LinkedIn export is read, parsed,
  scored and listed entirely in the browser. The 5,136 records do not touch a
  server. What leaves is the file you choose to download.
- **The panel's own data is `localStorage`** — the visitor's own device, not a
  third party at all.

### One thing that was wrong, and is fixed

The reCAPTCHA script tag sat at the bottom of the page and ran on every visit.
The widget was rendered explicitly and only with the gate, which is what the
comment beside it claimed, but the *fetch* is what sends the IP address and the
cookies — and it was going out on every page view, before the gate, before any
consent, and before a privacy policy exists to disclose it.

It is now requested at the moment the gate opens, and only when there is a live
form and a real key behind it. With `FORM_LIVE` false, which is where we are,
nothing is requested from Google at all. `check-behaviour.js` asserts it: any
third-party request on a plain page load fails the build.

### The privacy inbox

`privacy@anthifel.com` is the right address and it costs nothing — but it should
be a **Google Group, not an alias on Eray's seat**. A group can be read by more
than one person, survives a seat change, and keeps a thread history that an
alias does not. One-month response deadlines are hard to meet from an inbox only
one person can see.

Whatever the address ends up being, it goes in the privacy notice as text and
not as a form. Legal's note is explicit about that.

---

## 24. The database — Supabase, London

Approved 5 August. It replaces `localStorage`, which was one machine, one
browser, and gone if it was cleared.

**Why this and not the Sheet.** The Sheet was the cheaper answer and it was the
recommendation until §23 was written. §23 changed it: every provider the site
touches is outside the UK, and adding Google Sheets would have added another
one with an unclear region. A Supabase project in **London (eu-west-2)** is the
first row on that list that sits in the UK. It costs a monthly bill the Sheet
did not, and it buys a regional answer the Sheet could not give.

**Cost.** Free to start: 500 MB, enough for a ledger and a model selection by
several orders of magnitude. The catch is that a free project **pauses after a
week without use** and has to be resumed by hand. That is survivable now and
becomes irritating the moment anyone depends on it; Pro is $25 a month and
removes it. Start free, move when the pause bites — the move is a button, not
a migration.

### What is stored, and how

| Table | What it holds | Why that shape |
|---|---|---|
| `dash_state` | Key and JSON: the cash model selection, the checklists | The shape is whatever the panel says it is and changes when the panel changes. Losing a row costs a minute of re-ticking |
| `ledger` | Real columns: date, kind, description, category, amount, currency | It is a record. It has to be queryable, exportable and reconcilable without a parser. Losing a row costs money |

That split is the same one §21 already drew between working aids and records.
It is worth keeping in the schema rather than only in the prose.

**One workspace, not one row per person.** Eray and whoever joins later look at
the same ledger. The row level security policies let any *authenticated* user
read and write everything, and there is deliberately **no policy for the
anonymous role** — so the anon key alone opens nothing.

### The setting the whole thing rests on

The anon key ships inside the page. That is what it is designed for, and it is
not a leak. What it means is that **the only thing between the cash model and
the internet is who is allowed to sign in.**

> Authentication → Sign In / Providers → **turn off "Allow new users to sign up"**

Leave that on and anyone who finds the panel can create an account, and the
policies above will let them read everything. Users are added one at a time by
invitation.

### What this replaces

The panel's door is a password written into the page. §21 called it a deterrent
and not a lock, and said that was acceptable only as long as nothing behind it
was worth stealing. A shared database ends that argument: the door becomes
Supabase's own authentication, and open work 25 stops being a someday item and
becomes part of this build. That is items 38 and 39.

### The move itself

Finance's panel already exports and reads `{ mode, real, scen, off, on, edits,
custom }`, and the browser store was written in exactly that shape for this
reason. `finSave()` and `finLoad()` are the only two functions that change, and
the file the panel exports stays interchangeable with what is stored — which is
what makes the move safe rather than a migration.

The ledger is a genuine change of shape: an array in a browser becomes rows in
a table. The existing CSV export is the bridge, and there are few enough
entries today that the honest answer is to re-enter them.

**Written and waiting:** `anthifel_schema.sql`. It runs once, in the project's
SQL editor, after the project exists. This department cannot create the
project — that needs an account and a card.

---

## Change protocol

```
### Last change (date)

- [what changed — page, module, infrastructure]
- Live: [yes / no — awaiting deploy]
- Aligned with Services: [yes / no — if no, why]
- CEO decision needed: [yes — why / no]
```

Save to `Anthifel MD's/`. Mirrors are read-only.
