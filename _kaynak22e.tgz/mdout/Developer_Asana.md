# [Developer] — Asana Durum

Son güncelleme: 2026-08-12 (üçüncü yazım)
İşlenme: 2026-08-12

> Bu dosya Developer departmanının Asana operasyonuna tek girdisidir.
>
> **Her turda bu dosyanın ÜZERİNE YAZILIR.** Geçmiş burada tutulmaz —
> geçmiş Asana'dadır. Dosya her zaman yalnızca o anki durumu gösterir.
>
> **Her satır Task ID taşımak zorundadır.** ID'siz satır işlenmez, CEO'ya
> hata olarak bildirilir. Mevcut ID listesi ve son kullanılan numara için
> `Developer_ID_Kayit.md`.
>
> Yeni iş yazarken numarayı ID kaydındaki son numaradan devam ettir,
> atlama yapma, kullanılmış numarayı yeniden kullanma.
>
> Boş bölümü silme, altına "Yok" yaz. Silinen bölüm "atlandı" mı "boş" mu
> ayırt edilemez.
>
> `Son güncelleme` satırını her yazışta güncelle — Asana tarafı bu satıra
> bakarak dosyanın işlenip işlenmediğini anlıyor. `İşlenme` satırına
> dokunma, onu Asana tarafı dolduruyor.

## 1 — Tamamlananlar

Asana'da kapatılacak task'lar.

| Task ID | Task | Tamamlanma tarihi |
|---|---|---|
| DEV-024 | Marketing'in yeniden yazdığı dört cümleyi siteye işle | 2026-08-08 |
| DEV-050 | Marketing sekizinci tur: "boutique/butik" temizliği ve Türkçe H1 | 2026-08-08 |
| DEV-051 | Hero cümlesini CEO metniyle güncelle ve Yaklaşım III-IV başlıklarını Türkçeleştir | 2026-08-09 |
| DEV-052 | Marketing dokuzuncu/onuncu/on birinci tur ve hero butonlarının yer değiştirmesi | 2026-08-09 |
| DEV-053 | Ücretsiz görüşme butonunu Google takvim popup'ına bağla, ölü meet/ bağlantısını kaldır | 2026-08-09 |
| DEV-001 | Site için işleyen (processor) listesini çıkar | 2026-08-10 |
| DEV-002 | Çerez tablosunu çıkar ve zorunlu/zorunlu değil sınıflandırmasını yap | 2026-08-10 |
| DEV-054 | AI Readiness Audit sayfasını kur, sonuç ekranını ve teklif formunu bağla | 2026-08-10 |
| DEV-055 | Görüşme penceresini ortak parçaya çıkar, iki sayfa aynı pencereyi kullansın | 2026-08-10 |
| DEV-056 | Üç hukuki sayfayı Legal metniyle doldur, işlemci ve çerez tablolarını yaz | 2026-08-10 |
| DEV-057 | reCAPTCHA yerine tarayıcıda çalışan proof-of-work bot kontrolü kur | 2026-08-10 |
| DEV-058 | Görüşme penceresini sayfa içi banda çevir ve menüyü tüm sayfalara koy | 2026-08-10 |
| DEV-059 | Mobil kontrol suite'i yaz ve dokunma hedeflerini düzelt | 2026-08-10 |
| DEV-061 | Bot kontrolünü e-posta koduyla değiştir, üç maili ve doğrulama akışını kur | 2026-08-11 |
| DEV-062 | Hero satırını harf harf yazılan animasyona çevir | 2026-08-11 |
| DEV-063 | Apps Script endpoint'ini bağla, teslimat sorunlarını görünür kıl | 2026-08-12 |
| DEV-003 | privacy@anthifel.com adresini Google Grup olarak aç | 2026-08-12 |
| DEV-066 | Site footer'ını ortak parçaya çıkar, her sayfaya koy | 2026-08-12 |
| DEV-064 | DigitalOcean uygulamasını Londra'ya taşı | 2026-08-12 |
| DEV-016 | Supabase Pro'ya geç | 2026-08-12 |
| DEV-048 | Toplantı not alma aracını seç ve iç toplantıda pilotla | 2026-08-12 |
| DEV-028 | reCAPTCHA anahtarlarını üret | 2026-08-12 |
| DEV-031 | reCAPTCHA kararını ver | 2026-08-12 |
| DEV-057 | reCAPTCHA yerine tarayıcıda çalışan bot kontrolü kur | 2026-08-12 |

## 2 — Durum değişiklikleri

Sadece şu üç değer: `Devam ediyor`, `Bloke`, `Ertelendi`.

| Task ID | Yeni durum | Sebep |
|---|---|---|
| DEV-033 | Ertelendi | Calendly kurulmuyor. Görüşme 9 Ağustos'ta Google Takvim randevu takvimiyle çözüldü (DEV-053); task'ın kapatılması yerine CEO'nun aracı onaylaması bekleniyor |
| DEV-034 | Ertelendi | 0-29 bandının çağrısı Calendly yerine aynı popup'a bağlanacak; DEV-033 kararından sonra |
| DEV-029 | Devam ediyor | Proof-of-work token'ının sunucuda doğrulanması maddesi düştü; artık doğrulanacak token yok, kod endpoint'in kendisinde doğrulanıyor. Kalan iş Apps Script'in yayınlanması |
| DEV-001 | Devam ediyor | Liste `Anthifel_Website.md` §23'te yazılı; kalan iş Legal'in istediği biçimde teslim |
| DEV-022 | Bloke | Legal'in onaylayacağı Türkçe künye metni gelmedi |
| DEV-023 | Bloke | Şirket 20 Ağustos'ta kuruluyor, adres o gün kesinleşiyor |
| DEV-025 | Bloke | Kaç sapmanın açık olduğu kaynakta çelişiyor, CEO kararı gerekiyor |
| DEV-037 | Bloke | Uzun tire kararı Marketing'de |
| DEV-032 | Devam ediyor | FORM_LIVE hâlâ kapalı; endpoint bağlandı ama uçtan uca kanıtlanmadı ve gizlilik politikası yayımlanmadı |

## 3 — Deadline değişikliği talepleri

Tarihi kendiniz değiştirmiyorsunuz, talep ediyorsunuz.

| Task ID | Mevcut tarih | İstenen tarih | Sebep |
|---|---|---|---|

Yok

## 4 — Yeni işler

| Task ID | Kategori | Task | Deadline | Öncelik | Not |
|---|---|---|---|---|---|
| DEV-050 | Site | Marketing sekizinci tur: "boutique/butik" temizliği ve Türkçe H1 | 2026-08-08 | Yüksek | Aynı turda geldi ve bitti; kayda geçmesi için açılıyor |
| DEV-051 | Site | Hero cümlesini CEO metniyle güncelle ve Yaklaşım III-IV başlıklarını Türkçeleştir | 2026-08-09 | Yüksek | Aynı turda geldi ve bitti; site ilk kez §8'den kararla ayrılıyor |
| DEV-052 | Site | Marketing dokuzuncu/onuncu/on birinci tur ve hero butonlarının yer değiştirmesi | 2026-08-09 | Yüksek | Aynı gün geldi ve bitti; on birinci tur sekizinci turu geri alıyor |
| DEV-053 | Site | Ücretsiz görüşme butonunu Google takvim popup'ına bağla, ölü meet/ bağlantısını kaldır | 2026-08-09 | Yüksek | meet/ hiç kurulmamıştı; üç bağlantı 404 veriyordu. DEV-033 (Calendly) bununla gereksiz kaldı |
| DEV-054 | Site | AI Readiness Audit sayfasını kur, sonuç ekranını ve teklif formunu bağla | 2026-08-10 | Yüksek | Developer brief §C.1-C.5. Sonuç ekranı en sıcak anında katalog satırına gidiyordu |
| DEV-055 | Site | Görüşme penceresini ortak parçaya çıkar | 2026-08-10 | Orta | İki sayfa aynı pencereyi sunuyor; metin ve adres iki yerde durmamalı |
| DEV-056 | Site | Üç hukuki sayfayı Legal metniyle doldur | 2026-08-10 | Yüksek | Metin build sırasında Legal'in kendi dosyasından okunuyor; Legal'in üç bilgisi girilmeden yayın sürümü yazılmıyor |
| DEV-057 | Site | reCAPTCHA yerine proof-of-work bot kontrolü kur | 2026-08-10 | Yüksek | İki anahtar yoktu, gizlilik metnine işleyen ekliyordu; yeni kontrol hiçbir yere istek göndermiyor. CEO onayı bekliyor |
| DEV-058 | Site | Görüşme penceresini sayfa içi banda çevir, menüyü tüm sayfalara koy | 2026-08-10 | Orta | Modal yanlış kalıptı; ayrıca hizmet ve hukuki sayfalardan hiçbir yere gidilemiyordu |
| DEV-059 | Site | Mobil kontrol suite'i yaz ve dokunma hedeflerini düzelt | 2026-08-10 | Yüksek | İlk turda 24 gerçek hata: dil değiştirici 14 px, alt bilgi linkleri 17 px, blog çipleri 34 px. Hiçbiri taşma testinde görünmüyordu |
| DEV-060 | Site | Web sitesi yapılacaklar iş listesi | 2026-08-20 | Yüksek | Tek task, bütün açık maddeler açıklamada. Ayrıntı aşağıdaki DEV-060 açıklama bloğunda |
| DEV-061 | Site | Bot kontrolünü e-posta koduyla değiştir, üç maili ve doğrulama akışını kur | 2026-08-11 | Yüksek | Aynı gün geldi ve bitti. Proof-of-work ile reCAPTCHA'nın ikisi de "otomatik mi" diye soruyordu; asıl soru adresin gerçek olup olmadığıydı. Kod gelene kadar hiçbir şey kaydedilmiyor. Yeni suite: check-code.js, 46 test |
| DEV-062 | Site | Hero satırını harf harf yazılan animasyona çevir | 2026-08-11 | Orta | CEO talimatı. Bitmiş cümle sayfada görünmez duruyor, altındaki başlık hiç oynamıyor; ekrandan çıkınca ve sekme arkadayken duruyor. 12 Ağustos'ta CEO kararıyla hareket azaltma tercihinde de döngüye alındı |
| DEV-063 | Site | Apps Script endpoint'ini bağla, teslimat sorunlarını görünür kıl | 2026-08-12 | Yüksek | Endpoint build sırasında damgalanıyor, elle yapıştırma yok. Yarım gün mailin nereye gittiğini aradık; sorun yapılandırmada değil Gmail'in spam filtresindeydi. Asıl maliyet dört ayrı sessiz durumdu, dördü de artık konuşuyor |
| DEV-064 | Altyapı | DigitalOcean uygulamasını Londra'ya taşı | 2026-08-20 | Yüksek | Uygulama Frankfurt'ta (FRA1). Uyum sorunu değil — Almanya BK yeterlilik kapsamında — ama §23 ve metinler Londra diyor. Bölge mevcut uygulamada değişmiyor, yeni uygulama + alan adı taşıma |
| DEV-065 | Site | Hizmet sayfalarını zenginleştir, tasarım ve SEO ile yeniden kur | 2026-08-25 | Yüksek | Tek task. Business metni, Marketing aramayı, tasarım görünümü verir; Developer birleştirir. Ayrıntı aşağıdaki DEV-065 açıklama bloğunda |
| DEV-067 | Site | Yayın öncesi son kontrol ve FORM_LIVE'ı aç | 2026-08-20 | Yüksek | Tek task. Formu açmadan önce yapılacak her şey tek listede. Ayrıntı aşağıdaki DEV-067 açıklama bloğunda |
| DEV-068 | Site | Bloğun adını belirle ve siteye uygula | 2026-08-18 | Orta | CEO "The Journal" öneriyor. Türkçesi karara bağlanacak; "Yolculuk" çeviri hatası olur. Ayrıntı aşağıdaki DEV-068 açıklama bloğunda |
| DEV-066 | Site | Site footer'ını ortak parçaya çıkar, her sayfaya koy | 2026-08-12 | Orta | Hizmet ve üç hukuki sayfada yalnızca telif satırı vardı; aramadan gelen ziyaretçi çıkmaz sokaktaydı. Footer artık tek parça, check-links her genel sayfada arıyor |

### DEV-060 — açıklama (Asana description alanına birebir gider)

**Web sitesi yapılacaklar iş listesi.** 11 Ağustos 2026 itibarıyla açık olan
her madde. Yirmi madde; hiçbiri tahmin değil, hepsi ya `Anthifel_Website.md`
Bölüm 10'daki açık iş satırlarından ya da kodun kendisinden okundu. 11 Ağustos
güncellemesi: 6. ve 7. maddeler değişti — doğrulanacak proof-of-work token'ı ve
karara bağlanacak bir reCAPTCHA kalmadı, yerlerine Script Properties ve mail
metinlerinin onayı geldi.

**Başka departmandan bekleyenler**

1. Legal — üç bilgi: şirket numarası, kayıtlı adres, ICO kayıt numarası.
   Bunlar girilmeden privacy.html ve terms.html yayın sürümüne yazılmıyor;
   yapı reddediyor. Aynı departmandan ayrıca: saklama süresinin gün olarak
   verilmesi (PURGE_AFTER_DAYS), Türkçe künye ifadesinin onayı, ve ICO
   numarası 20 Ağustos'a yetişmezse ilgili cümlenin silinmesi kararı.
2. Business — üç hizmet sayfası metni: Discovery Sprint, Transformation
   Retainer, Advisory Board Seat. Gelene kadar hazırlık testi sonuç
   ekranındaki üç bandın butonu katalog satırına gitmeye devam ediyor.
   Ayrıca Services 9.2'nin Türkçesi ve on iki sorunun boyut eşlemesinin
   teyidi.
3. Marketing — beş açık madde: 9a Türkçe alt metin, 7c'deki "görüşme ayarla"
   yasağı, 8.7c'nin yeni ifadesi, Business'ın bant metnindeki uzun tire,
   beşinci alt bilgi blog başlığı. Buna Legal'in tablolarındaki uzun tire de
   ekleniyor; o madde Legal ile ortak.
4. CEO — Services Bölüm 11'deki sapmalardan kaçının açık olduğu. Karar
   çıkmadan sitede o metinler değişmiyor.

**Karar ya da bilgi bekleyenler**

5. Apps Script yayınlanmadı. Hazırlık testi de teklif formu da hiçbir yere
   göndermiyor. Web app URL'i gerekiyor. **11 Ağustos'tan sonra bu madde daha
   da kritik:** test artık e-posta koduyla açılıyor, endpoint olmadan kod
   gönderilemiyor, yani önizlemede test kod adımını atlıyor.
6. Script Properties dolmadı: `SHEET_ID`, `NOTIFY_TO`, ve `SEND_AS`. Sonuncusu
   Workspace'in gerçekten o adresten göndermeye izin verdiği bir
   `hello@anthifel.com` olmalı — kod maili başka bir adresten gelirse ya da
   spam'e düşerse akışın tamamı çalışmaz. DKIM (10. madde grubu) bu yüzden
   artık "iyi olur" değil, kritik yolda.
7. Üç mailin metni Marketing onayında: kod maili, ziyaretçinin sonuç maili, ve
   bize gelen lead maili. İkisi de TR ve EN. Developer taslağı olduğu
   `Code.gs` içinde yazılı; beşinin ekran görüntüsü 11 Ağustos'ta CEO'ya
   gönderildi.
8. FORM_LIVE hâlâ kapalı. 5, 6 ve 7 bitmeden ve gizlilik politikası
   yayımlanmadan açılamaz.
9. Deploy zinciri. Masaüstü köprüsü 10 Ağustos'ta dört kez düştü ve üç build
   deploy edilemeden bekledi. İki yol var: buradan push, ya da deploy.sh'ın
   build'i kendisi çekmesi.

**Developer'da, düz iş**

10. Blog altyapısı: GitHub ince ayarlı token ve Script Properties, blogSelfTest
    yeşile, günlük publishDue tetikleyicisi, lansmanda BLOG_PREFIX'in
    boşaltılması, ilk yazının uçtan uca yayını.
11. DKIM kaydı.
12. Canlı URL'i okuyan bir test. Bütün suite'ler bu konteynerdeki dosyaları
    okuyor; check-comingsoon bir kez yanlış artefaktta yeşil kalmıştı.
13. Ölü bağlantı kontrolü klasör linklerini görmüyor. #çapa ve *.html
    çözüyor, başka bir şey çözmüyor; meet/ günlerce bu yüzden kırık kaldı.
14. Google'ın randevu takvimini anthifel.com kaynağından iframe'e alıp
    almadığının teyidi. Yalnızca yayındaki sayfadan okunur.
15. Lansman mekaniği: production build köke, coming-soon sayfasının
    kaldırılması, /preview/ dizininin silinmesi, panelin yönlendirme
    stub'larının production build ile değişmesi.
16. Kayıtlı adresin alt bilgiye eklenmesi. Legal'in 1. maddedeki bilgisinden
    sonra.

**Konsoldan okunacaklar — hiçbiri henüz okunmadı**

17. DigitalOcean bölgesi. Londra değilse uygulama yeniden kurulup DNS
    taşınacak; bu iş lansmandan sonra değil, önce yapılır.
18. Google Workspace sürümü ve veri bölgesi ayarı, Admin konsolundan.
19. Alan adı kayıt kuruluşunda WHOIS gizliliği. Tescil sahibi bilgileri
    kişisel veridir.
20. privacy@anthifel.com adresinin takma ad değil, gerçek ve okunan bir
    Google Grubu olarak açılması ve okuyacak kişinin belirlenmesi.

**Sıra önerisi:** önce 5 ve 6 birlikte (5-6-7-8 zincirini açıyorlar ve ikisi de
aynı Apps Script ekranında yapılıyor), sonra 17 (Londra değilse lansmandan önce
taşıma var), sonra 10.

### DEV-068 — açıklama (Asana description alanına birebir gider)

**Bloğun adı.** CEO 12 Ağustos'ta **"The Journal"** öneriyor. Developer'ın
görüşü: iyi bir seçim, iki sebeple.

Birincisi, sıklık baskısını kaldırıyor. "Blog" haftalık bir ritim vaat eder ve
o ritim tutmadığında sayfa bakımsız görünür; bir *journal* ayda bir de çıkabilir
ve geç kalmışlık hissi vermez. Yayın planımız da bunu gerektiriyor. İkincisi,
yazdığımız şeyin cinsini doğru anlatıyor: haber ya da güncelleme değil,
düşünülmüş metin.

**Türkçesi için "Yolculuk" olmamalı.** *Journal* Türkçede yolculuk değil, günlük
kayıt ya da dergi demek. İngilizcede *journey* yolculuk, *journal* kayıt; aynı
kökten gelirler (Fransızca *jour*, gün) ama anlamları ayrılmıştır. "AI
Yolculuğu" dersek İngilizce ad ile Türkçe ad iki farklı şeyi anlatır, ve bunu
fark eden ilk okuyucu haklı olarak dikkatsizlik sayar. Ayrıca "yolculuk"
dönüşüm danışmanlığında fazlasıyla yıpranmış bir kelime.

**Üç seçenek, Developer'ın tercih sırasıyla:**

1. **İki dilde de "The Journal".** Hizmet adlarında zaten bu kuralı
   uyguluyoruz — K34, AI Readiness Audit Türkçe sayfada da İngilizce. Bir yayın
   adı da özel isimdir. Çeviri riski sıfır, mevcut kuralla tutarlı.
2. **"Yazılar".** Düz ve dürüst, marka sesimize uygun. Ayırt edici değil.
3. **"Defter".** *Journal*'ın birebir karşılığı, sıcak ve az kullanılmış.
   Kurumsal alıcı için fazla samimi olabilir.

**"Günlük" önerilmiyor** — Türkçede kişisel günce çağrışımı çok güçlü.

**Karar Marketing'in** ve çıktığında `Anthifel_Brand_Guidelines.md` §8'e
işlenmeli. Kaynak güncellenmezse site ile kılavuz sessizce çelişir; bu 9
Ağustos'ta hero cümlesinde bir kez oldu.

**Developer tarafında değişecekler** — hepsi mekanik, yarım gün: menüdeki ve alt
bilgideki başlık iki dilde, blog dizin sayfasının başlığı ve `<title>`'ı,
`og:title` ve meta açıklamalar, yazıların üstündeki dönüş bağlantısı, ve
`check-blog.js` içindeki başlık kontrolleri.

**Adres değişmiyor:** `/blog/` olarak kalır. Yayımlanmış bir bağlantının
kırılmaması, sayfanın adından önemli.

### DEV-067 — açıklama (Asana description alanına birebir gider)

**Yayın öncesi son kontrol ve `FORM_LIVE`'ı aç.** Form bugün itibarıyla uçtan
uca çalışıyor ve kanıtlandı: kod maili geliyor, kod doğrulanıyor, test açılıyor,
sonuç maili ve lead maili gidiyor, tabloya satır düşüyor, ve on iki cevabın
hiçbiri hiçbir yere gitmiyor. Kapalı olmasının tek sebebi artık teknik değil.

**Açmadan önce, sırayla:**

1. **Legal'in üç bilgisi** — şirket numarası, kayıtlı adres, ICO kayıt numarası.
   Bunlar girilmeden yapı `privacy.html` ve `terms.html`'in yayın sürümünü
   yazmıyor; rıza kutusu içi boş bir sayfaya link veriyorsa aydınlatılmış rıza
   olmaz. Tek gerçek engel bu.
2. **Saklama süresi** — Legal gün olarak versin, `PURGE_AFTER_DAYS` değeriyle
   (şu an 730) ve yayımlanan politikayla aynı olsun.
3. **Resend gizlilik metnine ve §23'e girsin.** 12 Ağustos'tan beri bir
   işleyen: alıcının adresini ve mailin gövdesini görüyor, sonuç mailinde skor
   ve bant da var. Legal'in onayı gerekiyor.
4. **`?form=live` ile son bir uçtan uca tur** — iki dilde. Kod maili, sonuç
   maili, lead maili, tablo satırı, ve lead mailinde cevapların **olmadığının**
   teyidi.
5. **`FORM_LIVE = true`** ve deploy.
6. **Açtıktan sonra ilk gerçek gönderimi izle** — Resend Logs ekranından
   teslim edildiğini doğrula.

**Bilinen ve kabul edilmiş:** kod maili yeni alan adı itibarı yüzünden bazı
kutularda spam'e düşebilir. Kod ekranı zaten "spam klasörüne bakın" diyor ve
kod konu satırında, yani mail açılmadan okunabiliyor. İtibar kullanıldıkça
düzelir.

### DEV-065 — açıklama (Asana description alanına birebir gider)

**Hizmet sayfalarını zenginleştir.** Bugün elimizde tek bir hizmet sayfası var,
AI Readiness Audit, ve o da ince. Diğer beşi hâlâ ana sayfadaki katalog satırı —
hazırlık testi sonuç ekranındaki üç bandın butonu da oraya gidiyor, çünkü
gidecek sayfa yok.

Üç ayrı iş, karıştırılmamalı.

**Business yazar — her hizmet için altı blok, her biri iki-üç cümle:**

1. Kim için — ve kim için değil
2. Ne yapıyoruz — somut teslim
3. Nasıl işliyor — gün ya da hafta olarak adımlar
4. Ne teslim alıyorsunuz — rapor, yol haritası, oturum
5. **Bu hizmet ne zaman uygun değil** — dürüst eleme; sayfanın en güvenilir
   yeri burası olur ve şu an hiçbir sayfada yok
6. Sonraki adım — görüşme mi, teklif mi

Fiyat yok (K50). Hizmet adları iki dilde de İngilizce kalır (K34).

Öncelik, sonuç ekranındaki bantların gideceği yer olduğu için: Discovery Sprint,
Transformation Retainer, Advisory Board Seat, sonra Executive Workshop ve
Keynote. AI Readiness Audit'in mevcut metni de aynı altı bloğa göre genişletilir.

**Marketing verir — sayfa başına:**

- Şirketin gerçekten arattığı üç-beş soru (anahtar kelime listesi değil; bunlar
  ara başlıklara ve sık sorulanlara dönüşecek)
- 60 karakteri geçmeyen `<title>`, 155 karakterlik meta açıklama, iki dilde
- Hangi blog yazısı hangi hizmet sayfasına bağlanmalı — dört yazımız var ve şu
  an hizmet sayfaları ile blog birbirini hiç beslemiyor

**Tasarım verir:** masaüstü ve mobil için birer ekran. Prompt hazır, Developer
tarafındaki brief dosyasında.

**Developer yapar:** sık sorulanlar ve ilgili yazılar bölümleri, açılır kapanır
başlıklar, FAQ yapısal verisi (schema.org — sık sorulanlar arama sonucunda
görünsün diye), her hizmet için ayrı sayfa, üç bandın butonlarının kendi
sayfasına bağlanması, blog ile çift yönlü bağlantı, ve check-links ile
check-service için yeni kontroller.

**Sıra — bu önemli:** önce **tek sayfa**. Discovery Sprint baştan sona bitirilip
onaylanır, kalan beşi aynı kalıptan çıkar. Kalıp onaylanmadan beş sayfa
yazdırmak, beş sayfayı iki kez yazdırmak demek.

Kategori mevcut sekmelerden biri olmalı. Yeni kategori gerekiyorsa 5.
bölümde talep edin, kendiniz açtırmayın.

Öncelik yalnızca: `Yüksek`, `Orta`, `Düşük`.

Deadline bilinmiyorsa boş bırakın. Tarih uydurmayın.

## 5 — Talepler ve sorular

Başka departmandan veya CEO'dan beklediğiniz kararlar.

| No | Kime | Talep | Neden gerekiyor |
|---|---|---|---|
| 1 | ~~CEO~~ | ~~DEV-016 için Supabase Pro onayı~~ | **Kapandı 12 Ağustos.** CEO: şimdilik gerek yok. Panel günlük kullanımda değil, duraklayan proje tek tıkla geri geliyor ve veri kaybı olmuyor. Lansmanda, panel gerçekten kullanılmaya başlayınca yeniden bakılacak |
| 2 | CEO | DEV-025 için Services §9'da açık sapma sayısının netleşmesi | `Anthifel_Website.md` kendi içinde beş ve iki diyor; karar çıkmadan sitede metin değişmiyor |
| 3 | ~~CEO~~ | ~~DEV-048 için not alma aracının seçilmesi~~ | **Kapandı 12 Ağustos: Wispr Flow, ücretsiz plan.** Tam transkript veriyor, takvimi okuyor, notları MCP ile Claude'a bağlıyor. Toplantıya bot olarak katılmıyor, Mac'in sistem sesinden kaydediyor — bu yüzden kayıt yapıldığını söylemek bize düşüyor, DEV-049 hâlâ açık |
| 4 | Legal | DEV-007 için saklama süresinin gün olarak verilmesi | `PURGE_AFTER_DAYS` değeri bu sayı olmadan yazılamıyor |
| 5 | Legal | DEV-049 için toplantı kaydı rıza metni ve işleyen sözleşmesi | K39: Legal'in görüşü pilotun sonrasında değil, öncesinde ve paralelinde geliyor |
| 6 | Sales | Lansman DM şablonlarındaki "butik" kelimesinin değiştirilmesi | Marketing kelimeyi markadan kaldırdı; şablonlar panelde ama metin Sales'in, dört yerde geçiyor |
| 7 | Marketing | Türkçe metinde hangi kesme işaretinin kullanılacağı | Sayfada ikisi birden var: `AI'a` düz, `AI’a` tipografik; aynı ayrım rıza satırında ve künyede de var |
| 8 | Marketing | 7g · Advisory Board Seat'in beş aşamadan hangisine oturduğu | 3 Ağustos'ta soruldu, hâlâ cevapsız; ifade sayfada duruyor |
| 9 | Marketing | Hero cümlesinin §8'e işlenmesi | Site 9 Ağustos'ta CEO talimatıyla §8'den ayrıldı; kaynak güncellenmezse ikisi sessizce çelişir |
| 10 | Marketing | §9a alt metninin Türkçesi | CEO bandı kaldırıp cümleyi hero'nun başına aldı; §9a "çevrilmez" diyor. Sitede şu an *AI dönüşümünün insan tarafını biz düzenliyoruz.* var, bu yeni bir Türkçe marka dizesi ve Marketing'in |
| 11 | Marketing | 7c'deki "görüşme ayarla" yasağı | CEO butonlara **Görüşme Ayarla** adını verdi. Testteki koruma silinmedi, tarih ve gerekçeyle yorum satırına alındı; 7c ya geri gelir ya kalkar |
| 12 | Marketing | §8.7c'nin yeni ifadesi | Buton artık "ücretsiz" demiyor; söz popup'ın içine taşındı ve orada test ediliyor. §8.7c'nin bu hâli kabul ediyor mu |
| 13 | CEO | Google Takvim randevu takviminin araç olarak onayı | Calendly (DEV-033) yerine geçiyor, ek maliyeti yok, ama üçüncü tarafa veri gidiyor ve §23'e yeni satır olarak yazıldı |
| 14 | Business | Discovery Sprint, Transformation Retainer ve Advisory Board Seat sayfa metinleri | Brief §C.2'de yalnızca Audit metni var; üç bandın butonu hâlâ katalog satırına gidiyor ve metin gelmeden bağlanamaz |
| 15 | Legal | Şirket numarası, kayıtlı adres ve ICO kayıt numarası | privacy.html ve terms.html bu üçü girilmeden yayın sürümüne yazılmıyor; yapı reddediyor |
| 16 | Legal | ICO numarası 20 Ağustos'a yetişmezse ilgili cümlenin silinmesi | Legal'in kendi Part A notu boş yayımlamak yerine silmeyi söylüyor; kararı teyit edilsin |
| 17 | Marketing + Legal | Kural 2'nin (uzun tire yok) hukuki metni kapsayıp kapsamadığı | Legal'in tabloları uzun tire kullanıyor, metin birebir girdi |
| 18 | ~~CEO~~ | ~~Bot kontrolünün e-posta kodu olarak kalması~~ | **Kapandı 12 Ağustos: onaylandı ve uçtan uca çalıştığı kanıtlandı.** Kod adrese gidiyor, kod gelmeden test açılmıyor, kod gelmeden hiçbir şey kaydedilmiyor. DEV-028, DEV-031 ve DEV-057 birlikte kapandı |
| 19 | CEO | Apps Script web app URL'i | Form uçtan uca bağlanamıyor; token üretiliyor ama sunucuda doğrulanamıyor |
| 20 | CEO | Deploy zincirinin köprüden kurtarılması | 10 Ağustos'ta köprü üç kez düştü, iki build deploy edilemeden bekledi. Ya buradan push, ya deploy.sh build'i kendisi çeksin |
| 22 | ~~Marketing~~ | ~~Üç mailin metni~~ | **Kapandı.** CEO 12 Ağustos'ta beşini de okudu ve onayladı; Marketing'e gitmesine gerek görmedi |
| 26 | Marketing | Bloğun adı: **The Journal**, ve Türkçesi | CEO "The Journal" öneriyor. Türkçesi için "Yolculuk" bir çeviri hatası olur — *journal* yolculuk değil, günlük kayıt/dergi demek. Üç seçenek ve gerekçeleri `Blog_Adi_Onerisi.md` dosyasında. Karar §8'e işlenmeli |
| 25 | CEO | Kod mailinin spam'e düşmesi: kabul mü, yoksa itibarı olan bir gönderene mi taşınalım | Alan adı iki haftalık ve gönderim geçmişi yok. Yapılandırmada eksik yok — SPF, DKIM, DMARC, MX, takma ad hepsi doğru. Kullandıkça düzelir, ama lansmanda ilk izlenim kod mailinin spam'de olması |
| 23 | Marketing | Test giriş ekranındaki iki buton metni: **Kodu gönder →** ve **Teste başla →** | Buton artık kod gönderiyor, eski metin (*AI Hazırlık Testi →*) ne yaptığını söylemiyordu. İşlev metni, marka metni değil, ama ekranda duruyor |
| 24 | CEO | `hello@anthifel.com` için Workspace send-as izni ve DKIM | Kod maili başka bir adresten gelirse ya da spam'e düşerse testin girişi çalışmaz. DKIM artık kritik yolda |
| 21 | Asana operasyonu | Task açıklaması için bir alan | 4. bölümün tablosunda description sütunu yok. DEV-060 tek task ve bütün ayrıntısı açıklamada duruyor; şimdilik tablonun altına "DEV-060 — açıklama" bloğu olarak yazıldı. Bu bloğun Asana'da description alanına aktarıldığını teyit edin |

## 6 — Bloke olanlar

Açık ama başka bir şeyi bekleyen task'lar.

| Task ID | Neyi bekliyor | Kimden |
|---|---|---|
| DEV-016 | Aylık $25'lık maliyet onayı | CEO |
| DEV-022 | Türkçe künye metninin onaylanması | Legal |
| DEV-023 | Şirketin kurulması ve kayıtlı adresin kesinleşmesi | Legal, 20 Ağustos |
| DEV-025 | Services §9 sapmalarının karara bağlanması | CEO |
| DEV-037 | Uzun tire kararı | Marketing |
| DEV-048 | Not alma aracının seçilmesi | CEO |
