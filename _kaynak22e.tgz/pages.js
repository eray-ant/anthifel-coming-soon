/* The address table, for the suites.
 *
 * `addresses.json` is written by build.py from PAGES, so this file and
 * build.py cannot drift: there is one table and both languages of this
 * repository read it. Before 21 August every suite spelled the addresses out
 * itself, which is why moving a page meant editing sixteen files and finding
 * out from a red test which ones you had missed.
 */
const A = require('./addresses.json');

const ALL = [];
for (const [key, v] of Object.entries(A.pages)) {
  for (const lang of ['en', 'tr']) ALL.push({ key, lang, path: v[lang], file: v[lang] + 'index.html' });
}
const EN = ALL.filter(p => p.lang === 'en');
const TR = ALL.filter(p => p.lang === 'tr');

/* The pages that come out of the page shell — everything except the Journal,
 * whose two indexes are written from the blog templates and whose cards the
 * publisher fills in. */
const SHELL = ALL.filter(p => p.key !== 'blog');

const url = (key, lang) => 'https://anthifel.com/' + A.pages[key][lang || 'en'];
const file = (key, lang) => A.pages[key][lang || 'en'] + 'index.html';

/* Go to the other language of the page you are on.
 *
 * The switch is a link now, so "switch language" means "follow it". Tests that
 * used to click a button and read the same document again have to load the
 * other document instead — which is the point of the change, and the reason
 * this helper navigates rather than hiding the navigation.
 */
async function goLang(page, dir, key, lang) {
  const path = require('path');
  await page.goto('file://' + path.join(dir, file(key, lang)), { waitUntil: 'load' });
  await page.waitForTimeout(250);
}

module.exports = { A, ALL, EN, TR, SHELL, url, file, goLang, moved: A.moved };
