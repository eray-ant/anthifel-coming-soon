/*
 * check-lang.js — the Turkish page really is in Turkish, before any script runs.
 *
 * Every translatable node carries English as its content and Turkish in
 * `data-tr`, and `applyLang` swaps them in the browser. That works for a person
 * and not at all for a crawler: `hakkimizda.html` said `<html lang="tr">` and
 * its visible words were English. Marketing's §12 rests on assistants
 * preferring content in the language of the question, so the one page with a
 * Turkish address was answering in the wrong one.
 *
 * `trlang.py` now does the same swap at build time. That makes two
 * implementations of one rule, which is the shape every fork on this site has
 * started as — so this file renders both and compares them:
 *
 *   built page          the file we ship, read with JavaScript switched off
 *   applyLang('tr')     the English page, switched by the site's own function
 *
 * If the two ever disagree, one of them is wrong and it does not matter which.
 *
 *   node check-lang.js [dist/production]
 */
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const P = require('./pages');
const DIR = path.resolve(process.argv[2] || 'dist/production');
let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.log('  ✗ ' + n + (x ? '  → ' + x : ''))); };

/* Every page, not just About.
 *
 * When this was written About was the only page with a Turkish address, so it
 * was the only pair there was. Since 21 August every page has one, and the
 * thing being tested is the same for all of them: the file trlang.py wrote has
 * to say exactly what the browser's own switch would have said. */
const PAIRS = P.SHELL.filter(p => p.lang === 'en')
                     .map(p => [p.file, P.file(p.key, 'tr')]);

(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  const visible = async (file, switchTo) => {
    const ctx = await b.newContext({ javaScriptEnabled: switchTo !== null });
    const p = await ctx.newPage();
    await p.route('**calendar.google.com/**', r => r.fulfill({ status: 200, contentType: 'text/html', body: '<p>x</p>' }));
    await p.goto('file://' + path.join(DIR, file), { waitUntil: switchTo === null ? 'domcontentloaded' : 'load' });
    /* Called by name. Until 21 August this pressed the TR button, because
       applyLang lived in a closure and the visitor's path was the one worth
       comparing. The button is a link to a different document now, so pressing
       it would compare the Turkish page with itself and pass for the wrong
       reason. Each shell puts its own switch function on window for exactly
       this comparison. */
    if (switchTo) { await p.evaluate(l => window.applyLang(l), switchTo); await p.waitForTimeout(250); }
    const t = await p.evaluate(() => {
      const walk = document.body.cloneNode(true);
      walk.querySelectorAll('script,style,template,[hidden]').forEach(e => e.remove());
      /* The hero line types itself, one letter at a time, forever. Whatever it
         happens to be holding when the snapshot is taken is animation, not
         copy, and comparing it would fail on timing rather than on language. */
      walk.querySelectorAll('#heroEyebrow').forEach(e => e.remove());
      return walk.textContent.replace(/\s+/g, ' ').trim();
    });
    await ctx.close();
    return t;
  };

  for (const [en, tr] of PAIRS) {
    console.log(`\n— ${tr} —`);
    const raw = await visible(tr, null);              // scripts off: what a crawler reads
    ok('reads Turkish with JavaScript switched off',
       /Yaklaşım|Hizmetler|Hazırlık Testi/.test(raw) && !/^.{0,400}Approach/.test(raw),
       raw.slice(0, 120));
    ok('…and says so in <html lang>',
       /<html lang="tr"/.test(fs.readFileSync(path.join(DIR, tr), 'utf-8')));

    /* Compared with scripts on, on both sides. `raw` above is the crawler's
       view and is asserted on its own terms; putting it into this comparison
       measured two things at once — the language, and what the scripts do to
       the page. */
    const built = (await visible(tr, 'tr')).replace(/\s+/g, ' ');
    const switched = (await visible(en, 'tr')).replace(/\s+/g, ' ');
    /* Not byte-equal: the English page keeps a few nodes the Turkish build
       drops, and the assessment is drawn in JS. What has to match is the prose. */
    /* The menu is on every page and is the same on every page, so it is the
       one stretch of prose that can be compared across all eleven pairs. */
    const grab = s => (s.match(/Yaklaşım.{0,500}/) || [''])[0];
    ok('the build-time swap agrees with applyLang, word for word',
       grab(built) === grab(switched),
       (() => {
         const a = grab(built), b2 = grab(switched);
         let i = 0; while (i < a.length && a[i] === b2[i]) i++;
         return 'they part at character ' + i + ':\n      built:    …' +
                a.slice(Math.max(0, i - 30), i + 60) + '\n      switched: …' +
                b2.slice(Math.max(0, i - 30), i + 60);
       })());

    /* The switch still works: the page is Turkish, and a visitor can get back. */
    const ctx = await b.newContext(); const p = await ctx.newPage();
    await p.route('**calendar.google.com/**', r => r.fulfill({ status: 200, contentType: 'text/html', body: '<p>x</p>' }));
    await p.goto('file://' + path.join(DIR, tr), { waitUntil: 'load' });
    await p.waitForTimeout(250);
    ok('the language switch marks Turkish as current',
       (await p.getAttribute('.lang a[data-lang="tr"]', 'aria-current')) === 'true');
    ok('…and points at the English page to get back',
       (await p.getAttribute('.lang a[data-lang="en"]', 'href')) === '/' + en.replace(/index\.html$/, ''),
       await p.getAttribute('.lang a[data-lang="en"]', 'href'));
    await ctx.close();
  }

  await b.close();
  console.log(fail ? `\n❌  ${pass} passed, ${fail} failed` : `\n✅  ${pass} passed, 0 failed`);
  process.exit(fail ? 1 : 0);
})();
