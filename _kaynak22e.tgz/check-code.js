/**
 * check-code.js — Anthifel
 *
 * The email-code gate, driven in the shape it will actually run in.
 *
 * The preview build carries FORM_LIVE = false and an unwired endpoint, so the
 * suite that walks the preview can only ever see the code step skipped. That is
 * correct behaviour and it is tested where it belongs — but it leaves the part
 * that matters untested. So this suite makes its own copy of the built page
 * with the switch flipped and a fake endpoint substituted, then answers that
 * endpoint locally. Nothing here reaches Google, Apps Script, or a mailbox.
 *
 * What is being checked is the contract between the page and Code.gs:
 *   send-code    email + consent  → the code screen opens
 *   verify-code  email + code      → the assessment opens
 *   result       score + band      → both mails are asked for, once
 * and the red line: the twelve answers never appear in a request body.
 */
const { chromium } = require('playwright');
const path = require('path');
const P = require('./pages');
const fs = require('fs');
const os = require('os');

const SRC = path.resolve(process.argv[2] || 'dist/preview/index.html');
const EP = 'https://script.example.invalid/exec';
let pass = 0, fail = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };

(async () => {
  let html = fs.readFileSync(SRC, 'utf8');
  // The real endpoint is stamped into the build from 11 August, so the fixture
  // has to replace an address rather than a placeholder. Both substitutions are
  // asserted: a fixture that quietly kept the real endpoint would send real
  // codes to real people every time this suite runs.
  const armed = html.replace(/var ENDPOINT( +)= '[^']*';/, "var ENDPOINT$1= '" + EP + "';")
                    .replace('var FORM_LIVE  = false;', 'var FORM_LIVE  = true;');
  /* Comments are not code, and this is the second suite to learn it the same
     way. check-behaviour spent a day failing on a comment that explained a
     banned phrase; this one failed on a comment in newsletter.js that names
     script.google.com while explaining what happens when a network refuses to
     reach it. The guard is right — a fixture that quietly kept the real
     endpoint would send real codes to real people every time this runs — so it
     stays, and looks at the code instead of at the prose about the code. */
  const live = armed.replace(/\/\*[\s\S]*?\*\//g, '')
                    .replace(/<!--[\s\S]*?-->/g, '');
  if (!armed.includes("var ENDPOINT   = '" + EP + "';") ||
      !armed.includes('var FORM_LIVE  = true;') ||
      /script\.google\.com/.test(live)) {
    console.log('  ✗ could not arm the fixture — the build changed shape, or the real endpoint survived');
    process.exit(1);
  }
  html = armed;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'anthifel-code-'));
  const FIX = path.join(dir, 'index.html');
  fs.writeFileSync(FIX, html);

  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));

  // The endpoint, answered here. `reply` is what the next call gets back.
  const calls = [];
  let reply = { ok: true };
  await page.route(EP, async r => {
    // Only POSTs are the flow. The GET is the warm-up: a throwaway request the
    // code screen fires to wake Apps Script while the visitor reads their mail,
    // and counting it here would make every "one call went out" a lie.
    if (r.request().method() !== 'POST') { await r.fulfill({ status: 200, body: '{}' }); return; }
    let body = {};
    try { body = JSON.parse(r.request().postData() || '{}'); } catch (e) {}
    calls.push(body);
    await r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(reply) });
  });
  await page.route('**calendar.google.com/**', r =>
    r.fulfill({ status: 200, contentType: 'text/html', body: '<p>schedule</p>' }));
  // Belt and braces. If anything in here ever reaches the real Apps Script, the
  // suite fails loudly rather than mailing a stranger.
  let escaped = 0;
  await page.route('**script.google.com/**', r => { escaped++; r.abort(); });

  const browser2Page = async () => {
    const q = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await q.route('**calendar.google.com/**', r =>
      r.fulfill({ status: 200, contentType: 'text/html', body: 'x' }));
    return q;
  };

  await page.goto('file://' + FIX, { waitUntil: 'load' });
  await page.waitForTimeout(400);

  console.log('\n— step 1: the address —');
  await page.click('#aIntro [data-start]');
  await page.waitForTimeout(400);
  await page.click('#next'); await page.waitForTimeout(200);
  ok('an empty form asks nothing of the endpoint', calls.length === 0);

  await page.fill('#email', 'lead@example.com');
  await page.check('#consent');
  await page.click('#next');
  await page.waitForTimeout(400);

  ok('one call went out', calls.length === 1, String(calls.length));
  const c1 = calls[0] || {};
  ok('it asks for a code', c1.action === 'send-code', c1.action);
  ok('it carries the address', c1.email === 'lead@example.com');
  ok('it carries the consent, as a fact and as a moment',
     c1.consent === true && typeof c1.consentAt === 'string' && c1.consentAt.length > 10);
  ok('it carries the wording that was agreed to',
     typeof c1.consentText === 'string' && /Privacy Policy|Gizlilik/.test(c1.consentText));
  ok('it says which language the visitor is reading', c1.lang === 'en' || c1.lang === 'tr');
  /* §3's remaining three fields. The reading list has carried them since
     19 August; this gate is the other form on the site and the same rule
     applies — a consent that cannot be shown is the same as no consent. */
  ok('  §3 · which wording, in this gate\'s own identifier',
     /^assessment-(en|tr)-v\d+$/.test(c1.consentVersion || ''), c1.consentVersion);
  ok('  §3 · which channel', c1.channel === 'web-form', c1.channel);
  ok('  §3 · the affirmative act, captured', c1.affirmative === 'checkbox:true', c1.affirmative);
  ok('  §3 · which notice was on the page',
     /^privacy-v\d+$/.test(c1.privacyVersion || ''), c1.privacyVersion);
  /* Two forms, two sentences, two identifiers. Sharing one would make an old
     record resolve to wording the person never saw. */
  ok('  …and it is not the reading list\'s identifier',
     !/^consent-/.test(c1.consentVersion || ''), c1.consentVersion);

  console.log('\n— step 2: the code —');
  ok('the code screen is now shown', await page.isVisible('#aCode'));
  ok('the address screen is put away', await page.isHidden('#aGate'));
  ok('the assessment is still not reached', await page.isHidden('#aQuiz'));
  ok('the screen repeats the address back',
     (await page.textContent('#sentTo')).includes('lead@example.com'));

  // Everything past this point types a code, and six digits sends itself, so
  // the endpoint has to be refusing before a single digit is entered —
  // otherwise the first line below opens the assessment and takes the code
  // screen off the page.
  reply = { ok: false, error: 'wrong', left: 4 };

  // A short code goes nowhere. Nothing has been decided at four digits.
  const base = calls.length;
  await page.fill('#code', '1234');
  await page.click('#verify'); await page.waitForTimeout(300);
  ok('a short code is refused here, not at the endpoint', calls.length === base);
  ok('and the screen says so', (await page.textContent('#e-code')).length > 0);

  // Codes get pasted out of a mail client with spaces in them, and typed by
  // people who reach for the letter keys. The field takes whatever arrives,
  // keeps the first six digits — and at six there is nothing left to decide,
  // so it goes without anyone pressing anything.
  await page.fill('#code', ' 11 11 11 22 ');
  await page.waitForTimeout(600);
  ok('the field keeps the digits, drops the rest, and stops at six',
     (await page.inputValue('#code')) === '111111', await page.inputValue('#code'));
  ok('the sixth digit sends the code by itself', calls.length === base + 1,
     String(calls.length - base));
  ok('and it is the verify call', (calls[calls.length - 1] || {}).action === 'verify-code');
  ok('the same six digits do not fire a second time',
     await (async () => {
       await page.fill('#code', '11111');
       await page.type('#code', '1');
       await page.waitForTimeout(500);
       return calls.length === base + 1;
     })(), String(calls.length - base));

  await page.click('#verify'); await page.waitForTimeout(400);
  ok('the button still works for a second attempt at the same code',
     calls.length === base + 2 && calls[calls.length - 1].action === 'verify-code');
  ok('the visitor is told the code did not match',
     /does not match|eşleşmedi/.test(await page.textContent('#e-code')));
  ok('and stays on the code screen', await page.isVisible('#aCode'));

  ok('and is told how many tries are left',
     /4 attempts left|4 deneme/.test(await page.textContent('#e-code')),
     await page.textContent('#e-code'));

  reply = { ok: false, error: 'expired' };
  await page.fill('#code', '222222');
  await page.waitForTimeout(400);
  ok('an expired code says expired, not "wrong"',
     /expired|süresi doldu/.test(await page.textContent('#e-code')));

  // A code that was never issued, or has already been spent, reads the same as
  // an expired one. Which addresses we hold is not something this screen tells.
  reply = { ok: false, error: 'no-code' };
  await page.fill('#code', '333333');
  await page.waitForTimeout(400);
  ok('an unknown code reads the same as an expired one',
     /expired|süresi doldu/.test(await page.textContent('#e-code')));

  reply = { ok: false, error: 'too-many' };
  await page.fill('#code', '444444');
  await page.waitForTimeout(400);
  ok('too many tries says so, and points at a new code',
     /Too many|Çok fazla/.test(await page.textContent('#e-code')));

  console.log('\n— asking for another code —');
  const n = calls.length;
  await page.click('#resend'); await page.waitForTimeout(400);
  ok('resend asks for a new code', calls.length === n + 1 && calls[n].action === 'send-code');
  ok('and marks itself as a resend', calls[n].source === 'assessment-gate-resend');
  ok('the field is cleared', (await page.inputValue('#code')) === '');

  console.log('\n— going back for a different address —');
  await page.click('#codeBack'); await page.waitForTimeout(400);
  ok('the address screen comes back', await page.isVisible('#aGate'));
  ok('the code screen is put away', await page.isHidden('#aCode'));
  ok('the address is still there to correct', (await page.inputValue('#email')) === 'lead@example.com');

  reply = { ok: true };
  await page.click('#next'); await page.waitForTimeout(400);
  await page.fill('#code', '654321');
  await page.waitForTimeout(700);

  console.log('\n— step 3: the assessment, and what leaves it —');
  ok('a correct code opens the assessment', await page.isVisible('#aQuiz'));
  ok('the code screen is put away', await page.isHidden('#aCode'));
  ok('no preview notice once the flow is live', await page.isHidden('#devnote'));

  const atVerify = calls.length;
  for (let i = 0; i < 12; i++) {
    await page.click('#qOpts .qopt:nth-child(3)');
    await page.waitForTimeout(50);
  }
  await page.waitForTimeout(600);
  ok('the result screen is drawn', await page.isVisible('#qRes'));
  ok('exactly one call followed the last answer', calls.length === atVerify + 1, String(calls.length - atVerify));

  const last = calls[calls.length - 1] || {};
  ok('it is the result call', last.action === 'result', last.action);
  ok('it carries the verified address', last.email === 'lead@example.com');
  ok('it carries the score', typeof last.score === 'number' && last.score > 0);
  ok('it carries a stable band key, not a translated title', /^\d+-\d+$/.test(String(last.band)), String(last.band));
  ok('it carries the band as the visitor read it',
     typeof last.bandTitle === 'string' && last.bandTitle.length > 10);
  ok('it carries the five dimension averages',
     Array.isArray(last.dims) && last.dims.length === 5, JSON.stringify(last.dims));
  ok('each one is a name and a number',
     (last.dims || []).every(d => typeof d.name === 'string' && typeof d.value === 'number'));
  ok('it names the weakest dimension', typeof last.weakest === 'string' && last.weakest.length > 3);

  // The red line. Twelve answers were given; not one of them may appear in any
  // request body, in any shape — not as an array, not as a string, not folded
  // into a field nobody looked at.
  const bodies = JSON.stringify(calls);
  ok('no answers left the page — no answer array',
     !/"answers"/.test(bodies) && !/"a12"|"q1"/.test(bodies), bodies.slice(0, 200));
  ok('no answers left the page — nothing twelve items long',
     !calls.some(c => Object.keys(c).some(k => Array.isArray(c[k]) && c[k].length === 12)));

  console.log('\n— the language switch does not send a second pair of mails —');
  const atResult = calls.length;
/* Language is applied by name, not by pressing the switch.

   The switch is a link to the other document since 21 August, so clicking it
   would leave this page rather than re-render it — and everything below is
   about what the page does when it is told a language: the booking frame's
   hl=, the result screen's copy, the service names that must stay English.
   That machinery still runs, once, on load; each shell hands it out on window
   so a test can ask for it directly. */
  await page.evaluate(l => window.applyLang(l), 'tr');
  await page.waitForTimeout(500);
  ok('the result screen is still there', await page.isVisible('#qRes'));
  ok('and it is now in Turkish', /Türkçe|puan|\/ 100/.test(await page.textContent('#qRes')));
  ok('nothing more was sent', calls.length === atResult, String(calls.length - atResult));

  console.log('\n— the endpoint failing does not lose the visitor —');
  ok('no page errors anywhere in the flow', errs.length === 0, errs.join(' | '));
  ok('nothing in this suite ever reached the real Apps Script', escaped === 0, String(escaped));

  // Apps Script answers in anywhere from two to twenty seconds. The visitor
  // must not be looking at a dead button for any of it: there is nothing for
  // them to decide while it runs, and the mail they are waiting for takes
  // longer than the request does.
  console.log('\n— the diagnostics are silent unless asked for —');
  ok('no endpoint note on a plain ?form=live run',
     (await page.textContent('#devnote2')).trim() === '' ||
     (await page.isHidden('#devnote2')), await page.textContent('#devnote2'));

  console.log('\n— a slow endpoint does not freeze the visitor —');
  {
    const p2 = await browser2Page();
    let released;
    const gate = new Promise(r => { released = r; });
    await p2.route(EP, async r => {
      if (r.request().method() !== 'POST') { await r.fulfill({ status: 200, body: '{}' }); return; }
      await gate;
      await r.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' });
    });
    await p2.goto('file://' + FIX + '?form=live&debug=1', { waitUntil: 'load' });
    await p2.waitForTimeout(300);
    await p2.click('#aIntro [data-start]'); await p2.waitForTimeout(300);
    await p2.fill('#email', 'slow@example.com');
    await p2.check('#consent');
    await p2.click('#next');
    await p2.waitForTimeout(600);          // the request is still in the air
    ok('the code screen is already open while the call is still running',
       await p2.isVisible('#aCode'));
    /* The "on its way" note is a diagnostic and diagnostics are preview-only:
       `DEBUG` is gated on `TEST_MODE`, which production stamps false. Running
       this suite against the production build — which LANSMAN step 1 asks for —
       used to fail here on a feature that is correctly absent. So the assertion
       forks on which build is under test, and the production side asserts the
       silence rather than skipping it, because "no diagnostics on the live
       site" is itself a promise worth holding. */
    const isPreview = /var FORM_TEST {2}= true;/.test(html);
    if (isPreview) {
      ok('and it says the code is on its way',
         /Sending the code|Kod gönderiliyor/.test(await p2.textContent('#e-code')),
         await p2.textContent('#e-code'));
    } else {
      ok('production says nothing about the endpoint while it waits',
         (await p2.textContent('#e-code')).trim() === '', await p2.textContent('#e-code'));
    }
    released();
    await p2.waitForTimeout(500);
    ok('the note clears once the endpoint answers',
       (await p2.textContent('#e-code')).trim() === '', await p2.textContent('#e-code'));
    await p2.close();
  }

  await browser.close();
  fs.rmSync(dir, { recursive: true, force: true });

  /* The live-test switch, tested on the two real builds with no fixture and no
     substitution.

     20 August, launch. Until today FORM_LIVE was false and this block asserted
     that production sent nothing at all — the form was closed, and `?form=live`
     had to be unreachable there or it would have been a way for a stranger to
     write a row and trigger two mails. FORM_LIVE is true now, so a production
     form that sends nothing would be the failure, not the pass.

     What has to stay true is narrower and it is the part that was always the
     point: production is stamped FORM_TEST = false, so the back door does not
     exist — the form works because the switch is on, not because somebody knows
     a query string. If FORM_LIVE is ever turned off again, the last assertion
     here is what proves the door did not stay ajar. */
  console.log('\n— the form is on, and the back door does not exist —');
  {
    const b2 = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
    for (const [name, file] of [['production', 'dist/production/index.html'],
                                ['preview',    'dist/preview/index.html']]) {
      const p = await b2.newPage({ viewport: { width: 1280, height: 900 } });
      const out = [];
      await p.route('**calendar.google.com/**', r =>
        r.fulfill({ status: 200, contentType: 'text/html', body: 'x' }));
      // Aborted, never sent. What is being measured is whether the page tried.
      await p.route('**script.google.com/**', r => { out.push(r.request().url()); r.abort(); });
      await p.goto('file://' + path.resolve(file) + '?form=live', { waitUntil: 'load' });
      await p.waitForTimeout(400);
      const flag = /var FORM_TEST {2}= (true|false);/.exec(
        await p.evaluate(() => document.documentElement.innerHTML))[1];
      await p.click('[data-start]'); await p.waitForTimeout(300);
      await p.fill('#email', 'someone@example.com');
      await p.check('#consent');
      await p.click('#next'); await p.waitForTimeout(700);
      const reachedCode = await p.isVisible('#aCode');

      if (name === 'production') {
        ok('production is stamped FORM_TEST = false', flag === 'false');
        ok('production: the form is open and reaches the code step', reachedCode);
        ok('production: …and it calls the real endpoint', out.length > 0, out.join(' '));
        /* The back door, asserted by its absence in the source rather than by
           behaviour: with FORM_LIVE true both paths reach the same place, so
           only the code can tell you whether the query string still means
           anything. */
        const src = fs.readFileSync(path.resolve(file), 'utf-8');
        ok('production: the ?form=live branch is inert — FORM_TEST is false',
           /FORM_TEST {0,2}= false;/.test(src));
      } else {
        ok('preview is stamped FORM_TEST = true', flag === 'true');
        ok('preview: ?form=live really does call the endpoint', out.length > 0, out.join(' '));
      }
      await p.close();
    }
    await b2.close();
  }

  /* ---------------- the reading list ----------------
     Until 19 August this form sent a packet the endpoint did not recognise and
     the endpoint rejected it: the visitor saw a failure and there was no list
     at all. What is checked here is the contract with Code.gs — the five fields
     Anthifel_Legal_DataProcessing.md §3 asks to be recorded, and the rule that
     anything short of a clear yes sends nothing. */
  {
    console.log('\n— the reading list —');
    /* The shared fixture is cleaned up further up this file, so this block
       makes its own from the same armed html. */
    const dir3 = fs.mkdtempSync(path.join(os.tmpdir(), 'anthifel-list-'));
    const FIX3 = path.join(dir3, 'index.html');
    fs.writeFileSync(FIX3, html);
    const b3 = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
    const p3 = await b3.newPage({ viewport: { width: 1280, height: 900 } });
    const sent = [];
    await p3.route(EP, async r => {
      if (r.request().method() === 'POST') {
        try { sent.push(JSON.parse(r.request().postData() || '{}')); } catch (e) { sent.push({ broken: true }); }
      }
      await r.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' });
    });
    await p3.goto('file://' + FIX3, { waitUntil: 'load' });
    await p3.waitForTimeout(400);

    ok('two questions, not one', (await p3.$$('.ncons input[type=checkbox]')).length === 2);
    ok('neither is pre-ticked',
       !(await p3.isChecked('#ncons')) && !(await p3.isChecked('#npriv')));

    /* Fails closed. An address with no tick is not a subscription, and a form
       that sends it anyway records a consent nobody gave. */
    await p3.fill('#nemail', 'reader@example.com');
    await p3.click('#nbtn'); await p3.waitForTimeout(300);
    ok('an address without the tick sends nothing', sent.length === 0, String(sent.length));
    await p3.check('#ncons');
    await p3.click('#nbtn'); await p3.waitForTimeout(300);
    ok('…and neither does one without the privacy box', sent.length === 0, String(sent.length));

    await p3.check('#npriv');
    await p3.click('#nbtn'); await p3.waitForTimeout(600);
    ok('a complete answer is sent', sent.length === 1, String(sent.length));
    const body = sent[0] || {};
    ok('  it is the reading list, named so the endpoint can route it',
       body.source === 'reading-list', body.source);
    /* §3's five fields, one assertion each, because "the consent record is
       there" is not a thing a suite can check and each of these is. */
    ok('  §3 · when the box was ticked', /^\d{4}-\d{2}-\d{2}T/.test(body.consentAt || ''), body.consentAt);
    ok('  §3 · which wording', /^consent-(en|tr)-v\d+$/.test(body.consentVersion || ''), body.consentVersion);
    ok('  §3 · which channel', body.channel === 'web-form', body.channel);
    ok('  §3 · the affirmative act, captured', body.affirmative === 'checkbox:true', body.affirmative);
    ok('  §3 · which notice was on the page', /^privacy-v\d+$/.test(body.privacyVersion || ''), body.privacyVersion);
    /* The sentence itself, read off the label rather than repeated in code, so
       what is recorded is what was on the screen. */
    ok('  the wording is Legal\'s sentence, not a paraphrase',
       /I would like to receive content and updates from Anthifel by email/.test(body.consentText || ''),
       body.consentText);
    ok('  and it is not bundled with the privacy acknowledgement',
       !/Privacy Policy|Gizlilik/.test(body.consentText || ''), body.consentText);
    ok('  the privacy acknowledgement is its own answer', body.privacyAck === true, String(body.privacyAck));

    /* The Turkish reader agrees to the Turkish sentence, and the record says so.
       One list, two wordings, and a record that cannot tell them apart is a
       record that points at the wrong sentence for half the list. */
    const p4 = await b3.newPage({ viewport: { width: 1280, height: 900 } });
    const trSent = [];
    await p4.route(EP, async r => {
      if (r.request().method() === 'POST') { try { trSent.push(JSON.parse(r.request().postData() || '{}')); } catch (e) {} }
      await r.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' });
    });
    await p4.goto('file://' + FIX3, { waitUntil: 'load' });
    await p4.waitForTimeout(300);
    await p4.evaluate(l => window.applyLang(l), 'tr');
    await p4.waitForTimeout(300);
    await p4.fill('#nemail', 'okur@example.com');
    await p4.check('#ncons'); await p4.check('#npriv');
    await p4.click('#nbtn'); await p4.waitForTimeout(600);
    const tr = trSent[0] || {};
    ok('Turkish: the record points at the Turkish wording', tr.consentVersion === 'consent-tr-v1', tr.consentVersion);
    ok('Turkish: …and carries the Turkish sentence',
       /e-posta ile içerik ve güncelleme almak istiyorum/.test(tr.consentText || ''), tr.consentText);
    await p4.close();
    await p3.close();
    await b3.close();
    fs.rmSync(dir3, { recursive: true, force: true });
  }

  /* ---- Code.gs and newsletter.js, read as files rather than driven -----
   *
   * Written on 21 August, after one subscription failed in somebody's browser
   * and left no trace anywhere.
   *
   * One name, one function. Code.gs held two checkMailSetup() definitions for
   * days. Apps Script keeps the last, so the diagnostic we ran on 20 August was
   * not the diagnostic we had written, and nothing said so.
   *
   * A notification may not fail the record. Handlers that have already written
   * a row send through notify_(), which swallows and logs; sendMail_() throws
   * and is allowed only where the mail *is* the product — the login code. Read
   * from the source rather than driven, because reproducing it needs a spent
   * mail quota, and a suite that needs a broken account is one nobody runs.
   *
   * A failure leaves a trace, and it carries no address. */
  console.log('\n— Code.gs —');
  const gs = fs.readFileSync(path.join(__dirname, 'Code.gs'), 'utf8');

  const names = [...gs.matchAll(/^function\s+([A-Za-z0-9_$]+)\s*\(/gm)].map(m => m[1]);
  const twice = names.filter((n, i) => names.indexOf(n) !== i);
  ok('no function is defined twice', twice.length === 0, [...new Set(twice)].join(', '));

  const body = name => {
    const i = gs.indexOf('function ' + name + '(');
    if (i < 0) return '';
    const j = gs.indexOf('\nfunction ', i + 1);
    return gs.slice(i, j < 0 ? gs.length : j);
  };
  for (const h of ['readingList_', 'quote_', 'result_']) {
    const b = body(h);
    ok(`${h}: exists`, b.length > 0);
    ok(`${h}: notifies through notify_, which cannot throw`, /notify_\(/.test(b));
    ok(`${h}: does not call sendMail_ directly`, !/[^_]sendMail_\(/.test(b),
       (b.match(/.*sendMail_\(.*/) || [''])[0].trim().slice(0, 70));
  }
  for (const h of ['sendCode_', 'verifyCode_']) {
    const b = body(h);
    if (!b) continue;
    ok(`${h}: still sends through sendMail_, because the mail is the product`,
       !/notify_\(/.test(b));
  }
  ok('notify_ exists and swallows', /function notify_\([\s\S]*?catch\s*\(/.test(gs));

  console.log('\n— the failure log —');
  ok('client-error has a route', /d\.source === 'client-error'/.test(gs));
  const ce = body('clientError_');
  ok('clientError_ exists', ce.length > 0);
  ok('…and records no email address', !/email/i.test(ce), 'the word "email" appears in it');
  ok('…and strips the query string off the page', /split\('\?'\)/.test(ce));

  const nl = fs.readFileSync(path.join(__dirname, 'newsletter.js'), 'utf8');
  ok('the form retries a transport failure once', /trying once more/.test(nl));
  ok('…but never retries a refusal', /e\.retry\s*=\s*\(res\.http\s*>=\s*500\)/.test(nl));
  ok('…and reports it without the address',
     /source:'client-error'/.test(nl) && !/source:'client-error'[\s\S]{0,220}email/.test(nl));
  ok('a request that never arrived gets its own sentence',
     /blocked:\{en:/.test(nl) && /e\.blocked\s*=\s*true/.test(nl));

  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
