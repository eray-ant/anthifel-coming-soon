# Delil — anthifel.com WHOIS dökümü

**Alan adı:** anthifel.com
**Alınma tarihi (Creation Date):** 2026-07-26 04:25:42 UTC
**Kayıt kuruluşu:** Squarespace Domains LLC (IANA 895)
**Süre sonu:** 2027-07-26 04:25:42 UTC
**Son değişiklik:** 2026-08-01 11:03:05 UTC
**Ad sunucuları:** ns1 / ns2 / ns3 .digitalocean.com
**DNSSEC:** unsigned
**WHOIS gizliliği:** AÇIK — kayıt sahibinin adı, sokağı, şehri ve telefonu
`REDACTED FOR PRIVACY`; iletişim yalnızca Squarespace'in formu üzerinden.
Ülke alanı açık kalmış: `TR`.

**Neden dosya, ekran görüntüsü değil:** marka itirazı gelirse ilk kullanım
tarihini kanıtlayan şey bu satırdır — 26 Temmuz 2026. Ekran görüntüsü metin
değildir; aranamaz, kopyalanamaz ve içindeki tarih bir görüntüdür.

**Nasıl alındı:** CEO'nun makinesinde `whois anthifel.com`, 20 Ağustos 2026.
Bu konteynerde 43. port kapalı olduğu için Developer üretemedi.

**Bu dosyanın altındaki her şey ham çıktıdır, değiştirilmemiştir.**

---

% IANA WHOIS server
% for more information on IANA, visit http://www.iana.org
% This query returned 1 object

refer:        whois.verisign-grs.com

domain:       COM

organisation: VeriSign Global Registry Services
address:      12061 Bluemont Way
address:      Reston VA 20190
address:      United States of America (the)

contact:      administrative
name:         Registry Customer Service
organisation: VeriSign Global Registry Services
address:      12061 Bluemont Way
address:      Reston VA 20190
address:      United States of America (the)
phone:        +1 703 925-6999
fax-no:       +1 703 948 3978
e-mail:       info@verisign-grs.com

contact:      technical
name:         Registry Customer Service
organisation: VeriSign Global Registry Services
address:      12061 Bluemont Way
address:      Reston VA 20190
address:      United States of America (the)
phone:        +1 703 925-6999
fax-no:       +1 703 948 3978
e-mail:       info@verisign-grs.com

nserver:      A.GTLD-SERVERS.NET 192.5.6.30 2001:503:a83e:0:0:0:2:30
nserver:      B.GTLD-SERVERS.NET 192.33.14.30 2001:503:231d:0:0:0:2:30
nserver:      C.GTLD-SERVERS.NET 192.26.92.30 2001:503:83eb:0:0:0:0:30
nserver:      D.GTLD-SERVERS.NET 192.31.80.30 2001:500:856e:0:0:0:0:30
nserver:      E.GTLD-SERVERS.NET 192.12.94.30 2001:502:1ca1:0:0:0:0:30
nserver:      F.GTLD-SERVERS.NET 192.35.51.30 2001:503:d414:0:0:0:0:30
nserver:      G.GTLD-SERVERS.NET 192.42.93.30 2001:503:eea3:0:0:0:0:30
nserver:      H.GTLD-SERVERS.NET 192.54.112.30 2001:502:8cc:0:0:0:0:30
nserver:      I.GTLD-SERVERS.NET 192.43.172.30 2001:503:39c1:0:0:0:0:30
nserver:      J.GTLD-SERVERS.NET 192.48.79.30 2001:502:7094:0:0:0:0:30
nserver:      K.GTLD-SERVERS.NET 192.52.178.30 2001:503:d2d:0:0:0:0:30
nserver:      L.GTLD-SERVERS.NET 192.41.162.30 2001:500:d937:0:0:0:0:30
nserver:      M.GTLD-SERVERS.NET 192.55.83.30 2001:501:b1f9:0:0:0:0:30
ds-rdata:     19718 13 2 8acbb0cd28f41250a80a491389424d341522d946b0da0c0291f2d3d771d7805a

whois:        whois.verisign-grs.com

status:       ACTIVE
remarks:      Registration information: http://www.verisigninc.com

created:      1985-01-01
changed:      2026-03-10
source:       IANA

# whois.verisign-grs.com

   Domain Name: ANTHIFEL.COM
   Registry Domain ID: 3125450440_DOMAIN_COM-VRSN
   Registrar WHOIS Server: whois.squarespace.domains
   Registrar URL: http://squarespace.domains
   Updated Date: 2026-08-01T11:03:05Z
   Creation Date: 2026-07-26T04:25:42Z
   Registry Expiry Date: 2027-07-26T04:25:42Z
   Registrar: Squarespace Domains LLC
   Registrar IANA ID: 3827
   Registrar Abuse Contact Email: abuse-complaints@squarespace.com
   Registrar Abuse Contact Phone: 1-646-693-5324
   Domain Status: clientDeleteProhibited https://icann.org/epp#clientDeleteProhibited
   Domain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited
   Name Server: NS1.DIGITALOCEAN.COM
   Name Server: NS2.DIGITALOCEAN.COM
   Name Server: NS3.DIGITALOCEAN.COM
   DNSSEC: unsigned
   URL of the ICANN Whois Inaccuracy Complaint Form: https://www.icann.org/wicf/
>>> Last update of whois database: 2026-08-20T17:03:32Z <<<

# whois.squarespace.domains

Domain Name: anthifel.com
Registry Domain ID: 3125450440_DOMAIN_COM-VRSN
Registrar WHOIS Server: whois.squarespace.domains
Registrar URL: https://domains.squarespace.com
Registrar: Squarespace Domains LLC
Registrar IANA ID: 3827
Registrar Abuse Contact Email: abuse-complaints@squarespace.com
Registrar Abuse Contact Phone: +1.646-693-5324
Reseller:
Updated Date: 2026-08-01T11:03:05.977293Z
Creation Date: 2026-07-26T04:25:42Z
Registrar Registration Expiration Date: 2027-07-26T04:25:42Z
Domain Status: client delete prohibited http://www.icann.org/epp#client delete prohibited
Domain Status: client transfer prohibited http://www.icann.org/epp#client transfer prohibited
Registry Registrant ID:
Registrant Name: REDACTED FOR PRIVACY
Registrant Organization:
Registrant Street: REDACTED FOR PRIVACY
Registrant City: REDACTED FOR PRIVACY
Registrant State/Province:
Registrant Postal Code: REDACTED FOR PRIVACY
Registrant Country: TR
Registrant Phone: REDACTED FOR PRIVACY
Registrant Phone Ext:
Registrant Fax: REDACTED FOR PRIVACY
Registrant Fax Ext:
Registrant Email: https://domains.squarespace.com/whois-contact-form
Registry Admin ID:
Admin Name:
Admin Organization:
Admin Street:
Admin City:
Admin State/Province:
Admin Postal Code:
Admin Country:
Admin Phone:
Admin Phone Ext:
Admin Fax:
Admin Fax Ext:
Admin Email:
Registry Tech ID:
Tech Name:
Tech Organization:
Tech Street:
Tech City:
Tech State/Province:
Tech Postal Code:
Tech Country:
Tech Phone:
Tech Phone Ext:
Tech Fax:
Tech Fax Ext:
Tech Email:
Name Server: ns2.digitalocean.com
Name Server: ns3.digitalocean.com
Name Server: ns1.digitalocean.com
DNSSEC: unsigned
URL of the ICANN WHOIS Data Problem Reporting System: http://wdprs.internic.net/
The registration data available in this service is limited.  Additional data may be available at https://lookup.icann.org.
****** Last update of WHOIS database: 2026-08-01T11:03:05.977293Z