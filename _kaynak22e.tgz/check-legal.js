/**
 * check-legal.js — Anthifel
 *
 * privacy.html, terms.html, cookies.html. The copy is Legal's and is read from
 * Legal's own files at build time, so what is checked here is not the wording:
 * it is that the whole document arrived, in both languages, that Part A never
 * leaks onto a public page, that Developer's two tables are filled, and that
 * every placeholder still standing is one Legal owns. A legal page that is
 * quietly half-rendered is worse than one that is missing.
 */
const { chromium } = require('playwright');
const path = require('path');
const P = require('./pages');
const fs = require('fs');

const DIR = path.resolve(process.argv[2] || 'dist/preview');
const PAGES = ['privacy', 'terms', 'cookies'];
let pass = 0, fail = 0;
const ok = (n, c, extra) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${extra ? '  → ' + extra : ''}`)); };

// Legal's, and nobody else may fill them.
const LEGAL_OWNED = ['[COMPANY NUMBER]', '[REGISTERED ADDRESS]', '[ICO REGISTRATION NUMBER]',
                     '[ŞİRKET NUMARASI]', '[KAYITLI ADRES]', '[ICO KAYIT NUMARASI]'];

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  for (const slug of PAGES) {
    console.log(`\n=== ${slug}.html ===`);
    const file = path.join(DIR, P.file(slug));
    ok('the page exists', fs.existsSync(file));
    if (!fs.existsSync(file)) continue;

    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const errs = [];
    page.on('pageerror', e => errs.push(String(e)));
    const offsite = [];
    page.on('request', r => {
      const u = r.url();
      if (!/^(file|data|blob|about):/.test(u)) offsite.push(u.split('?')[0]);
    });
    await page.goto('file://' + file, { waitUntil: 'load' });
    await page.waitForTimeout(300);

    ok('no third-party request on load', offsite.length === 0, offsite.join(' '));

    // Part A is Legal's handover note. It names placeholders, dates and
    // internal arguments, and it must never appear on a page a visitor can see.
    // The privacy modal is on every page now, and it carries the privacy notice
    // word for word. On terms.html and cookies.html that would read as those
    // pages having privacy's unfilled brackets. It is one document, checked
    // once, on its own page — so it is taken out of the source under test here.
    const src = await page.evaluate(() => {
      const c = document.documentElement.cloneNode(true);
      c.querySelectorAll('.povl').forEach(e => e.remove());
      return c.outerHTML;
    });
    for (const leak of ['PART A', 'HANDOVER NOTE', 'Filled by', 'CEO decision needed',
                        'Legal cannot write', 'Master file']) {
      ok(`Part A did not leak: "${leak}"`, !src.includes(leak));
    }

    const bodyEn = await page.$eval('.doc[data-pane="en"]', d => d.textContent);
    const bodyTr = await page.$eval('.doc[data-pane="tr"]', d => d.textContent);
    ok('the English body arrived', bodyEn.length > 1000, String(bodyEn.length));
    ok('the Turkish body arrived', bodyTr.length > 800, String(bodyTr.length));
    ok('the two are not the same text', bodyEn !== bodyTr);

    console.log('  — placeholders —');
    const left = [...new Set((src.match(/\[[A-Z][A-ZÇĞİÖŞÜ \-]+\]/g) || []))];
    ok('every placeholder left is one Legal owns',
      left.every(p => LEGAL_OWNED.includes(p)), left.join(' '));
    ok('none of Developer\'s placeholders survived',
      !/\[PRIVACY EMAIL\]|\[PROCESSOR LIST\]|\[COOKIE TABLE\]|\[GO-LIVE DATE\]|\[GİZLİLİK E-POSTASI\]|\[HİZMET SAĞLAYICI LİSTESİ\]|\[ÇEREZ TABLOSU\]|\[YAYIN TARİHİ\]/.test(src));
    ok('the privacy mailbox is a real address, and a link',
      await page.$('a[href="mailto:privacy@anthifel.com"]') !== null);
    /* Both directions. Until 20 August only the first was checked, so when the
       company number arrived and the last bracket went, four assertions simply
       stopped running and the suite total dropped without anything failing — a
       page can be wrong by carrying a gap note it no longer deserves, and
       nothing was looking. */
    if (left.length) {
      ok('an unfilled page says so', await page.$('.lgnote') !== null);
      ok('…and each marker is visible, not hidden',
        (await page.$$('.lgap')).length >= left.length);
    } else {
      ok('a filled page does not claim to be unfinished', await page.$('.lgnote') === null);
      ok('…and carries no gap markers', (await page.$$('.lgap')).length === 0);
    }

    /* Legal's rule for the one placeholder that is deleted rather than shown:
       if the ICO number is not issued, the sentence goes. What must never
       happen is the half-state — the claim without the number. */
    ok('no ICO registration is claimed without a number',
       !/registration number\s*[.<]|registration number\s*$/m.test(src) &&
       !/ICO\)\s*numarasıyla|\s+numarasıyla kayıtlıyız/.test(src)
       || /registration number 1[0-9]{7}/.test(src),
       (src.match(/registration number[^<.]{0,30}/) || [''])[0]);

    console.log('  — both languages —');
    ok('the English page shows the English document, and only that',
       await page.isVisible('.doc[data-pane="en"]') &&
       await page.isHidden('.doc[data-pane="tr"]'));
    /* The Turkish document is a page now, at /tr/gizlilik/ and its two
       siblings, so this opens it rather than pressing a button. The pane
       mechanism stays — the document is too long to live in an attribute — but
       which pane is showing is decided by the file, not by a click. */
    const trp = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    await trp.goto('file://' + path.join(DIR, P.file(slug, 'tr')), { waitUntil: 'load' });
    await trp.waitForTimeout(250);
    ok('the Turkish page shows the Turkish document', await trp.isHidden('.doc[data-pane="en"]') &&
      await trp.isVisible('.doc[data-pane="tr"]'));
    ok('html lang follows', (await trp.getAttribute('html', 'lang')) === 'tr');
    ok('…and said so before any script ran',
       /<html lang="tr"/.test(fs.readFileSync(path.join(DIR, P.file(slug, 'tr')), 'utf-8')));
    ok('the three siblings are the Turkish ones',
       (await trp.$$eval('.lgnav a', as => as.map(a => a.getAttribute('href'))))
         .every(h => h.startsWith('/tr/')),
       (await trp.$$eval('.lgnav a', as => as.map(a => a.getAttribute('href')))).join(' '));
    await trp.close();

    console.log('  — the site menu —');
    const nav = await page.$$eval('.nav a', as => as.map(a => a.getAttribute('href')));
    ok('the menu is on the page', nav.length === 5, nav.join(' '));
    ok('its anchors resolve against the home page',
      nav.filter(h => h.startsWith('/#')).length === 4, nav.join(' '));

    console.log('  — the site\'s gutter —');
    const g = await page.evaluate(() => {
      const h = document.querySelector('.hdr').getBoundingClientRect();
      const img = document.querySelector('.hdr img').getBoundingClientRect();
      return { left: Math.round(h.left), right: Math.round(innerWidth - h.right),
               mark: Math.round(img.left), bg: getComputedStyle(document.body).backgroundColor };
    });
    ok('the header runs edge to edge', g.left === 0 && g.right === 0, JSON.stringify(g));
    ok('the gutter is the site\'s 72px floor at 1280px', g.mark === 72, JSON.stringify(g));
    ok('no second background behind the page', g.bg === 'rgb(245, 241, 234)', g.bg);

    console.log('  — structure —');
    ok('headings survived the conversion', (await page.$$('.doc[data-pane="en"] h3')).length >= 3);
    ok('no raw markdown left', !/(^|\n)#{1,4} |\*\*/.test(bodyEn), (bodyEn.match(/\*\*.{0,30}/) || [''])[0]);
    ok('the three pages link to each other', (await page.$$('.lgnav a')).length === 3);
    ok('this page is marked in that row',
      (await page.getAttribute(`.lgnav a[href="/${P.A.pages[slug].en}"]`, 'aria-current')) === 'page');
    ok('every wide table can be scrolled rather than overflowing',
      (await page.$$('.doc[data-pane="en"] table')).length === (await page.$$('.doc[data-pane="en"] .tw table')).length);

    console.log('  — the privacy notice in place —');
    // The reading list is on these pages too, and its consent box asks the same
    // three things. The document switcher above is deliberately left alone: a
    // reader choosing between the three documents wants the page, not a dialog.
    ok('the modal is here', await page.$('#povl') !== null);
    ok('the document switcher still navigates',
      await page.$eval(`.lgnav a[href="/${P.A.pages.privacy.en}"]`, a => a.target !== '_blank'));
    if (slug !== 'privacy') {
      await page.$eval(`.ncons label a[href$="/${P.A.pages.privacy.en}"]`, a => a.click());
      await page.waitForTimeout(150);
      ok('the reading list\'s consent link opens it', await page.isVisible('#povl'));
      ok('the page stayed where it was', page.url().includes(P.A.pages[slug].en));
      const h = await page.$eval('#pmDone', b => Math.round(b.getBoundingClientRect().height));
      ok('its close button clears the 44px touch floor', h >= 44, String(h));
      await page.keyboard.press('Escape');
      await page.waitForTimeout(120);
      ok('Escape closes it', await page.isHidden('#povl'));
    }

    console.log('  — js —');
    ok('no page errors', errs.length === 0, errs.join(' | '));
    await page.close();
  }

  // Developer owes two tables. They are the items a regulator and a client's
  // due diligence read first, and an empty one is not a cosmetic gap.
  console.log('\n=== Developer\'s two tables ===');
  const priv = fs.readFileSync(path.join(DIR, P.file('privacy')), 'utf-8');
  const cook = fs.readFileSync(path.join(DIR, P.file('cookies')), 'utf-8');
  ok('the processor list names the host', /DigitalOcean/.test(priv));
  ok('…and every Google service the site touches',
    ['Apps Script', 'Calendar'].every(s => priv.includes(s)));
  // The bot check stopped being Google's on 10 August. A processor listed but
  // not used is as wrong as one used but not listed.
  ok('…and does not list a processor we removed', !/reCAPTCHA/.test(priv));
  /* 20 August. This read /London region/ — Developer's own phrasing, because
     Developer wrote the table. Legal owns it now and writes "United Kingdom —
     London", so the assertion failed while the page was correct: it was testing
     the author, not the fact. What matters is that every row answers the
     question, so the test now counts hosting answers against processor rows. */
  const provRows = (priv.match(/<tr><td>(?:DigitalOcean|Squarespace|Resend|Google|Supabase)/g) || []).length;
  ok('…and says where each is hosted',
     provRows >= 8 && (priv.match(/United Kingdom|United States|Google\./g) || []).length >= provRows,
     `satır ${provRows}`);
  // The wording changed on 12 August with the bot check itself. "Contacts
  // nobody" was true of the proof of work; an emailed code contacts our own
  // endpoint. What has to stay true is the claim that matters to a visitor:
  // nothing is set or stored on their device.
  ok('the cookie table says the bot check stores nothing on your device',
     /sets no cookie and stores nothing on your device|cihazınızda hiçbir şey saklamaz/.test(cook));
  ok('…and says how long the code itself is kept',
     /fifteen minutes|on beş dakika/.test(cook));
  // Processors, checked by name rather than by count: the list is only useful
  // if it is the list, and it went stale within two days the first time.
  ok('every processor that is live today is listed',
     ['Resend', 'DigitalOcean', 'Squarespace', 'Apps Script', 'Supabase']
       .every(n => priv.includes(n)),
     ['Resend', 'DigitalOcean', 'Squarespace', 'Apps Script', 'Supabase']
       .filter(n => !priv.includes(n)).join(', '));
  /* Same cause. The point is not the sentence, it is that the result email's
     contents are disclosed rather than glossed — a band alone would be an
     understatement of what Resend can see. */
  ok('…and the mail sender says what it sees',
     /band and five dimension scores|your band and your five dimension scores|bandınız ve beş boyut/.test(priv));
  ok('…and classifies every row', (cook.match(/Strictly necessary|Not applicable/g) || []).length >= 3);
  ok('…and says the site sets no cookie of its own', /not a cookie/.test(cook));

  await browser.close();
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
