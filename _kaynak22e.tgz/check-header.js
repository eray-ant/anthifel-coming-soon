/*
 * check-header.js — the header is the same object on every page.
 *
 * Why this exists. On 21 August the CEO said the menu "shifts slightly" between
 * the home page and a service page. It did: 34px of gap between the five labels
 * on the home page and the Journal, 30px on the service and legal pages. Four
 * gaps, 16px, a menu that slid left while the wordmark and the language switch
 * held still. The burger breakpoint had drifted further — 820px on one shell
 * and 960px on the other — so between those widths the same site showed five
 * links on one page and a hamburger on the next.
 *
 * None of it was a decision. The header had been written out five times, once
 * per shell, and the copies had aged apart. header.css is one part now, but a
 * part is only one part while something checks. Comments do not check: each of
 * the five copies already had one at the top.
 *
 * What this asserts: at twelve widths, every page's header geometry equals the
 * home page's — the header box, the wordmark, the language switch, every menu
 * item's x and width, and whether the burger and the menu are displayed. Not
 * "looks similar": equal. A 4px difference is exactly the kind nobody measures
 * and everybody sees.
 *
 * y is deliberately not compared. The header is sticky and /meet lands on an
 * anchor, so its header can sit a few pixels up the page at load without
 * anything being wrong. Drift shows up in x and width.
 *
 *   node check-header.js [dist/production]
 */
const { chromium } = require('playwright');
const path = require('path');
const P = require('./pages');
const fs = require('fs');

const OUT = path.resolve(process.argv[2] ||
  path.join(__dirname, 'dist', 'production'));

// Every page that carries the site chrome. The Turkish Journal index is not
// here on purpose: it defaults to Turkish, its labels are different words, and
// comparing "Yaklaşım" to "Approach" measures translation, not drift.
const PAGES = [
  ...P.ALL.filter(p => p.key !== 'home').map(p => p.file),
  '404.html',
];

// 960 / 900 / 860 / 821 are in the list because that is where the two
// breakpoints disagreed. 821 is one pixel above the one breakpoint there is
// now: the last width at which the full menu must still be a row.
const WIDTHS = [1440, 1280, 1024, 960, 900, 860, 821, 768, 430, 390, 360, 320];

// Half a pixel of tolerance on the numbers, exact on the strings.
//
// Not slack: the Journal marks its own menu item with aria-current, which sets
// font-weight 600 on that one label and makes it 0.2px wider, which nudges the
// two labels after it by the same 0.2px. That is the marker doing its job. The
// drift this file exists to catch was 16px. Anything at or above half a pixel
// is a layout decision; anything below it is the renderer.
const CLOSE = 0.5;
const same = (a, b) => {
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  if (Array.isArray(a)) {
    return a.length === b.length && a.every((v, i) => same(v, b[i]));
  }
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) < CLOSE;
  return a === b;
};

let pass = 0, fail = 0;
const ok = (name, cond, detail) => {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (detail ? '  → ' + detail : '')); }
};

(async () => {
  if (!fs.existsSync(path.join(OUT, 'index.html'))) {
    console.error('no build at ' + OUT + ' — run build.py first');
    process.exit(2);                       // not "nothing to test": a failure
  }

  const browser = await chromium.launch(
    { executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  const geometry = async (rel, width) => {
    const page = await browser.newPage({ viewport: { width, height: 900 } });
    await page.goto('file://' + path.join(OUT, rel), { waitUntil: 'load' });
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(60);
    const g = await page.evaluate(() => {
      // x and width, tenths of a pixel. Sub-pixel noise is not drift; 4px is.
      const box = e => {
        const b = e.getBoundingClientRect();
        return [Math.round(b.x * 10) / 10, Math.round(b.width * 10) / 10];
      };
      return {
        hdr: box(document.querySelector('.hdr')),
        brand: box(document.querySelector('.brandlink')),
        lang: box(document.querySelector('.lang')),
        nav: [...document.querySelectorAll('.nav a')].map(box),
        burger: getComputedStyle(document.querySelector('.burger')).display,
        menu: getComputedStyle(document.querySelector('.nav')).display,
      };
    });
    await page.close();
    return g;
  };

  /* Measured against the home page *in the same language*.
     The menu reads "Approach Services…" in English and "Yaklaşım Hizmetler…"
     in Turkish, so the entries are different widths and always will be. What
     has to hold is that every English page agrees with the English home page
     and every Turkish page with the Turkish one — which is the drift this was
     written to catch, since the drift came from five copies of the markup and
     not from the words. */
  const langOf = rel => rel.startsWith('tr/') ? 'tr' : 'en';
  for (const width of WIDTHS) {
    console.log('\n— ' + width + 'px —');
    const home = { en: await geometry(P.file('home'), width),
                   tr: await geometry(P.file('home', 'tr'), width) };
    for (const rel of PAGES) {
      const g = await geometry(rel, width);
      const base = home[langOf(rel)];
      const off = [];
      for (const k of ['hdr', 'brand', 'lang', 'nav', 'burger', 'menu'])
        if (!same(base[k], g[k]))
          off.push(`${k} ${JSON.stringify(base[k])} ≠ ${JSON.stringify(g[k])}`);
      ok(rel, off.length === 0, off.join('; '));
    }
    /* The two languages are allowed to differ inside the menu and nowhere
       else: the bar, the wordmark and the switch are the same furniture. */
    for (const k of ['hdr', 'brand', 'lang', 'burger'])
      ok(`${k} is identical in both languages`, same(home.en[k], home.tr[k]),
         `${JSON.stringify(home.en[k])} ≠ ${JSON.stringify(home.tr[k])}`);
  }

  // The part itself. A second file defining .hdr or .nav is how the last five
  // copies started, and it would pass every assertion above on the day it was
  // written — the drift arrives later, when one of them is edited.
  console.log('\n— one part, one file —');
  const src = fs.readdirSync(__dirname)
    .filter(f => /\.(html|css)$/.test(f) && f !== 'header.css');
  for (const sel of ['.hdr{', '.nav{']) {
    const guilty = src.filter(f =>
      fs.readFileSync(path.join(__dirname, f), 'utf-8')
        .split('\n').some(l => l.trimStart().startsWith(sel)));
    ok(`nothing but header.css defines ${sel.slice(0, -1)}`,
       guilty.length === 0, guilty.join(', '));
  }

  await browser.close();
  console.log(fail ? `\n❌  ${pass} passed, ${fail} failed`
                   : `\n✅  ${pass} passed, 0 failed`);
  process.exit(fail ? 1 : 0);
})();
