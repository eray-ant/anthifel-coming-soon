/**
 * check-seo.js — Anthifel
 *
 * What a machine reads. Every other suite opens a page the way a person does;
 * this one reads the site the way a crawler and a share card do, which until
 * today was nobody's job and showed: the front page had no picture to share,
 * the service pages had no share tags at all, and there was no sitemap and no
 * robots.txt anywhere — only a note telling somebody to write one by hand.
 *
 * The rules it holds to:
 *   - a sitemap may only name pages that exist and that robots.txt allows
 *   - anything a stranger's machine has to fetch is an absolute URL and a real
 *     file, because the rest of this site is inlined and a data URI is useless
 *     to a crawler
 *   - K50 travels into structured data too: no price, anywhere, in any form
 *
 *   node check-seo.js [dist/production]
 */
const path = require('path');
const P = require('./pages');
const fs = require('fs');

const DIR = path.resolve(process.argv[2] || 'dist/production');
const SITE = 'https://anthifel.com/';
let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n}${x ? '  → ' + x : ''}`)); };
const read = f => fs.readFileSync(path.join(DIR, f), 'utf-8');

console.log('\n— robots.txt —');
ok('it exists at the root the crawler asks for', fs.existsSync(path.join(DIR, 'robots.txt')));
const robots = read('robots.txt');
/* 20 August, launch: `/preview/` is gone from the repository, so the line that
   closed it is gone from robots.txt. Asserting its *absence* rather than
   dropping the check, because a Disallow for a path that does not exist is not
   harmless — it is a public announcement that a staging copy is somewhere, and
   robots.txt is the first file anyone curious reads. The day a staging copy
   comes back, this fails and somebody has to think about it. */
ok('no staging copy is announced', !/^Disallow: \/preview\//m.test(robots), robots);
ok('the panel is still closed', /^Disallow: \/dashboard\//m.test(robots), robots);
ok('the panel is closed', /^Disallow: \/dashboard\//m.test(robots));
ok('it names the sitemap, absolutely', robots.includes('Sitemap: ' + SITE + 'sitemap.xml'));

/* Every AI crawler stays welcome — Marketing's decision, 21 August, and the
   kind that gets quietly reversed by somebody adding one "sensible" line.
   Blocking Claude-SearchBot or OAI-SearchBot removes this company from AI
   answers altogether; blocking Google-Extended does not reduce AI Overviews
   visibility at all, it only withholds the site from Gemini training. Both are
   easy to get backwards, which is why this is a test and not a note. */
const AI_CRAWLERS = [
  'GPTBot', 'OAI-SearchBot', 'ChatGPT-User',
  'ClaudeBot', 'Claude-SearchBot', 'Claude-User',
  'PerplexityBot', 'Perplexity-User', 'CCBot', 'Amazonbot',
  'meta-externalagent', 'Applebot', 'Applebot-Extended',
  'Google-Extended', 'Bytespider',
];
{
  // A Disallow only binds the User-agent block it sits in, so the file is read
  // in blocks rather than grepped: "Disallow: /" under `*` would close the site
  // to everything and a grep for a crawler's name would not see it.
  const blocks = [];
  let cur = null;
  for (const raw of robots.split('\n')) {
    const line = raw.replace(/#.*/, '').trim();
    if (!line) continue;
    const m = line.match(/^User-agent:\s*(.+)$/i);
    if (m) {
      if (!cur || cur.rules.length) { cur = { agents: [], rules: [] }; blocks.push(cur); }
      cur.agents.push(m[1].trim());
    } else if (cur && /^Disallow:/i.test(line)) {
      cur.rules.push(line.replace(/^Disallow:\s*/i, '').trim());
    }
  }
  const closedFor = agent => {
    const b = blocks.find(x => x.agents.some(a => a.toLowerCase() === agent.toLowerCase()))
           || blocks.find(x => x.agents.includes('*'));
    return b ? b.rules.filter(r => r === '/' || r === '').filter(r => r === '/') : [];
  };
  for (const a of AI_CRAWLERS) {
    ok(`${a} is not blocked`, closedFor(a).length === 0,
       'a Disallow: / applies to it');
    ok(`  …and has no rule of its own`,
       !blocks.some(b => b.agents.some(x => x.toLowerCase() === a.toLowerCase())),
       'it has its own User-agent block, which is how a Disallow gets added later');
  }
}
// A rule with no agent applies to nobody. This is the mistake that makes a
// robots.txt look right and do nothing.
ok('the rules are addressed to somebody', /^User-agent: \*/m.test(robots));

console.log('\n— sitemap.xml —');
ok('it exists', fs.existsSync(path.join(DIR, 'sitemap.xml')));
const map = read('sitemap.xml');
const locs = [...map.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m => m[1]);
ok('it names something', locs.length > 5, String(locs.length));
ok('every address is absolute and ours', locs.every(l => l.startsWith(SITE)), locs.find(l => !l.startsWith(SITE)));

/* The contradiction a crawler reports back: a map that names a page the rules
   forbid it to read. Worth a test of its own because both files are correct on
   their own and only wrong together. */
const disallowed = robots.split('\n').filter(l => l.startsWith('Disallow:'))
  .map(l => l.replace('Disallow:', '').trim()).filter(Boolean);
ok('nothing in the map is disallowed by the rules',
   !locs.some(l => disallowed.some(d => l.replace(SITE, '/').startsWith(d))),
   locs.find(l => disallowed.some(d => l.replace(SITE, '/').startsWith(d))));

const missing = locs.map(l => l.replace(SITE, ''))
  .map(rel => rel.endsWith('/') || rel === '' ? rel + 'index.html' : rel)
  .filter(rel => !fs.existsSync(path.join(DIR, rel)));
/* A published article is written by the publisher straight into the repository,
   so it is in the map and legitimately not in this build. Everything else that
   is named has to be here. */
ok('every page it names is in this build, or is a published article',
   missing.every(m => /^(tr\/)?blog\/[a-z0-9-]+\/index\.html$/.test(m)), missing.join(' '));
/* Reciprocal, on every page and not just About. An hreflang set that names
   one side and not the other is discarded, so the map has to carry the pair
   for each of the twenty-two addresses. */
for (const key of Object.keys(P.A.pages)) {
  for (const lang of ['en', 'tr']) {
    const loc = P.url(key, lang);
    if (!locs.includes(loc)) continue;
    const block = map.split('<loc>' + loc + '</loc>')[1].split('</url>')[0];
    ok(`${key} (${lang}): the map names both of its addresses`,
       block.includes(P.url(key, 'en')) && block.includes(P.url(key, 'tr')));
  }
}
ok('the Journal is in it, in both languages',
   locs.includes(P.url('blog', 'en')) && locs.includes(P.url('blog', 'tr')));
ok('the panel is not in it', !locs.some(l => /dashboard/.test(l)));
ok('the staging copy is not in it', !locs.some(l => /\/preview\//.test(l)));

console.log('\n— the files a stranger has to fetch —');
for (const f of ['logo.png', 'share-card.webp']) {
  ok(`${f} is a real file`, fs.existsSync(path.join(DIR, f)));
  ok(`  …and not empty`, fs.statSync(path.join(DIR, f)).size > 2000,
     String(fs.existsSync(path.join(DIR, f)) && fs.statSync(path.join(DIR, f)).size));
}

console.log('\n— what every public page says about itself —');
const PUBLIC = P.SHELL.filter(p => !['privacy', 'terms', 'cookies', 'meet'].includes(p.key))
                       .map(p => p.file);
for (const f of PUBLIC) {
  const html = read(f);
  const og = k => (html.match(new RegExp(`<meta property="og:${k}" content="([^"]*)"`)) || [])[1];
  ok(`${f}: has a title and a description to share`, !!og('title') && !!og('description'),
     `${og('title')} | ${og('description')}`);
  ok(`${f}: names a picture`, !!og('image'), og('image'));
  /* Absolute, and this is the whole reason logo.png and share-card.webp exist
     as files: every other image on this site is a data URI, which a crawler
     cannot fetch and will not render. */
  ok(`${f}: …at an address a crawler can fetch`, (og('image') || '').startsWith('https://'), og('image'));
  ok(`${f}: the card is the large one`,
     /twitter:card" content="summary_large_image"/.test(html));
  ok(`${f}: og:url is its own address`, (og('url') || '').startsWith(SITE), og('url'));
}

console.log('\n— structured data —');
const ld = f => [...read(f).matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)]
  .map(m => { try { return JSON.parse(m[1]); } catch (e) { return { broken: m[1].slice(0, 80) }; } });

const home = ld('index.html');
ok('the front page carries two blocks', home.length === 2, String(home.length));
ok('none of them is broken JSON', !home.some(o => o.broken), JSON.stringify(home.find(o => o.broken)));
const org = home.find(o => o['@type'] === 'Organization');
ok('one of them says who we are', !!org);
ok('it names the logo as a URL, not as bytes',
   org && org.logo === SITE + 'logo.png', org && String(org.logo).slice(0, 40));
ok('it says London, and does not invent a street',
   org && org.address.addressLocality === 'London' && !org.address.streetAddress,
   org && JSON.stringify(org.address));
/* The founder is a node now, not a name inside the company: Marketing §5 asks
   for a Person tied to the organisation, and an assistant can resolve an @id
   where it can only read a string. */
ok('it points at the founder rather than naming him inline',
   org && org.founder && org.founder['@id'] === SITE + '#founder',
   org && JSON.stringify(org.founder));
{
  const person = ld('index.html').find(o => o['@type'] === 'Person');
  ok('…and the founder is a node of his own', !!person);
  ok('…tied back to the company', person && person.worksFor['@id'] === SITE + '#organisation');
  ok('…with one LinkedIn profile and nothing invented',
     person && person.sameAs.length === 1 && /linkedin\.com\/in\//.test(person.sameAs[0]),
     person && JSON.stringify(person.sameAs));
}

/* sameAs is a list of places this company can be found, and every entry is a
   claim that it is us. Marketing §6 will add Wikidata, Crunchbase and Clutch
   when they exist; until then the array holds three addresses that resolve
   today. The assertion is an exact set rather than a count, because the failure
   worth catching is not "too many" — it is a plausible-looking profile nobody
   opened. Companies House is here on purpose: it is the register itself, the
   one entry the other five get checked against (§7). */
ok('sameAs is exactly the set we have decided on',
   org && JSON.stringify(org.sameAs) === JSON.stringify([
     'https://www.linkedin.com/company/anthifel',
     'https://x.com/anthifel',
     'https://find-and-update.company-information.service.gov.uk/company/17411895',
   ]), org && JSON.stringify(org.sameAs));

/* §7: one spelling of this company everywhere. The registered name and the
   company number belong in the record a machine reads, not only in the footer
   a person reads. */
ok('the registered name is in the record', org && org.legalName === 'Anthifel Ltd', org && org.legalName);
ok('…and the company number, as the register writes it',
   org && org.identifier && org.identifier.value === '17411895',
   org && JSON.stringify(org.identifier));
ok('foundingDate is ISO 8601', org && /^\d{4}-\d{2}-\d{2}$/.test(org.foundingDate), org && org.foundingDate);

/* Marketing's "do not want" list: nothing beyond the six types in §5. WebSite
   was here and described a search box this site does not have. */
{
  const ALLOWED = ['Organization', 'Person', 'Service', 'BlogPosting',
                   'BreadcrumbList', 'FAQPage'];
  for (const f of [P.file('home'), P.file('ai-readiness-audit'), P.file('about'),
                   P.file('meet'), P.file('about', 'tr'), P.file('home', 'tr')]) {
    const types = ld(f).map(o => o['@type']);
    const extra = types.filter(t => !ALLOWED.includes(t));
    ok(`${f}: no schema beyond the six agreed types`, extra.length === 0, extra.join(', '));
  }
}

/* §5 again, and the one that matters most: the array must read the same on
   every page. It was on the front page only, so an assistant landing on a
   service page had no way to tell whose service it was. */
{
  const pages = P.SHELL.map(p => p.file);
  const seen = pages.map(f => {
    const o = ld(f).find(x => x['@type'] === 'Organization');
    return { f, s: o ? JSON.stringify(o.sameAs) : '(no Organization)' };
  });
  const first = seen[0].s;
  const off = seen.filter(x => x.s !== first);
  ok('every page carries the identity, with the same sameAs', off.length === 0,
     off.map(x => x.f).join(', '));
}

const SERVICE_KEYS = ['ai-readiness-audit', 'discovery-sprint',
                      'transformation-retainer', 'advisory-board-seat'];
for (const f of SERVICE_KEYS.flatMap(k => [P.file(k), P.file(k, 'tr')])) {
  const svc = ld(f).find(o => o['@type'] === 'Service');
  ok(`${f}: is described as a service`, !!svc);
  ok(`  …provided by the organisation on the front page`,
     svc && svc.provider['@id'] === SITE + '#organisation');
  /* K50. schema.org has an `offers` field with a price in it, and filling it
     would publish the number in the one place nobody looks at and everybody can
     read. The rule is the site never states a price; a machine-readable page is
     still the site. */
  ok(`  …with no price in it`, svc && !svc.offers && !JSON.stringify(svc).match(/price|\$|£|€/i));
}

/* ---- titles: the template never adds the brand -------------------------
 *
 * Marketing wrote this down as a standing rule on 21 August, after four
 * service pages went out reading "AI Readiness Audit · Anthifel · Anthifel".
 * The shell was appending " · Anthifel" while Business's own §2 titles already
 * carried it. Nobody saw it in the page — a browser tab shows about thirty
 * characters and the second brand fell off the end of it.
 *
 * Two assertions, because the bug has two halves. The first reads the built
 * pages: no title says the brand twice, in either language. The second reads
 * the templates: no title tag has the brand written beside a token, which is
 * the shape the appending took. The first would catch it today; the second
 * catches somebody re-introducing the habit on a page that has no title yet.
 *
 * The 60-character limit is Business's, from §2, and it is the reason this is
 * not merely cosmetic: a Turkish title plus an appended brand ran to 63. */
console.log('\n— titles —');
const TITLE_RE = /<title[^>]*?(?:data-en="([^"]*)")?[^>]*?(?:data-tr="([^"]*)")?[^>]*>([^<]*)<\/title>/;
for (const f of fs.readdirSync(DIR).filter(n => n.endsWith('.html'))
                 .concat(P.ALL.map(p => p.file))) {
  let html;
  try { html = read(f); } catch { continue; }
  const m = html.match(TITLE_RE);
  if (!m) { ok(`${f}: has a title at all`, false); continue; }
  for (const [lang, t] of [['en', m[1] || m[3]], ['tr', m[2] || m[3]]]) {
    if (!t) continue;
    const brands = (t.match(/Anthifel/g) || []).length;
    ok(`${f} (${lang}): names the brand at most once`, brands <= 1, t);
    ok(`${f} (${lang}): fits Business's 60 characters`, t.length <= 60,
       `${t.length}: ${t}`);
  }
}
const TEMPLATES = fs.readdirSync(__dirname).filter(n => /_template\.html$|^blog_index\.html$|^body\.html$/.test(n));
for (const t of TEMPLATES) {
  const line = (fs.readFileSync(path.join(__dirname, t), 'utf-8')
    .split('\n').find(l => l.includes('<title')) || '');
  ok(`${t}: the title tag does not append the brand to a token`,
     !/__TITLE_(EN|TR)__[^"<]*Anthifel/.test(line), line.trim().slice(0, 90));
}

/* Every page says which address it is.
 *
 * Eight of thirteen production pages had no canonical: the four service pages,
 * the three legal pages and /meet/. The token was in the shell and only About
 * was passing it, so the rest rendered it empty — invisible in the browser,
 * invisible in the diff, visible only if you go looking for something that is
 * not there. This asserts the presence, and asserts the value is the page's
 * own address, because the second half of the same bug had /en/blog/ naming
 * /blog/ as its canonical, which asks Google to drop the English Journal.
 *
 * A canonical is not decoration here: the footer of every page links to
 * `?lang=tr`, and `?form=live` and `?debug=1` run off the same addresses.
 * Without this line each of those is a separate page to a crawler. */
console.log('\n— canonical —');
for (const p of P.ALL) {
  let html;
  try { html = read(p.file); } catch { ok(`${p.file}: exists`, false); continue; }
  const all = html.match(/<link rel="canonical" href="([^"]*)"/g) || [];
  ok(`${p.file}: exactly one canonical`, all.length === 1, `${all.length} found`);
  const m = html.match(/<link rel="canonical" href="([^"]*)"/);
  ok(`${p.file}: canonical is its own address`, !!m && m[1] === P.url(p.key, p.lang),
     m ? m[1] : 'none');
}

/* hreflang may only name an address that actually serves that language.
 *
 * This is the assertion the whole /tr move exists to make passable. Before it,
 * the Turkish alternate pointed at `?lang=tr` — an address a static host
 * answers in English, because the switch ran in JavaScript and no crawler runs
 * JavaScript. So the test does not check the string: it opens the file the tag
 * names and reads what that document says its language is. */
console.log('\n— hreflang is true —');
const bySelf = new Map(P.ALL.map(p => [P.url(p.key, p.lang), p]));
for (const p of P.ALL) {
  let html;
  try { html = read(p.file); } catch { continue; }
  for (const code of ['en', 'tr']) {
    const m = html.match(new RegExp(`<link rel="alternate" hreflang="${code}" href="([^"]*)"`));
    ok(`${p.file}: names its ${code} counterpart`, !!m && m[1] === P.url(p.key, code),
       m ? m[1] : 'none');
    if (!m) continue;
    const target = bySelf.get(m[1]);
    let doc = '';
    try { doc = read(target.file); } catch { ok(`  …and that address is a page`, false, m[1]); continue; }
    ok(`  …and that page is ${code} before any script runs`,
       new RegExp(`<html lang="${code}"`).test(doc),
       (doc.match(/<html lang="[^"]*"/) || ['none'])[0]);
  }
  ok(`${p.file}: x-default is the English one`,
     new RegExp(`hreflang="x-default" href="${P.url(p.key, 'en')}"`).test(html));
}

/* Nothing is left pointing at an address that no longer exists, and every
 * address that used to answer still answers. */
console.log('\n— the addresses that moved —');
for (const [old, to] of Object.entries(P.moved)) {
  const rel = old.endsWith('/') ? old + 'index.html' : old;
  let html;
  try { html = read(rel); } catch { ok(`${old}: still answers`, false); continue; }
  ok(`${old}: still answers`, true);
  ok(`  …and names ${to} as the canonical`,
     html.includes(`<link rel="canonical" href="https://anthifel.com${to}">`));
  ok(`  …and sends a browser there too`,
     html.includes(`content="0; url=https://anthifel.com${to}"`));
}
for (const p of P.ALL) {
  let html;
  try { html = read(p.file); } catch { continue; }
  const stale = (html.match(/href="\/[a-z0-9-]+\.html"/g) || []);
  ok(`${p.file}: links to no address that has moved`, stale.length === 0, stale.join(' '));
}

console.log(`\n${fail ? '❌' : '✅'}  ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
