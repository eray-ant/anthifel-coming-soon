#!/usr/bin/env python3
"""
build.py — Anthifel site builder

Produces two builds from one source:

  dist/preview/     staging. Lives at anthifel.com/<PREVIEW_DIR>/ while the
                    coming-soon page keeps the root. noindex, nofollow,
                    no canonical, visible preview bar.
  dist/production/  what replaces the coming-soon page at launch. Canonical
                    and hreflang present, indexable, no bar.

Nothing differs between them except the head block and the bar. The markup,
the CSS, the form and the copy are the same bytes, so what is signed off in
preview is what goes live.

  python3 build.py
"""

import base64, io, json, os, re, shutil, sys
import trlang            # the Turkish page, built rather than switched

import legal
from PIL import Image

# ── the only line to change if the preview path should be different ──────────
PREVIEW_DIR = 'preview'
# ─────────────────────────────────────────────────────────────────────────────

ROOT = os.path.dirname(os.path.abspath(__file__))
LOGO = 'c790b9cb-88b7-418f-93a6-2e9edfd16d0e'
MONO = 'b3d4e4a2-dabe-414b-a6e1-475f65f4e1a9'


def asset(uid, maxw):
    im = Image.open(os.path.join(ROOT, 'assets', uid + '.png')).convert('RGBA')
    if im.width > maxw:
        im = im.resize((maxw, round(im.height * maxw / im.width)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, 'PNG', optimize=True)
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


def favicon(size=64):
    """
    Plain black mark on transparency — no plate behind it. The source has a real
    alpha channel, so the glyph is trimmed to its own bounds, forced to solid
    black, and centred in a square with a little breathing room. Anything else
    puts a cream tile in the tab that reads as a bug.
    """
    im = Image.open(os.path.join(ROOT, 'assets', MONO + '.png')).convert('RGBA')
    im = im.crop(im.getchannel('A').getbbox())          # drop the empty margin

    # Keep the shape from the alpha channel; make every visible pixel black.
    glyph = Image.new('RGBA', im.size, (0, 0, 0, 255))
    glyph.putalpha(im.getchannel('A'))

    pad = round(size * 0.10)
    box = size - pad * 2
    scale = min(box / glyph.width, box / glyph.height)
    glyph = glyph.resize((max(1, round(glyph.width * scale)),
                          max(1, round(glyph.height * scale))), Image.LANCZOS)

    out = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    out.alpha_composite(glyph, ((size - glyph.width) // 2, (size - glyph.height) // 2))

    buf = io.BytesIO()
    out.save(buf, 'PNG', optimize=True)
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


FONTS = open(os.path.join(ROOT, 'fonts.css'), encoding='utf-8').read()
FONTS_STUB = '/* ' + '/* '.join(
    b for b in FONTS.split('/* ') if b.strip() and 'font-style:italic' not in b
)
LOGO_URI, MONO_URI, FAV_URI = asset(LOGO, 600), asset(MONO, 800), favicon()

# The home page. No `hreflang="tr"` here, and its absence is the point.
#
# It used to say `href="https://anthifel.com/?lang=tr"`. That address is served
# by a static host that cannot vary on a query string: the file returned is the
# English one, and the Turkish only appears when applyLang runs in the browser.
# No crawler runs it. So the tag was promising a Turkish document at an address
# that hands back English - the same fault hakkimizda.html had before trlang.py,
# and Google's own rule is that an hreflang set with a bad member can be
# discarded whole, which would have taken About's honest pair down with it.
#
# Removing the claim is not the end state. The end state is a Turkish home page
# that is Turkish in the HTML, the way hakkimizda.html is, and that needs an
# address - which is a CEO call, not a build decision. Until then the site says
# less and everything it says is true. check-seo asserts this.
PROD_HEAD = '''<link rel="canonical" href="https://anthifel.com/">
<link rel="alternate" hreflang="en" href="https://anthifel.com/">
<link rel="alternate" hreflang="x-default" href="https://anthifel.com/">'''

PREVIEW_HEAD = '''<meta name="robots" content="noindex,nofollow,noarchive">'''

PREVIEW_BAR = '''<div class="pvbar">
  <span data-en="Preview · not published. The live site is still the coming-soon page." data-tr="Önizleme · yayında değil. Yayındaki site hâlâ çok yakında sayfası.">Preview · not published. The live site is still the coming-soon page.</span>
</div>
<style>
.pvbar{background:#0F0F0E;color:#F5F1EA;font-family:'Inter',system-ui,sans-serif;font-size:11.5px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;text-align:center;padding:9px 18px;line-height:1.4}
@media (max-width:640px){.pvbar{font-size:10px;letter-spacing:.1em;padding:8px 14px}}
</style>'''



MEET_PANEL = open(os.path.join(ROOT, 'meet_panel.html'), encoding='utf-8').read().strip()

# The site footer, and its stylesheet, as one part. Until 12 August the service
# page and the three legal pages carried only the thin legal strip — no address,
# no menu, no blog, no way back into the site except the header. A visitor who
# lands on a legal page from a search result should not be at a dead end.
#
# `__HOME__` is what makes one copy work on every page: empty on index.html, so
# `#approach` stays a same-page anchor, and `index.html` everywhere else, so the
# same link travels home first.
FOOTER     = open(os.path.join(ROOT, 'footer.html'), encoding='utf-8').read().strip()
# The trading disclosure's styles. One file, three consumers — footer.css for
# the service and legal pages, body.html for the main pages, blog_common.css for
# the Journal. The footer's rules are forked across those three (DEV-079); this
# part is not, because on 20 August the fork ate an hour: the rules went into
# footer.css, the page was rebuilt, and the block came out unstyled.
IMPRINT_CSS = open(os.path.join(ROOT, 'imprint.css'), encoding='utf-8').read().strip()
# The header, for the same reason and with a longer history. It was written out
# five times — body.html, blog_common.css, service_template.html,
# legal_template.html and a stub template nothing built from — and the copies
# disagreed: 34px of menu gap here and 30px there, a burger at 820px here and
# at 960px there. Nobody chose either. The CEO saw the menu move between the
# home page and a service page on 21 August, which is what a copied part looks
# like from the outside. One file now; check-header.js fails if a second one
# defines .hdr or .nav.
HEADER_CSS = open(os.path.join(ROOT, 'header.css'), encoding='utf-8').read().strip()
FOOTER_CSS = open(os.path.join(ROOT, 'footer.css'), encoding='utf-8').read().strip()
FOOTER_CSS = FOOTER_CSS.replace('__IMPRINT_CSS__', IMPRINT_CSS)

# The reading list, and its stylesheet. It was the blog's alone until 13 August;
# it is the one thing on the site that asks for an address without asking for
# anything else, and it sat on the pages the fewest people reach.
NEWS     = open(os.path.join(ROOT, 'newsletter.html'), encoding='utf-8').read().strip()
NEWS_CSS = open(os.path.join(ROOT, 'newsletter.css'), encoding='utf-8').read().strip()
# DEV-032. One line, one place, flipped on launch day.
#
# It used to be a literal in three shells and missing from a fourth: body.html
# said false with a `?form=live` way past it, service_template.html and
# blog_parts.html each said false on their own, and legal_template.html did not
# declare it at all — so the reading list on the legal pages was off in a way
# nothing could switch on. Flipping "the" switch would have turned the forms on
# for the front page and left them off on five of seven, which is the kind of
# thing nobody finds on launch morning.
# 20 August, launch. Flipped once, here, and stamped into all four shells —
# which is the whole reason this line exists in one place.
FORM_LIVE = True

NEWS_JS  = open(os.path.join(ROOT, 'newsletter.js'), encoding='utf-8').read().strip()

# The privacy notice's own version identifier, stamped into the consent record.
# Legal sets it in Anthifel_Legal_PrivacyPolicy.md — "Notice version identifier"
# — and changes it whenever Part B changes, so an old consent record still
# resolves to the text the person actually saw. Read from Legal's file rather
# than typed here: two copies of a version number is how a record ends up
# pointing at a notice nobody published.
PRIVACY_VERSION = legal.privacy_version()
NEWS_JS = NEWS_JS.replace('__PRIVACY_VERSION__', PRIVACY_VERSION)


def newsletter(up=''):
    return NEWS.replace('__PRIVACY__', up + 'privacy.html')

# The privacy modal. Markup, stylesheet and behaviour, injected as one block by
# `privacy_panel()` — the reading list taught this the hard way: a part whose
# styles live in the host page's stylesheet cannot travel to a page that does
# not carry them.
# The cookie question, and with it the only Google tag on the site. It is a
# part for the same reason the others are: markup, stylesheet and behaviour go
# together or it arrives half alive.
#
# GA_ID is stamped into production only. The preview build gets an empty string,
# which means the band still shows and can be tested but nothing is ever
# fetched from Google — staging traffic in a production property is noise you
# cannot take back out.
GA_ID = 'G-W376XEN94E'

CONSENT     = open(os.path.join(ROOT, 'consent.html'), encoding='utf-8').read().strip()
CONSENT_CSS = open(os.path.join(ROOT, 'consent.css'), encoding='utf-8').read().strip()
CONSENT_JS  = open(os.path.join(ROOT, 'consent.js'), encoding='utf-8').read().strip()


def consent_panel(up='', preview=True):
    return ('<style>\n%s\n</style>\n%s\n<script>\n%s\n</script>'
            % (CONSENT_CSS,
               CONSENT.replace('__COOKIES__', up + 'cookies.html'),
               CONSENT_JS.replace('__GA_ID__', '' if preview else GA_ID)
                          .replace('__COOKIES_SELECTOR__', cookies_selector())))


PMOD     = open(os.path.join(ROOT, 'privacy_modal.html'), encoding='utf-8').read().strip()
PMOD_CSS = open(os.path.join(ROOT, 'privacy_modal.css'), encoding='utf-8').read().strip()
PMOD_JS  = open(os.path.join(ROOT, 'privacy_modal.js'), encoding='utf-8').read().strip()

# The four planned pieces, shown until the first one is published. One list, so
# the Journal's footer and every other page's footer cannot disagree about what
# has been written — which is exactly how they drifted apart.
# The four planned pieces, shown until the first one is published. One list, so
# the Journal's footer and every other page's footer cannot disagree about what
# has been written — which is exactly how they drifted apart.
SEED_POSTS = [
    ('ai-transformation-people-problem',
     'Why AI transformation is a people problem',
     'AI Dönüşümü Neden Teknoloji Değil, Organizasyon Problemidir?'),
    ('twelve-signals-ready-for-ai',
     'Twelve signals your company is ready for AI',
     'Bir Şirketin AI’a Hazır Olduğunu Nasıl Anlarsın? 12 Sinyal'),
    ('who-should-own-ai',
     'Who should own AI in your organisation?',
     '“AI’dan Kim Sorumlu?” Sorusunun Cevabı Yoksa Dönüşüm Başlamamıştır'),
    ('what-a-pilot-really-tells-you',
     'What a pilot project really tells you',
     'Pilot Mezarlığı: Şirketler AI Projelerini Neden Gömüyor?'),
]


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def published_posts():
    """
    What the Journal has actually published, if we know.

    The publisher writes `blog/posts.json` into the repository every time it
    runs, so that file is the one true list of what is live. Drop a copy next to
    this script as `blog_posts.json` and every page's footer follows it. Without
    one, the four planned titles stand in, which is what they were always for.

    Read from disk rather than fetched: a build that reaches the network fails
    differently on a bad day, and this list changes about once a week.
    """
    path = os.path.join(ROOT, 'blog_posts.json')
    if not os.path.exists(path):
        return None
    try:
        rows = json.load(open(path, encoding='utf-8'))
    except Exception as e:
        print('blog_posts.json could not be read (%s) — the planned titles stand in.' % e)
        return None

    # Newest first, one row per piece. A piece and its translation are the same
    # piece: the footer link is fixed and only the title swaps with the language,
    # exactly as the four planned rows do, so a pair has to collapse into one
    # row carrying both titles. Turkish leads because the Turkish URL is the one
    # the row points at.
    live = [r for r in rows if r.get('slug') and r.get('title')]
    live.sort(key=lambda r: str(r.get('date', '')), reverse=True)
    by_id = {r.get('id'): r for r in live if r.get('id')}

    out, used = [], set()
    for r in live:
        if r.get('id') in used or r['slug'] in used:
            continue
        mate = by_id.get(r.get('pair')) if r.get('pair') else None
        tr = r if r.get('lang') != 'en' else (mate if mate else None)
        en = r if r.get('lang') == 'en' else (mate if mate else None)
        home = tr or en
        # Two addresses, not one. The row used to point at the Turkish page
        # whatever language the reader was in, so an English reader clicking a
        # Journal title in the footer landed on Turkish — the title swapped and
        # the destination did not. The footer's own script swaps [data-href-tr]
        # exactly as it does for About; this gives it something to swap.
        def _href(r, fallback):
            r = r or fallback
            code = 'en' if r.get('lang') == 'en' else 'tr'
            # Absolute, and no query string. `/blog/<slug>/?lang=tr` used to be
            # the Turkish address: an English path with the language bolted on
            # the end, which the CEO called out on 21 August and was right to.
            return '/' + path_of('blog', code) + r['slug'] + '/'
        out.append({
            'href': _href(en, home),          # the English address, and the default
            'href_tr': _href(tr, home),       # the Turkish one
            'en': (en or home)['title'],
            'tr': (tr or home)['title'],
        })
        for x in (r, mate):
            if x:
                used.add(x.get('id'))
                used.add(x['slug'])
        if len(out) == 5:
            break
    return out or None


def seed_footer(up):
    """The footer's reading list: what is published, or what is planned."""
    live = published_posts()
    if live:
        return ''.join(
            '\n        <li><a href="{h}" data-href-tr="{ht}"'
            ' data-en="{en}" data-tr="{tr}">{en}</a></li>'
            .format(h=r['href'], ht=r['href_tr'], en=esc(r['en']), tr=esc(r['tr']))
            for r in live) + '\n      '
    return ''.join(
        '\n        <li><a href="/{b}{s}/" data-en="{en}" data-tr="{tr}">{en}</a></li>'
        .format(b=path_of('blog', 'tr'), s=slug, en=en, tr=tr)
        for slug, en, tr in SEED_POSTS) + '\n      '


def footer(root='', up='', posts=None):
    """
    The shared footer, aimed at wherever it is being put.

    root — the prefix before "#approach": '' on index.html, 'index.html' on
           another root page, '../' one level down.
    up   — the prefix before a root-level file: '' at the root, '../' below it.
    posts — the Journal list. None leaves the token in place, which is what the
           two blog templates need so the publisher can fill it later.
    """
    return (FOOTER
            .replace('__ROOT__', root)
            .replace('__UP__', up)
            .replace('__FOOTER_POSTS__',
                     seed_footer(up) if posts is None else posts))


# One page per service, generated from the shared shell. All four exist as of
# 12 August: Business wrote the Audit in Developer brief §C.2 and the other
# three in `Anthifel_Website_Service_Pages.md` (BUS-033). A page per service is
# the point — a quote or an email links to a page, not to an anchor in a
# catalogue row.
#
# One bilingual page each, not a page per language. Business's file proposes
# /hizmetler/… and /services/…; the CEO settled it on 12 August: the same shape
# as the Audit, which has been live at one address since 9 August. Splitting now
# would move that address for no reader's benefit — the language button already
# does the work, and the blog is the only place where per-language URLs earn
# their keep, because an article body is written once in one language.
#
# The three new bodies are generated by make_services.py from Business's copy.
# Run that first if the copy changes; nothing here edits the words.
# Business's BUS-042 titles and descriptions, 21 August, with Marketing's three
# corrections applied where they overlap.
#
# Four strings per service rather than two. Until today a service page carried
# one title and one description in both languages, on the reasoning that a
# service name is fixed English (Business K34) — true of the name, and it made
# the sentence around it English too. Business wrote a Turkish title and a
# Turkish description for each, so the shell takes four.
#
# Two of these are Marketing's rather than Business's: the Retainer's
# descriptions in both languages. Business's copy said "Doğru insanlar işe
# alınmış" / "The right people hired and connected", which K47 withdrew on
# 3 August. Marketing caught it before it went in.
SERVICES = [
    ('ai-readiness-audit', 'svc_audit.html',
     'AI Readiness Audit · Anthifel',
     'AI Readiness Audit · Yapay zeka hazırlık denetimi',
     'Four working days. Five dimensions, nineteen criteria, scored on evidence '
     'rather than self-assessment. An honest picture of where you stand.',
     'Dört iş gününde, beş boyutta ve on dokuz kriterde kanıta dayalı hazırlık '
     'denetimi. Nerede durduğunuzun dürüst bir fotoğrafı ve önce düzeltilecek üç şey.'),
    ('discovery-sprint', 'svc_sprint.html',
     'Discovery Sprint · Anthifel',
     'Discovery Sprint · Yapay zeka yol haritası',
     'Seven to twelve working days. A roadmap with owners, costs and dates. '
     'Where AI creates value, and where it does not.',
     'Yedi ile on iki iş günü. Sahipleri, maliyetleri ve tarihleri olan bir yol '
     'haritası. Nerede yapay zeka değer yaratır ve nerede yaratmaz.'),
    ('transformation-retainer', 'svc_retainer.html',
     'Transformation Retainer · Anthifel',
     'Transformation Retainer · Sürekli dönüşüm rehberliği',
     'Roles settled, the team connected, and a rhythm that holds. Monthly '
     'guidance, defined access, readiness re-measured at month six and twelve.',
     'İşe alımlar yapılmış, roller birbirine bağlanmış, tutan bir ritim. Aylık '
     'rehberlik, tanımlı erişim, altıncı ve on ikinci ayda yeniden ölçüm.'),
    ('advisory-board-seat', 'svc_advisory.html',
     'Advisory Board Seat · Anthifel',
     'Advisory Board Seat · Danışma kurulu koltuğu',
     'A seat at your table. A few hours a month, and the phone when it matters. '
     'Not sold directly.',
     'Masanızda bir sandalye. Ayda birkaç saat ve önemli anlarda telefon. '
     'Doğrudan satılmaz; kurulmuş bir yapının üstüne gelir.'),
]


# ── the About page's portrait ────────────────────────────────────────────────
# Brand Guidelines §13a-2: square, natural colour, no rounding, no border, no
# shadow, and a backdrop that matches the page rather than sitting on it.
#
# It is inlined like every other image on this site, so the page stays one file
# and loads without a second request. 960px is twice the largest size it is ever
# drawn at, which is what a retina screen needs and no more.
PORTRAIT_NAMES = ('portrait.webp', 'portrait.jpg', 'portrait.jpeg', 'portrait.png')

# Two files with the same stem and different extensions is not worth refusing
# over, but picking by extension order would quietly serve yesterday's picture:
# a PNG left behind after a WebP arrives looks identical in a folder listing and
# nothing on the page says which one was used. Newest wins, and the build prints
# what it took and what it passed over.
SUPERSEDED = []


def newest(names):
    """The most recently written of `names` in assets/, or None if none exist."""
    found = [(os.path.getmtime(os.path.join(ROOT, 'assets', n)), n) for n in names
             if os.path.exists(os.path.join(ROOT, 'assets', n))]
    if not found:
        return None
    found.sort(reverse=True)
    if len(found) > 1:
        SUPERSEDED.append((found[0][1], [n for _, n in found[1:]]))
    return found[0][1]


def portrait():
    """The founder's portrait as a data URI, or None if it has not arrived."""
    name = newest(PORTRAIT_NAMES)
    if name:
        path = os.path.join(ROOT, 'assets', name)
        im = Image.open(path).convert('RGB')
        w, h = im.size
        if w != h:                       # square it from the centre, never stretch
            side = min(w, h)
            im = im.crop(((w - side) // 2, (h - side) // 2,
                          (w + side) // 2, (h + side) // 2))
        if im.width > 960:
            im = im.resize((960, 960), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, 'WEBP', quality=82, method=6)
        data = buf.getvalue()
        if len(data) > 200_000:          # try a little harder before giving up
            buf = io.BytesIO()
            im.save(buf, 'WEBP', quality=70, method=6)
            data = buf.getvalue()
        return 'data:image/webp;base64,' + base64.b64encode(data).decode(), name, len(data)
    return None


# ── the About page's second picture ─────────────────────────────────────────
# The limestone steps, in "What we do". Landscape, so it is not squared the way
# the portrait is — only bounded and re-encoded.
#
# If the file has not arrived, the whole figure is left out rather than drawn as
# an empty box. A missing picture on a page nobody has published yet costs
# nothing; a grey rectangle that looks like a broken image costs the page.
STEPS_NAMES = ('steps.webp', 'steps.jpg', 'steps.jpeg', 'steps.png')


def steps_image():
    """The steps photograph as a data URI, or None if it has not arrived."""
    name = newest(STEPS_NAMES)
    if name:
        path = os.path.join(ROOT, 'assets', name)
        im = Image.open(path).convert('RGB')
        # 1200, not 1400. Measured rather than chosen: the figure is never
        # drawn wider than 1136 CSS pixels at any viewport, so 1200 still covers
        # every size it appears at. It was the heaviest thing on the site — 289 KB
        # of a 930 KB page — and quality alone would not move it: this is a
        # limestone texture, and 80 → 60 buys 80 KB while 1400 → 1200 buys 112.
        if im.width > 1200:
            im = im.resize((1200, round(im.height * 1200 / im.width)), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, 'WEBP', quality=72, method=6)
        data = buf.getvalue()
        if len(data) > 260_000:
            buf = io.BytesIO()
            im.save(buf, 'WEBP', quality=68, method=6)
            data = buf.getvalue()
        return ('data:image/webp;base64,' + base64.b64encode(data).decode(),
                name, len(data), im.width, im.height)
    return None


STEPS_MISSING = []

# The founder's LinkedIn profile, next to his picture on the About page.
# Empty until the URL arrives, and while it is empty the button is not drawn:
# a button that goes nowhere is worse than no button, and a guessed profile URL
# on a page that carries his face is worse than both.
LINKEDIN_URL = 'https://www.linkedin.com/in/eraydengiz/'
LINKEDIN_MISSING = []


def linkedin_button():
    if not LINKEDIN_URL:
        LINKEDIN_MISSING.append('about.html')
        return ''
    # The label says what is on the other side, not which website it is. "LinkedIn"
    # names a platform; a reader deciding whether to click wants to know what they
    # will find. CEO, 19 August.
    return ('<a class="btn btn-s ab-li" href="%s" target="_blank" rel="noopener"\n'
            '             data-en="What has he done before?"\n'
            '             data-tr="Daha önce neler yapmış?">What has he done before?</a>' % LINKEDIN_URL)


def steps_figure():
    """The figure, or nothing at all — see steps_image()."""
    s = steps_image()
    if not s:
        STEPS_MISSING.append('assets/steps.webp')
        return ''
    uri, name, size, w, h = s
    return ('<figure class="ab-steps">\n'
            '            <img src="%s" width="%d" height="%d" loading="lazy"\n'
            '                 data-alt-en="Stone steps, worn by use, climbing in one direction"\n'
            '                 data-alt-tr="Kullanıla kullanıla aşınmış taş basamaklar, tek yönde yükseliyor"\n'
            '                 alt="Stone steps, worn by use, climbing in one direction">\n'
            '          </figure>' % (uri, w, h))


SITE = 'https://anthifel.com/'


# ---- addresses ----------------------------------------------------------
#
# One table, and everything that needs to know where a page lives reads it
# from here: the links inside the chrome, the canonical, the hreflang pair,
# the sitemap, the redirect left behind at the old address, and the tests.
#
# The shape is the CEO's, 21 August: English at the root, Turkish under /tr,
# no file extensions. It replaces two conventions that had been running side
# by side - /about.html next to /meet/ - and it retires `?lang=tr`, which was
# the part that actually misled: it looked like an address for a Turkish page
# and was served, every time, in English.
#
# Slugs follow the mixed rule the CEO chose: a service keeps its English name
# on both sides, because the name of the service *is* English (Business K34);
# everything else gets a Turkish word on the Turkish side.
#
# It reverses the 12 August decision that gave each service one bilingual
# address. That decision was right when it was made - splitting meant keeping
# two copies of every page by hand. trlang.py removed that cost: the Turkish
# document is generated from the same source, so the split now costs nothing
# to maintain and buys the thing the old shape could not give, which is a
# Turkish page that is Turkish before any JavaScript runs.
#
# Trailing slashes are deliberate. `about/index.html` is served at `/about/`;
# whether a host also answers `/about` without the slash is the host's
# business, and nothing we publish depends on it.
PAGES = {
    # key                        English            Turkish
    'home':                     ('',                'tr/'),
    'about':                    ('about/',          'tr/hakkimizda/'),
    'ai-readiness-audit':       ('ai-readiness-audit/',      'tr/ai-readiness-audit/'),
    'discovery-sprint':         ('discovery-sprint/',        'tr/discovery-sprint/'),
    'transformation-retainer':  ('transformation-retainer/', 'tr/transformation-retainer/'),
    'advisory-board-seat':      ('advisory-board-seat/',     'tr/advisory-board-seat/'),
    'privacy':                  ('privacy/',        'tr/gizlilik/'),
    'terms':                    ('terms/',          'tr/sartlar/'),
    'cookies':                  ('cookies/',        'tr/cerezler/'),
    'meet':                     ('meet/',           'tr/gorusme/'),
    'blog':                     ('blog/',           'tr/blog/'),
}


def path_of(key, lang='en'):
    """The page's path below the site root, with its trailing slash."""
    return PAGES[key][1 if lang == 'tr' else 0]


def url_of(key, lang='en'):
    return SITE + path_of(key, lang)


# What used to be at each address, and where that address now points. Every
# one of these is still reachable: an address that has been indexed and handed
# out in mail does not get to disappear because we tidied up.
MOVED = {
    'about.html':                    ('about', 'en'),
    'hakkimizda.html':               ('about', 'tr'),
    'ai-readiness-audit.html':       ('ai-readiness-audit', 'en'),
    'discovery-sprint.html':         ('discovery-sprint', 'en'),
    'transformation-retainer.html':  ('transformation-retainer', 'en'),
    'advisory-board-seat.html':      ('advisory-board-seat', 'en'),
    'privacy.html':                  ('privacy', 'en'),
    'terms.html':                    ('terms', 'en'),
    'cookies.html':                  ('cookies', 'en'),
    'en/blog/':                      ('blog', 'en'),
}


def write_addresses():
    """
    The table, in the other language this repository is written in.

    Sixteen suites had the address of every page spelled out inside them, which
    is how a rename turns into an afternoon of grep. They read this file now,
    so a page moves in one place. It is written on every build and committed,
    because a test that has to run the build first is a test nobody runs.
    """
    open(os.path.join(ROOT, 'addresses.json'), 'w', encoding='utf-8').write(
        json.dumps({
            'pages': {k: {'en': en, 'tr': tr} for k, (en, tr) in PAGES.items()},
            'moved': {old: '/' + path_of(k, lang) for old, (k, lang) in MOVED.items()},
        }, indent=2, sort_keys=True) + '\n')


def service_links_js(lang):
    """The four service addresses in one language, for the result bands."""
    return json.dumps({slug: '/' + path_of(slug, lang) for slug, *_ in SERVICES},
                      sort_keys=True)


def legal_paths_js():
    """The three legal documents' paths, both languages, as a JS array."""
    return json.dumps(['/' + path_of(k, l)
                       for k in ('privacy', 'terms', 'cookies')
                       for l in ('en', 'tr')])


def cookies_selector():
    """Every address the Cookie Policy answers to, as one CSS selector."""
    return json.dumps(', '.join('.ftr a[href="/%s"]' % path_of('cookies', lang)
                                for lang in ('en', 'tr')))


def legal_addresses_js():
    """The three legal documents, at every address they answer to."""
    out = {}
    for key in ('privacy', 'terms', 'cookies'):
        for lang in ('en', 'tr'):
            out['/' + path_of(key, lang)] = key
    return json.dumps(out, sort_keys=True)


def logo_png(width=600):
    """
    The wordmark as a file, not a data URI.

    Every image on this site is inlined, which is right for a page and wrong for
    everything that is not a page: a JSON-LD `logo`, an `og:image`, a search
    result, a share card. All of those need an address a stranger's machine can
    fetch. So the mark is written out once, at the site root, and named by URL
    from the places that cannot take bytes.
    """
    im = Image.open(io.BytesIO(base64.b64decode(LOGO_URI.split(',', 1)[1]))).convert('RGBA')
    if im.width > width:
        im = im.resize((width, max(1, round(im.height * width / im.width))), Image.LANCZOS)
    flat = Image.new('RGB', im.size, (245, 241, 234))
    flat.paste(im, (0, 0), im)
    buf = io.BytesIO()
    flat.save(buf, 'PNG', optimize=True)
    return buf.getvalue()


def share_card():
    """
    The picture a share carries when a piece has no cover of its own.

    LinkedIn and X draw a large card and fill it with whatever og:image names.
    With nothing there they draw a grey rectangle, which is the first thing
    anyone sees of a piece somebody bothered to recommend. This is a card drawn
    on purpose instead: limestone, the wordmark, one terracotta rule. It is
    written into the image folder the articles already use, so the publisher can
    name it without knowing anything about the build.
    """
    W, H = 1600, 900
    card = Image.new('RGB', (W, H), (245, 241, 234))
    mark = Image.open(io.BytesIO(base64.b64decode(LOGO_URI.split(',', 1)[1]))).convert('RGBA')
    w = round(W * 0.42)
    mark = mark.resize((w, max(1, round(mark.height * w / mark.width))), Image.LANCZOS)
    card.paste(mark, ((W - mark.width) // 2, (H - mark.height) // 2 - 18), mark)
    rule = Image.new('RGB', (round(W * 0.06), 2), (184, 76, 46))
    card.paste(rule, ((W - rule.width) // 2, H // 2 + 78))
    buf = io.BytesIO()
    card.save(buf, 'WEBP', quality=88, method=6)
    return buf.getvalue()


# A flat limestone square, used in preview only while the portrait is missing.
# It is deliberately empty rather than a silhouette or an icon: a placeholder
# that looks like a picture is a placeholder that ships.
PORTRAIT_STUB = ('data:image/svg+xml;utf8,'
                 "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E"
                 "%3Crect width='1' height='1' fill='%23EFEAE0'/%3E%3C/svg%3E")


def shell_page(slug, src, title_en, title_tr, desc_en, desc_tr, preview,
               portrait_uri='', lang='en', head_links='', ld='', foot=None):
    """
    The shared page shell: header, language switch, booking band, footer.

    Four service pages and the About page go through it. They differ only in the
    fragment dropped into __MAIN__ and in what their head says, which is the
    point — one shell means a change to the chrome reaches every page, and a
    page cannot quietly grow a different header.

    `title_en` and `title_tr` are the whole title, brand included. The template
    used to append ' · Anthifel' itself, which was invisible until Business sent
    titles that already carried the brand and four pages went out reading
    'AI Readiness Audit · Anthifel · Anthifel'. Appending is also wrong for the
    Turkish rows: 'Transformation Retainer · Sürekli dönüşüm rehberliği' plus a
    suffix is 63 characters, past Business's own 60-character limit. One rule
    now — the title is what the caller wrote.
    """
    tpl = open(os.path.join(ROOT, 'service_template.html'), encoding='utf-8').read()
    tpl = tpl.replace('__HEADER_CSS__', HEADER_CSS)
    main = open(os.path.join(ROOT, src), encoding='utf-8').read().rstrip()
    return (tpl
            # The 404 is served at every wrong address on the site, so it
            # aims its footer at '/' rather than at the page next to it.
            .replace('__FOOTER__', foot if foot is not None else footer('/', '/'))
            .replace('__FOOTER_CSS__', FOOTER_CSS)
            .replace('__NEWS_CSS__', NEWS_CSS)
            .replace('__NEWS_JS__', NEWS_JS)
            .replace('__FORM_LIVE__', 'true' if FORM_LIVE else 'false')
            .replace('__FORM_TEST__', 'true' if preview else 'false')
            # The notice version the consent record points at. One value, read
            # from Legal's own file, stamped into every shell that carries a
            # form — the reading list and the assessment gate both record it.
            .replace('__PRIVACY_VERSION__', PRIVACY_VERSION)
            .replace('__NEWSLETTER__', newsletter())
            .replace('__PRIVACY_PANEL__', privacy_panel(preview=preview))
            .replace('__CONSENT_PANEL__', consent_panel(preview=preview))
            # After __MAIN__, not before: both tokens live inside the About
            # fragment, and a fragment that is not in the string yet cannot
            # have anything replaced in it.
            .replace('__MAIN__', main)
            .replace('__STEPS_FIGURE__', steps_figure())
            .replace('__LINKEDIN_BTN__', linkedin_button())
            .replace('__MEET_PANEL__', MEET_PANEL)
            .replace('__FONTS__', FONTS)
            .replace('__LOGO__', LOGO_URI)
            .replace('__FAVICON__', FAV_URI)
            .replace('__MONOGRAM__', MONO_URI)
            .replace('__PORTRAIT__', portrait_uri)
            .replace('__BANNER__', PREVIEW_BAR if preview else '')
            .replace('__ROBOTS__', '<meta name="robots" content="noindex,nofollow,noarchive">'
                     if preview else '<meta name="robots" content="index,follow">')
            # Preview is noindex, so a canonical there would point a crawler at
            # a page it has been told not to read.
            .replace('__HEAD_LINKS__', '' if preview else head_links)
            .replace('__OG__', og_block(title_en, desc_en,
                                        url_of(slug if slug in PAGES else 'home', 'en')))
            .replace('__LD__', ld or '')
            .replace('__LANG_DEFAULT__', lang)
            .replace('__TITLE_EN__', title_en)
            .replace('__TITLE_TR__', title_tr)
            .replace('__DESC_EN__', desc_en)
            .replace('__DESC_TR__', desc_tr)
            .replace('__SLUG__', slug))


def page_links(key, lang):
    """
    The page's own address, and its counterpart in the other language.

    This is the first time the site can say this and mean it. The old
    hreflang pointed Turkish readers at `?lang=tr`, an address a static host
    answers in English - the switch ran in JavaScript and no crawler runs
    JavaScript. Under /tr the Turkish page is a Turkish document before
    anything executes, so the pair is now a fact rather than a promise.
    """
    return ('<link rel="canonical" href="%s">\n'
            '<link rel="alternate" hreflang="en" href="%s">\n'
            '<link rel="alternate" hreflang="tr" href="%s">\n'
            '<link rel="alternate" hreflang="x-default" href="%s">'
            % (url_of(key, lang), url_of(key, 'en'),
               url_of(key, 'tr'), url_of(key, 'en')))


LANG_RE = re.compile(
    r'<div class="lang">\s*'
    r'<button type="button" data-lang="en"[^>]*>EN</button>\s*'
    r'<span>·</span>\s*'
    r'<button type="button" data-lang="tr"[^>]*>TR</button>\s*'
    r'</div>')


def lang_switch(html, key, lang):
    """
    Two links where two buttons used to be.

    A button that rewrites the page in place was the right control while both
    languages lived at one address. They do not any more, and a control that
    changes what the page says without changing where the page is would put
    the reader on `/about/` reading Turkish - which is the exact confusion
    /tr was chosen to end. Pressing TR now goes to the Turkish page.
    """
    def a(code):
        return ('<a href="%s" data-lang="%s" aria-current="%s">%s</a>'
                % ('/' + path_of(key, code), code,
                   'true' if code == lang else 'false', code.upper()))
    return LANG_RE.sub('<div class="lang">%s<span>·</span>%s</div>'
                       % (a('en'), a('tr')), html)


def emit(outdir, key, lang, html):
    """Write the page at its address, making the directory it needs."""
    rel = path_of(key, lang) + 'index.html'
    dest = os.path.join(outdir, *rel.split('/'))
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    open(dest, 'w', encoding='utf-8').write(html)
    return rel


LINKS_TOKEN = '__PAGE_LINKS__'


def edition(html, key, lang, preview):
    """
    One source, one language, one address.

    The Turkish edition is built, not switched. trlang.py performs the same
    substitution applyLang performs in the browser, so the file on disk is
    Turkish before any script runs - which is the whole reason /tr exists,
    because no crawler runs the script. check-lang.js renders both and holds
    them to each other word for word.
    """
    page = (html
            .replace(LINKS_TOKEN, '' if preview else page_links(key, lang))
            .replace('__SVC_LINKS__', service_links_js(lang)))
    if lang == 'tr':
        page = trlang.to_turkish(page)
    # absolutise first, lang_switch second. The other way round, the Turkish
    # pass rewrites the switch's own English link into a Turkish one and the
    # control points at the page you are already on - which is how it read the
    # first time this was built.
    return lang_switch(absolutise(page, lang), key, lang)


def moved_page(to):
    """
    What is left standing at an address that has moved.

    A 301 is the right answer and it is not ours to write: this is a static
    site on a host that keeps its redirect rules in the platform's own app
    definition, not in the repository. So the address keeps answering, with a
    page that names its successor three ways - canonical for the crawler,
    refresh for the browser, and a sentence for whoever is reading. When the
    ingress rules go in, these files can go.

    They are deliberately not `noindex`. A noindex page cannot pass anything
    on; the canonical is the part doing the work here.
    """
    url = SITE + to.lstrip('/')
    return ('<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            '<title>Moved · Anthifel</title>\n'
            '<link rel="canonical" href="%s">\n'
            '<meta http-equiv="refresh" content="0; url=%s">\n'
            '</head>\n<body style="font:16px/1.6 -apple-system,BlinkMacSystemFont,'
            "'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#F1F0EC;"
            'color:#1A1815;margin:0;padding:64px 20px;text-align:center">\n'
            '<p>This page has moved to <a href="%s" style="color:#B84C2E">%s</a>.</p>\n'
            '<p style="color:#5A554C">Bu sayfa taşındı.</p>\n'
            '</body>\n</html>\n' % (url, url, url, url))


def write_moved(outdir):
    """Every address this build used to answer at, still answering."""
    left = []
    for old, (key, lang) in MOVED.items():
        rel = old + 'index.html' if old.endswith('/') else old
        if not os.path.exists(os.path.join(outdir, *path_of(key, lang).split('/'), 'index.html')):
            continue          # the page itself was withheld; do not point at it
        dest = os.path.join(outdir, *rel.split('/'))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        open(dest, 'w', encoding='utf-8').write(moved_page('/' + path_of(key, lang)))
        left.append(old)
    # The Journal's own addresses, from the same list the footers read. The
    # articles moved with everything else and their old addresses were the ones
    # actually being handed out - they are in the reading-list mail.
    for r in (published_posts() or []):
        for href, old_prefix in ((r['href'], 'en/blog/'), (r['href_tr'], 'blog/')):
            slug = href.rstrip('/').rsplit('/', 1)[-1]
            old = old_prefix + slug + '/'
            if old == href.lstrip('/'):
                continue
            dest = os.path.join(outdir, *(old + 'index.html').split('/'))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            open(dest, 'w', encoding='utf-8').write(moved_page(href))
            left.append(old)
    return left


def service_page(slug, src, title_en, title_tr, desc_en, desc_tr, preview):
    # The service *name* is fixed English on both pages (Business K34); the
    # sentence around it is not, and from 21 August each page carries its own
    # Turkish title and description. The structured data stays English: it is
    # read by machines that index one canonical description per service.
    # The structured-data name is the service, not the tab: 'AI Readiness Audit',
    # not 'AI Readiness Audit · Anthifel'. The brand is already on the
    # Organization node this Service points at through `provider`.
    name = title_en.split(' · ')[0]
    return shell_page(slug, src, title_en, title_tr, desc_en, desc_tr, preview,
                      head_links=LINKS_TOKEN,
                      ld=identity_ld() + '\n'
                         + jsonld(service_ld(slug, name, desc_en)) + '\n'
                         + jsonld(breadcrumb_ld(name, url_of(slug, 'en'))))


# The About page has two addresses and it is not two pages. Guidelines 13a:
# `/about`, and the Turkish page at `/hakkimizda`. One source, both languages in
# both files; what differs is which language the page opens in and which of the
# two calls itself canonical. Two files rather than one with a query string,
# because a Turkish reader should be able to send a Turkish address to someone.
ABOUT_EN = 'about.html'
ABOUT_TR = 'hakkimizda.html'


def about_links(self_name):
    site = 'https://anthifel.com/'
    return ('<link rel="canonical" href="%s%s">\n'
            '<link rel="alternate" hreflang="en" href="%s%s">\n'
            '<link rel="alternate" hreflang="tr" href="%s%s">\n'
            '<link rel="alternate" hreflang="x-default" href="%s%s">'
            % (site, self_name, site, ABOUT_EN, site, ABOUT_TR, site, ABOUT_EN))


LEGAL_NOTE_EN = ('Preview. This page is complete except for the details marked above, which are '
                 "Legal's and are filled at incorporation on 20 August 2026. The build refuses to "
                 'write a public version of this page while any marker remains.')
LEGAL_NOTE_TR = ('Önizleme. Bu sayfa, yukarıda işaretlenen bilgiler dışında tamamlanmıştır; onlar '
                 "Legal'in ve 20 Ağustos 2026'daki tescille doldurulur. İşaretlerden biri bile "
                 'dururken yapı bu sayfanın yayın sürümünü yazmayı reddeder.')


BLOCKED = []
PORTRAIT_MISSING = []
PORTRAIT_BLOCKED = []
MOVED_WRITTEN = []


def legal_pages(preview):
    """privacy.html, terms.html, cookies.html — Legal's copy, Developer's tables."""
    tpl = open(os.path.join(ROOT, 'legal_template.html'), encoding='utf-8').read()
    tpl = tpl.replace('__HEADER_CSS__', HEADER_CSS)
    docs = legal.documents()
    out = {}
    for slug, d in docs.items():
        left = legal.unfilled(d['en'] + d['tr'])
        note = ''
        if left and preview:
            note = ('      <p class="lgnote" data-en="%s" data-tr="%s">%s</p>\n'
                    % (LEGAL_NOTE_EN, LEGAL_NOTE_TR, LEGAL_NOTE_EN))
        html = (tpl
                .replace('__FOOTER__', footer('/', '/'))
                .replace('__FOOTER_CSS__', FOOTER_CSS)
                .replace('__NEWS_CSS__', NEWS_CSS)
                .replace('__NEWS_JS__', NEWS_JS)
            .replace('__FORM_LIVE__', 'true' if FORM_LIVE else 'false')
            .replace('__FORM_TEST__', 'true' if preview else 'false')
            # The notice version the consent record points at. One value, read
            # from Legal's own file, stamped into every shell that carries a
            # form — the reading list and the assessment gate both record it.
            .replace('__PRIVACY_VERSION__', PRIVACY_VERSION)
                .replace('__NEWSLETTER__', newsletter())
                .replace('__PRIVACY_PANEL__', privacy_panel(preview=preview))
                .replace('__CONSENT_PANEL__', consent_panel(preview=preview))
                .replace('__BODY_EN__', d['en'])
                .replace('__BODY_TR__', d['tr'])
                # The brand goes on here rather than in the template. Legal
                # writes "Privacy Policy" and "Gizlilik Politikası"; those are
                # the document's names, not the tab's, and they are Legal's
                # file to write, not Developer's. The template appending it was
                # the same habit that gave four service pages two brands in one
                # title — check-seo now fails on a title tag that does it.
                .replace('__TITLE_EN__', d['title_en'] + ' · Anthifel')
                .replace('__TITLE_TR__', d['title_tr'] + ' · Anthifel')
                .replace('__DESC__', d['desc'])
                # Preview is noindex; a canonical there would aim a crawler at
                # a page robots.txt has already told it not to read.
                .replace('__HEAD_LINKS__', LINKS_TOKEN)
                # The identity, on the legal pages too. §5 says the array reads
                # the same on every page and these three were the ones nobody
                # checked, because nobody thinks of a cookie policy as a place
                # an assistant lands. It is: it is the page that answers "who
                # is this company" for a reader who arrived at the small print.
                .replace('__LD__', identity_ld())
                .replace('__NOTE__', note)
                .replace('__FONTS__', FONTS_STUB)
                .replace('__LOGO__', LOGO_URI)
                .replace('__FAVICON__', FAV_URI)
                .replace('__BANNER__', PREVIEW_BAR if preview else '')
                .replace('__ROBOTS__', '<meta name="robots" content="noindex,nofollow,noarchive">'
                         if preview else '<meta name="robots" content="index,follow">'))
        for k in ('privacy', 'terms', 'cookies'):
            html = html.replace('__CUR_%s__' % k.upper(), ' aria-current="page"' if k == slug else '')
        # Legal's rule, enforced rather than remembered: nothing goes public
        # with a bracket in it. The preview may carry them; production may not,
        # so the page is not written at all rather than written wrong. The rest
        # of the build carries on and the run ends non-zero, which is the only
        # way this gets noticed on a day when nobody is reading the output.
        if left and not preview:
            BLOCKED.append((slug, left))
            continue
        out[slug] = html
    return out


def parts():
    """Header, newsletter and script for the blog pages.

    The footer is not here any more. It was a second copy of the site footer and
    the two had drifted — the blog's had no About link and an empty Journal
    list. There is one footer now, in footer.html, and blog_page aims it.
    """
    src = open(os.path.join(ROOT, 'blog_parts.html'), encoding='utf-8').read()
    def grab(name):
        m = re.search(r'<!-- ==== %s ==== -->(.*?)<!-- ==== /%s ==== -->' % (name, name), src, re.S)
        if not m:
            raise SystemExit('blog_parts.html: missing %s block' % name)
        return m.group(1).strip()
    return {k: grab(k) for k in ('HEADER', 'SCRIPT')}


COMMON = open(os.path.join(ROOT, 'blog_common.css'), encoding='utf-8').read()
COMMON = COMMON.replace('__IMPRINT_CSS__', IMPRINT_CSS)
COMMON = COMMON.replace('__HEADER_CSS__', HEADER_CSS)


def dash_parts():
    """Head, gate, section menu and shell script, shared by every dashboard page."""
    src = open(os.path.join(ROOT, 'dash_parts.html'), encoding='utf-8').read()
    def grab(name):
        m = re.search(r'<!-- ==== %s ==== -->(.*?)<!-- ==== /%s ==== -->' % (name, name), src, re.S)
        if not m:
            raise SystemExit('dash_parts.html: missing %s block' % name)
        return m.group(1).strip()
    return {k: grab(k) for k in ('HEAD', 'GATE', 'TOPBAR', 'SHELL')}


# Each section is a fragment: its own <style>, its markup, and a builder
# registered on window.dashInit. The dashboard is one document, so a fragment
# may not repeat anything the shell already provides.
DASH_SECTIONS = ('OZET', 'CRM', 'BLOG', 'ICERIK', 'SITE', 'SEO', 'ANALITIK', 'FINANS', 'SETTINGS')


def scope_css(css, scope):
    """
    Prefix every selector in a stylesheet with `scope`.

    The blog editor was written as a page of its own and uses names the shell
    also uses — .panel, .btn, .row, .empty. Inside one document those would
    collide, so its rules are confined to its own section at build time rather
    than renamed by hand in a thousand places.
    """
    out, i, n = [], 0, len(css)
    while i < n:
        j = css.find('{', i)
        if j < 0:
            out.append(css[i:]); break
        sel = css[i:j]
        head = sel.strip()
        if head.startswith('@'):
            # at-rule: keep the prelude, scope the body
            k, depth = j, 0
            while k < n:
                if css[k] == '{': depth += 1
                elif css[k] == '}':
                    depth -= 1
                    if depth == 0: break
                k += 1
            inner = css[j + 1:k]
            if head.split()[0] in ('@media', '@supports'):
                inner = scope_css(inner, scope)
            out.append(sel + '{' + inner + '}')
            i = k + 1
            continue
        k = css.find('}', j)
        body = css[j + 1:k if k >= 0 else n]
        # A comment sitting in front of a rule is part of `sel` but not part of
        # the selector. Prefixing it would produce "#cos /* note */ #cos{" and
        # silently kill the rule — which is how a block of custom properties
        # went missing the first time this ran.
        lead = re.match(r'\s*(?:/\*.*?\*/\s*)*', sel, re.S).group(0)
        sel = sel[len(lead):]
        parts = []
        for one in sel.split(','):
            keep = one[:len(one) - len(one.lstrip())]
            bare = one.strip()
            if not bare:
                continue
            parts.append(keep + (bare if bare.startswith(scope) else scope + ' ' + bare))
        out.append(lead + ','.join(parts) + '{' + body + '}')
        i = (k + 1) if k >= 0 else n
    return ''.join(out)


# The content calendar is a `const SEED` inside the İçerik section, written as
# one pipe-delimited row per item. The blog editor needs the blog rows out of
# it — a post's date and title are decided in the plan, not in the editor — and
# the two sections cannot see each other's scope at runtime. So the rows are
# lifted here, at build time, from the same text İçerik renders.
#
# One source: if the plan changes, the next build changes with it. The
# alternative was a second copy of the calendar inside the blog editor, which
# is the shape every drifting part in this project has had.
def blog_plan():
    src = open(os.path.join(ROOT, 'dash_sec_icerik.html'), encoding='utf-8').read()
    m = re.search(r'const SEED=`(.*?)`;', src, re.S)
    if not m:
        raise SystemExit('dash_sec_icerik.html: the content calendar (const SEED) has moved')
    rows = []
    for raw in m.group(1).strip().split('\n'):
        raw = raw.strip()
        if not raw:
            continue
        f = raw.split('|')
        if len(f) < 7 or f[2] != 'blog':
            continue
        note = f[7] if len(f) > 7 else ''
        en = re.search(r'\|\|EN:\s*(\S+)', note)
        note = re.sub(r'\s*\|\|EN:.*', '', note).strip()
        rows.append({'date': f[0], 'pillar': f[4], 'lang': f[5],
                     'title': f[6], 'note': note, 'enDate': en.group(1) if en else ''})
    if not rows:
        raise SystemExit('dash_sec_icerik.html: the calendar holds no blog rows')
    return rows


def dash_section(name, scope=None, preview=True):
    """One fragment, optionally with its stylesheet confined to its section."""
    html = open(os.path.join(ROOT, 'dash_sec_%s.html' % name.lower()), encoding='utf-8').read()
    if scope:
        def fix(m):
            return '<style>\n' + scope_css(m.group(1), scope) + '\n</style>'
        html = re.sub(r'<style>(.*?)</style>', fix, html, flags=re.S)
    if name == 'BLOG':
        html = html.replace('__BLOG_PLAN__', json.dumps(blog_plan(), ensure_ascii=False))
        # DEV-041. The editor's image prefix and the backend's BLOG_PREFIX have
        # to be the same string or a published post shows broken pictures. One
        # of the two is a Script Property and cannot be reached from here, so
        # the least this build can do is stop the other one being typed by hand.
        # 20 August. This read `'/%s/' % PREVIEW_DIR if PREVIEW_DIR else '/'`,
        # and `%` binds tighter than the conditional — so it was always
        # `/preview/`, in both builds, from a module constant that has nothing
        # to do with which build is running. The production panel therefore
        # believed the site lived under /preview/ while the backend wrote at the
        # root, and said so on every load.
        #
        # The warning was right and it is the whole reason DEV-041 exists: an
        # image uploaded from the panel is saved at one address and previewed at
        # another, so the editor shows a broken picture for a file that is
        # perfectly fine on the site. That is the 15 August bug in a different
        # costume — the editor telling you something is missing while the site
        # shows it.
        html = html.replace('__SITE_PREFIX__',
                            '/%s/' % PREVIEW_DIR if preview else '/')
    return html.strip()


SUPABASE_URL = 'https://gjnejpainbkzriwqdaes.supabase.co'
SUPABASE_KEY = 'sb_publishable_XPgThYIe8CS9vpKlodRtFg_jF2wxd5u'

# The Apps Script web app. Deployed 11 August 2026 and stamped in here rather
# than pasted into four source files by hand — index.html, the service page,
# the blog and the dashboard editor all talk to the same endpoint, and four
# copies of one address is three chances to update three of them.
#
# It is not a secret. It is in the page source of every visitor's browser by
# necessity: the form has to post somewhere. What protects it is on the far
# side — the script validates, rate-limits per address and per hour, and never
# returns anything it was not asked for. The two real secrets, the dashboard
# token and anything in Script Properties, are not here and never will be.
#
# Redeploying the script does NOT change this address, as long as the existing
# deployment is edited with 'Version: New version'. A brand new deployment
# gets a new address and this line has to change with it.
APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxuom6kpN6JO5viTNS3mFLziB--lSKFPgfIYGr43Mk700esfA46BhgKuURpu6p2KTkuxw/exec'


def dash_page(preview=True):
    """
    The dashboard is a single document at /dashboard/. Sections are panes in it,
    so the address never changes and the menu never leaves the panel. Heavy
    sections build themselves the first time they are opened.
    """
    p = dash_parts()
    html = open(os.path.join(ROOT, 'dash_app.html'), encoding='utf-8').read()
    for s in DASH_SECTIONS:
        # Only the blog editor needs scoping; the others were written for this shell.
        # Both applications were written as pages and use common class names.
        scope = {'BLOG': '#sec-blog', 'ICERIK': '#cos', 'FINANS': '#fin'}.get(s)
        html = html.replace('__SEC_%s__' % s, dash_section(s, scope, preview))
    html = (html
            .replace('__HEAD__', p['HEAD'])
            .replace('__GATE__', p['GATE'])
            .replace('__TOPBAR__', p['TOPBAR'])
            .replace('__SHELL__', p['SHELL']))
    html = (html
            .replace('__SITE__', '../')      # the dashboard sits one level under the site root
            .replace('__GATE_TITLE__', 'Dashboard')
            .replace('__FONTS__', FONTS_STUB)
            .replace('__LOGO__', LOGO_URI)
            .replace('__FAVICON__', FAV_URI))
    # The Supabase project identifier and its publishable key are not secrets.
    # The key names the project; it grants nothing on its own, because every
    # table has row level security and no policy exists for the anonymous role.
    # Access comes from a signed-in account, and sign-up is disabled. So these
    # two are stamped at build time like any other constant, and the file stays
    # deployable without a paste step. Anthifel_Website.md §24.
    html = (html
            .replace('__SUPABASE_URL__', SUPABASE_URL)
            .replace('__SUPABASE_KEY__', SUPABASE_KEY))
    # `__DASH_TOKEN__` used to be tolerated here and left in the served file for
    # someone to paste into. That was wrong: this page is served from a public
    # address, so a secret written into it is a published secret, gate or no
    # gate. The panel key is typed into the browser now and never reaches the
    # build — which is why it is an error, not an exemption, if it reappears.
    if '__DASH_TOKEN__' in html:
        raise SystemExit('dashboard: __DASH_TOKEN__ is back in the page — the panel key '
                         'is entered in the browser, never stamped into a served file')
    left = sorted(set(re.findall(r'__[A-Z_]+__', html)) - {'__APPS_SCRIPT_URL__'})
    if left:
        raise SystemExit('dashboard: placeholders left: %s' % ', '.join(left))
    return html


REDIRECT = """<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta http-equiv="refresh" content="0; url=%(to)s">
<title>Anthifel Dashboard</title>
</head>
<body>
<!-- %(why)s -->
<p><a href="%(to)s">Anthifel Dashboard</a></p>
<script>location.replace('%(to)s');</script>
</body>
</html>
"""


def redirect(to, why):
    return REDIRECT % {'to': to, 'why': why}


# ---------------------------------------------------------------------------
# The Journal index has two authors, and the only safe answer is that it has
# one.
#
# This script owns the shell — header, footer, stylesheet, the reading list
# band. The publisher, running inside Google and committing straight to GitHub,
# owns what is on it: the featured piece and the grid of cards. Both wrote
# blog/index.html and en/blog/index.html, and whichever wrote last won. The
# first piece went live on 11 August; the 15 August deploy wrote the shell over
# it and the Journal went empty in both languages, with nothing in either file
# wrong on its own.
#
# The first attempt at a fix carried the publisher's blocks across from a copy
# of the deployed page kept beside this script. That copy went stale within the
# hour — the publisher commits to GitHub, this machine never sees it — and a
# build that writes yesterday's cards over today's is worse than one that
# writes none.
#
# So the guard sits where the truth is. deploy.command runs on the machine that
# pulls from GitHub, and immediately after the pull it puts the committed copies
# of these two files back over whatever this build wrote. That machine is the
# only place where the fresh shell and the real published page exist at the same
# moment, and a rule enforced there cannot be forgotten by whoever is packaging
# the build.
#
# The cost is that a change to the shell does not reach the two index pages
# until the next publish, which is one press of Yayınla. Both this build and
# deploy.command say so, out loud, rather than leaving somebody to notice.
JOURNAL_NOTES = []


def blog_page(src_name, preview, *, depth, lang, is_blog_index, footer_posts=None):
    """
    depth = how many levels below the site root the page sits.
      blog/index.html            → 1
      blog/<slug>/index.html     → 2
    Links stay relative so the same output works under /preview/ and at the root.
    """
    up = '../' * depth
    html = open(os.path.join(ROOT, src_name), encoding='utf-8').read()
    p = parts()
    html = (html
            # The reading list's stylesheet, with the Journal's own. It used to
            # be a second copy inside blog_common.css, which is why the band
            # kept its old spacing here after the part changed everywhere else.
            .replace('__COMMON__', COMMON + '\n' + NEWS_CSS)
            .replace('__HEADER__', p['HEADER'])
            .replace('__NEWSLETTER__', newsletter(up))
            .replace('__PRIVACY_PANEL__', privacy_panel(up, preview))
            .replace('__CONSENT_PANEL__', consent_panel(up, preview))
            # The site footer, not a second copy of it. `footer_posts=None`
            # leaves __FOOTER_POSTS__ in place, which is what the two templates
            # need; the pages this build writes get the seeded four.
            .replace('__FOOTER__', footer('/', '/', footer_posts))
            .replace('__SCRIPT__', p['SCRIPT'].replace('__NEWS_JS__', NEWS_JS)
            .replace('__FORM_LIVE__', 'true' if FORM_LIVE else 'false')
            .replace('__FORM_TEST__', 'true' if preview else 'false')
            # The notice version the consent record points at. One value, read
            # from Legal's own file, stamped into every shell that carries a
            # form — the reading list and the assessment gate both record it.
            .replace('__PRIVACY_VERSION__', PRIVACY_VERSION)))
    html = (html
            .replace('__LEGAL_PATHS__', legal_paths_js())
            # '/', not a count of ../. In these templates __ROOT__ only ever
            # precedes the home page and its four anchors, and the home page is
            # at the root from every depth.
            .replace('__ROOT__', '/')
            # Addresses, not steps. These five were counted from the page's own
            # depth, which meant the step between the two Journals was a
            # different string from each side and a template rendered at the
            # wrong depth pointed at nothing. They are read from the table now.
            .replace('__BLOG_EN__', '/' + path_of('blog', 'en'))
            .replace('__BLOG__', '/' + path_of('blog', 'tr'))
            .replace('__PRIVACY__', '/' + path_of('privacy', lang))
            .replace('__TERMS__', '/' + path_of('terms', lang))
            .replace('__COOKIES__', '/' + path_of('cookies', lang))
            .replace('__BLOGCUR__', 'aria-current="page"' if is_blog_index else '')
            # The Journal's two indexes, and the way from each to the other.
            # /blog/ is one level down, /en/blog/ is two, so the step between
            # them is not the same string from both sides.
            .replace('__INDEX_LANG__', lang)
            # The Turkish Journal always carries its language in the address.
            # /blog/ on its own is the canonical page and answers to whatever the
            # reader last chose; /blog/?lang=tr is Turkish, said out loud, and it
            # is the address we hand out. The CEO set the pair on 16 August.
            # The way from each Journal to the other. No query string: /tr/blog/
            # is the Turkish address and says so by being it. Until 21 August
            # this was /blog/?lang=tr - an English path with the language bolted
            # on, served in English to anything that does not run scripts.
            .replace('__OTHER_INDEX__', '/' + path_of('blog', 'tr' if lang == 'en' else 'en'))
            .replace('__FONTS__', FONTS)
            .replace('__LOGO__', LOGO_URI)
            .replace('__MONOGRAM__', MONO_URI)
            .replace('__FAVICON__', FAV_URI)
            # Self-referencing, not shared. One string served both indexes and
            # /en/blog/ was declaring /blog/ its canonical - which asks Google
            # to drop the English Journal from the index in favour of the
            # Turkish one. The hreflang pair below is the same on both pages
            # and should be; the canonical is the page's own address.
            .replace('__HEAD_EXTRA__',
                     PREVIEW_HEAD if preview else blog_prod_head(lang))
            .replace('__BANNER__', PREVIEW_BAR if preview else ''))
    # The chrome's links, from the site root like every other page. The Journal
    # is served at four depths and the templates are filled in by a publisher
    # that cannot see this file; a link that has to be counted from where the
    # page happens to sit is the one thing here that has gone wrong repeatedly.
    return absolutise(html, lang)


def blog_prod_head(lang):
    """The Journal's head, from the same table as every other page."""
    return page_links('blog', lang)


# Shown until the first real post is published, so the page is never blank.


def legal_modal_body(which):
    """
    The consent tick links to the privacy policy. Navigating away to read it
    loses the tick and usually the visitor, so it opens in place instead.

    It used to carry the holding paragraph the old stub page carried. Now that
    privacy.html has Legal's real notice, the modal shows the same notice — the
    same bytes, from the same source — because a consent box that links to a
    summary is a consent box that was not read.
    """
    d = legal.documents()[which]
    return ('<div class="pmpane" data-pane="en">%s</div>\n'
            '<div class="pmpane" data-pane="tr" hidden>%s</div>' % (d['en'], d['tr']))


PANEL_WITHHELD = []


def privacy_panel(up='', preview=True):
    """
    The modal as one block: stylesheet, markup, behaviour.

    It was on index.html and nowhere else, so on every other page a consent tick
    still cost the visitor a page load — the exact thing the modal was built to
    prevent. It goes on every page now, which means it has to arrive whole: the
    reading list already proved that a part which borrows its styles from the
    host page is not a part.

    `up` is the only thing depth changes: where the footer link points.

    In production the panel is withheld while Legal's details are still
    brackets. It carries the privacy notice verbatim, so shipping it would put
    [COMPANY NUMBER] on the front page and on every service page — pages the
    bracket rule never looked at, because until today the notice was only ever
    on privacy.html. The rule is that nothing goes public with a bracket in it,
    and a part that travels has to be held to it wherever it lands.
    """
    docs = legal.documents()
    # The bracket rule, across all three now. The panel carries the notices
    # verbatim, so one unfilled bracket in any of them would put it on the front
    # page and on every service page — pages the bracket rule never looked at,
    # because until 19 August the notices were only ever on their own pages.
    left = legal.unfilled(''.join(docs[w][k] for w in ('privacy', 'terms', 'cookies')
                                  for k in ('en', 'tr')))
    if left and not preview:
        PANEL_WITHHELD.append(left)
        return ''
    return ('<style>\n%s\n</style>\n%s\n<script>\n%s\n</script>'
            % (PMOD_CSS,
               PMOD.replace('__PRIVACY_BODY__', legal_modal_body('privacy'))
                   .replace('__TERMS_BODY__', legal_modal_body('terms'))
                   .replace('__COOKIES_BODY__', legal_modal_body('cookies'))
                   # One "open the full page" link, aimed per document. The
                   # element keeps all three and the script picks; the href it
                   # starts with is the privacy one, so a page with no script
                   # still has a working link.
                   .replace('id="pmFull"',
                            'id="pmFull" data-privacy="%sprivacy.html" '
                            'data-terms="%sterms.html" data-cookies="%scookies.html"'
                            % (up, up, up))
                   .replace('__PRIVACY__', up + 'privacy.html'),
               PMOD_JS.replace('__LEGAL_ADDRESSES__', legal_addresses_js())))


# ── what a machine reads ─────────────────────────────────────────────────────
# Everything below exists for a reader that never sees the page: a crawler, a
# share card, a rich result. The site is inlined and self-contained, which those
# readers cannot use — they need addresses. So the few things they need are
# written out as real files and named absolutely.

def jsonld(obj):
    return ('<script type="application/ld+json">%s</script>'
            % json.dumps(obj, ensure_ascii=False, separators=(',', ':')))


def org_ld():
    """
    Who we are, in the form a search engine stores rather than reads.

    No street address: that is one of Legal's three blanks and an invented one
    would be worse than none. City and country are known and true, and are what
    a local result is built from.
    """
    return {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        '@id': SITE + '#organisation',
        'name': 'Anthifel',
        'url': SITE,
        'logo': SITE + 'logo.png',
        'image': SITE + 'share-card.webp',
        'description': 'AI transformation advisory in London. We work on the part of AI '
                       'that is not technical: the sequence of decisions, the people who '
                       'have to make them, and how an organisation absorbs the result.',
        'email': 'hello@anthifel.com',
        # Exact, because a year is a claim a company can be asked to prove and
        # this one has a date. Set by the CEO on 15 August.
        'foundingDate': '2026-08-20',
        'address': {'@type': 'PostalAddress', 'addressLocality': 'London',
                    'addressCountry': 'GB'},
        # The registered name and number, because Marketing's §7 asks for one
        # spelling of this company across six places and this is one of them.
        # Companies House is the record the other five are checked against.
        'legalName': 'Anthifel Ltd',
        'identifier': {'@type': 'PropertyValue',
                       'propertyID': 'GB-COH', 'value': '17411895'},
        'founder': {'@id': SITE + '#founder'},
        'sameAs': SAME_AS,
        'knowsLanguage': ['en', 'tr'],
    }


# The identity set, in one list, used by every page.
#
# Marketing §6: ship with what exists and add the rest as it arrives — the
# Wikidata QID, Crunchbase and Clutch are three to four weeks out and waiting
# for the full set means shipping none of it. Companies House is here because
# it is the one entry nobody can dispute: it is the register itself.
#
# §5's rule is that this array is identical on every page. It is a constant for
# that reason — a list built per page is a list that drifts per page.
SAME_AS = [
    'https://www.linkedin.com/company/anthifel',
    'https://x.com/anthifel',
    'https://find-and-update.company-information.service.gov.uk/company/17411895',
]


def person_ld():
    """
    The founder, as a node of his own rather than a name inside the company.

    Marketing §5 asks for a Person tied to the organisation with a sameAs to
    LinkedIn. A `founder` written inline is a string; a node with an @id is
    something the other nodes can point at and an assistant can resolve.

    Nothing here that is not on the About page in words. That is §5's rule
    above all the others, and it is the one worth keeping: a claim that only
    exists in the markup is a claim nobody reads and a compliance risk nobody
    needs.
    """
    return {
        '@context': 'https://schema.org',
        '@type': 'Person',
        '@id': SITE + '#founder',
        'name': 'Eray Dengiz',
        'jobTitle': 'Founder',
        'worksFor': {'@id': SITE + '#organisation'},
        # The same constant the About page's button uses. Written out here once
        # and it was already a second copy of the address — the kind that is
        # correct on the day it is typed and wrong the day the other one moves.
        'sameAs': [LINKEDIN_URL.rstrip('/')],
    }


def breadcrumb_ld(name, url):
    """Home → this page. Two levels, because the site has two."""
    return {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        'itemListElement': [
            {'@type': 'ListItem', 'position': 1, 'name': 'Anthifel', 'item': SITE},
            {'@type': 'ListItem', 'position': 2, 'name': name, 'item': url},
        ],
    }


def identity_ld():
    """
    Organization and Person, on every page.

    They were on the front page only. Marketing §5 asks for `sameAs` to read the
    same on every page, and a node that appears on one page out of fourteen does
    not — an assistant that lands on a service page from a search had no way to
    tell whose service it was.

    The WebSite node that used to sit here is gone. Marketing's "do not want"
    list is explicit: nothing beyond the six types in §5, and WebSite is not one
    of them. It described a search box this site does not have.
    """
    return jsonld(org_ld()) + '\n' + jsonld(person_ld())


def service_ld(slug, name, desc):
    """
    One service, as an offer without a price.

    K50 says no price appears on the site, and that holds here too: schema.org
    has an `offers` field and filling it would publish the number in a place
    nobody looks at but everybody can read.
    """
    return {'@context': 'https://schema.org', '@type': 'Service',
            '@id': SITE + slug + '.html#service',
            'name': name, 'description': desc, 'serviceType': 'AI transformation advisory',
            'provider': {'@id': SITE + '#organisation'},
            'areaServed': [{'@type': 'Country', 'name': 'United Kingdom'},
                           {'@type': 'Country', 'name': 'Türkiye'}],
            'availableLanguage': ['en', 'tr'],
            'url': url_of(slug, 'en')}


def og_block(title, desc, url, kind='website'):
    """The tags a share card is built from. Absent on every page but the front
       one and the articles until now, so sharing a service page produced a bare
       link with no picture and no sentence."""
    return '\n'.join([
        '<meta property="og:type" content="%s">' % kind,
        '<meta property="og:site_name" content="Anthifel">',
        '<meta property="og:title" content="%s">' % esc(title),
        '<meta property="og:description" content="%s">' % esc(desc),
        '<meta property="og:url" content="%s">' % url,
        '<meta property="og:image" content="%sshare-card.webp">' % SITE,
        '<meta name="twitter:card" content="summary_large_image">',
        '<meta name="twitter:title" content="%s">' % esc(title),
        '<meta name="twitter:description" content="%s">' % esc(desc),
        '<meta name="twitter:image" content="%sshare-card.webp">' % SITE,
    ])


def sitemap(outdir):
    """
    Every page a stranger may land on, and nothing else.

    The dashboard is not in it, the templates are not in it, and the preview is
    not in it — the preview is disallowed in robots.txt and a sitemap that names
    a disallowed page is a contradiction a crawler reports back to you.
    Published articles come from the same posts.json the footers read, so the
    map grows with the Journal instead of being remembered. They are the one
    exception to the on-disk rule: the publisher writes them straight into the
    repository, so they are live without ever passing through this build.
    """
    # /meet/ was missing until 21 August. It is a real address a stranger can
    # land on — the footer's "Book a call" points at it — and it was left out
    # only because it was built last, which is not a reason.
    # Every page, in both languages, from the one table. The map used to be a
    # hand-written list and it was wrong twice for the same reason: a page was
    # added and nobody came back here. Now a page that exists in PAGES is in
    # the map, and a page that is not written to disk is still left out.
    PRIORITY = {'home': '1.0', 'blog': '0.9', 'about': '0.7', 'meet': '0.6',
                'privacy': '0.3', 'terms': '0.3', 'cookies': '0.3'}

    def written(key, lang):
        rel = path_of(key, lang) + 'index.html'
        return os.path.exists(os.path.join(outdir, *rel.split('/')))

    rows = []
    for key in PAGES:
        for lang in ('en', 'tr'):
            if not written(key, lang):
                continue
            # Both members named on both members: an hreflang set has to be
            # reciprocal or it is ignored, and this is the first time we can
            # write it truthfully, because /tr is a Turkish document and
            # ?lang=tr was not.
            alt = ('\n    <xhtml:link rel="alternate" hreflang="en" href="%s"/>'
                   '\n    <xhtml:link rel="alternate" hreflang="tr" href="%s"/>'
                   '\n    <xhtml:link rel="alternate" hreflang="x-default" href="%s"/>'
                   % (url_of(key, 'en'), url_of(key, 'tr'), url_of(key, 'en')))
            rows.append('  <url>\n    <loc>%s</loc>%s\n    <priority>%s</priority>\n  </url>'
                        % (url_of(key, lang), alt, PRIORITY.get(key, '0.9')))

    seen = set(r.split('<loc>')[1].split('</loc>')[0] for r in rows)
    for r in (published_posts() or []):
        for href in (r['href'], r['href_tr']):
            loc = SITE + href.lstrip('/')
            if loc in seen:
                continue
            seen.add(loc)
            rows.append('  <url>\n    <loc>%s</loc>\n    <priority>0.8</priority>\n  </url>'
                        % loc)

    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n'
            '        xmlns:xhtml="http://www.w3.org/1999/xhtml">\n'
            + '\n'.join(rows) + '\n</urlset>\n')


# 20 August, launch: `/preview/` is gone from the repository, so the line that
# closed it is gone from here. A Disallow for a path that does not exist is not
# harmless — it is a public statement that a staging copy exists, and it is the
# first thing anyone curious reads. `/dashboard/` stays: that one is real.
ROBOTS = """# anthifel.com
#
# The panel is a real address that no crawler has any business in. robots.txt
# asks a crawler not to read it; the pages carry noindex as well, because
# robots.txt is a request and the tag is the instruction. Neither alone is
# enough.
#
# Every AI crawler is welcome, and that is a decision rather than an oversight.
# Marketing, 21 August: no Disallow is written for GPTBot, OAI-SearchBot,
# ChatGPT-User, ClaudeBot, Claude-SearchBot, Claude-User, PerplexityBot,
# Perplexity-User, CCBot, Amazonbot, meta-externalagent, Applebot,
# Applebot-Extended, Google-Extended or Bytespider.
#
# Two of those names are usually misunderstood, so the reasoning is written
# down here rather than remembered. Google-Extended and Applebot-Extended are
# directives, not crawlers: blocking Google-Extended does not reduce visibility
# in AI Overviews, it only withholds the site from Gemini training. And
# Claude-SearchBot and OAI-SearchBot are the search crawlers — blocking either
# removes this company from the answers entirely, which is the opposite of what
# blocking them feels like it does.
#
# check-seo fails if a Disallow ever appears for any of these names.
User-agent: *
Disallow: /dashboard/

Sitemap: {site}sitemap.xml
""".format(site=SITE)


# Every attribute that names a page. `href` is the obvious one; the rest are
# links the browser does not know are links - the privacy modal keeps its three
# destinations in data- attributes and hands them to an anchor when it opens,
# and the language pair rides in data-href-tr. An address rewrite that only
# knows about href leaves those pointing at the old shape, and nothing shows it
# until somebody opens the panel.
LINK_ATTRS = ('href', 'data-href-tr', 'data-privacy', 'data-terms', 'data-cookies')


def absolutise(html, lang='en'):
    """
    Every internal link, written from the site root.

    Relative links made sense while every page sat at the root next to every
    other one. They do not survive /about/ and /tr/hakkimizda/, where the same
    fragment of chrome is one level deep in one place and two in another, and
    the old fix - `__UP__`, counted per page - is a sum somebody has to get
    right every time a page moves. This does it once, from the table.

    Two passes. The first turns the source's relative targets into English
    addresses. The second, only on a Turkish document, swaps each of those for
    its Turkish counterpart, so a reader who arrives in Turkish stays in
    Turkish by following links rather than by carrying a query string.
    """
    # `index.html#approach` and friends carry a fragment, so they are matched
    # as a prefix rather than as a whole value.
    for q in ('"', "'"):
        html = html.replace('href=%sindex.html#' % q, 'href=%s/#' % q)
    en = {
        '__UP__meet/': '/meet/',
        'en/blog/': '/blog/',
        'blog/?lang=tr': '/tr/blog/',
        'index.html': '/',
    }
    for key in PAGES:
        if key in ('home', 'blog', 'meet'):
            continue
        src = 'about.html' if key == 'about' else key + '.html'
        en[src] = '/' + path_of(key, 'en')
        en['__UP__' + src] = '/' + path_of(key, 'en')
    # About was the one page that already had two addresses, so the footer
    # carries the Turkish one by name. It maps to the Turkish page, not to a
    # Turkish-sounding English one.
    for src in ('hakkimizda.html', '__UP__hakkimizda.html'):
        en[src] = '/' + path_of('about', 'tr')
    # Longest first: '__UP__privacy.html' must not be eaten by 'privacy.html'.
    for src in sorted(en, key=len, reverse=True):
        for q in ('"', "'"):
            for attr in LINK_ATTRS:
                html = html.replace('%s=%s%s%s' % (attr, q, src, q),
                                    '%s=%s%s%s' % (attr, q, en[src], q))
    html = html.replace('href="__UP__', 'href="/').replace("href='__UP__", "href='/")
    # The same targets arrive with a prefix already on them: `footer()`
    # substitutes __UP__ itself, and the Journal's templates are rendered at a
    # known depth, so the source can hand us `/privacy.html` or `../privacy.html`
    # or `../../privacy.html`. All four spellings mean one page.
    for src in sorted(en, key=len, reverse=True):
        if src.startswith('__UP__'):
            continue
        for attr in LINK_ATTRS:
            html = re.sub(r'%s="(?:\.\./)*/?%s"' % (attr, re.escape(src)),
                          '%s="%s"' % (attr, en[src]), html)
            html = re.sub(r"%s='(?:\.\./)*/?%s'" % (attr, re.escape(src)),
                          "%s='%s'" % (attr, en[src]), html)
    if lang != 'tr':
        return html
    for key in PAGES:
        a, b = '/' + path_of(key, 'en'), '/' + path_of(key, 'tr')
        if a == b:
            continue
        for q in ('"', "'"):
            for attr in LINK_ATTRS:
                html = html.replace('%s=%s%s%s' % (attr, q, a, q),
                                    '%s=%s%s%s' % (attr, q, b, q))
    # Anything that already knew its Turkish address says so in
    # `data-href-tr`. That attribute used to be read by the switch at run time;
    # on a built Turkish page nothing runs, so it is applied here instead. The
    # Journal entry and the footer's reading list are the two that need it.
    html = re.sub(r'href="[^"]*"(\s+)data-href-tr="([^"]*)"',
                  lambda m: 'href="%s"%sdata-href-tr="%s"' % (m.group(2), m.group(1), m.group(2)),
                  html)
    # The menu's four entries are sections of the home page, so they carry a
    # fragment and no path. On a Turkish page they have to reach the Turkish
    # home page, otherwise the menu is the one thing that drops the reader
    # back into English.
    for q in ('"', "'"):
        html = html.replace('href=%s/#' % q, 'href=%s/tr/#' % q)
    return html


def page_meet(preview):
    """
    /meet/ — the booking call, as a page.

    The band already existed and opens inside whatever page you are on. The CEO
    asked for an address as well, on 20 August, and the reason holds: the footer
    is on every page including the Journal and the three legal pages, and "open
    a band further down this page" is a different promise on each of them. A
    page is the same promise everywhere, and it can be put in an email.

    It is the same band, not a second copy of it — the page carries a marker and
    the band opens itself. A booking page that made you press a button to see
    the calendar would be asking for a click that carries no decision.

    On consent: the notice says Google Calendar loads "once you open the
    window", and arriving here is opening it — the link says Book a call and
    this page is the booking. The band's own line under the frame says so. Legal
    has been told, because whether that reading holds is theirs and not mine.
    """
    # The page says the title once. The band carries its own eyebrow and
    # heading — it has to, because everywhere else it opens inside a page that
    # is about something else — and here that made the same two lines appear
    # twice, forty pixels apart. The page keeps the heading, the band's copy of
    # it is hidden, and the four questions below it stay where they are.
    body = ('<div>\n'
            '  <span class="eyebrow" data-en="Introductory call" data-tr="Tanışma görüşmesi">Introductory call</span>\n'
            '  <h1 data-en="Thirty minutes, free" data-tr="Otuz dakika, ücretsiz">Thirty minutes, free</h1>\n'
            '</div>\n'
            '<span id="meetHere" hidden></span>\n'
            '<style>#meetHere ~ .meet .meetttl,\n'
            '       body:has(#meetHere) .meet .meetttl{display:none}\n'
            '       body:has(#meetHere) .meet .meetx,\n'
            '       body:has(#meetHere) .meet{border-top:0;padding-top:8px}\n'
            '       body:has(#meetHere) .meet .meetx{display:none}</style>\n')
    tmp = os.path.join(ROOT, '.meet-main.html')
    open(tmp, 'w', encoding='utf-8').write(body)
    try:
        page = absolutise(
            shell_page('meet', '.meet-main.html',
                       'Book a call · Anthifel', 'Görüşme planlayın · Anthifel',
                       'A free 30-minute introductory call. Pick a time that suits you.',
                       'Ücretsiz 30 dakikalık tanışma görüşmesi. Size uyan bir saat seçin.',
                       preview,
                       head_links=LINKS_TOKEN,
                       foot=footer(root='/', up='/'),
                       ld=identity_ld() + '\n'
                          + jsonld(breadcrumb_ld('Book a call', url_of('meet', 'en')))))
        # The Close button, removed from the markup rather than hidden by the
        # script that runs on load.
        #
        # Marketing's §4: an assistant stores the first ~200 characters of the
        # body as this page's snippet, and it does not run JavaScript. The word
        # "Close" was landing in that snippet — a button label that no human on
        # this page ever sees, because the script hides it a moment after the
        # page arrives. The band keeps its Close everywhere else; it is a modal
        # there and needs one.
        page = page.replace(
            '<button type="button" class="meetx" id="meetClose" '
            'data-en="Close" data-tr="Kapat">Close</button>', '')
        return page
    finally:
        os.remove(tmp)


def page_404(preview):
    """
    The not-found page, on the site's own shell.

    First written on its own minimal template, which gave it a bare header and a
    copyright line — the reasoning being that a 404 is a dead end and the full
    menu is for a site you are already in. The CEO ruled the other way on
    20 August and he is right about the reader: somebody who mistyped an address
    usually knows where they were going, and a menu is how they get there. A
    dead end with a door in it is not a dead end.

    So it goes through `shell_page`, the same shell as the service pages and
    About — one header, one footer, one place to change them. The alternative
    was a fourth copy of the chrome, which is the thing this project keeps
    paying for.

    Two departures from that shell, both deliberate. Its links are absolute,
    because a 404 is served *at the address that was asked for*: /blog/nope/
    gets this page while the browser still thinks it is two levels down, and a
    relative "index.html" from there points at nothing. And it is noindex — one
    page answering a thousand wrong addresses would otherwise be indexed under
    all of them.
    """
    body = ('<div>\n'
            '  <span class="eyebrow" data-en="Not found" data-tr="Bulunamadı">Not found</span>\n'
            '  <h1 data-en="This page is not here" data-tr="Bu sayfa burada değil">This page is not here</h1>\n'
            '  <p class="lede" data-en="The address may have changed, or it may never have existed. '
            'Nothing is broken on your side — the menu above goes everywhere this site goes." '
            'data-tr="Adres değişmiş olabilir, ya da hiç var olmamış olabilir. Sizin tarafınızda '
            'bozuk bir şey yok — yukarıdaki menü bu sitenin gittiği her yere gidiyor.">'
            'The address may have changed, or it may never have existed. Nothing is broken on '
            'your side — the menu above goes everywhere this site goes.</p>\n'
            '  <p class="lede" data-en="If a link brought you here, we would like to know where it was: '
            '<a href=\'mailto:hello@anthifel.com\'>hello@anthifel.com</a>." '
            'data-tr="Sizi buraya bir bağlantı getirdiyse nerede olduğunu bilmek isteriz: '
            '<a href=\'mailto:hello@anthifel.com\'>hello@anthifel.com</a>.">'
            'If a link brought you here, we would like to know where it was: '
            '<a href="mailto:hello@anthifel.com">hello@anthifel.com</a>.</p>\n'
            '</div>\n')
    tmp = os.path.join(ROOT, '.404-main.html')
    open(tmp, 'w', encoding='utf-8').write(body)
    try:
        html = shell_page('404', '.404-main.html',
                          'This page is not here · Anthifel',
                          'Bu sayfa burada değil · Anthifel',
                          'The address may have changed, or it may never have existed.',
                          'Adres değişmiş olabilir, ya da hiç var olmamış olabilir.',
                          preview,
                          foot=footer(root='/', up='/'))
    finally:
        os.remove(tmp)

    # Absolute, so the page works at whatever depth it is served from.
    return (absolutise(html)
            .replace('<meta name="robots" content="index,follow">',
                     '<meta name="robots" content="noindex,follow">'))


def build(target, outdir):
    preview = target == 'preview'
    write_addresses()
    os.makedirs(outdir, exist_ok=True)

    html = open(os.path.join(ROOT, 'body.html'), encoding='utf-8').read()
    html = html.replace('__IMPRINT_CSS__', IMPRINT_CSS)
    html = html.replace('__HEADER_CSS__', HEADER_CSS)
    html = (html
            # first, because the footer carries __LOGO__ of its own
            # Every page aims its chrome at the site root now, whatever depth
            # it is served from. absolutise() finishes the job.
            .replace('__FOOTER__', footer('/', '/'))
            .replace('__NEWSLETTER__', newsletter())
            .replace('__NEWS_CSS__', NEWS_CSS)
            .replace('__NEWS_JS__', NEWS_JS)
            .replace('__FORM_LIVE__', 'true' if FORM_LIVE else 'false')
            .replace('__FORM_TEST__', 'true' if preview else 'false')
            # The notice version the consent record points at. One value, read
            # from Legal's own file, stamped into every shell that carries a
            # form — the reading list and the assessment gate both record it.
            .replace('__PRIVACY_VERSION__', PRIVACY_VERSION)
            .replace('__FONTS__', FONTS)
            .replace('__LOGO__', LOGO_URI)
            .replace('__MONOGRAM__', MONO_URI)
            .replace('__FAVICON__', FAV_URI)
            # Left as a token on purpose: the two language editions of this page
            # declare different addresses, so the head is stamped per edition
            # a few lines below rather than once here.
            .replace('__HEAD_EXTRA__', PREVIEW_HEAD if preview else LINKS_TOKEN)
            .replace('__LD__', identity_ld())
            # `?form=live` runs the real flow. Stamped false into production, so
            # on the live site the branch is unreachable by any URL.
            .replace('__FORM_TEST__', 'true' if preview else 'false')
            .replace('__PRIVACY_PANEL__', privacy_panel(preview=preview))
            .replace('__CONSENT_PANEL__', consent_panel(preview=preview))
            .replace('__MEET_PANEL__', MEET_PANEL)
            .replace('__BANNER__', PREVIEW_BAR if preview else ''))
    for lang in ('en', 'tr'):
        emit(outdir, 'home', lang, edition(html, 'home', lang, preview))

    for slug, src, t_en, t_tr, d_en, d_tr in SERVICES:
        page = service_page(slug, src, t_en, t_tr, d_en, d_tr, preview)
        for lang in ('en', 'tr'):
            emit(outdir, slug, lang, edition(page, slug, lang, preview))

    # About. One bilingual page, footer only, never in the top menu — §13a.
    # The portrait is the one thing it cannot be honest without, so a missing
    # one is treated the way Legal's missing details are: preview gets a flat
    # limestone square and says so, production refuses to write the page at all.
    pt = portrait()
    if pt:
        portrait_uri, pt_name, pt_bytes = pt
    else:
        portrait_uri, pt_name, pt_bytes = PORTRAIT_STUB, None, 0
        if preview:
            PORTRAIT_MISSING.append('about.html')
        else:
            PORTRAIT_BLOCKED.append('about.html')
    if pt or preview:
        page = shell_page(
            'about', 'about.html',
            'About · Anthifel', 'Hakkımızda · Anthifel',
            'Anthifel is an AI transformation advisory in London. The name comes from '
            'anthropos: human. We work on the part of AI that is not technical.',
            'Anthifel, Londra merkezli bir AI dönüşüm danışmanı şirketidir. Adı Yunanca '
            'anthropos kökünden gelir: insan. İşin teknik olmayan tarafında çalışıyoruz.',
            preview, portrait_uri, head_links=LINKS_TOKEN,
            # The About page is where the founder is described in words, so the
            # Person node here has a page behind it.
            ld=identity_ld() + '\n'
               + jsonld(breadcrumb_ld('About', url_of('about', 'en'))))
        for lang in ('en', 'tr'):
            emit(outdir, 'about', lang, edition(page, 'about', lang, preview))

    # The three legal pages are no longer stubs: their copy is Legal's, read
    # from Legal's own files at build time (legal.py). STUBS is gone with them.
    for slug, page in legal_pages(preview).items():
        for lang in ('en', 'tr'):
            emit(outdir, slug, lang, edition(page, slug, lang, preview))

    # ---- blog ----
    #
    # 21 August: the two indexes changed places. English was at /en/blog/ and
    # Turkish at /blog/ - the site's own language filed under a country code
    # while the Turkish page took the plain address and then carried
    # `?lang=tr` on every article link. The CEO called it what it was. English
    # is now /blog/ and Turkish /tr/blog/, in step with every other page.
    #
    # The articles themselves are the publisher's, not this build's. It writes
    # them straight into the repository, so BlogCode.gs has to be moved in the
    # same round or the indexes will link to pages still at the old addresses.
    tree = PREVIEW_DIR if preview else 'production'
    published = bool(published_posts())
    for lang in ('en', 'tr'):
        rel = path_of('blog', lang) + 'index.html'
        target = os.path.join(outdir, *rel.split('/'))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        page = blog_page('blog_index.html', preview, lang=lang,
                         depth=len(path_of('blog', lang).rstrip('/').split('/')),
                         is_blog_index=True)
        if published:
            JOURNAL_NOTES.append('%s/%s' % (tree, rel))
        # The publisher stamps the index's language on <html>; this does the
        # same, so the two authors of this file agree on every byte they both
        # touch. A page that says its language before any script runs is the
        # one a crawler reads.
        page = re.sub(r'<html lang="[^"]*"', '<html lang="%s"' % lang, page, count=1)
        open(target, 'w', encoding='utf-8').write(page)

    # The files a machine fetches by address. Written into both builds so the
    # preview renders identically, but the map and the rules are production
    # only: a sitemap under /preview/ would name pages robots.txt disallows.
    open(os.path.join(outdir, 'logo.png'), 'wb').write(logo_png())
    open(os.path.join(outdir, 'share-card.webp'), 'wb').write(share_card())
    if not preview:
        open(os.path.join(outdir, 'robots.txt'), 'w', encoding='utf-8').write(ROBOTS)

    # The 404, in our own hand.
    #
    # DigitalOcean is already configured to serve `404.html` and we never wrote
    # one, so a mistyped address got their default: black Times on white, the
    # word 404, and no way back. That page is the first thing some people will
    # ever see of this company — a stale link in an email, a typo, an address
    # from a talk. It says nothing about us and offers nothing to do next.
    #
    # Links are absolute rather than relative, because a 404 is served *at the
    # address that was asked for* — /blog/nope/ gets this page while the browser
    # still thinks it is two levels down, and a relative "index.html" from there
    # points at nothing.
    open(os.path.join(outdir, '404.html'), 'w', encoding='utf-8').write(page_404(preview))

    # /meet/ — a directory so the address has no extension on it.
    meet = page_meet(preview)
    for lang in ('en', 'tr'):
        emit(outdir, 'meet', lang, edition(meet, 'meet', lang, preview))

    # The sitemap is written *here*, after every page exists, and not with
    # robots.txt above.
    #
    # sitemap() names only what it finds on disk, so a page the build declined
    # to publish is never advertised. That guard turns the order of this
    # function into content: the map used to be written before /meet/, and
    # /meet/ was silently absent from it for no reason anybody chose. What was
    # missing was not an entry in a list — the entry was in the list. It was a
    # file that did not exist yet.
    #
    # Anything added below this line is invisible to the map. Add pages above.
    # Below the sitemap on purpose: a page that only forwards has no business
    # in the map. It exists for the links already out in the world.
    if not preview:
        open(os.path.join(outdir, 'sitemap.xml'), 'w', encoding='utf-8').write(sitemap(outdir))
        MOVED_WRITTEN.extend(write_moved(outdir))

    # The share card, next to the covers the publisher writes. It is the same
    # file at the same address in both builds; only the prefix around it moves.
    # The covers and this card stay at /blog/img/ whatever language links to
    # them: they are one set of files, not two, and moving them would have
    # meant rewriting every published article's <img> for no reader's gain.
    blogdir = os.path.join(outdir, 'blog')
    os.makedirs(blogdir, exist_ok=True)
    imgdir = os.path.join(blogdir, 'img')
    os.makedirs(imgdir, exist_ok=True)
    open(os.path.join(imgdir, 'share-default.webp'), 'wb').write(share_card())

    # Templates the publish step fills in. They are served as pages too, but
    # carry noindex so a crawler never sees the unfilled version.
    # Four, not two. The Journal is served at four depths and every one of them
    # needs its own set of prefixes:
    #
    #   blog/index.html              1   English index
    #   tr/blog/index.html           2   Turkish index
    #   blog/<slug>/index.html       2   English article
    #   tr/blog/<slug>/index.html    3   Turkish article
    #
    # 21 August: the languages changed places, so the depths did too. The names
    # still mean what they say - a `-en` file is the English one - but English
    # is now the shallow one, because English is now the plain address.
    #
    # Until 15 August the publisher had two templates and used the Turkish pair
    # for both languages, so every English page pointed its logo, its menu, its
    # footer and its privacy link one level too high. Nothing in the publish
    # step could notice: it writes the file and the file looks fine.
    TEMPLATES = (
        ('_tpl-index-en.html', 'blog_index.html', 1, 'en', True),
        ('_tpl-index.html',    'blog_index.html', 2, 'tr', True),
        ('_tpl-post-en.html',  'blog_post.html',  2, 'en', False),
        ('_tpl-post.html',     'blog_post.html',  3, 'tr', False),
    )
    # Every published Journal page carries the shell it was made from.
    #
    # This build writes the four templates; the publisher, inside Google, writes
    # the pages from them — and only when somebody presses Yayınla. So a deploy
    # that changes the header, the footer or the stylesheet leaves every
    # published article on the old shell, looking exactly like a fix that did
    # not work. It has cost three rounds of "this is still broken" in one day.
    #
    # A short hash of the four templates goes into each of them. The publisher
    # copies it into every page it writes, so a page says which shell it came
    # from, and deploy.command can compare a published page with the current
    # templates and say out loud that the Journal is behind the build.
    rendered = []
    for name, src, depth, lang, is_index in TEMPLATES:
        rendered.append((name, blog_page(src, preview, depth=depth, lang=lang,
                                         is_blog_index=is_index,
                                         footer_posts='__FOOTER_POSTS__')))
    import hashlib
    stamp = hashlib.md5(''.join(h for _n, h in rendered).encode('utf-8')).hexdigest()[:10]
    for name, html in rendered:
        # After <head> so it survives every substitution the publisher makes and
        # sits in a place nothing else writes to.
        html = html.replace('<head>', '<head>\n<!-- journal-shell: %s -->' % stamp, 1)
        open(os.path.join(blogdir, name), 'w', encoding='utf-8').write(html)
    JOURNAL_NOTES.append('shell stamp %s' % stamp)

    # ---- dashboard ----
    # One document, one address. Sections are panes inside it.
    dashroot = os.path.join(outdir, 'dashboard')
    os.makedirs(dashroot, exist_ok=True)
    open(os.path.join(dashroot, 'index.html'), 'w', encoding='utf-8').write(dash_page(preview))
    for old_path, sec in (('crm', 'crm'), ('blog', 'blog')):
        d = os.path.join(dashroot, old_path)
        os.makedirs(d, exist_ok=True)
        open(os.path.join(d, 'index.html'), 'w', encoding='utf-8').write(
            redirect('../#' + sec, 'The dashboard used to have a page per section.'))

    if preview:
        # Belt and braces: the meta tag covers crawlers that fetch the page,
        # this covers the ones that only read robots.txt. Merge by hand if a
        # robots.txt already exists at the repo root — do not overwrite it.
        open(os.path.join(outdir, 'ROBOTS-SNIPPET.txt'), 'w', encoding='utf-8').write(
            'Add this to the repo-root robots.txt (create it if there is none):\n\n'
            'User-agent: *\n'
            'Disallow: /%s/\n' % PREVIEW_DIR
        )

    # The endpoint is stamped last, over the whole tree, because four different
    # files carry it and they are written by four different code paths.
    stamped = 0
    for root, _dirs, names in os.walk(outdir):
        for name in names:
            if not name.endswith('.html'):
                continue
            fp = os.path.join(root, name)
            text = open(fp, encoding='utf-8').read()
            if '__APPS_SCRIPT_URL__' not in text:
                continue
            open(fp, 'w', encoding='utf-8').write(
                text.replace('__APPS_SCRIPT_URL__', APPS_SCRIPT_URL))
            stamped += 1
    html = html.replace('__APPS_SCRIPT_URL__', APPS_SCRIPT_URL)

    left = set(re.findall(r'__[A-Z_]+__', html))
    return outdir, len(html) // 1024, left


if __name__ == '__main__':
    dist = os.path.join(ROOT, 'dist')
    if os.path.isdir(dist):
        shutil.rmtree(dist)

    for target, sub in (('preview', os.path.join('dist', 'preview')),
                        ('production', os.path.join('dist', 'production'))):
        out, kb, left = build(target, os.path.join(ROOT, sub))
        placeholders = ', '.join(sorted(left)) or 'none'
        print('%-11s → %-22s index.html %4d KB   placeholders left: %s'
              % (target, sub + '/', kb, placeholders))

    print('\nPreview deploys to  anthifel.com/%s/' % PREVIEW_DIR)
    print('Production replaces the coming-soon page at the repo root, at launch.')

    if PORTRAIT_MISSING:
        print('\nAbout: no portrait yet, so preview shows a flat limestone square.')
        print('  Drop the file at assets/portrait.webp — square, natural colour, 1600px.')
        print('  It is inlined as WebP at 960px; nothing else has to be prepared.')

    if PORTRAIT_BLOCKED:
        print('\nNOT WRITTEN TO PRODUCTION — the portrait is missing:')
        print('  about.html    assets/portrait.webp')
        print('  A page about the founder that shows an empty square is worse than no page.')

    # These two do not block anything. They are printed because a picture and a
    # button that are simply absent leave no trace on the page, and a gap nobody
    # can see is a gap nobody fills.
    if STEPS_MISSING:
        print('\nAbout: "What we do" has no picture — assets/steps.webp has not arrived.')
        print('  Drop the file in and rebuild; nothing else has to be prepared.')
    if SUPERSEDED:
        print('\nassets/: two files for the same picture. The newest was used.')
        for taken, passed in sorted(set((t, tuple(p)) for t, p in SUPERSEDED)):
            print('  used %-16s  ignored %s' % (taken, ', '.join(passed)))
        print('  Delete the old one when you are sure, so this line stops appearing.')

    # Which list the footers carry. Silent here would mean a stale
    # blog_posts.json could put titles on every page for pieces that are not
    # live, and the only way to notice would be to click one.
    _live = published_posts()
    if _live:
        print('\nFooters list what is published, from blog_posts.json:')
        for r in _live:
            print('  %s' % r['href'])
    else:
        print('\nFooters list the four planned pieces — nothing is published yet.')
        print('  After the first publish, copy blog/posts.json from the repo to')
        print('  blog_posts.json here and rebuild, and every page follows it.')

    # What happened to the two files this script and the publisher both write.
    # Loud on purpose: the failure this replaces was silent, and cost a live
    # Journal for four days.
    if JOURNAL_NOTES:
        print('\nWritten here, but not deployed — the publisher owns these two:')
        for n in JOURNAL_NOTES:
            print('  %s' % n)
        print('  They are built so the suites and the local preview have something to')
        print('  open. deploy.command puts the committed copies back before it pushes,')
        print('  because the cards on them come from the publisher and this machine')
        print('  never sees them. If this build changed the header, the footer or the')
        print('  stylesheet, press Yayınla in the panel afterwards and they catch up.')

    if PANEL_WITHHELD:
        print('\nPRODUCTION HAS NO PRIVACY MODAL — the notice still has brackets in it.')
        print('  ' + ', '.join(sorted(set(x for l in PANEL_WITHHELD for x in l))))
        print('  The modal carries the notice verbatim, so publishing it would put those')
        print('  brackets on every page. The consent links navigate to privacy.html in')
        print('  production until Legal fills them; preview shows the modal as it will be.')

    if LINKEDIN_MISSING:
        print('\nAbout: no LinkedIn button — the profile URL is not set.')
        print('  Put it in LINKEDIN_URL in build.py. Until then the button is not drawn.')

    if BLOCKED:
        print('\nNOT WRITTEN TO PRODUCTION — Legal has not filled these:')
        for slug, left in BLOCKED:
            print('  %-14s %s' % (slug + '.html', ', '.join(left)))
        print('\nThe preview carries them as markers. Nothing goes public with a bracket in it.')

    if BLOCKED or PORTRAIT_BLOCKED:
        sys.exit(2)
