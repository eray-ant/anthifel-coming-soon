"""
The Turkish page, in Turkish — for a reader that does not run JavaScript.

Every translatable node on this site carries the English as its content and the
Turkish in `data-tr`; `applyLang` swaps them in the browser. That is fine for a
person and useless for a crawler, and it produced a page that said
`<html lang="tr">` while its visible words were English. Marketing's §12 rests
on assistants preferring content in the language of the question, and the one
page with a Turkish address was answering in English.

So the swap happens here too, at build time, for pages served at a Turkish
address. The rule is copied from `applyLang` exactly — same attribute, same
three cases — and `check-lang.js` renders both and compares the visible text,
because a second implementation of anything is a fork until something proves it
is not.

Only `data-tr` is moved into place. `data-en` stays on the node, so the language
switch still works in the browser and a visitor can go back to English.
"""
from html.parser import HTMLParser
import html as _html
import re

VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link',
        'meta', 'param', 'source', 'track', 'wbr'}


class _Swap(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.out = []
        self.skip_until = None      # tag name whose children we are discarding
        self.depth = 0

    # ---- helpers ---------------------------------------------------------
    def _attrs(self, attrs):
        s = ''
        for k, v in attrs:
            s += ' ' + k if v is None else ' %s="%s"' % (k, _html.escape(v, quote=True))
        return s

    def _emit(self, text):
        if self.skip_until is None:
            self.out.append(text)

    # ---- tags ------------------------------------------------------------
    def handle_starttag(self, tag, attrs):
        if self.skip_until is not None:
            if tag == self.skip_until and tag not in VOID:
                self.depth += 1
            return
        d = dict(attrs)
        tr = d.get('data-tr')
        if tr is None or 'data-en' not in d:
            self.out.append('<%s%s>' % (tag, self._attrs(attrs)))
            return

        # The three cases applyLang knows about, in the same order.
        if tag == 'title':
            self.out.append('<title%s>%s</title>' % (self._attrs(attrs), _html.escape(tr)))
            self.skip_until, self.depth = tag, 1
            return
        if tag == 'meta':
            attrs = [(k, tr if k == 'content' else v) for k, v in attrs]
            self.out.append('<meta%s>' % self._attrs(attrs))
            return
        # …and the ordinary one: the attribute *is* markup, so it goes in raw.
        self.out.append('<%s%s>%s' % (tag, self._attrs(attrs), _html.unescape(tr)))
        if tag in VOID:
            return
        self.skip_until, self.depth = tag, 1

    def handle_endtag(self, tag):
        if self.skip_until is not None:
            if tag == self.skip_until:
                self.depth -= 1
                if self.depth == 0:
                    self.skip_until = None
                    self.out.append('</%s>' % tag)
            return
        self.out.append('</%s>' % tag)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.skip_until == tag:
            self.skip_until, self.depth = None, 0

    # ---- everything else passes through ---------------------------------
    def handle_data(self, d):      self._emit(d)
    def handle_comment(self, d):   self._emit('<!--%s-->' % d)
    def handle_entityref(self, n): self._emit('&%s;' % n)
    def handle_charref(self, n):   self._emit('&#%s;' % n)
    def handle_decl(self, d):      self.out.append('<!%s>' % d)
    def unknown_decl(self, d):     self.out.append('<![%s]>' % d)
    def handle_pi(self, d):        self.out.append('<?%s>' % d)


def to_turkish(html_text):
    """Return the page as it reads after applyLang('tr'), before any script runs."""
    p = _Swap()
    p.feed(html_text)
    p.close()
    s = ''.join(p.out)
    # Two panes rather than an attribute, for the long legal documents.
    s = re.sub(r'<div([^>]*\bdata-pane="en"[^>]*)>',
               lambda m: '<div%s hidden>' % m.group(1) if 'hidden' not in m.group(1) else m.group(0), s)
    s = re.sub(r'<div([^>]*)\bhidden\b([^>]*\bdata-pane="tr"[^>]*)>', r'<div\1\2>', s)
    # The switch shows which language is current.
    s = s.replace('data-lang="en" aria-current="true"', 'data-lang="en" aria-current="false"')
    s = s.replace('data-lang="tr" aria-current="false"', 'data-lang="tr" aria-current="true"')
    return s
